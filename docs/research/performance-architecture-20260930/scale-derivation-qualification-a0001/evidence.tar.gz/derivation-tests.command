cargo test --locked -p borsuk --example build_sq8_source -- --test-threads=1
