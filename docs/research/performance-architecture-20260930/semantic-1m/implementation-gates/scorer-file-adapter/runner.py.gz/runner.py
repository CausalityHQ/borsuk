import hashlib, json, os, pathlib, signal, subprocess, sys, time

root = pathlib.Path('/home/rb/worktrees/borsuk-semantic-scorer-file-adapter-20261001')
out = pathlib.Path(__file__).parent
os.chdir(root)
sys.path.insert(0, str(root))
from scripts.run_native_semantic_router_cold import native_inventory, encoded

name = sys.argv[1]
commands = {
    'red': ['cargo', 'test', '--locked', '-p', 'borsuk', '--bin', 'check_semantic_router_scorer', 'real_file_source_and_sq8_preserve_production_ranking_and_fail_closed', '--', '--test-threads=1'],
    'green': ['cargo', 'test', '--locked', '-p', 'borsuk', '--bin', 'check_semantic_router_scorer', '--', '--test-threads=1'],
    'release': ['cargo', 'build', '--locked', '--release', '-p', 'borsuk', '--bin', 'check_semantic_router_scorer'],
    'clippy': ['cargo', 'clippy', '--locked', '--workspace', '--all-targets', '--', '-D', 'clippy::correctness', '-D', 'clippy::suspicious'],
    'workspace-test-build': ['bash', 'scripts/check_rust_test_build.sh'],
}
commands['red-a2'] = commands['red']
assert not (out/'STOP').exists(), 'pressure stop forbids launching another gate'
assert not (out/(name+'-receipt.json')).exists(), 'do not overwrite an original gate'
inventory = native_inventory()
owned = 'crates/borsuk/src/bin/check_semantic_router_scorer.rs'
source = dict(base_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              native_source_identity_sha256=hashlib.sha256(encoded(inventory).encode()).hexdigest(),
              native_inventory=inventory,
              scorer_source_sha256=inventory[owned],
              diff_sha256=hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary'])).hexdigest())
(out/(name+'-source.json')).write_text(json.dumps(source, sort_keys=True, indent=2)+'\n')
(out/(name+'-scorer.rs')).write_bytes((root/owned).read_bytes())
cg = pathlib.Path('/sys/fs/cgroup') / pathlib.Path(pathlib.Path('/proc/self/cgroup').read_text().strip().split('::', 1)[1]).relative_to('/')
limits = {key: (cg/key).read_text().strip() for key in ['memory.max', 'memory.swap.max', 'cpu.max', 'pids.max']}
assert limits['memory.max'] == '8589934592' and limits['memory.swap.max'] == '0'
assert limits['cpu.max'].split()[0] == str(2*int(limits['cpu.max'].split()[1]))
assert limits['pids.max'] == '512'
start = time.time_ns()
reason = None
pressure_started = None
memory_peak = swap_peak = 0
command = commands[name]
print(json.dumps(dict(phase='start', name=name, command=command, source=source['native_source_identity_sha256'], cgroup=str(cg), limits=limits)), flush=True)
with (out/(name+'.log')).open('wb') as log, (out/(name+'-resources.jsonl')).open('w') as resources:
    child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (out/'active.json').write_text(json.dumps(dict(name=name, child_pid=child.pid, runner_pid=os.getpid(), cgroup=str(cg)))+'\n')
    while child.poll() is None:
        memory = int((cg/'memory.current').read_text())
        swap = int((cg/'memory.swap.current').read_text())
        memory_peak = max(memory_peak, memory)
        swap_peak = max(swap_peak, swap)
        pressure = pathlib.Path('/proc/pressure/memory').read_text()
        full = float(pressure.split('full avg10=', 1)[1].split()[0])
        available = int(pathlib.Path('/proc/meminfo').read_text().split('MemAvailable:', 1)[1].split()[0])*1024
        stressed = full >= 1
        pressure_started = pressure_started or time.monotonic() if stressed else None
        resources.write(json.dumps(dict(time_ns=time.time_ns(), memory_bytes=memory, swap_bytes=swap, host_full_avg10=full, host_available_bytes=available))+'\n')
        resources.flush()
        if pressure_started is not None and time.monotonic()-pressure_started >= 30:
            reason = 'sustained host pressure'
            (out/'STOP').write_text(reason+'\n')
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
            break
        time.sleep(2)
    status = child.wait()
body = (out/(name+'.log')).read_bytes()
unchanged = inventory == native_inventory()
receipt = dict(name=name, command=command, source=source, status=status, stop_reason=reason,
               source_unchanged=unchanged, start_ns=start, end_ns=time.time_ns(), cgroup=str(cg), limits=limits,
               observed_memory_peak_bytes=memory_peak, observed_swap_peak_bytes=swap_peak,
               log_sha256=hashlib.sha256(body).hexdigest(), log_bytes=len(body),
               environment={k: os.environ.get(k) for k in ['RUSTC_WRAPPER', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'BORSUK_TEST_BUILD_JOBS', 'BORSUK_TEST_BUILD_COMMAND']})
(out/(name+'-receipt.json')).write_text(json.dumps(receipt, sort_keys=True, indent=2)+'\n')
print(json.dumps(dict(phase='terminal', name=name, status=status, stop_reason=reason, source_unchanged=unchanged, log_bytes=len(body))), flush=True)
assert unchanged, 'source changed during gate'
sys.exit(status if status >= 0 else 128-status)
