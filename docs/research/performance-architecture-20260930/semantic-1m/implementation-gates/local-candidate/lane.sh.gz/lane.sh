#!/usr/bin/env bash
export CARGO_BUILD_JOBS=1 BORSUK_TEST_BUILD_JOBS=1 RUST_TEST_THREADS=1 RAYON_NUM_THREADS=2 TOKIO_WORKER_THREADS=2 RUSTC_WRAPPER="" RUSTC_WORKSPACE_WRAPPER="" CARGO_TARGET_DIR=/data/target
export BORSUK_WORKER_LOG=/tmp/borsuk-semantic-1m-worker-20261001
run_check() {
    local check_name="$1"
    shift
    local check_log="$BORSUK_WORKER_LOG/$check_name.log"
    printf "command:" > "$check_log"
    printf " %q" "$@" >> "$check_log"
    printf "\nstarted_utc=%s\n" "$(date -u +%FT%TZ)" >> "$check_log"
    "$@" >> "$check_log" 2>&1
    local check_status=$?
    printf "\nexit_status=%s finished_utc=%s\n" "$check_status" "$(date -u +%FT%TZ)" >> "$check_log"
    printf "%s exit=%s log=%s\n" "$check_name" "$check_status" "$check_log"
    tail -n 35 "$check_log"
    return "$check_status"
}
export -f run_check
export PS1="borsuk-lane> "
printf "lane_started_utc=%s pid=%s\n" "$(date -u +%FT%TZ)" "$$" > "$BORSUK_WORKER_LOG/lane.log"
bash --noprofile --norc -i
lane_status=$?
printf "lane_exit_status=%s finished_utc=%s\n" "$lane_status" "$(date -u +%FT%TZ)" >> "$BORSUK_WORKER_LOG/lane.log"
exit "$lane_status"
