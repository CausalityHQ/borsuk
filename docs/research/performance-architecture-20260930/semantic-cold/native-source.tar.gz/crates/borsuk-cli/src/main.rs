//! BORSUK command-line administration tool.

use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    str::FromStr,
    time::Duration,
};

use borsuk::{
    BorsukError, BorsukIndex, BuildConfig, CompactionOptions, DEFAULT_COMPACTION_MAX_SEGMENTS,
    DEFAULT_ROUTING_PAGE_FANOUT, Fusion, GarbageCollectionOptions, HybridOptions, HybridQuery,
    IncrementalMaintenanceOptions, IndexConfig, LeafCapability, LeafMode, OpenOptions,
    RebuildOptions, RecordId, SearchHit, SearchMode, SearchOptions, VectorMetric, VectorRecord,
    VectorSpec, WalConfig, metadata_from_json, metadata_to_json, vector_records_from_parquet,
};
use clap::{Parser, Subcommand};

/// Replace each serialized hit's tagged `metadata` with its plain-JSON form so
/// the CLI emits user-facing metadata (`{"genre":"rock"}`, not `{"Str":...}`).
/// Hits without returned metadata get a `null` field.
fn rewrite_hit_metadata(hit_values: &mut [serde_json::Value], hits: &[SearchHit]) {
    for (hit_value, hit) in hit_values.iter_mut().zip(hits.iter()) {
        if let Some(object) = hit_value.as_object_mut() {
            let metadata = match &hit.metadata {
                Some(metadata) => metadata_to_json(metadata),
                None => serde_json::Value::Null,
            };
            object.insert("metadata".to_string(), metadata);
        }
    }
}

fn print_search_output(search: &borsuk::SearchReport, report: bool) -> Result<()> {
    if report {
        let mut value = serde_json::to_value(search)?;
        if let Some(hits) = value.get_mut("hits").and_then(|hits| hits.as_array_mut()) {
            rewrite_hit_metadata(hits, &search.hits);
        }
        println!("{}", serde_json::to_string(&value)?);
    } else {
        let mut hits = serde_json::to_value(&search.hits)?;
        if let Some(hits) = hits.as_array_mut() {
            rewrite_hit_metadata(hits, &search.hits);
        }
        println!("{}", serde_json::to_string(&hits)?);
    }
    Ok(())
}

/// User-facing JSON shape for `borsuk add`: metadata is a plain JSON object
/// rather than the engine's internal tagged representation.
#[derive(serde::Deserialize)]
struct JsonRecord {
    id: RecordId,
    #[serde(default)]
    vector: Option<Vec<f32>>,
    #[serde(default)]
    metadata: serde_json::Value,
    #[serde(default)]
    sparse: Option<JsonSparse>,
    #[serde(default)]
    sparse_indices: Option<Vec<u32>>,
    #[serde(default)]
    sparse_values: Option<Vec<f32>>,
    #[serde(default)]
    text: Option<String>,
    #[serde(default)]
    named_vectors: BTreeMap<String, JsonNamedVector>,
}

#[derive(serde::Deserialize)]
struct JsonSparse {
    indices: Vec<u32>,
    values: Vec<f32>,
}

#[derive(serde::Deserialize)]
#[serde(untagged)]
enum JsonNamedVector {
    Dense(Vec<f32>),
    LateInteraction(Vec<Vec<f32>>),
    Sparse(JsonSparse),
}

impl JsonRecord {
    fn into_record(
        self,
        dimensions: usize,
        named_specs: &BTreeMap<String, VectorSpec>,
    ) -> borsuk::Result<VectorRecord> {
        let JsonRecord {
            id,
            vector,
            metadata,
            sparse,
            sparse_indices,
            sparse_values,
            text,
            named_vectors,
        } = self;
        let metadata = metadata_from_json(&metadata)?;
        let sparse = json_sparse_payload(sparse, sparse_indices, sparse_values)?;
        let mut record = match (vector, sparse) {
            (Some(vector), None) => VectorRecord::new(id, vector),
            (None, Some((indices, values))) => {
                VectorRecord::from_sparse(id, indices, values, dimensions)?
            }
            (Some(_), Some(_)) => {
                return Err(BorsukError::InvalidRecordInput(
                    "record cannot specify both `vector` and sparse input".to_string(),
                ));
            }
            (None, None) => {
                return Err(BorsukError::InvalidRecordInput(
                    "record must specify either `vector` or sparse input".to_string(),
                ));
            }
        }
        .with_metadata(metadata);
        if let Some(text) = text {
            record = record.with_text(text);
        }
        for (name, vector) in named_vectors {
            match vector {
                JsonNamedVector::Dense(vector) => {
                    record = record.with_named_vector(name, vector);
                }
                JsonNamedVector::LateInteraction(tokens) => {
                    record = record.with_late_interaction(name, tokens)?;
                }
                JsonNamedVector::Sparse(sparse) => {
                    let spec = named_specs.get(&name).ok_or_else(|| {
                        BorsukError::InvalidRecordInput(format!("unknown named vector `{name}`"))
                    })?;
                    record = match spec.kind {
                        // Sparse-kind keeps the sparse form (inverted index);
                        // dense-kind densifies into the child index.
                        borsuk::VectorKind::Sparse => {
                            record.with_named_sparse_vector(name, sparse.indices, sparse.values)?
                        }
                        borsuk::VectorKind::Dense => record.with_named_sparse(
                            name,
                            sparse.indices,
                            sparse.values,
                            spec.dimensions,
                        )?,
                        borsuk::VectorKind::LateInteraction => {
                            return Err(BorsukError::InvalidRecordInput(format!(
                                "late-interaction named vector `{name}` requires a nested token matrix"
                            )));
                        }
                    };
                }
            }
        }
        Ok(record)
    }
}

fn json_sparse_payload(
    sparse: Option<JsonSparse>,
    sparse_indices: Option<Vec<u32>>,
    sparse_values: Option<Vec<f32>>,
) -> borsuk::Result<Option<(Vec<u32>, Vec<f32>)>> {
    match (sparse, sparse_indices, sparse_values) {
        (Some(sparse), None, None) => Ok(Some((sparse.indices, sparse.values))),
        (None, Some(indices), Some(values)) => Ok(Some((indices, values))),
        (None, None, None) => Ok(None),
        (Some(_), _, _) => Err(BorsukError::InvalidRecordInput(
            "record cannot specify both `sparse` and `sparse_indices`/`sparse_values`".to_string(),
        )),
        (None, Some(_), None) | (None, None, Some(_)) => Err(BorsukError::InvalidRecordInput(
            "`sparse_indices` and `sparse_values` must be provided together".to_string(),
        )),
    }
}

fn main() {
    if let Err(error) = run() {
        eprintln!("{error}");
        std::process::exit(1);
    }
}

fn run() -> Result<()> {
    match Cli::parse().command {
        Commands::Create {
            uri,
            metric,
            vector_element_type,
            dimensions,
            segment_max_vectors,
            routing_page_fanout,
            leaf_capability,
            global_scan_codec,
            global_pq_code_bytes,
            turboquant_bits,
            turboquant_qjl_bits,
            turboquant_shards,
            ram_budget,
            text,
            named_vector,
        } => {
            let ram_budget_bytes = ram_budget
                .as_deref()
                .map(borsuk::parse_ram_budget)
                .transpose()?
                .or(Some(borsuk::DEFAULT_RAM_BUDGET_BYTES));
            let segment_max_vectors = segment_max_vectors
                .unwrap_or_else(|| borsuk::recommended_segment_max_vectors(dimensions));
            let named_vectors = parse_named_vector_specs(&named_vector)?;
            let requires_collection_wal = named_vectors
                .values()
                .any(|spec| spec.kind != borsuk::VectorKind::Sparse);
            let config = IndexConfig {
                uri,
                metric,
                dimensions,
                segment_max_vectors,
                ram_budget_bytes,
                text,
                named_vectors,
            };
            BorsukIndex::create_with_wal_routing_page_fanout_leaf_capability_and_build_config(
                config,
                if requires_collection_wal {
                    WalConfig::default()
                } else {
                    WalConfig::disabled()
                },
                routing_page_fanout.unwrap_or(DEFAULT_ROUTING_PAGE_FANOUT),
                leaf_capability.into(),
                BuildConfig {
                    vector_element_type: vector_element_type.parse()?,
                    global_scan_codec: global_scan_codec.into(),
                    global_pq_code_bytes,
                    global_turboquant_bits: turboquant_bits,
                    global_turboquant_qjl_bits: turboquant_qjl_bits,
                    global_turboquant_shards: turboquant_shards,
                    ..BuildConfig::default()
                },
            )?;
            Ok(())
        }
        Commands::Add {
            uri,
            input,
            input_format,
            resident_routing,
        } => {
            let bytes = fs::read(&input).map_err(|source| CliError::Io {
                path: input.clone(),
                source,
            })?;
            let mut index = open_index(&uri, None, resident_routing, false)?;
            let records = match input_format.resolve(&input) {
                CliInputFormat::Parquet => {
                    vector_records_from_parquet(&bytes, index.manifest().config.dimensions)?
                }
                CliInputFormat::Json => serde_json::from_slice::<Vec<JsonRecord>>(&bytes)?
                    .into_iter()
                    .map(|record| {
                        record.into_record(
                            index.manifest().config.dimensions,
                            &index.manifest().config.named_vectors,
                        )
                    })
                    .collect::<borsuk::Result<Vec<_>>>()?,
                CliInputFormat::Auto => unreachable!("auto input format must be resolved"),
            };
            index.add(records)?;
            Ok(())
        }
        Commands::Upsert {
            uri,
            input,
            input_format,
            resident_routing,
        } => {
            let bytes = fs::read(&input).map_err(|source| CliError::Io {
                path: input.clone(),
                source,
            })?;
            let mut index = open_index(&uri, None, resident_routing, false)?;
            let records = match input_format.resolve(&input) {
                CliInputFormat::Parquet => {
                    vector_records_from_parquet(&bytes, index.manifest().config.dimensions)?
                }
                CliInputFormat::Json => serde_json::from_slice::<Vec<JsonRecord>>(&bytes)?
                    .into_iter()
                    .map(|record| {
                        record.into_record(
                            index.manifest().config.dimensions,
                            &index.manifest().config.named_vectors,
                        )
                    })
                    .collect::<borsuk::Result<Vec<_>>>()?,
                CliInputFormat::Auto => unreachable!("auto input format must be resolved"),
            };
            index.upsert(records)?;
            Ok(())
        }
        Commands::Flush {
            uri,
            resident_routing,
        } => {
            let mut index = open_index(&uri, None, resident_routing, false)?;
            index.flush()?;
            Ok(())
        }
        Commands::Search {
            uri,
            query,
            k,
            mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
            leaf_mode,
            cache_execution,
            filter,
            include_metadata,
            report,
            cache_dir,
            resident_routing,
            preload,
            vector,
        } => {
            let query = serde_json::from_str::<Vec<f32>>(&query)?;
            let max_bytes = max_bytes
                .as_deref()
                .map(|value| borsuk::parse_byte_size(value, "max_bytes"))
                .transpose()?;
            let filter = match filter.as_deref() {
                Some(value) => {
                    let parsed = serde_json::from_str::<serde_json::Value>(value)?;
                    Some(borsuk::Filter::from_json(&parsed)?)
                }
                None => None,
            };
            let index = open_index(&uri, cache_dir, resident_routing, preload)?;
            let options = SearchOptions {
                k,
                mode: match mode {
                    CliSearchMode::Exact => SearchMode::Exact,
                    CliSearchMode::Approx => SearchMode::Approx {
                        leaf_mode: leaf_mode.into(),
                        eps,
                        max_segments,
                        max_bytes,
                        max_latency_ms,
                        routing_page_overfetch,
                        max_candidates_per_segment,
                        adaptive_stop: None,
                        projected_reads: None,
                    },
                },
                filter,
                include_metadata,
                guaranteed_recall: false,
                prefetch_depth: borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH,
                vector_name: vector.unwrap_or_default(),
                disable_coarse_quantizer: false,
                cache_execution: cache_execution.into(),
            };
            let search = index.search_with_report(&query, options)?;
            print_search_output(&search, report)?;
            Ok(())
        }
        Commands::Explain {
            uri,
            query,
            k,
            mode,
            leaf_mode,
            cache_execution,
            filter,
            vector,
            request_price_per_million,
            data_price_per_gib,
            cache_dir,
            resident_routing,
            preload,
        } => {
            let query = serde_json::from_str::<Vec<f32>>(&query)?;
            let filter = match filter.as_deref() {
                Some(value) => {
                    let parsed = serde_json::from_str::<serde_json::Value>(value)?;
                    Some(borsuk::Filter::from_json(&parsed)?)
                }
                None => None,
            };
            let index = open_index(&uri, cache_dir, resident_routing, preload)?;
            let options = SearchOptions {
                k,
                mode: match mode {
                    CliSearchMode::Exact => SearchMode::Exact,
                    CliSearchMode::Approx => SearchMode::Approx {
                        leaf_mode: leaf_mode.into(),
                        eps: None,
                        max_segments: None,
                        max_bytes: None,
                        max_latency_ms: None,
                        routing_page_overfetch: None,
                        max_candidates_per_segment: None,
                        adaptive_stop: None,
                        projected_reads: None,
                    },
                },
                filter,
                include_metadata: false,
                guaranteed_recall: false,
                prefetch_depth: borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH,
                vector_name: vector.unwrap_or_default(),
                disable_coarse_quantizer: false,
                cache_execution: cache_execution.into(),
            };
            let report = index.explain(
                &query,
                options,
                borsuk::QueryCostModel {
                    request_price_per_million,
                    data_price_per_gib,
                },
            )?;
            println!("{}", serde_json::to_string_pretty(&report)?);
            Ok(())
        }
        Commands::SearchSparseNamed {
            uri,
            name,
            indices,
            values,
            k,
            cache_dir,
            resident_routing,
            preload,
        } => {
            let indices = serde_json::from_str::<Vec<u32>>(&indices)?;
            let values = serde_json::from_str::<Vec<f32>>(&values)?;
            let index = open_index(&uri, cache_dir, resident_routing, preload)?;
            let hits = index.search_sparse_named(&name, indices, values, k)?;
            let ids = hits
                .iter()
                .map(|hit| hit.id.to_string())
                .collect::<Vec<_>>();
            println!("{}", serde_json::to_string_pretty(&ids)?);
            Ok(())
        }
        Commands::SearchLateInteraction {
            uri,
            name,
            query,
            k,
            candidates_per_query_token,
            report,
            cache_dir,
            resident_routing,
            preload,
        } => {
            let query = serde_json::from_str::<Vec<Vec<f32>>>(&query)?;
            let index = open_index(&uri, cache_dir, resident_routing, preload)?;
            let options = candidates_per_query_token.map_or_else(
                || borsuk::LateInteractionSearchOptions::exact(k),
                |candidates| borsuk::LateInteractionSearchOptions::bounded(k, candidates),
            );
            let search = index.search_late_interaction_with_report(&name, query, options)?;
            if report {
                let mut value = serde_json::to_value(&search)?;
                if let Some(hits) = value.get_mut("hits").and_then(|hits| hits.as_array_mut()) {
                    rewrite_hit_metadata(hits, &search.hits);
                }
                println!("{}", serde_json::to_string(&value)?);
            } else {
                let mut hits = serde_json::to_value(&search.hits)?;
                if let Some(hit_values) = hits.as_array_mut() {
                    rewrite_hit_metadata(hit_values, &search.hits);
                }
                println!("{}", serde_json::to_string(&hits)?);
            }
            Ok(())
        }
        Commands::SearchText {
            uri,
            text,
            k,
            report,
            cache_dir,
            resident_routing,
            preload,
        } => {
            let index = open_index(&uri, cache_dir, resident_routing, preload)?;
            let search = index.search_text(&text, k)?;
            print_search_output(&search, report)?;
            Ok(())
        }
        Commands::SearchHybrid {
            uri,
            vector,
            sparse_vector,
            text,
            k,
            fusion,
            rrf_k,
            weights,
            report,
            cache_dir,
            resident_routing,
            preload,
        } => {
            let index = open_index(&uri, cache_dir, resident_routing, preload)?;
            let mut query = HybridQuery::new();
            let mut has_query = false;
            for vector in vector {
                let (name, values) = parse_named_vector_query("vector", &vector)?;
                query = query.with_vector(name, values);
                has_query = true;
            }
            for sparse_vector in sparse_vector {
                let (name, indices, values) = parse_sparse_vector_query(&sparse_vector)?;
                let dimensions = dimensions_for_vector_name(
                    &name,
                    index.manifest().config.dimensions,
                    &index.manifest().config.named_vectors,
                )?;
                query = query.with_sparse_vector(name, indices, values, dimensions)?;
                has_query = true;
            }
            if let Some(text) = text {
                query = query.with_text(text);
                has_query = true;
            }
            if !has_query {
                return Err(BorsukError::InvalidSearchOptions(
                    "hybrid query must include at least one of `--vector`, `--sparse-vector`, or `--text`"
                        .to_string(),
                )
                .into());
            }
            let mut options = HybridOptions::new(k);
            options.fusion = match fusion {
                CliFusion::Rrf => Fusion::Rrf { k: rrf_k },
                CliFusion::Weighted => Fusion::Weighted {
                    weights: parse_weights(weights.as_deref())?,
                },
            };
            let search = index.search_hybrid(&query, options)?;
            print_search_output(&search, report)?;
            Ok(())
        }
        Commands::Stats {
            uri,
            resident_routing,
        } => {
            let index = open_index(&uri, None, resident_routing, false)?;
            println!("{}", serde_json::to_string(&index.try_stats()?)?);
            Ok(())
        }
        Commands::Compact {
            uri,
            source_level,
            target_level,
            max_segments,
            all_matching,
            min_segments,
            target_segment_max_vectors,
            target_segment_max_radius,
            cache_dir,
            resident_routing,
        } => {
            let mut index = open_index(&uri, cache_dir, resident_routing, false)?;
            let max_segments = if all_matching {
                None
            } else {
                Some(max_segments.unwrap_or(DEFAULT_COMPACTION_MAX_SEGMENTS))
            };
            let report = index.compact(CompactionOptions {
                source_level,
                target_level,
                max_segments,
                min_segments,
                target_segment_max_vectors,
                target_segment_max_radius,
            })?;
            println!("{}", serde_json::to_string(&report)?);
            Ok(())
        }
        Commands::Rebuild {
            uri,
            source_level,
            target_level,
            min_segments,
            target_segment_max_vectors,
            delete_obsolete,
            cache_dir,
            resident_routing,
        } => {
            let mut index = open_index(&uri, cache_dir, resident_routing, false)?;
            let report = index.rebuild(RebuildOptions {
                source_level,
                target_level,
                min_segments,
                target_segment_max_vectors,
                delete_obsolete,
            })?;
            println!("{}", serde_json::to_string(&report)?);
            Ok(())
        }
        Commands::Gc {
            uri,
            delete,
            min_age_seconds,
            resident_routing,
        } => {
            let mut index = open_index(&uri, None, resident_routing, false)?;
            // Repo-policy anchor for the CLI dry-run flag: GarbageCollectionOptions { dry_run: !delete }.
            let report = index.gc_obsolete_segments(GarbageCollectionOptions {
                dry_run: !delete,
                min_age: Duration::from_secs(min_age_seconds),
            })?;
            println!("{}", serde_json::to_string(&report)?);
            Ok(())
        }
        Commands::Delete {
            uri,
            ids,
            cache_dir,
            resident_routing,
        } => {
            let mut index = open_index(&uri, cache_dir, resident_routing, false)?;
            let report = index.delete(ids)?;
            println!("{}", serde_json::to_string(&report)?);
            Ok(())
        }
        Commands::Purge {
            uri,
            cache_dir,
            resident_routing,
        } => {
            let mut index = open_index(&uri, cache_dir, resident_routing, false)?;
            let report = index.purge_with_report()?;
            println!("{}", serde_json::to_string(&report)?);
            Ok(())
        }
        Commands::Maintain {
            uri,
            max_segment_vectors,
            max_segment_radius,
            min_segment_vectors,
            max_operations,
            cache_dir,
            resident_routing,
        } => {
            let mut index = open_index(&uri, cache_dir, resident_routing, false)?;
            let defaults = IncrementalMaintenanceOptions::default();
            let report = index.run_incremental_maintenance(IncrementalMaintenanceOptions {
                max_segment_vectors: max_segment_vectors.unwrap_or(defaults.max_segment_vectors),
                max_segment_radius,
                min_segment_vectors: min_segment_vectors.unwrap_or(defaults.min_segment_vectors),
                max_operations: max_operations.unwrap_or(defaults.max_operations),
            })?;
            println!("{}", serde_json::to_string(&report)?);
            Ok(())
        }
    }
}

fn open_index(
    uri: &str,
    cache_dir: Option<PathBuf>,
    resident_routing: bool,
    preload: bool,
) -> Result<BorsukIndex> {
    Ok(BorsukIndex::open_with_options(
        uri,
        OpenOptions {
            cache_dir,
            resident_routing,
            preload,
            ..OpenOptions::default()
        },
    )?)
}

#[derive(Debug, Parser)]
#[command(
    name = "borsuk",
    version,
    about = "BORSUK local/blob similarity search"
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Debug, Subcommand)]
enum Commands {
    /// Create a BORSUK index.
    Create {
        /// Index URI. Plain paths, `file://...`, `s3://...`, `gs://...`, and `az://...` are supported.
        #[arg(long)]
        uri: String,
        /// Fixed metric for the physical index.
        #[arg(long, value_parser = parse_metric)]
        metric: VectorMetric,
        /// Dense vector dimensionality.
        #[arg(long)]
        dimensions: usize,
        /// Physical vector scalar type: float32, float16, bfloat16,
        /// float8-e4m3fn (alias: fp8), float8-e5m2, int8, or binary.
        #[arg(long, default_value = "float32")]
        vector_element_type: String,
        /// Maximum vectors per immutable segment.
        #[arg(long)]
        segment_max_vectors: Option<usize>,
        /// Routing page fanout used to compute the persisted hierarchy depth.
        #[arg(long)]
        routing_page_fanout: Option<usize>,
        /// Leaf structures persisted at build time. Production is graph-free.
        #[arg(long, value_enum, default_value = "pq-scan-only")]
        leaf_capability: CliLeafCapability,
        /// Persisted global scan codec used for approximate storage search.
        #[arg(long, value_enum, default_value = "srht-pq-scan")]
        global_scan_codec: CliGlobalScanCodec,
        /// Fixed learned-PQ bytes per vector; omitted selects the adaptive width.
        #[arg(long)]
        global_pq_code_bytes: Option<usize>,
        /// Packed coordinate bits for TurboQuant scan codecs; zero selects the codec default.
        #[arg(long, default_value_t = BuildConfig::default().global_turboquant_bits)]
        turboquant_bits: u8,
        /// Legacy experimental QJL residual direction count.
        #[arg(long, default_value_t = 0)]
        turboquant_qjl_bits: u32,
        /// Independent SRHT shards for fast-turboquant-mse-scan.
        #[arg(long, default_value_t = 1)]
        turboquant_shards: u32,
        /// Optional resident metadata RAM budget, for example `512MB` or `2GiB`.
        #[arg(long)]
        ram_budget: Option<String>,
        /// Enable text payloads and BM25 search for this index.
        #[arg(long)]
        text: bool,
        /// Declare a named vector as NAME:DIMS:METRIC. Repeat for multiple named vectors.
        #[arg(long = "named-vector")]
        named_vector: Vec<String>,
    },
    /// Add records from a binary Parquet table or JSON fixture file.
    Add {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Input containing records with ids and vectors.
        #[arg(long)]
        input: PathBuf,
        /// Input file format. `auto` treats `.parquet` and `.parq` as Parquet, otherwise JSON.
        #[arg(long, value_enum, default_value = "auto")]
        input_format: CliInputFormat,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Insert or replace records by id (MVCC upsert) from a Parquet or JSON file.
    Upsert {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Input containing records with ids and vectors.
        #[arg(long)]
        input: PathBuf,
        /// Input file format. `auto` treats `.parquet` and `.parq` as Parquet, otherwise JSON.
        #[arg(long, value_enum, default_value = "auto")]
        input_format: CliInputFormat,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Materialize the positioned mutation tail into immutable search segments.
    Flush {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Keep routing summaries resident while materializing.
        #[arg(long)]
        resident_routing: bool,
    },
    /// Search an index and write JSON hits to stdout.
    Search {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Query vector as a JSON array.
        #[arg(long)]
        query: String,
        /// Number of hits to return.
        #[arg(long, default_value_t = 10)]
        k: usize,
        /// Search mode.
        #[arg(long, default_value = "exact")]
        mode: CliSearchMode,
        /// Approximate epsilon.
        #[arg(long)]
        eps: Option<f32>,
        /// Approximate segment budget.
        #[arg(long)]
        max_segments: Option<usize>,
        /// Approximate segment payload byte budget.
        #[arg(long)]
        max_bytes: Option<String>,
        /// Approximate latency budget in milliseconds.
        #[arg(long)]
        max_latency_ms: Option<u64>,
        /// Approximate routing metadata page overfetch multiplier.
        #[arg(long)]
        routing_page_overfetch: Option<usize>,
        /// Approximate exact-scored candidate budget per fetched segment.
        #[arg(long)]
        max_candidates_per_segment: Option<usize>,
        /// Segment-local leaf engine for approximate candidate generation.
        #[arg(long, default_value = "srht-pq-scan")]
        leaf_mode: CliLeafMode,
        /// Cache execution policy; graph falls back to scan unless a complete
        /// local graph snapshot exists, while auto uses qualified defaults.
        #[arg(long, value_enum, default_value = "scan")]
        cache_execution: CliCacheExecution,
        /// Metadata filter as a Pinecone-style JSON object, for example
        /// `{"genre":"rock","year":{"$gte":1990}}`. Records whose metadata does
        /// not match are never returned.
        #[arg(long)]
        filter: Option<String>,
        /// Include each hit's stored metadata in the JSON output.
        #[arg(long)]
        include_metadata: bool,
        /// Named vector to search; omitted searches the primary vector.
        #[arg(long)]
        vector: Option<String>,
        /// Emit a full SearchReport JSON object instead of only hit rows.
        #[arg(long)]
        report: bool,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
        /// Eagerly load every active segment into RAM before searching.
        #[arg(long)]
        preload: bool,
    },
    /// Run a query and print its plan and estimated object-storage cost as JSON.
    Explain {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Query vector as a JSON array.
        #[arg(long)]
        query: String,
        /// Number of hits to return.
        #[arg(long, default_value_t = 10)]
        k: usize,
        /// Search mode.
        #[arg(long, default_value = "exact")]
        mode: CliSearchMode,
        /// Segment-local leaf engine for approximate candidate generation.
        #[arg(long, default_value = "srht-pq-scan")]
        leaf_mode: CliLeafMode,
        /// Cache execution policy.
        #[arg(long, value_enum, default_value = "scan")]
        cache_execution: CliCacheExecution,
        /// Metadata filter as a Pinecone-style JSON object.
        #[arg(long)]
        filter: Option<String>,
        /// Named vector to search; omitted searches the primary vector.
        #[arg(long)]
        vector: Option<String>,
        /// USD per 1,000,000 GET/HEAD requests (default: AWS S3 Standard).
        #[arg(long, default_value_t = 0.40)]
        request_price_per_million: f64,
        /// USD per GiB of payload read (default: 0, same-region).
        #[arg(long, default_value_t = 0.0)]
        data_price_per_gib: f64,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM.
        #[arg(long)]
        resident_routing: bool,
        /// Eagerly load every active segment into RAM before explaining.
        #[arg(long)]
        preload: bool,
    },
    /// Search a sparse (inverted-index) named vector; prints hit ids as JSON.
    SearchSparseNamed {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Sparse named vector name.
        #[arg(long)]
        name: String,
        /// Sparse query indices as a JSON array, e.g. `[5,7]`.
        #[arg(long)]
        indices: String,
        /// Sparse query values as a JSON array, e.g. `[1.0,2.0]`.
        #[arg(long)]
        values: String,
        /// Number of hits to return.
        #[arg(long, default_value_t = 10)]
        k: usize,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM.
        #[arg(long)]
        resident_routing: bool,
        /// Eagerly load every active segment into RAM before searching.
        #[arg(long)]
        preload: bool,
    },
    /// Search a late-interaction named field and exact-MaxSim rerank entities.
    SearchLateInteraction {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Late-interaction named vector.
        #[arg(long)]
        name: String,
        /// Query token matrix as a nested JSON array.
        #[arg(long)]
        query: String,
        /// Number of entity hits to return.
        #[arg(long, default_value_t = 10)]
        k: usize,
        /// Optional token-ANN frontier per query token; omitted performs the exact reference scan.
        #[arg(long)]
        candidates_per_query_token: Option<usize>,
        /// Emit the complete candidate/timing/I/O report instead of only hits.
        #[arg(long)]
        report: bool,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM.
        #[arg(long)]
        resident_routing: bool,
        /// Eagerly load every active segment before searching.
        #[arg(long)]
        preload: bool,
    },
    /// Search an index by BM25 text query and write JSON hits to stdout.
    SearchText {
        /// Existing index URI.
        #[arg(long, alias = "index")]
        uri: String,
        /// Text query.
        #[arg(long)]
        text: String,
        /// Number of hits to return.
        #[arg(long, default_value_t = 10)]
        k: usize,
        /// Emit a full SearchReport JSON object instead of only hit rows.
        #[arg(long)]
        report: bool,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
        /// Eagerly load every active segment into RAM before searching.
        #[arg(long)]
        preload: bool,
    },
    /// Search an index by vector and/or text query fusion.
    SearchHybrid {
        /// Existing index URI.
        #[arg(long, alias = "index")]
        uri: String,
        /// Dense query vector as NAME:csv; use an empty NAME (`:csv`) for the primary vector.
        #[arg(long = "vector")]
        vector: Vec<String>,
        /// Sparse query vector as NAME:idxcsv:valcsv; use an empty NAME for the primary vector.
        #[arg(long = "sparse-vector")]
        sparse_vector: Vec<String>,
        /// Text query.
        #[arg(long)]
        text: Option<String>,
        /// Number of hits to return.
        #[arg(long, default_value_t = 10)]
        k: usize,
        /// Fusion strategy.
        #[arg(long, default_value = "rrf")]
        fusion: CliFusion,
        /// Reciprocal-rank-fusion rank constant.
        #[arg(long, default_value_t = 60)]
        rrf_k: usize,
        /// Weighted fusion weights as NAME=w,NAME=w. Use `@text` for text and an empty NAME for primary.
        #[arg(long)]
        weights: Option<String>,
        /// Emit a full SearchReport JSON object instead of only hit rows.
        #[arg(long)]
        report: bool,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
        /// Eagerly load every active segment into RAM before searching.
        #[arg(long)]
        preload: bool,
    },
    /// Print manifest-derived index statistics as JSON.
    Stats {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Compact immutable segments out-of-place and publish a new manifest.
    Compact {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Source LSM level to compact from.
        #[arg(long, default_value_t = 0)]
        source_level: u8,
        /// Target LSM level to compact into.
        #[arg(long, default_value_t = 1)]
        target_level: u8,
        /// Maximum number of source segments to compact.
        #[arg(long)]
        max_segments: Option<usize>,
        /// Compact all matching source segments instead of the bounded default batch.
        #[arg(long, conflicts_with = "max_segments")]
        all_matching: bool,
        /// Minimum matching source segments required before compaction runs.
        #[arg(long, default_value_t = 2)]
        min_segments: usize,
        /// Maximum vectors per compacted output segment.
        #[arg(long)]
        target_segment_max_vectors: Option<usize>,
        /// Optional maximum bubble radius per compacted output segment. Splits a
        /// spread-out cluster into tight, small-radius segments that prune better.
        #[arg(long)]
        target_segment_max_radius: Option<f32>,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Rebuild a full source level and report or delete obsolete objects.
    Rebuild {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Source LSM level to rebuild from.
        #[arg(long, default_value_t = 0)]
        source_level: u8,
        /// Target LSM level to rebuild into.
        #[arg(long, default_value_t = 1)]
        target_level: u8,
        /// Minimum matching source segments required before rebuild compaction runs.
        #[arg(long, default_value_t = 1)]
        min_segments: usize,
        /// Maximum vectors per rebuilt output segment.
        #[arg(long)]
        target_segment_max_vectors: Option<usize>,
        /// Delete obsolete segment and graph objects after publishing the rebuilt manifest.
        #[arg(long)]
        delete_obsolete: bool,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Garbage collect inactive segment objects that are not referenced by the active manifest.
    Gc {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Actually delete obsolete objects. Without this flag, GC only reports candidates.
        #[arg(long)]
        delete: bool,
        /// Minimum age in seconds before an obsolete object can be reported or deleted.
        #[arg(long, default_value_t = 86_400)]
        min_age_seconds: u64,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Logically delete records by id. Deletes are hidden from search immediately;
    /// storage is reclaimed later by compaction or `purge`.
    Delete {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Record id to delete. Repeat `--id` to delete several ids in one call.
        #[arg(long = "id", required = true)]
        ids: Vec<String>,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Physically remove every deleted record and clear the tombstone, reclaiming
    /// storage synchronously and re-enabling those ids for `add`.
    Purge {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
    /// Run one incremental-maintenance pass: split oversized bubbles and merge
    /// sparse ones locally, touching only the affected segments.
    Maintain {
        /// Existing index URI.
        #[arg(long)]
        uri: String,
        /// Split a segment holding more than this many vectors.
        #[arg(long)]
        max_segment_vectors: Option<usize>,
        /// Also split a segment whose bubble radius exceeds this.
        #[arg(long)]
        max_segment_radius: Option<f32>,
        /// Merge a segment whose live vector count falls below this.
        #[arg(long)]
        min_segment_vectors: Option<usize>,
        /// Maximum split/merge operations to apply in this pass.
        #[arg(long)]
        max_operations: Option<usize>,
        /// Optional local read-through cache directory for fetched objects.
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        /// Keep routing summaries resident in RAM for lower latency on small, hot
        /// indexes. Default is paged routing (minimal RAM).
        #[arg(long)]
        resident_routing: bool,
    },
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliSearchMode {
    Exact,
    Approx,
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliLeafMode {
    FlatScan,
    SqScan,
    PqScan,
    SrhtPqScan,
    #[value(name = "fast-turboquant-mse-scan")]
    FastTurboQuantMseScan,
    #[value(name = "fast-turboquant-scan")]
    FastTurboQuantScan,
    Graph,
    VamanaPq,
    Hybrid,
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliCacheExecution {
    Scan,
    Graph,
    Auto,
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliGlobalScanCodec {
    #[value(name = "pq-scan")]
    Pq,
    #[value(name = "srht-pq-scan")]
    SrhtPq,
    #[value(name = "fast-turboquant-mse-scan")]
    FastTurboQuantMse,
    #[value(name = "fast-turboquant-scan")]
    FastTurboQuant,
}

impl From<CliGlobalScanCodec> for borsuk::GlobalScanCodec {
    fn from(codec: CliGlobalScanCodec) -> Self {
        match codec {
            CliGlobalScanCodec::Pq => Self::Pq,
            CliGlobalScanCodec::SrhtPq => Self::SrhtPq,
            CliGlobalScanCodec::FastTurboQuantMse => Self::FastTurboQuantMse,
            CliGlobalScanCodec::FastTurboQuant => Self::FastTurboQuantProd,
        }
    }
}

impl From<CliCacheExecution> for borsuk::CacheExecutionPolicy {
    fn from(policy: CliCacheExecution) -> Self {
        match policy {
            CliCacheExecution::Scan => Self::Scan,
            CliCacheExecution::Graph => Self::Graph,
            CliCacheExecution::Auto => Self::Auto,
        }
    }
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliLeafCapability {
    PqScanOnly,
    GraphEnabled,
}

impl From<CliLeafCapability> for LeafCapability {
    fn from(capability: CliLeafCapability) -> Self {
        match capability {
            CliLeafCapability::PqScanOnly => Self::PqScanOnly,
            CliLeafCapability::GraphEnabled => Self::GraphEnabled,
        }
    }
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliFusion {
    Rrf,
    Weighted,
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum CliInputFormat {
    Auto,
    Parquet,
    Json,
}

impl CliInputFormat {
    fn resolve(self, input: &Path) -> Self {
        match self {
            Self::Auto => match input.extension().and_then(|extension| extension.to_str()) {
                Some(extension) if extension.eq_ignore_ascii_case("parquet") => Self::Parquet,
                Some(extension) if extension.eq_ignore_ascii_case("parq") => Self::Parquet,
                _ => Self::Json,
            },
            format => format,
        }
    }
}

impl From<CliLeafMode> for LeafMode {
    fn from(mode: CliLeafMode) -> Self {
        match mode {
            CliLeafMode::FlatScan => Self::FlatScan,
            CliLeafMode::SqScan => Self::SqScan,
            CliLeafMode::PqScan => Self::PqScan,
            CliLeafMode::SrhtPqScan => Self::SrhtPqScan,
            CliLeafMode::FastTurboQuantMseScan => Self::FastTurboQuantMseScan,
            CliLeafMode::FastTurboQuantScan => Self::FastTurboQuantProdScan,
            CliLeafMode::Graph => Self::Graph,
            CliLeafMode::VamanaPq => Self::VamanaPq,
            CliLeafMode::Hybrid => Self::Hybrid,
        }
    }
}

#[derive(Debug, thiserror::Error)]
enum CliError {
    #[error(transparent)]
    Borsuk(#[from] borsuk::BorsukError),

    #[error("I/O error at `{path}`: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    #[error(transparent)]
    Json(#[from] serde_json::Error),
}

type Result<T> = std::result::Result<T, CliError>;

fn parse_metric(value: &str) -> std::result::Result<VectorMetric, String> {
    VectorMetric::from_str(value).map_err(|error| error.to_string())
}

fn parse_named_vector_specs(values: &[String]) -> Result<BTreeMap<String, VectorSpec>> {
    let mut specs = BTreeMap::new();
    for value in values {
        let parts: Vec<&str> = value.splitn(5, ':').collect();
        if parts.len() < 3 {
            return Err(BorsukError::InvalidSearchOptions(format!(
                "`--named-vector` must be NAME:DIMS:METRIC[:KIND[:TYPE]], got `{value}`"
            ))
            .into());
        }
        let name = parts[0].trim();
        if name.is_empty() {
            return Err(BorsukError::InvalidSearchOptions(
                "`--named-vector` NAME must not be empty".to_string(),
            )
            .into());
        }
        let dimensions = parts[1].trim().parse::<usize>().map_err(|error| {
            BorsukError::InvalidSearchOptions(format!(
                "`--named-vector` dimensions in `{value}` are invalid: {error}"
            ))
        })?;
        let metric = VectorMetric::from_str(parts[2].trim()).map_err(|error| {
            BorsukError::InvalidSearchOptions(format!(
                "`--named-vector` metric in `{value}` is invalid: {error}"
            ))
        })?;
        let kind = match parts.get(3).map(|kind| kind.trim()) {
            None | Some("") | Some("dense") => borsuk::VectorKind::Dense,
            Some("sparse") => borsuk::VectorKind::Sparse,
            Some("late") | Some("late-interaction") | Some("multivector") => {
                borsuk::VectorKind::LateInteraction
            }
            Some(other) => {
                return Err(BorsukError::InvalidSearchOptions(format!(
                    "`--named-vector` kind in `{value}` must be 'dense', 'sparse', or 'late-interaction', got `{other}`"
                ))
                .into());
            }
        };
        let element_type = parts
            .get(4)
            .map(|value| value.trim())
            .filter(|value| !value.is_empty())
            .unwrap_or("float32")
            .parse::<borsuk::VectorElementType>()?;
        specs.insert(
            name.to_string(),
            VectorSpec {
                dimensions,
                metric,
                kind,
                element_type,
            },
        );
    }
    Ok(specs)
}

fn parse_named_vector_query(field: &str, value: &str) -> Result<(String, Vec<f32>)> {
    let Some((name, values)) = value.split_once(':') else {
        return Err(BorsukError::InvalidSearchOptions(format!(
            "`--{field}` value `{value}` must be NAME:csv"
        ))
        .into());
    };
    Ok((name.to_string(), parse_csv_value(field, values)?))
}

fn parse_csv_values<T>(field: &str, values: &[String]) -> Result<Vec<T>>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    let mut parsed = Vec::new();
    for value in values {
        for token in value.split(',') {
            let token = token.trim();
            if token.is_empty() {
                return Err(BorsukError::InvalidSearchOptions(format!(
                    "`--{field}` contains an empty value"
                ))
                .into());
            }
            parsed.push(token.parse::<T>().map_err(|error| {
                BorsukError::InvalidSearchOptions(format!(
                    "`--{field}` value `{token}` is invalid: {error}"
                ))
            })?);
        }
    }
    if parsed.is_empty() {
        return Err(BorsukError::InvalidSearchOptions(format!(
            "`--{field}` must contain at least one value"
        ))
        .into());
    }
    Ok(parsed)
}

fn parse_csv_value<T>(field: &str, value: &str) -> Result<Vec<T>>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    parse_csv_values(field, &[value.to_string()])
}

fn parse_sparse_vector_query(value: &str) -> Result<(String, Vec<u32>, Vec<f32>)> {
    let mut parts = value.splitn(3, ':');
    let name = parts.next().unwrap_or_default();
    let indices = parts.next();
    let values = parts.next();
    let (Some(indices), Some(values)) = (indices, values) else {
        return Err(BorsukError::InvalidSearchOptions(format!(
            "`--sparse-vector` value `{value}` must be NAME:idxcsv:valcsv"
        ))
        .into());
    };
    Ok((
        name.to_string(),
        parse_csv_value("sparse-vector", indices)?,
        parse_csv_value("sparse-vector", values)?,
    ))
}

fn dimensions_for_vector_name(
    name: &str,
    primary_dimensions: usize,
    named_specs: &BTreeMap<String, VectorSpec>,
) -> Result<usize> {
    if name.is_empty() {
        return Ok(primary_dimensions);
    }
    named_specs
        .get(name)
        .map(|spec| spec.dimensions)
        .ok_or_else(|| {
            BorsukError::InvalidSearchOptions(format!("unknown named vector `{name}`")).into()
        })
}

fn parse_weights(weights: Option<&str>) -> Result<BTreeMap<String, f32>> {
    let Some(weights) = weights else {
        return Ok(BTreeMap::new());
    };
    let mut parsed = BTreeMap::new();
    for entry in weights.split(',') {
        let Some((name, value)) = entry.split_once('=') else {
            return Err(BorsukError::InvalidSearchOptions(format!(
                "`--weights` entry `{entry}` must be NAME=value"
            ))
            .into());
        };
        parsed.insert(
            name.to_string(),
            value.parse::<f32>().map_err(|error| {
                BorsukError::InvalidSearchOptions(format!(
                    "`--weights` value `{value}` is invalid: {error}"
                ))
            })?,
        );
    }
    Ok(parsed)
}
