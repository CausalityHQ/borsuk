//! Standalone durability, boundedness, and recovery tests for the V12 positioned log.

mod common;

use std::{
    io::Cursor,
    sync::{Arc, Barrier},
};

use arrow_array::{Array, ArrayRef, FixedSizeBinaryArray, RecordBatch, StringArray, UInt64Array};
use arrow_ipc::{
    CompressionType,
    writer::{IpcWriteOptions, StreamWriter},
};
use arrow_schema::{DataType, Field, Schema};
use borsuk::{
    MAX_APPEND_ENCODED_BYTES, MAX_APPEND_ROWS, MAX_PAYLOADS_PER_TRANSACTION,
    MAX_PENDING_ENVELOPES_PER_SHARD, MAX_RECENT_COMMIT_RECEIPTS_PER_SHARD, PositionedLogWriter,
    PositionedMutationModality, PositionedMutationPayloadInput, PositionedPayloadFormat,
    SOURCE_SHARD_COUNT,
};
use bytes::Bytes;
use object_store::{
    ObjectStore, ObjectStoreExt, PutOptions, PutPayload, memory::InMemory, path::Path as ObjectPath,
};
use parquet::{
    arrow::{ArrowWriter, arrow_reader::ParquetRecordBatchReaderBuilder},
    file::properties::WriterProperties,
};

const SCHEMA_FINGERPRINT: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

fn arrow_payload(hlc: u64) -> Vec<u8> {
    arrow_payload_rows(hlc, 1)
}

fn mutation_batch(first_hlc: u64, rows: usize) -> (Arc<Schema>, RecordBatch) {
    let schema = Arc::new(Schema::new(vec![
        Field::new("mutation_hlc", DataType::UInt64, false),
        Field::new("mutation_writer", DataType::FixedSizeBinary(16), false),
        Field::new("mutation_digest", DataType::FixedSizeBinary(32), false),
    ]));
    let batch = RecordBatch::try_new(
        Arc::clone(&schema),
        vec![
            Arc::new(UInt64Array::from_iter_values(
                first_hlc..first_hlc + rows as u64,
            )) as ArrayRef,
            Arc::new(FixedSizeBinaryArray::try_from_iter((0..rows).map(|_| [7_u8; 16])).unwrap())
                as ArrayRef,
            Arc::new(FixedSizeBinaryArray::try_from_iter((0..rows).map(|_| [9_u8; 32])).unwrap())
                as ArrayRef,
        ],
    )
    .unwrap();
    (schema, batch)
}

fn arrow_payload_rows(first_hlc: u64, rows: usize) -> Vec<u8> {
    let (schema, batch) = mutation_batch(first_hlc, rows);
    let mut bytes = Vec::new();
    let mut writer = StreamWriter::try_new(&mut bytes, &schema).unwrap();
    writer.write(&batch).unwrap();
    writer.finish().unwrap();
    drop(writer);
    bytes
}

fn compressed_arrow_payload(hlc: u64) -> Vec<u8> {
    let (schema, batch) = mutation_batch(hlc, 1);
    let options = IpcWriteOptions::default()
        .try_with_compression(Some(CompressionType::ZSTD))
        .unwrap();
    let mut bytes = Vec::new();
    let mut writer = StreamWriter::try_new_with_options(&mut bytes, &schema, options).unwrap();
    writer.write(&batch).unwrap();
    writer.finish().unwrap();
    drop(writer);
    bytes
}

fn parquet_payload(hlc: u64) -> Vec<u8> {
    let (schema, batch) = mutation_batch(hlc, 1);
    let mut bytes = Vec::new();
    let mut writer = ArrowWriter::try_new(
        &mut bytes,
        schema,
        Some(WriterProperties::builder().build()),
    )
    .unwrap();
    writer.write(&batch).unwrap();
    writer.close().unwrap();
    bytes
}

fn overwrite(store: &Arc<dyn ObjectStore>, path: &str, bytes: Vec<u8>) {
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    runtime
        .block_on(store.put_opts(
            &ObjectPath::from(path),
            PutPayload::from(Bytes::from(bytes)),
            PutOptions::default(),
        ))
        .unwrap();
}

fn read(store: &Arc<dyn ObjectStore>, path: &str) -> Vec<u8> {
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    runtime
        .block_on(async { store.get(&ObjectPath::from(path)).await?.bytes().await })
        .unwrap()
        .to_vec()
}

fn checkpoint_target(
    writer: &PositionedLogWriter,
    shard: u8,
    target_sequence: u64,
) -> borsuk::PositionedMaterializationWatermark {
    let snapshot = writer.reader().snapshot().unwrap();
    let mut watermark = snapshot.materialized_watermarks[usize::from(shard)].clone();
    let prior_sequence = watermark.sequence();
    for (envelope, checksum) in snapshot
        .transactions
        .iter()
        .zip(&snapshot.envelope_checksums)
        .filter(|(envelope, _)| {
            envelope.position.shard == shard
                && envelope.position.sequence <= target_sequence
                && envelope.position.sequence > prior_sequence
        })
    {
        watermark = watermark
            .advanced(
                envelope.position.source_epoch,
                shard,
                envelope.position.sequence,
                checksum,
            )
            .unwrap();
    }
    watermark
}

fn checkpoint(
    writer: &PositionedLogWriter,
    shard: u8,
    target_sequence: u64,
    generation: u64,
) -> borsuk::Result<()> {
    let target = checkpoint_target(writer, shard, target_sequence);
    writer.checkpoint_materialized_through(shard, &target, generation)
}

fn payload(role: impl Into<String>, hlc: u64) -> PositionedMutationPayloadInput {
    PositionedMutationPayloadInput {
        modality: PositionedMutationModality::PrimaryDense,
        role: role.into(),
        id_bloom: Vec::new(),
        format: PositionedPayloadFormat::ArrowIpc,
        bytes: arrow_payload(hlc),
        rows: 1,
    }
}

fn route_plan_payload(hlc: u64) -> PositionedMutationPayloadInput {
    PositionedMutationPayloadInput {
        modality: PositionedMutationModality::RoutePlan,
        role: "route_plan_v1".to_owned(),
        id_bloom: Vec::new(),
        format: PositionedPayloadFormat::Parquet,
        bytes: parquet_payload(hlc),
        rows: 1,
    }
}

fn envelope_identity(bytes: &[u8]) -> (String, u64) {
    let batch = ParquetRecordBatchReaderBuilder::try_new(Bytes::copy_from_slice(bytes))
        .unwrap()
        .build()
        .unwrap()
        .next()
        .unwrap()
        .unwrap();
    let request_digest = batch
        .column_by_name("request_digest")
        .unwrap()
        .as_any()
        .downcast_ref::<StringArray>()
        .unwrap()
        .value(0)
        .to_owned();
    let sequence = batch
        .column_by_name("sequence")
        .unwrap()
        .as_any()
        .downcast_ref::<UInt64Array>()
        .unwrap()
        .value(0);
    (request_digest, sequence)
}

fn create_writer(store: Arc<dyn ObjectStore>, epoch: u64) -> PositionedLogWriter {
    PositionedLogWriter::create("memory:///positioned-log", store, epoch, SCHEMA_FINGERPRINT)
        .unwrap()
}

fn tx_shard(transaction_id: &str) -> u8 {
    blake3::hash(transaction_id.as_bytes()).as_bytes()[0] % SOURCE_SHARD_COUNT
}

fn transaction_ids_for_shard(shard: u8, count: usize) -> Vec<String> {
    (0_u64..)
        .map(|ordinal| format!("tx-{ordinal}"))
        .filter(|transaction_id| tx_shard(transaction_id) == shard)
        .take(count)
        .collect()
}

#[test]
fn arrow_and_parquet_payloads_reopen_from_one_typed_envelope() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let committed = writer
        .append(
            "typed-formats",
            SCHEMA_FINGERPRINT,
            vec![
                payload("arrow", 10),
                PositionedMutationPayloadInput {
                    modality: PositionedMutationModality::Sparse,
                    role: "parquet".to_owned(),
                    id_bloom: Vec::new(),
                    format: PositionedPayloadFormat::Parquet,
                    bytes: parquet_payload(11),
                    rows: 1,
                },
            ],
        )
        .unwrap();

    let snapshot = writer.reader().snapshot().unwrap();
    assert_eq!(snapshot.transactions.len(), 1);
    let envelope = &snapshot.transactions[0];
    assert_eq!(envelope.position, committed.position);
    assert_eq!(envelope.payloads.len(), 2);
    assert!(envelope.payloads[0] < envelope.payloads[1]);
}

#[test]
fn schema_mismatch_is_rejected_before_immutable_or_head_writes() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();

    let error = writer
        .append(
            "wrong-schema",
            "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            vec![payload("primary", 1)],
        )
        .unwrap_err();

    assert!(error.to_string().contains("schema fingerprint"), "{error}");
    assert!(
        operations.entries().is_empty(),
        "schema rejection must precede immutable uploads and head CAS: {:?}",
        operations.entries()
    );
    assert!(writer.reader().snapshot().unwrap().transactions.is_empty());
}

#[test]
fn positioned_storage_fanouts_use_only_the_bounded_io_pool() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let store: Arc<dyn ObjectStore> = Arc::new(traced);
    let writer = create_writer(Arc::clone(&store), 7);
    operations.clear();

    writer
        .append(
            "bounded-positioned-io",
            SCHEMA_FINGERPRINT,
            (0..8)
                .map(|ordinal| payload(format!("payload-{ordinal}"), ordinal + 1))
                .collect(),
        )
        .unwrap();
    let immutable_puts = operations
        .entries()
        .into_iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Put
                && (entry.path.starts_with("positioned-log/payloads/")
                    || entry.path.starts_with("positioned-log/envelopes/"))
        })
        .collect::<Vec<_>>();
    assert_eq!(immutable_puts.len(), 9);
    assert!(
        immutable_puts.iter().all(|entry| entry
            .thread_name
            .as_deref()
            .is_some_and(|name| name.starts_with("borsuk-io-"))),
        "positioned immutable writes escaped the bounded pool: {immutable_puts:?}"
    );

    operations.clear();
    let reopened =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&store), 7).unwrap();
    let head_gets = operations
        .entries()
        .into_iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Get
                && entry.path.starts_with("positioned-log/heads/")
        })
        .collect::<Vec<_>>();
    assert_eq!(head_gets.len(), usize::from(SOURCE_SHARD_COUNT));
    assert!(
        head_gets.iter().all(|entry| entry
            .thread_name
            .as_deref()
            .is_some_and(|name| name.starts_with("borsuk-io-"))),
        "positioned head reads escaped the bounded pool: {head_gets:?}"
    );

    operations.clear();
    assert_eq!(reopened.reader().snapshot().unwrap().transactions.len(), 1);
    let envelope_gets = operations
        .entries()
        .into_iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Get
                && entry.path.starts_with("positioned-log/envelopes/")
        })
        .collect::<Vec<_>>();
    assert_eq!(envelope_gets.len(), 1);
    assert!(
        envelope_gets.iter().all(|entry| entry
            .thread_name
            .as_deref()
            .is_some_and(|name| name.starts_with("borsuk-io-"))),
        "positioned envelope reads escaped the bounded pool: {envelope_gets:?}"
    );
}

#[test]
fn two_writers_rebase_one_shard_without_duplicate_visibility() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let barrier = Arc::new(Barrier::new(2));
    let ids = transaction_ids_for_shard(9, 2);
    let mut operation_logs = Vec::new();
    let writers = (0..2)
        .map(|_| {
            let wrapped = common::FaultInjectingObjectStore::new(Arc::clone(&base))
                .with_put_barrier(Arc::clone(&barrier), |operation, path| {
                    operation == common::StoreOperation::Put
                        && path.as_ref().starts_with("positioned-log/heads/")
                });
            let (wrapped, operations) = wrapped.with_operation_log();
            let writer =
                PositionedLogWriter::open("memory:///positioned-log", Arc::new(wrapped), 7)
                    .unwrap();
            operations.clear();
            operation_logs.push(operations);
            writer
        })
        .collect::<Vec<_>>();

    let threads = writers
        .into_iter()
        .zip(ids)
        .enumerate()
        .map(|(ordinal, (writer, transaction_id))| {
            std::thread::spawn(move || {
                writer
                    .append(
                        &transaction_id,
                        SCHEMA_FINGERPRINT,
                        vec![payload("primary", ordinal as u64 + 1)],
                    )
                    .unwrap()
            })
        })
        .collect::<Vec<_>>();
    let mut committed = threads
        .into_iter()
        .map(|thread| thread.join().unwrap())
        .collect::<Vec<_>>();
    committed.sort_unstable_by_key(|receipt| receipt.position.sequence);

    assert_eq!(
        committed
            .iter()
            .map(|receipt| receipt.position.sequence)
            .collect::<Vec<_>>(),
        [1, 2]
    );
    let entries = operation_logs
        .iter()
        .flat_map(|operations| operations.entries())
        .collect::<Vec<_>>();
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Get
                && entry.path.starts_with("positioned-log/heads/"))
            .count(),
        1
    );
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/payloads/"))
            .count(),
        2
    );
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/envelopes/"))
            .count(),
        3
    );
    let head_puts = entries
        .iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/heads/")
        })
        .collect::<Vec<_>>();
    assert_eq!(head_puts.len(), 3);
    assert!(
        head_puts
            .iter()
            .all(|entry| entry.put_mode == Some(common::LoggedPutMode::Update))
    );
    assert!(entries.iter().all(|entry| {
        entry.put_mode != Some(common::LoggedPutMode::Overwrite)
            && entry.operation != common::StoreOperation::List
            && entry.operation != common::StoreOperation::Head
            && entry.path != "collection/CURRENT"
    }));
    let snapshot = PositionedLogWriter::open("memory:///positioned-log", base, 7)
        .unwrap()
        .reader()
        .snapshot()
        .unwrap();
    assert_eq!(snapshot.transactions.len(), 2);
    assert_eq!(
        snapshot
            .transactions
            .iter()
            .map(|envelope| envelope.position.sequence)
            .collect::<Vec<_>>(),
        [1, 2]
    );
}

#[test]
fn stale_writer_accepts_same_request_committed_at_rebased_position_after_cas_loss() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let shard = 21;
    let ids = transaction_ids_for_shard(shard, 2);
    let intervening_id = ids[0].clone();
    let target_id = ids[1].clone();
    let barrier = Arc::new(Barrier::new(2));
    let stale_store = common::FaultInjectingObjectStore::new(Arc::clone(&base)).with_put_barrier(
        Arc::clone(&barrier),
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let stale =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(stale_store), 7).unwrap();
    let stale_target = target_id.clone();
    let stale_thread = std::thread::spawn(move || {
        stale.append(
            &stale_target,
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 2)],
        )
    });

    let winner =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    let intervening = winner
        .append(
            &intervening_id,
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();
    let committed = winner
        .append(&target_id, SCHEMA_FINGERPRINT, vec![payload("primary", 2)])
        .unwrap();
    assert_eq!(intervening.position.sequence, 1);
    assert_eq!(committed.position.sequence, 2);
    barrier.wait();

    let reconciled = stale_thread.join().unwrap().unwrap();
    assert_eq!(reconciled.position, committed.position);
    assert_eq!(reconciled.request_digest, committed.request_digest);
    assert_eq!(reconciled.envelope_checksum, committed.envelope_checksum);
}

#[test]
fn append_uses_parallel_payload_wave_then_one_conditional_head_cas() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let overlap = Arc::new(Barrier::new(2));
    let traced =
        traced.with_first_matching_puts_barrier(Arc::clone(&overlap), 2, |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/payloads/")
        });
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();

    let committed = writer
        .append(
            "tx-7",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 11), payload("named-image", 12)],
        )
        .unwrap();

    assert_eq!(committed.position.sequence, 1);
    let entries = operations.entries();
    let head = entries
        .iter()
        .position(|entry| entry.path.starts_with("positioned-log/heads/"))
        .unwrap();
    assert!(entries[..head].iter().all(|entry| {
        entry.path.starts_with("positioned-log/payloads/")
            || entry.path.starts_with("positioned-log/envelopes/")
    }));
    assert_eq!(head, entries.len() - 1);
    assert_eq!(entries[head].put_mode, Some(common::LoggedPutMode::Update));
    assert_eq!(committed.requests.gets, 0);
    assert_eq!(committed.requests.heads, 0);
    assert_eq!(committed.requests.lists, 0);
    assert_eq!(committed.requests.puts, 4);
    assert!(
        entries
            .iter()
            .all(|entry| entry.path != "collection/CURRENT")
    );
}

#[test]
fn shared_payload_checksum_is_created_once_without_an_append_path_get() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();
    let bytes = arrow_payload(11);

    let committed = writer
        .append(
            "shared-payload",
            SCHEMA_FINGERPRINT,
            vec![
                PositionedMutationPayloadInput {
                    modality: PositionedMutationModality::PrimaryDense,
                    role: "primary".to_owned(),
                    id_bloom: Vec::new(),
                    format: PositionedPayloadFormat::ArrowIpc,
                    bytes: bytes.clone(),
                    rows: 1,
                },
                PositionedMutationPayloadInput {
                    modality: PositionedMutationModality::NamedDense,
                    role: "named".to_owned(),
                    id_bloom: Vec::new(),
                    format: PositionedPayloadFormat::ArrowIpc,
                    bytes,
                    rows: 1,
                },
            ],
        )
        .unwrap();

    assert_eq!(committed.requests.gets, 0);
    assert_eq!(committed.requests.puts, 3);
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Put && path.starts_with("positioned-log/payloads/")
        }),
        1
    );
}

#[test]
fn existing_content_addressed_payload_is_verified_and_reported_separately() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    let bytes = arrow_payload(11);
    writer
        .append(
            "collision-first",
            SCHEMA_FINGERPRINT,
            vec![PositionedMutationPayloadInput {
                modality: PositionedMutationModality::PrimaryDense,
                role: "primary".to_owned(),
                id_bloom: Vec::new(),
                format: PositionedPayloadFormat::ArrowIpc,
                bytes: bytes.clone(),
                rows: 1,
            }],
        )
        .unwrap();
    operations.clear();

    let committed = writer
        .append(
            "collision-second",
            SCHEMA_FINGERPRINT,
            vec![PositionedMutationPayloadInput {
                modality: PositionedMutationModality::PrimaryDense,
                role: "primary".to_owned(),
                id_bloom: Vec::new(),
                format: PositionedPayloadFormat::ArrowIpc,
                bytes,
                rows: 1,
            }],
        )
        .unwrap();
    assert_eq!(committed.requests.gets, 1);
    assert_eq!(committed.requests.puts, 3);
    assert_eq!(committed.requests.heads, 0);
    assert_eq!(committed.requests.lists, 0);
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Get && path.starts_with("positioned-log/payloads/")
        }),
        1
    );
    let entries = operations.entries();
    assert!(entries.iter().all(|entry| {
        entry.put_mode != Some(common::LoggedPutMode::Overwrite)
            && entry.path != "collection/CURRENT"
    }));
}

#[test]
fn retry_returns_the_same_position_without_duplicate_visibility() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let first = writer
        .append("tx-7", SCHEMA_FINGERPRINT, vec![payload("primary", 11)])
        .unwrap();
    let retry = writer
        .append("tx-7", SCHEMA_FINGERPRINT, vec![payload("primary", 11)])
        .unwrap();

    assert_eq!(retry, first);
    assert_eq!(writer.reader().snapshot().unwrap().transactions.len(), 1);
}

#[test]
fn same_position_retry_preserves_payload_request_and_envelope_bytes() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) =
        common::FaultInjectingObjectStore::new(Arc::clone(&inner)).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();

    let append = || {
        writer.append(
            "byte-stable-retry",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 11), route_plan_payload(12)],
        )
    };
    let first = append().unwrap();
    let first_operations = operations.entries();
    let payload_paths = first_operations
        .iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/payloads/")
        })
        .map(|entry| entry.path.clone())
        .collect::<Vec<_>>();
    let envelope_path = first_operations
        .iter()
        .find(|entry| {
            entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/envelopes/")
        })
        .unwrap()
        .path
        .clone();
    let head_path = format!("positioned-log/heads/{:02}.json", first.position.shard);
    let payload_bytes = payload_paths
        .iter()
        .map(|path| read(&inner, path))
        .collect::<Vec<_>>();
    let envelope_bytes = read(&inner, &envelope_path);
    let head_bytes = read(&inner, &head_path);
    let (request_digest, sequence) = envelope_identity(&envelope_bytes);
    assert_eq!(payload_paths.len(), 2);
    assert_eq!(request_digest, first.request_digest);
    assert_eq!(sequence, first.position.sequence);

    operations.clear();
    let retry = append().unwrap();

    assert_eq!(retry.position, first.position);
    assert_eq!(retry.request_digest, first.request_digest);
    assert_eq!(retry.envelope_checksum, first.envelope_checksum);
    assert_eq!(
        payload_paths
            .iter()
            .map(|path| read(&inner, path))
            .collect::<Vec<_>>(),
        payload_bytes
    );
    assert_eq!(read(&inner, &envelope_path), envelope_bytes);
    assert_eq!(read(&inner, &head_path), head_bytes);
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );
}

#[test]
fn cas_rebase_preserves_payload_and_request_digest_but_rewrites_positioned_envelope() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&inner), 7);
    let shard = 21;
    let ids = transaction_ids_for_shard(shard, 2);
    let barrier = Arc::new(Barrier::new(2));
    let target_store = common::FaultInjectingObjectStore::new(Arc::clone(&inner)).with_put_barrier(
        Arc::clone(&barrier),
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let (target_store, operations) = target_store.with_operation_log();
    let target =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(target_store), 7).unwrap();
    operations.clear();
    let target_id = ids[1].clone();
    let target_thread = std::thread::spawn(move || {
        target.append(
            &target_id,
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 20), route_plan_payload(21)],
        )
    });
    while operations.count_matching(|operation, path| {
        operation == common::StoreOperation::Put && path.starts_with("positioned-log/heads/")
    }) == 0
    {
        std::thread::yield_now();
    }
    let first_envelope_path = operations
        .matching_paths(|operation, path| {
            operation == common::StoreOperation::Put
                && path.starts_with("positioned-log/envelopes/")
        })
        .into_iter()
        .next()
        .unwrap();
    let first_envelope_bytes = read(&inner, &first_envelope_path);
    let (first_request_digest, first_sequence) = envelope_identity(&first_envelope_bytes);

    let intervening = PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&inner), 7)
        .unwrap()
        .append(
            &ids[0],
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1), route_plan_payload(2)],
        )
        .unwrap();
    assert_eq!(intervening.position.sequence, 1);
    barrier.wait();
    let committed = target_thread.join().unwrap().unwrap();
    assert_eq!(committed.position.sequence, 2);

    let target_operations = operations.entries();
    let payload_paths = target_operations
        .iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/payloads/")
        })
        .map(|entry| entry.path.clone())
        .collect::<Vec<_>>();
    let envelope_paths = target_operations
        .iter()
        .filter(|entry| {
            entry.operation == common::StoreOperation::Put
                && entry.path.starts_with("positioned-log/envelopes/")
        })
        .map(|entry| entry.path.clone())
        .collect::<Vec<_>>();
    let second_envelope_bytes = read(&inner, envelope_paths.last().unwrap());
    let (second_request_digest, second_sequence) = envelope_identity(&second_envelope_bytes);

    assert_eq!(payload_paths.len(), 2, "payload objects upload only once");
    assert_eq!(
        envelope_paths.len(),
        2,
        "one envelope per attempted position"
    );
    assert_eq!(
        target_operations
            .iter()
            .filter(|entry| {
                entry.operation == common::StoreOperation::Put
                    && entry.path.starts_with("positioned-log/heads/")
            })
            .count(),
        2,
        "the stale position and rebased position each attempt one CAS"
    );
    assert_eq!(first_sequence, 1);
    assert_eq!(second_sequence, 2);
    assert_eq!(first_request_digest, second_request_digest);
    assert_eq!(second_request_digest, committed.request_digest);
    assert_ne!(first_envelope_path, *envelope_paths.last().unwrap());
    assert_ne!(first_envelope_bytes, second_envelope_bytes);
    assert!(
        payload_paths
            .iter()
            .all(|path| !read(&inner, path).is_empty())
    );
}

#[test]
fn unchanged_snapshot_reads_heads_but_performs_no_envelope_gets() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    writer
        .append("tx-7", SCHEMA_FINGERPRINT, vec![payload("primary", 11)])
        .unwrap();
    let snapshot = writer.reader().snapshot().unwrap();
    operations.clear();

    let unchanged = writer
        .reader()
        .snapshot_if_changed(&snapshot.head_checksums)
        .unwrap();

    assert!(unchanged.is_none());
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Get
                && path.starts_with("positioned-log/envelopes/")
        }),
        0
    );
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Get && path.starts_with("positioned-log/heads/")
        }),
        usize::from(SOURCE_SHARD_COUNT)
    );
}

#[test]
fn checkpoint_preserves_recent_idempotence_then_evicts_exactly_at_sixty_four() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let shard = 3;
    let ids = transaction_ids_for_shard(shard, MAX_RECENT_COMMIT_RECEIPTS_PER_SHARD + 1);
    let mut first = None;
    for (ordinal, transaction_id) in ids.iter().enumerate() {
        let committed = writer
            .append(
                transaction_id,
                SCHEMA_FINGERPRINT,
                vec![payload("primary", ordinal as u64 + 1)],
            )
            .unwrap();
        if ordinal == 0 {
            first = Some(committed.clone());
        }
        checkpoint(
            &writer,
            shard,
            committed.position.sequence,
            ordinal as u64 + 1,
        )
        .unwrap();
        if ordinal + 1 == MAX_RECENT_COMMIT_RECEIPTS_PER_SHARD {
            let oldest = writer
                .append(&ids[0], SCHEMA_FINGERPRINT, vec![payload("primary", 1)])
                .unwrap();
            assert_eq!(oldest.position, first.as_ref().unwrap().position);
        }
    }

    let appended_again = writer
        .append(&ids[0], SCHEMA_FINGERPRINT, vec![payload("primary", 1)])
        .unwrap();
    assert_ne!(appended_again.position, first.unwrap().position);
}

#[test]
fn stale_cached_receipt_refreshes_after_external_recent_eviction() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let stale =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    let shard = 13;
    let ids = transaction_ids_for_shard(shard, MAX_RECENT_COMMIT_RECEIPTS_PER_SHARD + 1);
    let first = stale
        .append(&ids[0], SCHEMA_FINGERPRINT, vec![payload("primary", 1)])
        .unwrap();
    let external =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    checkpoint(&external, shard, first.position.sequence, 1).unwrap();
    for (ordinal, transaction_id) in ids.iter().enumerate().skip(1) {
        let committed = external
            .append(
                transaction_id,
                SCHEMA_FINGERPRINT,
                vec![payload("primary", ordinal as u64 + 1)],
            )
            .unwrap();
        checkpoint(
            &external,
            shard,
            committed.position.sequence,
            ordinal as u64 + 1,
        )
        .unwrap();
    }

    let reused = stale
        .append(
            &ids[0],
            SCHEMA_FINGERPRINT,
            vec![payload("changed", 10_000)],
        )
        .unwrap();
    assert!(reused.position.sequence > first.position.sequence);
}

#[test]
fn stale_full_cache_refreshes_after_external_checkpoint() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let stale =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    let shard = 17;
    let ids = transaction_ids_for_shard(shard, MAX_PENDING_ENVELOPES_PER_SHARD + 1);
    let mut last = None;
    for (ordinal, transaction_id) in ids[..MAX_PENDING_ENVELOPES_PER_SHARD].iter().enumerate() {
        last = Some(
            stale
                .append(
                    transaction_id,
                    SCHEMA_FINGERPRINT,
                    vec![payload("primary", ordinal as u64 + 1)],
                )
                .unwrap(),
        );
    }
    let external =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    checkpoint(&external, shard, last.unwrap().position.sequence, 1).unwrap();

    let committed = stale
        .append(
            &ids[MAX_PENDING_ENVELOPES_PER_SHARD],
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 100)],
        )
        .unwrap();
    assert_eq!(committed.position.sequence, 65);
}

#[test]
fn checkpoint_refreshes_when_writer_opened_before_external_append() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let stale =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    let external =
        PositionedLogWriter::open("memory:///positioned-log", Arc::clone(&base), 7).unwrap();
    let committed = external
        .append(
            "external-before-checkpoint",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();

    checkpoint(
        &stale,
        committed.position.shard,
        committed.position.sequence,
        1,
    )
    .unwrap();
    assert!(stale.reader().snapshot().unwrap().transactions.is_empty());
}

#[test]
fn concurrent_checkpoint_generation_race_converges_on_one_materialized_prefix() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let initializer = create_writer(Arc::clone(&base), 7);
    let committed = initializer
        .append(
            "checkpoint-race",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();
    let shard = committed.position.shard;
    let sequence = committed.position.sequence;
    let target = checkpoint_target(&initializer, shard, sequence);
    let barrier = Arc::new(Barrier::new(2));
    let threads = (0..2)
        .map(|_| {
            let target = target.clone();
            let wrapped = common::FaultInjectingObjectStore::new(Arc::clone(&base))
                .with_put_barrier(Arc::clone(&barrier), |operation, path| {
                    operation == common::StoreOperation::Put
                        && path.as_ref().starts_with("positioned-log/heads/")
                });
            let writer =
                PositionedLogWriter::open("memory:///positioned-log", Arc::new(wrapped), 7)
                    .unwrap();
            std::thread::spawn(move || writer.checkpoint_materialized_through(shard, &target, 7))
        })
        .collect::<Vec<_>>();
    for thread in threads {
        thread.join().unwrap().unwrap();
    }
    let snapshot = PositionedLogWriter::open("memory:///positioned-log", base, 7)
        .unwrap()
        .reader()
        .snapshot()
        .unwrap();
    assert_eq!(
        snapshot.materialized_watermarks[usize::from(shard)].sequence(),
        sequence
    );
    assert_eq!(
        snapshot.materialized_collection_generations[usize::from(shard)],
        7
    );
}

#[test]
fn checkpoint_rebase_rejects_a_head_from_another_schema() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let initializer = create_writer(Arc::clone(&base), 7);
    let committed = initializer
        .append(
            "checkpoint-schema-rebase",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();
    let shard = committed.position.shard;
    let head_path = format!("positioned-log/heads/{shard:02}.json");
    let barrier = Arc::new(Barrier::new(2));
    let wrapped = common::FaultInjectingObjectStore::new(Arc::clone(&base)).with_put_barrier(
        Arc::clone(&barrier),
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let (wrapped, operations) = wrapped.with_operation_log();
    let writer =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(wrapped), 7).unwrap();
    let target = checkpoint_target(&writer, shard, committed.position.sequence);
    let checkpoint =
        std::thread::spawn(move || writer.checkpoint_materialized_through(shard, &target, 1));

    while operations.count_matching(|operation, path| {
        operation == common::StoreOperation::Put && path.starts_with("positioned-log/heads/")
    }) == 0
    {
        std::thread::yield_now();
    }
    let mut head = serde_json::from_slice::<serde_json::Value>(&read(&base, &head_path)).unwrap();
    head["schema_fingerprint"] =
        "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb".into();
    overwrite(&base, &head_path, serde_json::to_vec(&head).unwrap());
    barrier.wait();

    let error = checkpoint.join().unwrap().unwrap_err();
    assert!(error.to_string().contains("schema fingerprint"), "{error}");
}

#[test]
fn retryable_head_failure_without_receipt_rebases_and_retries() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let faulted = common::FaultInjectingObjectStore::fail_nth_matching(
        Arc::clone(&base),
        1,
        true,
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let writer =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(faulted), 7).unwrap();

    let committed = writer
        .append(
            "retryable-rebase",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();
    assert_eq!(committed.position.sequence, 1);
    assert_eq!(committed.requests.gets, 1);
}

#[test]
fn exact_sixteen_retryable_head_failures_exhaust_the_cas_cap() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let faulted = common::FaultInjectingObjectStore::fail_nth_matching(
        Arc::clone(&base),
        1,
        false,
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let (faulted, operations) = faulted.with_operation_log();
    let writer =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(faulted), 7).unwrap();
    operations.clear();

    let error = writer
        .append(
            "retryable-cap",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap_err();
    assert!(error.to_string().contains("concurrent modification"));
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Get && path.starts_with("positioned-log/heads/")
        }),
        16
    );
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Put && path.starts_with("positioned-log/heads/")
        }),
        16
    );
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Put
                && path.starts_with("positioned-log/envelopes/")
        }),
        1
    );
    assert_eq!(
        operations.count_matching(|operation, path| {
            operation == common::StoreOperation::Put && path.starts_with("positioned-log/payloads/")
        }),
        1
    );
}

#[test]
fn pending_count_bound_rejects_the_sixty_fifth_transaction_before_any_put() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    let ids = transaction_ids_for_shard(5, MAX_PENDING_ENVELOPES_PER_SHARD + 1);
    for (ordinal, transaction_id) in ids[..MAX_PENDING_ENVELOPES_PER_SHARD].iter().enumerate() {
        writer
            .append(
                transaction_id,
                SCHEMA_FINGERPRINT,
                vec![payload("primary", ordinal as u64 + 1)],
            )
            .unwrap();
    }
    operations.clear();

    let error = writer
        .append(
            &ids[MAX_PENDING_ENVELOPES_PER_SHARD],
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 65)],
        )
        .unwrap_err();

    assert!(error.to_string().contains("backpressure"));
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );
}

#[test]
fn invalid_inputs_and_conflicting_retry_fail_before_publication() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();
    for (transaction_id, fingerprint, payloads) in [
        ("", SCHEMA_FINGERPRINT, vec![payload("primary", 1)]),
        ("tx", "schema-a", vec![payload("primary", 1)]),
        ("tx", SCHEMA_FINGERPRINT, vec![payload("", 1)]),
        ("empty-payload", SCHEMA_FINGERPRINT, Vec::new()),
    ] {
        assert!(
            writer
                .append(transaction_id, fingerprint, payloads)
                .is_err()
        );
    }
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );

    writer
        .append("same-id", SCHEMA_FINGERPRINT, vec![payload("primary", 2)])
        .unwrap();
    let conflict = writer
        .append("same-id", SCHEMA_FINGERPRINT, vec![payload("primary", 3)])
        .unwrap_err();
    assert!(conflict.to_string().contains("conflict"));
}

#[test]
fn payload_and_envelope_failures_remain_invisible() {
    for failed_prefix in ["positioned-log/payloads/", "positioned-log/envelopes/"] {
        let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
        let initializer = create_writer(Arc::clone(&base), 7);
        drop(initializer);
        let faulted = common::FaultInjectingObjectStore::fail_nth_matching(
            Arc::clone(&base),
            1,
            false,
            move |operation, path| {
                operation == common::StoreOperation::Put && path.as_ref().starts_with(failed_prefix)
            },
        );
        let writer =
            PositionedLogWriter::open("memory:///positioned-log", Arc::new(faulted), 7).unwrap();

        assert!(
            writer
                .append("tx-fail", SCHEMA_FINGERPRINT, vec![payload("primary", 1)])
                .is_err()
        );
        assert!(writer.reader().snapshot().unwrap().transactions.is_empty());
    }
}

#[test]
fn lost_successful_head_response_is_reconciled_by_exact_receipt() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let faulted = common::FaultInjectingObjectStore::accept_then_fail_nth_put(
        Arc::clone(&base),
        1,
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let (faulted, operations) = faulted.with_operation_log();
    let writer =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(faulted), 7).unwrap();
    operations.clear();

    let committed = writer
        .append("tx-lost", SCHEMA_FINGERPRINT, vec![payload("primary", 1)])
        .unwrap();

    assert_eq!(committed.position.sequence, 1);
    assert_eq!(committed.requests.gets, 1);
    assert_eq!(committed.requests.puts, 3);
    assert_eq!(committed.requests.heads, 0);
    assert_eq!(committed.requests.lists, 0);
    let entries = operations.entries();
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Get
                && entry.path.starts_with("positioned-log/heads/"))
            .count(),
        1
    );
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Put)
            .count(),
        3
    );
    assert!(entries.iter().all(|entry| {
        entry.put_mode != Some(common::LoggedPutMode::Overwrite)
            && entry.operation != common::StoreOperation::List
            && entry.operation != common::StoreOperation::Head
            && entry.path != "collection/CURRENT"
    }));
    assert_eq!(writer.reader().snapshot().unwrap().transactions.len(), 1);
}

#[test]
fn cold_open_reports_exact_sixty_four_head_gets() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let (_writer, requests) =
        PositionedLogWriter::open_with_report("memory:///positioned-log", base, 7).unwrap();
    assert_eq!(requests.gets, u64::from(SOURCE_SHARD_COUNT));
    assert_eq!(requests.puts, 0);
    assert_eq!(requests.heads, 0);
    assert_eq!(requests.lists, 0);
}

#[test]
fn lost_successful_head_initialization_response_reconciles_exact_empty_head() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let faulted = common::FaultInjectingObjectStore::accept_then_fail_nth_put(
        Arc::clone(&base),
        1,
        |operation, path| {
            operation == common::StoreOperation::Put
                && path.as_ref().starts_with("positioned-log/heads/")
        },
    );
    let (faulted, operations) = faulted.with_operation_log();
    PositionedLogWriter::create(
        "memory:///positioned-log",
        Arc::new(faulted),
        7,
        SCHEMA_FINGERPRINT,
    )
    .unwrap();
    let entries = operations.entries();
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Put)
            .count(),
        usize::from(SOURCE_SHARD_COUNT)
    );
    assert_eq!(
        entries
            .iter()
            .filter(|entry| entry.operation == common::StoreOperation::Get)
            .count(),
        1
    );
    assert!(
        entries
            .iter()
            .filter_map(|entry| entry.put_mode)
            .all(|mode| { mode == common::LoggedPutMode::Create })
    );
}

#[test]
fn concurrent_source_initialization_race_converges_on_exact_empty_heads() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let barrier = Arc::new(Barrier::new(2));
    let threads = (0..2)
        .map(|_| {
            let wrapped = common::FaultInjectingObjectStore::new(Arc::clone(&base))
                .with_put_barrier(Arc::clone(&barrier), |operation, path| {
                    operation == common::StoreOperation::Put
                        && path.as_ref() == "positioned-log/heads/00.json"
                });
            std::thread::spawn(move || {
                PositionedLogWriter::create(
                    "memory:///positioned-log",
                    Arc::new(wrapped),
                    7,
                    SCHEMA_FINGERPRINT,
                )
            })
        })
        .collect::<Vec<_>>();
    for thread in threads {
        thread.join().unwrap().unwrap();
    }
    let (_writer, requests) =
        PositionedLogWriter::open_with_report("memory:///positioned-log", base, 7).unwrap();
    assert_eq!(requests.gets, u64::from(SOURCE_SHARD_COUNT));
}

#[test]
fn payload_must_be_a_typed_container_with_truthful_rows() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let malformed = PositionedMutationPayloadInput {
        modality: PositionedMutationModality::PrimaryDense,
        role: "primary".to_owned(),
        id_bloom: Vec::new(),
        format: PositionedPayloadFormat::ArrowIpc,
        bytes: Cursor::new(b"not-arrow".to_vec()).into_inner(),
        rows: 1,
    };
    assert!(
        writer
            .append("tx-bad", SCHEMA_FINGERPRINT, vec![malformed])
            .is_err()
    );

    let mut wrong_rows = payload("primary", 1);
    wrong_rows.rows = 2;
    assert!(
        writer
            .append("tx-rows", SCHEMA_FINGERPRINT, vec![wrong_rows])
            .is_err()
    );
}

#[test]
fn compressed_arrow_payload_is_rejected_before_decompression_or_publication() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();
    let error = writer
        .append(
            "compressed-arrow",
            SCHEMA_FINGERPRINT,
            vec![PositionedMutationPayloadInput {
                modality: PositionedMutationModality::PrimaryDense,
                role: "primary".to_owned(),
                id_bloom: Vec::new(),
                format: PositionedPayloadFormat::ArrowIpc,
                bytes: compressed_arrow_payload(1),
                rows: 1,
            }],
        )
        .unwrap_err();
    assert!(
        error
            .to_string()
            .contains("compressed positioned Arrow IPC")
    );
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );
}

#[test]
fn exact_payload_and_row_bounds_admit_then_bound_plus_one_rejects_before_put() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let exact_payloads = (0..MAX_PAYLOADS_PER_TRANSACTION)
        .map(|ordinal| payload(format!("role-{ordinal}"), ordinal as u64 + 1))
        .collect();
    writer
        .append("payload-exact", SCHEMA_FINGERPRINT, exact_payloads)
        .unwrap();

    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();
    let too_many = (0..=MAX_PAYLOADS_PER_TRANSACTION)
        .map(|ordinal| payload(format!("role-{ordinal}"), ordinal as u64 + 1))
        .collect();
    assert!(
        writer
            .append("payload-over", SCHEMA_FINGERPRINT, too_many)
            .is_err()
    );
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );

    let exact_rows = PositionedMutationPayloadInput {
        modality: PositionedMutationModality::PrimaryDense,
        role: "rows".to_owned(),
        id_bloom: Vec::new(),
        format: PositionedPayloadFormat::ArrowIpc,
        bytes: arrow_payload_rows(1, MAX_APPEND_ROWS as usize),
        rows: MAX_APPEND_ROWS,
    };
    writer
        .append("rows-exact", SCHEMA_FINGERPRINT, vec![exact_rows])
        .unwrap();

    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();
    let excessive_rows = PositionedMutationPayloadInput {
        modality: PositionedMutationModality::PrimaryDense,
        role: "rows".to_owned(),
        id_bloom: Vec::new(),
        format: PositionedPayloadFormat::ArrowIpc,
        bytes: arrow_payload_rows(1, MAX_APPEND_ROWS as usize + 1),
        rows: MAX_APPEND_ROWS + 1,
    };
    assert!(
        writer
            .append("rows-over", SCHEMA_FINGERPRINT, vec![excessive_rows])
            .is_err()
    );
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );
}

#[test]
fn declared_row_and_aggregate_encoded_bounds_reject_before_container_decode() {
    let inner: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let (traced, operations) = common::FaultInjectingObjectStore::new(inner).with_operation_log();
    let writer = create_writer(Arc::new(traced), 7);
    operations.clear();

    let row_error = writer
        .append(
            "predecode-row-bound",
            SCHEMA_FINGERPRINT,
            vec![PositionedMutationPayloadInput {
                modality: PositionedMutationModality::PrimaryDense,
                role: "rows".to_owned(),
                id_bloom: Vec::new(),
                format: PositionedPayloadFormat::ArrowIpc,
                bytes: vec![0],
                rows: MAX_APPEND_ROWS + 1,
            }],
        )
        .unwrap_err();
    assert!(row_error.to_string().contains("hard row or byte bound"));

    let first_len = usize::try_from(MAX_APPEND_ENCODED_BYTES / 2).unwrap();
    let second_len = usize::try_from(MAX_APPEND_ENCODED_BYTES / 2 + 1).unwrap();
    let byte_error = writer
        .append(
            "predecode-byte-bound",
            SCHEMA_FINGERPRINT,
            vec![
                PositionedMutationPayloadInput {
                    modality: PositionedMutationModality::PrimaryDense,
                    role: "a".to_owned(),
                    id_bloom: Vec::new(),
                    format: PositionedPayloadFormat::ArrowIpc,
                    bytes: vec![0; first_len],
                    rows: 1,
                },
                PositionedMutationPayloadInput {
                    modality: PositionedMutationModality::Sparse,
                    role: "b".to_owned(),
                    id_bloom: Vec::new(),
                    format: PositionedPayloadFormat::ArrowIpc,
                    bytes: vec![0; second_len],
                    rows: 1,
                },
            ],
        )
        .unwrap_err();
    assert!(byte_error.to_string().contains("hard row or byte bound"));
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );
}

#[test]
fn stale_epoch_and_sequence_overflow_fail_closed() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let writer = create_writer(Arc::clone(&base), 7);
    let transaction_id = "stale-epoch";
    let shard = tx_shard(transaction_id);
    let path = format!("positioned-log/heads/{shard:02}.json");
    let mut head = serde_json::from_slice::<serde_json::Value>(&read(&base, &path)).unwrap();
    head["source_epoch"] = 8.into();
    overwrite(&base, &path, serde_json::to_vec(&head).unwrap());
    let error = writer
        .append(
            transaction_id,
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap_err();
    assert!(error.to_string().contains("epoch"));

    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    create_writer(Arc::clone(&base), 7);
    let transaction_id = "sequence-overflow";
    let shard = tx_shard(transaction_id);
    let path = format!("positioned-log/heads/{shard:02}.json");
    let mut head = serde_json::from_slice::<serde_json::Value>(&read(&base, &path)).unwrap();
    head["durable_sequence"] = u64::MAX.into();
    head["materialized_sequence"] = u64::MAX.into();
    head["materialized_prefix_digest"] = "c".repeat(64).into();
    head["materialized_collection_generation"] = 1.into();
    head["evicted_recent_through_collection_generation"] = 1.into();
    head["recent"] = serde_json::Value::Array(
        (u64::MAX - u64::try_from(MAX_RECENT_COMMIT_RECEIPTS_PER_SHARD).unwrap() + 1..=u64::MAX)
            .map(|sequence| {
                serde_json::json!({
                    "transaction_digest": format!("{sequence:064x}"),
                    "request_digest": "a".repeat(64),
                    "envelope_checksum": "b".repeat(64),
                    "sequence": sequence,
                    "rows": 1,
                    "encoded_bytes": 1,
                    "materialized_collection_generation": 1,
                })
            })
            .collect(),
    );
    overwrite(&base, &path, serde_json::to_vec(&head).unwrap());
    let (traced, operations) =
        common::FaultInjectingObjectStore::new(Arc::clone(&base)).with_operation_log();
    let writer =
        PositionedLogWriter::open("memory:///positioned-log", Arc::new(traced), 7).unwrap();
    operations.clear();
    let error = writer
        .append(
            transaction_id,
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap_err();
    assert!(error.to_string().contains("overflow"));
    assert_eq!(
        operations.count_matching(|operation, _| operation == common::StoreOperation::Put),
        0
    );
}

#[test]
fn corrupt_envelope_is_never_returned_by_a_snapshot() {
    let base: Arc<dyn ObjectStore> = Arc::new(InMemory::new());
    let writer = create_writer(Arc::clone(&base), 7);
    let committed = writer
        .append("corrupt", SCHEMA_FINGERPRINT, vec![payload("primary", 1)])
        .unwrap();
    let path = format!(
        "positioned-log/envelopes/{}/{}.parquet",
        &committed.envelope_checksum[..2],
        committed.envelope_checksum
    );
    overwrite(&base, &path, b"not parquet".to_vec());

    let error = writer.reader().snapshot().unwrap_err();
    assert!(error.to_string().contains("checksum"));
}

#[test]
fn checkpoint_generation_must_advance_and_cannot_skip_durable_positions() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let committed = writer
        .append(
            "checkpoint",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();
    let target = checkpoint_target(
        &writer,
        committed.position.shard,
        committed.position.sequence,
    );
    let beyond = borsuk::PositionedMaterializationWatermark::from_parts(
        committed.position.sequence + 1,
        target.prefix_digest().to_owned(),
    )
    .unwrap();
    assert!(
        writer
            .checkpoint_materialized_through(committed.position.shard, &beyond, 1,)
            .is_err()
    );
    writer
        .checkpoint_materialized_through(committed.position.shard, &target, 2)
        .unwrap();
    writer
        .checkpoint_materialized_through(committed.position.shard, &target, 2)
        .unwrap();
    assert!(
        writer
            .checkpoint_materialized_through(committed.position.shard, &target, 3)
            .is_err()
    );
    let snapshot = writer.reader().snapshot().unwrap();
    assert!(snapshot.transactions.is_empty());
    assert_eq!(
        snapshot.materialized_collection_generations[usize::from(committed.position.shard)],
        2
    );
}

#[test]
fn reader_pinned_before_checkpoint_loads_bounded_recent_envelopes() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let committed = writer
        .append(
            "generation-visible",
            SCHEMA_FINGERPRINT,
            vec![payload("primary", 1)],
        )
        .unwrap();
    checkpoint(
        &writer,
        committed.position.shard,
        committed.position.sequence,
        7,
    )
    .unwrap();

    assert!(writer.reader().snapshot().unwrap().transactions.is_empty());
    let pinned_before = writer
        .reader()
        .snapshot_for_collection_generation(6)
        .unwrap();
    assert_eq!(pinned_before.transactions.len(), 1);
    assert_eq!(pinned_before.transactions[0].position, committed.position);
    let pinned_after = writer
        .reader()
        .snapshot_for_collection_generation(7)
        .unwrap();
    assert!(pinned_after.transactions.is_empty());
}

#[test]
fn generation_visibility_fails_closed_after_bounded_recent_eviction() {
    let writer = create_writer(Arc::new(InMemory::new()), 7);
    let shard = 19;
    let ids = transaction_ids_for_shard(shard, MAX_RECENT_COMMIT_RECEIPTS_PER_SHARD + 1);
    for (ordinal, transaction_id) in ids.iter().enumerate() {
        let committed = writer
            .append(
                transaction_id,
                SCHEMA_FINGERPRINT,
                vec![payload("primary", ordinal as u64 + 1)],
            )
            .unwrap();
        checkpoint(
            &writer,
            shard,
            committed.position.sequence,
            ordinal as u64 + 1,
        )
        .unwrap();
    }

    let expired = writer
        .reader()
        .snapshot_for_collection_generation(0)
        .unwrap_err();
    assert!(expired.to_string().contains("recent window"));
    let still_bounded = writer
        .reader()
        .snapshot_for_collection_generation(1)
        .unwrap();
    assert_eq!(still_bounded.transactions.len(), 64);
}
