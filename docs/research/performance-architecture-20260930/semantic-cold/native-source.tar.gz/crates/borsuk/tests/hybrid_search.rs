#![allow(missing_docs)]

use std::collections::BTreeMap;

use borsuk::{
    BorsukError, BorsukIndex, Fusion, HybridOptions, HybridQuery, IndexConfig, OpenOptions,
    RecallGuarantee, SearchHit, SearchOptions, SearchTerminationReason, VectorMetric, VectorRecord,
    VectorSpec,
};

fn index_config(uri: String) -> IndexConfig {
    IndexConfig {
        uri,
        metric: VectorMetric::Euclidean,
        dimensions: 2,
        segment_max_vectors: 2,
        ram_budget_bytes: None,
        text: true,
        named_vectors: Default::default(),
    }
}

fn repeated_text(term_count: usize) -> String {
    std::iter::repeat_n("needle", term_count)
        .collect::<Vec<_>>()
        .join(" ")
}

fn hybrid_record(id: &str, dense_x: f32, text_terms: usize) -> VectorRecord {
    VectorRecord::new(id, vec![dense_x, 0.0]).with_text(repeated_text(text_terms))
}

fn build_index() -> (BorsukIndex, tempfile::TempDir) {
    let dir = tempfile::tempdir().unwrap();
    let uri = dir.path().to_string_lossy().into_owned();
    let mut index = BorsukIndex::create(index_config(uri)).unwrap();
    index
        .add(vec![
            // Dense: A, B, C, D. Text: D, B, C, A.
            hybrid_record("doc-a", 0.0, 1),
            hybrid_record("doc-b", 1.0, 3),
            hybrid_record("doc-c", 2.0, 2),
            hybrid_record("doc-d", 3.0, 4),
        ])
        .unwrap();
    // Flush the (default-on) WAL so records land in real segments; the hybrid
    // tests below pin cross-segment vector + BM25 behavior on indexed segments.
    index.flush().unwrap();
    assert!(
        index.stats().segments >= 2,
        "test setup must create multiple segments"
    );
    (index, dir)
}

fn hit_ids(hits: &[SearchHit]) -> Vec<String> {
    hits.iter()
        .map(|hit| hit.id.to_utf8_string().unwrap())
        .collect()
}

fn hybrid_options(k: usize, fusion: Fusion) -> HybridOptions {
    let mut options = HybridOptions::new(k);
    options.fusion = fusion;
    options.candidate_depth = 4;
    options.dense_options = SearchOptions::exact(4);
    options
}

fn hybrid_query() -> HybridQuery {
    HybridQuery::new()
        .with_vector("", vec![0.0, 0.0])
        .with_text("needle")
}

fn weighted(weights: &[(&str, f32)]) -> Fusion {
    Fusion::Weighted {
        weights: weights
            .iter()
            .map(|(name, weight)| ((*name).to_string(), *weight))
            .collect(),
    }
}

fn multi_vector_config(uri: String) -> IndexConfig {
    IndexConfig {
        uri,
        metric: VectorMetric::Euclidean,
        dimensions: 2,
        segment_max_vectors: 2,
        ram_budget_bytes: None,
        text: false,
        named_vectors: BTreeMap::from([(
            "lexical".to_string(),
            VectorSpec {
                dimensions: 2,
                metric: VectorMetric::Euclidean,
                kind: Default::default(),
                element_type: Default::default(),
            },
        )]),
    }
}

fn multi_vector_record(id: &str, primary_x: f32, lexical_x: f32) -> VectorRecord {
    VectorRecord::new(id, vec![primary_x, 0.0]).with_named_vector("lexical", vec![lexical_x, 0.0])
}

fn build_multi_vector_index() -> (BorsukIndex, tempfile::TempDir) {
    let dir = tempfile::tempdir().unwrap();
    let uri = dir.path().to_string_lossy().into_owned();
    let mut index = BorsukIndex::create(multi_vector_config(uri)).unwrap();
    index
        .add(vec![
            // Primary: A, B, C, D. Lexical: D, B, C, A.
            multi_vector_record("doc-a", 0.0, 3.0),
            multi_vector_record("doc-b", 1.0, 1.0),
            multi_vector_record("doc-c", 2.0, 2.0),
            multi_vector_record("doc-d", 3.0, 0.0),
        ])
        .unwrap();
    // This fixture tests cross-segment fusion, so establish that physical
    // boundary explicitly instead of depending on a WAL threshold default.
    index.flush().unwrap();
    assert!(
        index.stats().segments >= 2,
        "test setup must create multiple segments"
    );
    (index, dir)
}

fn rrf_score(ranks: &[usize], k: usize) -> f32 {
    ranks
        .iter()
        .map(|rank| 1.0 / (k as f32 + *rank as f32))
        .sum()
}

#[test]
fn hybrid_default_uses_recall_qualified_rrf_constant() {
    assert!(matches!(
        HybridOptions::new(10).fusion,
        Fusion::Rrf { k: 1 }
    ));
}

#[test]
fn collection_shared_single_search_permit_does_not_deadlock_hybrid_legs() {
    let (index, dir) = build_index();
    let uri = index.manifest().config.uri.clone();
    drop(index);
    let index = BorsukIndex::open_with_options(
        &uri,
        OpenOptions {
            max_active_searches: 1,
            max_waiting_searches: 0,
            ..OpenOptions::default()
        },
    )
    .unwrap();

    let report = index
        .search_hybrid(&hybrid_query(), hybrid_options(2, Fusion::Rrf { k: 1 }))
        .unwrap();

    assert_eq!(report.hits.len(), 2);
    drop(dir);
}

#[test]
fn rrf_fuses_vector_and_bm25_rankings() {
    let (index, _dir) = build_index();

    let report = index
        .search_hybrid(&hybrid_query(), hybrid_options(3, Fusion::Rrf { k: 60 }))
        .unwrap();

    assert_eq!(hit_ids(&report.hits), vec!["doc-b", "doc-a", "doc-d"]);
    assert_eq!(report.leaf_mode, "hybrid");
    assert_eq!(report.termination_reason, SearchTerminationReason::Complete);
    assert_eq!(report.recall_guarantee, RecallGuarantee::Approximate);

    let expected = [
        ("doc-b", rrf_score(&[1, 1], 60)),
        ("doc-a", rrf_score(&[0, 3], 60)),
        ("doc-d", rrf_score(&[3, 0], 60)),
    ];
    for (hit, (expected_id, expected_score)) in report.hits.iter().zip(expected) {
        assert_eq!(hit.id.as_str(), expected_id);
        assert!(
            (hit.distance + expected_score).abs() <= 1e-6,
            "hit {expected_id} distance {} expected fused score {expected_score}",
            hit.distance
        );
    }
}

#[test]
fn weighted_single_modality_weights_reproduce_that_modality_ordering() {
    let (index, _dir) = build_index();

    let dense_only = index
        .search_with_report(&[0.0, 0.0], SearchOptions::exact(4))
        .unwrap();
    let dense_weighted = index
        .search_hybrid(
            &hybrid_query(),
            hybrid_options(4, weighted(&[("", 1.0), ("@text", 0.0)])),
        )
        .unwrap();
    assert_eq!(hit_ids(&dense_weighted.hits), hit_ids(&dense_only.hits));

    let text_only = index.search_text("needle", 4).unwrap();
    let text_weighted = index
        .search_hybrid(
            &hybrid_query(),
            hybrid_options(4, weighted(&[("", 0.0), ("@text", 1.0)])),
        )
        .unwrap();
    assert_eq!(hit_ids(&text_weighted.hits), hit_ids(&text_only.hits));
}

#[test]
fn rrf_fuses_primary_and_named_vector_rankings() {
    let (index, _dir) = build_multi_vector_index();
    let query = HybridQuery::new()
        .with_vector("", vec![0.0, 0.0])
        .with_vector("lexical", vec![0.0, 0.0]);

    let report = index
        .search_hybrid(&query, hybrid_options(3, Fusion::Rrf { k: 60 }))
        .unwrap();

    assert_eq!(hit_ids(&report.hits), vec!["doc-b", "doc-a", "doc-d"]);
    let expected = [
        ("doc-b", rrf_score(&[1, 1], 60)),
        ("doc-a", rrf_score(&[0, 3], 60)),
        ("doc-d", rrf_score(&[3, 0], 60)),
    ];
    for (hit, (expected_id, expected_score)) in report.hits.iter().zip(expected) {
        assert_eq!(hit.id.as_str(), expected_id);
        assert!(
            (hit.distance + expected_score).abs() <= 1e-6,
            "hit {expected_id} distance {} expected fused score {expected_score}",
            hit.distance
        );
    }
}

#[test]
fn weighted_named_vector_weight_reproduces_that_vector_ordering() {
    let (index, _dir) = build_multi_vector_index();
    let query = HybridQuery::new()
        .with_vector("", vec![0.0, 0.0])
        .with_vector("lexical", vec![0.0, 0.0]);

    let lexical_only = index
        .search_with_report(
            &[0.0, 0.0],
            SearchOptions::exact(4).with_vector_name("lexical"),
        )
        .unwrap();
    let lexical_weighted = index
        .search_hybrid(
            &query,
            hybrid_options(4, weighted(&[("", 0.0), ("lexical", 1.0)])),
        )
        .unwrap();

    assert_eq!(hit_ids(&lexical_weighted.hits), hit_ids(&lexical_only.hits));
}

#[test]
fn sparse_vector_builder_matches_dense_primary_query() {
    let (index, _dir) = build_index();
    let sparse_query = HybridQuery::new()
        .with_sparse_vector("", vec![0], vec![0.0], 2)
        .unwrap()
        .with_text("needle");

    let sparse_report = index
        .search_hybrid(&sparse_query, hybrid_options(3, Fusion::Rrf { k: 60 }))
        .unwrap();
    let dense_report = index
        .search_hybrid(&hybrid_query(), hybrid_options(3, Fusion::Rrf { k: 60 }))
        .unwrap();

    assert_eq!(hit_ids(&sparse_report.hits), hit_ids(&dense_report.hits));
}

#[test]
fn text_only_hybrid_query_returns_bm25_top_k() {
    let (index, _dir) = build_index();

    let report = index
        .search_hybrid(
            &HybridQuery::new().with_text("needle"),
            hybrid_options(2, Fusion::Rrf { k: 60 }),
        )
        .unwrap();
    let text_only = index.search_text("needle", 2).unwrap();

    assert_eq!(hit_ids(&report.hits), hit_ids(&text_only.hits));
    assert!(report.bytes_read > 0);
    assert!(report.backing_bytes_read > 0);
    assert!(report.backing_reads > 0);
    assert!(report.requests.gets > 0);
}

#[test]
fn dense_only_hybrid_query_attributes_disk_cached_reads_to_the_outer_query() {
    let dir = tempfile::tempdir().unwrap();
    let cache = tempfile::tempdir().unwrap();
    let uri = dir.path().to_string_lossy().into_owned();
    let mut writer = BorsukIndex::create(index_config(uri.clone())).unwrap();
    writer
        .add(vec![
            hybrid_record("doc-a", 0.0, 1),
            hybrid_record("doc-b", 1.0, 1),
            hybrid_record("doc-c", 2.0, 1),
            hybrid_record("doc-d", 3.0, 1),
        ])
        .unwrap();
    writer.flush().unwrap();
    drop(writer);

    let index = BorsukIndex::open_with_cache(&uri, Some(cache.path().to_path_buf())).unwrap();
    let query = HybridQuery::new().with_vector("", vec![0.0, 0.0]);
    let options = hybrid_options(2, Fusion::Rrf { k: 60 });
    let uncached = index.search_hybrid(&query, options.clone()).unwrap();
    assert!(uncached.backing_bytes_read > 0);
    assert!(uncached.backing_reads > 0);

    let cached = index.search_hybrid(&query, options).unwrap();
    assert!(cached.disk_cache_bytes_read > 0);
    assert!(cached.disk_cache_reads > 0);
    assert_eq!(cached.backing_bytes_read, 0);
    assert_eq!(cached.backing_reads, 0);
}

#[test]
fn search_hybrid_rejects_empty_query_and_zero_k() {
    let (index, _dir) = build_index();

    let empty_query = index
        .search_hybrid(&HybridQuery::new(), HybridOptions::new(3))
        .unwrap_err();
    assert!(
        matches!(
            empty_query,
            BorsukError::InvalidSearchOptions(ref message)
                if message == "hybrid query must set at least one vector or text query"
        ),
        "{empty_query:?}"
    );

    let zero_k = index
        .search_hybrid(
            &HybridQuery::new().with_text("needle"),
            HybridOptions::new(0),
        )
        .unwrap_err();
    assert!(
        matches!(
            zero_k,
            BorsukError::InvalidSearchOptions(ref message)
                if message == "k must be greater than zero"
        ),
        "{zero_k:?}"
    );
}
