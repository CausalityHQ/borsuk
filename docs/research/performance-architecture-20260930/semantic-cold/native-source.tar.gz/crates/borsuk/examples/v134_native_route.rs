//! Development serial request with native PQ64 routing and physical planning.
//! It preserves V122's fixed method and V133's authenticated local placement.

use borsuk::exact_sq8_mirror::{ExactSq8Mirror, MirrorManifest, Placement};
use borsuk::exact_sq8_nominee::{Sq8Geometry, primary_ordinals};
use borsuk::native_source_id_map::NativeSourceIdMap;
use borsuk::native_source_tier::NativeSourceTier;
use borsuk::physical_interval::plan_weighted_nominee_pages;
use borsuk::pq64_router_artifact::load_source_router;
use borsuk::returned_sq8::{ReturnedRange, rank_returned_ranges};
use borsuk::serving_generation::{ExactServingGeneration, ServingGeneration};
use borsuk::sq8_page_authority::PageAuthority;
use serde::Deserialize;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::HashSet,
    error::Error,
    fs::{self, File},
    io::{self, BufRead, BufReader, BufWriter, Write},
    path::Path,
    sync::atomic::{AtomicUsize, Ordering as AtomicOrdering},
    thread,
    time::Instant,
};

const AUTHORITY_SHA: &str = "968ef7d795b53e5869400998ca19c6ab20d9b39830295fac3081c419f63f0f20";
const V131_REPLAY_SHA: &str = "9c687edc8ea66a5ef41b1e83d1d51788022b58cf526f2e9dcdb21a38bb5dd7d9";
const MAX_GETS: usize = 32;
const MAX_BYTES: usize = 16_777_216;
const TOP_K: usize = 100;
const EXPANSION: usize = 512;

#[derive(Deserialize)]
struct Query {
    query_ordinal: usize,
    source_query_ordinal: usize,
    query: Vec<f32>,
}

#[derive(Deserialize)]
struct Evidence {
    query_ordinal: usize,
    source_query_ordinal: usize,
    truth_ids: Vec<u64>,
    nominees: Vec<usize>,
    primary: Vec<usize>,
    candidate_ranges: Vec<[usize; 2]>,
    baseline_ranges: Vec<[usize; 2]>,
}

struct PreparedRoute {
    started: Instant,
    router_ids: Vec<u64>,
    router_ns: u128,
    nominee_ns: u128,
    planner_ns: u128,
    nominee_order_differs: bool,
    primary_order_differs: bool,
}

#[derive(Deserialize)]
struct ReplayArm {
    returned_ids: Vec<u64>,
    sq8_returned_ids: Vec<i64>,
    hits: usize,
    candidate_count: usize,
    local_read_bytes: u64,
    verified_block_reads: u64,
}

#[derive(Deserialize)]
struct Replay {
    query_ordinal: usize,
    source_query_ordinal: usize,
    candidate: ReplayArm,
    baseline: ReplayArm,
}

fn invalid(message: impl Into<String>) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message.into())
}

fn sha256(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn field<'a>(value: &'a Value, section: &str, name: &str, key: &str) -> Result<&'a str, io::Error> {
    value[section][name][key]
        .as_str()
        .ok_or_else(|| invalid(format!("generation field {section}.{name}.{key}")))
}

fn checked_lines<T: for<'de> Deserialize<'de>>(
    path: &Path,
    expected_sha: &str,
) -> Result<Vec<T>, Box<dyn Error>> {
    if sha256(&fs::read(path)?) != expected_sha {
        return Err(invalid(format!("sealed input SHA-256: {}", path.display())).into());
    }
    let lines = BufReader::new(File::open(path)?);
    let mut records = Vec::new();
    for line in lines.lines() {
        records.push(serde_json::from_str::<T>(&line?)?);
    }
    Ok(records)
}

fn percentile_ms(values: &[u128], percentage: usize) -> f64 {
    let mut sorted = values.to_vec();
    sorted.sort_unstable();
    sorted[(sorted.len() * percentage).div_ceil(100) - 1] as f64 / 1_000_000.0
}

fn exact_page_spans(
    pages: &PageAuthority,
    ranges: &[[usize; 2]],
) -> Result<Vec<(usize, usize, usize)>, io::Error> {
    if ranges.is_empty() || ranges.len() > MAX_GETS {
        return Err(invalid("physical range count"));
    }
    let full_page_bytes = pages
        .page_rows()
        .checked_mul(pages.dimensions() + 12)
        .ok_or_else(|| invalid("page byte width overflow"))?;
    let mut spans = Vec::with_capacity(ranges.len());
    let mut previous_end = 0;
    let mut total = 0usize;
    for &[start, end] in ranges {
        total = total
            .checked_add(
                end.checked_sub(start)
                    .ok_or_else(|| invalid("range order"))?,
            )
            .ok_or_else(|| invalid("range byte overflow"))?;
        if start < previous_end || end > pages.object_bytes() || total > MAX_BYTES || start == end {
            return Err(invalid("physical range cap or overlap"));
        }
        let first = start / full_page_bytes;
        let last = (end - 1) / full_page_bytes;
        if pages
            .byte_range(first, last)
            .map_err(|error| invalid(format!("page span {error:?}")))?
            != (start..end)
        {
            return Err(invalid("range is not an exact page span"));
        }
        spans.push((first, last, end - start));
        previous_end = end;
    }
    Ok(spans)
}

fn prepare_candidate_route(
    query_ordinal: usize,
    query: &[f32],
    sealed: &Evidence,
    mirror: &ExactSq8Mirror,
    generation: &ExactServingGeneration<'_>,
) -> Result<(PreparedRoute, Vec<[usize; 2]>), Box<dyn Error>> {
    let started = Instant::now();
    let pages = generation.base().pages();
    let page_count = pages.rows().div_ceil(pages.page_rows());
    let regions = (page_count * 1024).div_ceil(3907);
    let router_started = Instant::now();
    let nominees = generation
        .base()
        .router()
        .router
        .nominate(query, regions, 512)
        .map_err(|error| invalid(format!("query {query_ordinal} router: {error:?}")))?;
    let router_ns = router_started.elapsed().as_nanos();
    if nominees.len() != 512
        || nominees.iter().copied().collect::<HashSet<_>>()
            != sealed.nominees.iter().copied().collect::<HashSet<_>>()
    {
        return Err(invalid(format!("query {query_ordinal} nominee set differs")).into());
    }
    let nominee_started = Instant::now();
    let scored = mirror.score(&nominees, query)?;
    let primary = primary_ordinals(&scored, 100)
        .map_err(|error| invalid(format!("query {query_ordinal} primary: {error:?}")))?;
    let router_ids = scored
        .iter()
        .map(|row| u64::try_from(row.id).map_err(|_| invalid("negative nominee ID")))
        .collect::<Result<Vec<_>, _>>()?;
    let nominee_ns = nominee_started.elapsed().as_nanos();
    if primary.len() != 100
        || primary.iter().copied().collect::<HashSet<_>>()
            != sealed.primary.iter().copied().collect::<HashSet<_>>()
    {
        return Err(invalid(format!("query {query_ordinal} primary set differs")).into());
    }
    let planner_started = Instant::now();
    let (_, plan) = plan_weighted_nominee_pages(
        pages.rows(),
        pages.dimensions(),
        pages.page_rows(),
        &primary,
        &nominees,
        MAX_GETS,
        MAX_BYTES,
    )?;
    let planner_ns = planner_started.elapsed().as_nanos();
    let ranges = plan
        .ranges
        .iter()
        .map(|range| [range.start, range.end])
        .collect::<Vec<_>>();
    if ranges != sealed.candidate_ranges {
        return Err(invalid(format!("query {query_ordinal} candidate ranges differ")).into());
    }
    Ok((
        PreparedRoute {
            started,
            router_ids,
            router_ns,
            nominee_ns,
            planner_ns,
            nominee_order_differs: nominees != sealed.nominees,
            primary_order_differs: primary != sealed.primary,
        },
        ranges,
    ))
}

fn run_arm(
    query_ordinal: usize,
    arm: &str,
    query: &[f32],
    truth: &[u64],
    nominees: &[usize],
    ranges: &[[usize; 2]],
    expected: &ReplayArm,
    mirror: &ExactSq8Mirror,
    generation: &ExactServingGeneration<'_>,
    prepared: Option<&PreparedRoute>,
) -> Result<Value, Box<dyn Error>> {
    let total_started = prepared.map_or_else(Instant::now, |route| route.started);
    let (router_ids, mirror_ns) = if let Some(route) = prepared {
        (route.router_ids.clone(), route.nominee_ns)
    } else {
        let mirror_started = Instant::now();
        let ids = mirror
            .score(nominees, query)?
            .into_iter()
            .map(|row| u64::try_from(row.id).map_err(|_| invalid("negative nominee ID")))
            .collect::<Result<Vec<_>, _>>()?;
        (ids, mirror_started.elapsed().as_nanos())
    };
    let spans = exact_page_spans(generation.base().pages(), ranges)?;
    let read_started = Instant::now();
    let fetched = spans
        .iter()
        .enumerate()
        .map(|(number, &(first, last, bytes))| {
            mirror
                .read_verified_pages(generation.base().pages(), first, last, bytes)
                .map_err(|error| {
                    invalid(format!(
                        "query {query_ordinal} {arm} local range {number} failed: {error:?}"
                    ))
                })
        })
        .collect::<Result<Vec<_>, _>>()?;
    let read_ns = read_started.elapsed().as_nanos();
    let response_bytes = fetched.iter().map(|range| range.bytes.len()).sum::<usize>();
    if response_bytes != spans.iter().map(|span| span.2).sum::<usize>() {
        return Err(invalid("local SQ8 read byte inventory differs").into());
    }
    let sq8_block_reads = fetched
        .iter()
        .map(|range| range.verified_block_reads)
        .sum::<usize>();
    let returned = fetched
        .iter()
        .map(|range| ReturnedRange {
            start: range.start,
            bytes: &range.bytes,
        })
        .collect::<Vec<_>>();
    let sq8_ranked = rank_returned_ranges(
        generation.base().mirror().geometry,
        &returned,
        query,
        &generation.base().mirror().low,
        &generation.base().mirror().step,
        EXPANSION,
        MAX_BYTES,
    )
    .map_err(|error| invalid(format!("returned SQ8 score: {error:?}")))?;
    let sq8_first = sq8_ranked
        .iter()
        .take(TOP_K)
        .map(|row| row.id)
        .collect::<HashSet<_>>();
    let expected_sq8 = expected
        .sq8_returned_ids
        .iter()
        .copied()
        .collect::<HashSet<_>>();
    if sq8_first.len() != TOP_K || sq8_first != expected_sq8 {
        return Err(invalid(format!(
            "query {query_ordinal} {arm} SQ8 top-100 set differs"
        ))
        .into());
    }
    let expanded_ids = sq8_ranked
        .iter()
        .map(|row| u64::try_from(row.id).map_err(|_| invalid("negative SQ8 ID")))
        .collect::<Result<Vec<_>, _>>()?;
    let candidates =
        generation
            .map()
            .resolve_union(generation.source(), &router_ids, &expanded_ids)?;
    let source_started = Instant::now();
    let (ranked, local) = generation
        .source()
        .rank_exact_with_stats(query, &candidates, TOP_K)?;
    let source_ns = source_started.elapsed().as_nanos();
    if candidates.len() != expected.candidate_count
        || local.local_read_bytes != expected.local_read_bytes
        || local.verified_block_reads != expected.verified_block_reads
    {
        return Err(invalid(format!(
            "query {query_ordinal} {arm} source roster or reads differ"
        ))
        .into());
    }
    let ids = ranked.iter().map(|row| row.source_id).collect::<Vec<_>>();
    let actual = ids.iter().copied().collect::<HashSet<_>>();
    let expected_set = expected
        .returned_ids
        .iter()
        .copied()
        .collect::<HashSet<_>>();
    if actual.len() != TOP_K || actual != expected_set {
        return Err(invalid(format!(
            "query {query_ordinal} {arm} source top-100 set differs"
        ))
        .into());
    }
    let truth_set = truth.iter().copied().collect::<HashSet<_>>();
    let hits = actual.intersection(&truth_set).count();
    if hits != expected.hits {
        return Err(invalid(format!("query {query_ordinal} {arm} GT hits differ")).into());
    }
    Ok(json!({
        "hits": hits, "source_ids": ids, "candidate_count": candidates.len(),
        "range_reads": ranges.len(), "sq8_read_bytes": response_bytes,
        "sq8_verified_block_reads": sq8_block_reads,
        "mirror_ns": mirror_ns, "sq8_read_ns": read_ns, "source_ns": source_ns,
        "router_ns":prepared.map_or(0, |route| route.router_ns),
        "planner_ns":prepared.map_or(0, |route| route.planner_ns),
        "nominee_order_differs":prepared.is_some_and(|route| route.nominee_order_differs),
        "primary_order_differs":prepared.is_some_and(|route| route.primary_order_differs),
        "total_ns": total_started.elapsed().as_nanos(),
        "local_read_bytes": local.local_read_bytes,
        "verified_block_reads": local.verified_block_reads,
    }))
}

fn run_concurrent(
    queries: &[Query],
    evidence: &[Evidence],
    replay: &[Replay],
    mirror: &ExactSq8Mirror,
    generation: &ExactServingGeneration<'_>,
    output_path: &str,
    summary_path: &str,
    startup_ns: u128,
) -> Result<(), Box<dyn Error>> {
    const REPEATS: usize = 8;
    let mut output = BufWriter::new(File::create(output_path)?);
    let mut cells = Vec::new();
    // One complete, verified untimed pass hydrates the shared file cache.
    // Timed cells therefore compare concurrency, not startup hydration.
    for ordinal in 0..queries.len() {
        let query = &queries[ordinal];
        let sealed = &evidence[ordinal];
        let historical = &replay[ordinal];
        if query.query_ordinal != ordinal
            || sealed.query_ordinal != ordinal
            || historical.query_ordinal != ordinal
            || query.source_query_ordinal != 9_000 + ordinal
            || sealed.source_query_ordinal != query.source_query_ordinal
            || historical.source_query_ordinal != query.source_query_ordinal
        {
            return Err(invalid(format!("query {ordinal} identity differs")).into());
        }
        let (prepared, ranges) =
            prepare_candidate_route(ordinal, &query.query, sealed, mirror, generation)?;
        run_arm(
            ordinal,
            "candidate",
            &query.query,
            &sealed.truth_ids,
            &sealed.nominees,
            &ranges,
            &historical.candidate,
            mirror,
            generation,
            Some(&prepared),
        )?;
    }
    for concurrency in [1usize, 8, 32] {
        let requests = REPEATS * queries.len();
        let next = AtomicUsize::new(0);
        let started = Instant::now();
        let mut records = thread::scope(|scope| {
            let mut handles = Vec::new();
            for _ in 0..concurrency {
                let next = &next;
                handles.push(scope.spawn(move || -> Result<Vec<(usize, Value)>, String> {
                    let mut local = Vec::new();
                    loop {
                        let request_ordinal = next.fetch_add(1, AtomicOrdering::Relaxed);
                        if request_ordinal >= requests {
                            break;
                        }
                        let ordinal = request_ordinal % queries.len();
                        let query = &queries[ordinal];
                        let sealed = &evidence[ordinal];
                        let historical = &replay[ordinal];
                        let (prepared, ranges) = prepare_candidate_route(
                            ordinal,
                            &query.query,
                            sealed,
                            mirror,
                            generation,
                        )
                        .map_err(|error| error.to_string())?;
                        let record = run_arm(
                            ordinal,
                            "candidate",
                            &query.query,
                            &sealed.truth_ids,
                            &sealed.nominees,
                            &ranges,
                            &historical.candidate,
                            mirror,
                            generation,
                            Some(&prepared),
                        )
                        .map_err(|error| error.to_string())?;
                        local.push((request_ordinal, record));
                    }
                    Ok(local)
                }));
            }
            let mut all = Vec::with_capacity(requests);
            for handle in handles {
                let worker = handle
                    .join()
                    .map_err(|_| invalid("concurrent worker panicked"))?;
                all.extend(worker.map_err(invalid)?);
            }
            Ok::<Vec<(usize, Value)>, io::Error>(all)
        })?;
        let wall_ns = started.elapsed().as_nanos();
        records.sort_unstable_by_key(|record| record.0);
        if records.len() != requests
            || records
                .iter()
                .enumerate()
                .any(|(index, row)| row.0 != index)
        {
            return Err(invalid("concurrent request inventory differs").into());
        }
        let mut times = Vec::with_capacity(requests);
        let mut hits = 0usize;
        let mut range_reads = 0usize;
        let mut sq8_bytes = 0usize;
        for (request_ordinal, record) in records {
            let query_ordinal = request_ordinal % queries.len();
            times.push(
                record["total_ns"]
                    .as_u64()
                    .ok_or_else(|| invalid("total time"))? as u128,
            );
            hits += record["hits"].as_u64().ok_or_else(|| invalid("hits"))? as usize;
            range_reads += record["range_reads"]
                .as_u64()
                .ok_or_else(|| invalid("range reads"))? as usize;
            sq8_bytes += record["sq8_read_bytes"]
                .as_u64()
                .ok_or_else(|| invalid("SQ8 bytes"))? as usize;
            writeln!(
                output,
                "{}",
                json!({
                    "concurrency":concurrency,"request_ordinal":request_ordinal,
                    "query_ordinal":query_ordinal,
                    "source_query_ordinal":queries[query_ordinal].source_query_ordinal,
                    "candidate":record,
                })
            )?;
        }
        output.flush()?;
        cells.push(json!({
            "concurrency":concurrency,"requests":requests,"hits":hits,
            "range_reads":range_reads,"sq8_read_bytes":sq8_bytes,
            "wall_ns":wall_ns,"throughput_qps":requests as f64 * 1e9 / wall_ns as f64,
            "p50_ms":percentile_ms(&times,50),"p95_ms":percentile_ms(&times,95),
            "p99_ms":percentile_ms(&times,99),
        }));
    }
    fs::write(
        summary_path,
        serde_json::to_vec(&json!({
            "schema":"borsuk-v136-concurrent-local-route-v1",
            "generation_manifest_sha256":AUTHORITY_SHA,
            "queries":queries.len(),"repeats":REPEATS,
            "startup_auth_ns":startup_ns,"cells":cells,
        }))?,
    )?;
    Ok(())
}

fn run() -> Result<(), Box<dyn Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    if args.len() != 4 && !(args.len() == 5 && args[4] == "--concurrent") {
        return Err(invalid(
            "usage: v134_native_route prepared-dir output.jsonl summary.json [--concurrent]",
        )
        .into());
    }
    let root = Path::new(&args[1]);
    let startup = Instant::now();
    let authority_bytes = fs::read(root.join("generation.json"))?;
    if sha256(&authority_bytes) != AUTHORITY_SHA {
        return Err(invalid("generation manifest SHA-256").into());
    }
    let authority: Value = serde_json::from_slice(&authority_bytes)?;
    if authority["schema"] != "borsuk-v132-live-serving-generation-v1"
        || authority["generation"] != 131
    {
        return Err(invalid("generation manifest identity").into());
    }
    let queries = checked_lines::<Query>(
        &root.join("queries.jsonl"),
        field(&authority, "inputs", "queries.jsonl", "sha256")?,
    )?;
    let evidence = checked_lines::<Evidence>(
        &root.join("evidence.jsonl"),
        field(&authority, "inputs", "evidence.jsonl", "sha256")?,
    )?;
    let replay = checked_lines::<Replay>(&root.join("replay.jsonl"), V131_REPLAY_SHA)?;
    if queries.len() != 1_000 || evidence.len() != queries.len() || replay.len() != queries.len() {
        return Err(invalid("sealed cohort count").into());
    }
    let router = load_source_router(
        &root.join("router"),
        field(&authority, "derived", "router_manifest", "sha256")?,
    )?;
    let mirror_manifest = MirrorManifest {
        format_version: 1,
        generation: 131,
        max_nominees: 512,
        geometry: Sq8Geometry {
            rows: 100_000,
            dimensions: 96,
        },
        object_sha256: field(&authority, "inputs", "sq8", "sha256")?.to_owned(),
        block_digest_sha256: field(&authority, "derived", "mirror_digests", "sha256")?.to_owned(),
        low: router.low.clone(),
        step: router.step.clone(),
    };
    let mirror = ExactSq8Mirror::open(
        &root.join("sq8.bin"),
        &root.join("mirror-digests.bin"),
        mirror_manifest.clone(),
        Placement::File,
    )?;
    let pages = PageAuthority::load(
        &fs::read(root.join("page-manifest.json"))?,
        field(&authority, "derived", "page_manifest", "sha256")?,
        &fs::read(root.join("page-digests.bin"))?,
    )
    .map_err(|error| invalid(format!("page authority {error:?}")))?;
    let source = NativeSourceTier::open_authenticated(
        &root.join("source-tier.bin"),
        field(&authority, "inputs", "source_tier", "sha256")?,
        authority["source_sha256"]
            .as_str()
            .ok_or_else(|| invalid("source SHA"))?,
        100_000,
        96,
        131,
        65_536,
    )?;
    let map = NativeSourceIdMap::open_authenticated(
        &root.join("source-id-map.bin"),
        field(&authority, "inputs", "source_id_map", "sha256")?,
        authority["source_sha256"]
            .as_str()
            .ok_or_else(|| invalid("source SHA"))?,
        field(&authority, "inputs", "source_tier", "sha256")?,
        100_000,
        131,
    )?;
    let sq8_uri = field(&authority, "inputs", "sq8", "uri")?;
    let sq8_key = sq8_uri
        .strip_prefix("s3://borsuk-bench-453182569524-euc1/")
        .ok_or_else(|| invalid("SQ8 bucket differs"))?;
    let sq8_etag = field(&authority, "inputs", "sq8", "etag")?;
    let base = ServingGeneration::bind(&router, &mirror_manifest, &pages, sq8_key, sq8_etag)
        .map_err(|error| invalid(format!("serving generation {error:?}")))?;
    let generation = ExactServingGeneration::bind(base, &source, &map)
        .map_err(|error| invalid(format!("exact generation {error:?}")))?;
    let startup_ns = startup.elapsed().as_nanos();
    if args.len() == 5 {
        return run_concurrent(
            &queries,
            &evidence,
            &replay,
            &mirror,
            &generation,
            &args[2],
            &args[3],
            startup_ns,
        );
    }
    let mut output = BufWriter::new(File::create(&args[2])?);
    let mut totals = [0usize; 2];
    let mut ranges_read = [0usize; 2];
    let mut bytes = [0usize; 2];
    let mut sq8_blocks = [0usize; 2];
    let mut times = [Vec::<u128>::new(), Vec::<u128>::new()];
    let mut read_times = [Vec::<u128>::new(), Vec::<u128>::new()];
    let mut source_times = [Vec::<u128>::new(), Vec::<u128>::new()];
    let mut router_times = Vec::<u128>::new();
    let mut nominee_times = Vec::<u128>::new();
    let mut planner_times = Vec::<u128>::new();
    let mut nominee_order_differences = 0usize;
    let mut primary_order_differences = 0usize;
    let mut paired = [0usize; 3];
    let mut local_bytes = [0u64; 2];
    let mut local_blocks = [0u64; 2];
    for (ordinal, ((query, sealed), historical)) in
        queries.iter().zip(&evidence).zip(&replay).enumerate()
    {
        if query.query_ordinal != ordinal
            || sealed.query_ordinal != ordinal
            || historical.query_ordinal != ordinal
            || query.source_query_ordinal != 9_000 + ordinal
            || sealed.source_query_ordinal != query.source_query_ordinal
            || historical.source_query_ordinal != query.source_query_ordinal
            || query.query.len() != 96
            || sealed.truth_ids.len() != TOP_K
            || sealed.nominees.len() != 512
            || sealed.primary.len() != TOP_K
        {
            return Err(invalid(format!("query {ordinal} identity differs")).into());
        }
        let mut arms = [
            (
                0,
                "candidate",
                &sealed.candidate_ranges,
                &historical.candidate,
            ),
            (1, "baseline", &sealed.baseline_ranges, &historical.baseline),
        ];
        if ordinal % 2 == 1 {
            arms.swap(0, 1);
        }
        let mut records = [Value::Null, Value::Null];
        for (index, name, ranges, expected) in arms {
            let (prepared, dynamic_ranges) = if index == 0 {
                let (prepared, dynamic_ranges) =
                    prepare_candidate_route(ordinal, &query.query, sealed, &mirror, &generation)?;
                (Some(prepared), Some(dynamic_ranges))
            } else {
                (None, None)
            };
            let effective_ranges: &[[usize; 2]] = dynamic_ranges.as_deref().unwrap_or(ranges);
            let record = run_arm(
                ordinal,
                name,
                &query.query,
                &sealed.truth_ids,
                &sealed.nominees,
                effective_ranges,
                expected,
                &mirror,
                &generation,
                prepared.as_ref(),
            )?;
            if index == 0 {
                router_times.push(
                    record["router_ns"]
                        .as_u64()
                        .ok_or_else(|| invalid("router time record"))? as u128,
                );
                nominee_times.push(
                    record["mirror_ns"]
                        .as_u64()
                        .ok_or_else(|| invalid("nominee time record"))? as u128,
                );
                planner_times.push(
                    record["planner_ns"]
                        .as_u64()
                        .ok_or_else(|| invalid("planner time record"))? as u128,
                );
                nominee_order_differences += usize::from(
                    record["nominee_order_differs"]
                        .as_bool()
                        .ok_or_else(|| invalid("nominee order record"))?,
                );
                primary_order_differences += usize::from(
                    record["primary_order_differs"]
                        .as_bool()
                        .ok_or_else(|| invalid("primary order record"))?,
                );
            }
            totals[index] += record["hits"]
                .as_u64()
                .ok_or_else(|| invalid("hit record"))? as usize;
            ranges_read[index] += record["range_reads"]
                .as_u64()
                .ok_or_else(|| invalid("range read record"))?
                as usize;
            bytes[index] += record["sq8_read_bytes"]
                .as_u64()
                .ok_or_else(|| invalid("byte record"))? as usize;
            sq8_blocks[index] += record["sq8_verified_block_reads"]
                .as_u64()
                .ok_or_else(|| invalid("SQ8 block record"))?
                as usize;
            times[index].push(
                record["total_ns"]
                    .as_u64()
                    .ok_or_else(|| invalid("time record"))? as u128,
            );
            read_times[index].push(
                record["sq8_read_ns"]
                    .as_u64()
                    .ok_or_else(|| invalid("SQ8 read time record"))? as u128,
            );
            source_times[index].push(
                record["source_ns"]
                    .as_u64()
                    .ok_or_else(|| invalid("source time record"))? as u128,
            );
            local_bytes[index] += record["local_read_bytes"]
                .as_u64()
                .ok_or_else(|| invalid("local byte record"))?;
            local_blocks[index] += record["verified_block_reads"]
                .as_u64()
                .ok_or_else(|| invalid("local block record"))?;
            records[index] = record;
        }
        let candidate_hits = records[0]["hits"]
            .as_u64()
            .ok_or_else(|| invalid("candidate hits"))?;
        let baseline_hits = records[1]["hits"]
            .as_u64()
            .ok_or_else(|| invalid("baseline hits"))?;
        paired[if candidate_hits > baseline_hits {
            0
        } else if candidate_hits == baseline_hits {
            1
        } else {
            2
        }] += 1;
        writeln!(
            output,
            "{}",
            json!({"query_ordinal":ordinal,
            "source_query_ordinal":query.source_query_ordinal,
            "candidate":records[0],"baseline":records[1]})
        )?;
    }
    output.flush()?;
    let candidate_p95 = percentile_ms(&times[0], 95);
    let control_p95 = percentile_ms(&times[1], 95);
    let summary = json!({
        "schema":"borsuk-v134-native-route-v1",
        "generation_manifest_sha256":AUTHORITY_SHA,
        "query_count":queries.len(),"startup_auth_ns":startup_ns,
        "paired_candidate_wins":paired[0],"paired_ties":paired[1],"paired_baseline_wins":paired[2],
        "qualifies_serial_route":totals == [99_942,98_827] && candidate_p95 <= 75.624654,
        "nominee_order_differences":nominee_order_differences,
        "primary_order_differences":primary_order_differences,
        "candidate_router_p50_ms":percentile_ms(&router_times,50),
        "candidate_router_p95_ms":percentile_ms(&router_times,95),
        "candidate_router_p99_ms":percentile_ms(&router_times,99),
        "candidate_nominee_p50_ms":percentile_ms(&nominee_times,50),
        "candidate_nominee_p95_ms":percentile_ms(&nominee_times,95),
        "candidate_nominee_p99_ms":percentile_ms(&nominee_times,99),
        "candidate_planner_p50_ms":percentile_ms(&planner_times,50),
        "candidate_planner_p95_ms":percentile_ms(&planner_times,95),
        "candidate_planner_p99_ms":percentile_ms(&planner_times,99),
        "candidate": {"hits":totals[0],"range_reads":ranges_read[0],"sq8_read_bytes":bytes[0],
            "sq8_verified_block_reads":sq8_blocks[0],
            "local_read_bytes":local_bytes[0],"verified_block_reads":local_blocks[0],
            "p50_ms":percentile_ms(&times[0],50),"p95_ms":candidate_p95,
            "p99_ms":percentile_ms(&times[0],99),
            "sq8_read_p50_ms":percentile_ms(&read_times[0],50),
            "sq8_read_p95_ms":percentile_ms(&read_times[0],95),
            "sq8_read_p99_ms":percentile_ms(&read_times[0],99),
            "source_p50_ms":percentile_ms(&source_times[0],50),
            "source_p95_ms":percentile_ms(&source_times[0],95),
            "source_p99_ms":percentile_ms(&source_times[0],99)},
        "baseline": {"hits":totals[1],"range_reads":ranges_read[1],"sq8_read_bytes":bytes[1],
            "sq8_verified_block_reads":sq8_blocks[1],
            "local_read_bytes":local_bytes[1],"verified_block_reads":local_blocks[1],
            "p50_ms":percentile_ms(&times[1],50),"p95_ms":control_p95,
            "p99_ms":percentile_ms(&times[1],99),
            "sq8_read_p50_ms":percentile_ms(&read_times[1],50),
            "sq8_read_p95_ms":percentile_ms(&read_times[1],95),
            "sq8_read_p99_ms":percentile_ms(&read_times[1],99),
            "source_p50_ms":percentile_ms(&source_times[1],50),
            "source_p95_ms":percentile_ms(&source_times[1],95),
            "source_p99_ms":percentile_ms(&source_times[1],99)},
    });
    fs::write(&args[3], serde_json::to_vec(&summary)?)?;
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    run()
}
