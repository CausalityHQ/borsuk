use std::{
    cmp::{Ordering, Reverse},
    collections::{BTreeMap, BTreeSet, BinaryHeap, HashMap, HashSet},
    fs::{self, File, OpenOptions},
    io::{BufReader, BufWriter, Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::Arc,
    time::Instant,
};

use arrow_array::{
    Array, ArrayRef, FixedSizeBinaryArray, FixedSizeListArray, Float32Array, Float64Array,
    Int64Array, RecordBatch, UInt8Array, UInt16Array, UInt32Array, UInt64Array,
};
use arrow_ipc::{
    MetadataVersion,
    reader::{FileReader as ArrowFileReader, read_footer_length},
    root_as_footer, root_as_message,
    writer::{FileWriter as ArrowFileWriter, IpcWriteOptions},
};
use arrow_schema::{DataType, Field, Schema};
use futures_util::StreamExt;
use object_store::{ObjectStore, ObjectStoreExt, ObjectStoreScheme};
use parquet::{
    arrow::{
        ArrowSchemaConverter, ArrowWriter, ProjectionMask,
        arrow_reader::ParquetRecordBatchReaderBuilder,
    },
    file::properties::WriterProperties,
    file::reader::ChunkReader,
    schema::types::SchemaDescriptor,
};
use rayon::{ThreadPoolBuilder, prelude::*};
use sha2::{Digest, Sha256};

use crate::v36_funnel::{
    canonical_v36_prefix_checkpoint_population_authority_bytes,
    canonical_v36_prefix_checkpoint_source_registry_bytes,
};
use crate::{
    BorsukError, Result, V36ArtifactIdentity, V36PrefixCheckpointContext,
    V36PrefixCheckpointManifest, V36PrefixCheckpointPhase, V36PrefixCheckpointPointer,
    V36PrefixCheckpointPublication, V36PrefixFreezeAuthority, V36PrefixFreezeExecutionAuthority,
    V36PrefixFreezeReceipt, V36PrefixMaterializedArtifacts, V36PrefixPopulationAuthority,
    V36PrefixPopulationCheckpoint, V36PrefixPopulationSelection, V36PrefixRegisteredSourceObject,
    V36PrefixRoleAuthority, V36PrefixSourceObject, bind_v36_prefix_population_authority,
    canonical_v36_prefix_checkpoint_manifest_bytes, canonical_v36_prefix_checkpoint_pointer_bytes,
    canonical_v36_prefix_freeze_authority_bytes,
    canonical_v36_prefix_freeze_execution_authority_bytes,
    canonical_v36_prefix_freeze_receipt_bytes, plan_v36_prefix_checkpoint_dependency_closure,
    plan_v36_prefix_checkpoint_publication, validate_v36_prefix_checkpoint_manifest_with_context,
    validate_v36_prefix_checkpoint_transition, validate_v36_prefix_freeze_authority,
    validate_v36_prefix_freeze_execution_authority, validate_v36_prefix_freeze_receipt,
    validate_v36_prefix_population_authority,
};
use crate::{
    v35_projection::project_v35_query_simd,
    v36_funnel_geometry::{
        V36PostingContainmentDiagnostic, V36PostingScoreContainment,
        V36ProjectedCorpusBlockVisitor, V36ProjectedCorpusSource, V36ResidentPostingDiagnostic,
        V36ResidentPostingScoreModel, build_v36_srht192_control,
        evaluate_v36_posting_prefix_containment, evaluate_v36_posting_score_containment_with_model,
    },
};

const DIMENSIONS: usize = 768;
const GT_NEIGHBORS: usize = 100;
const GT_NEIGHBORS_U64: u64 = 100;
const DISTINCT_CANDIDATES: usize = 1_100_000;
const CORPUS_ROWS: usize = 1_000_000;
const PARQUET_ROW_GROUP_ROWS: usize = 65_536;
pub(crate) const SOURCE_DECODER_COMPRESSED_CAP_BYTES: u64 = 256 * 1_048_576;
pub(crate) const SOURCE_DECODER_UNCOMPRESSED_CAP_BYTES: u64 = 256 * 1_048_576;
const IDENTITY_RUN_BATCH_ROWS: usize = 65_536;
const IDENTITY_RUN_FORMAT: &str = "borsuk-v36-prefix-identity-run-v3";
const SELECTED_IDS_BATCH_ROWS: usize = 65_536;
const POPULATION_SCORE_ALGORITHM: &str =
    "sha256-seed-sha256-manifest-sha256-feature-row-id-le-u64-v2";
const POPULATION_SEED_SHA256: &str =
    "bcb490ff7944bfa3a0a6d5abe6d35ba34ecaba60b615e214edb057a1a5b63b8e";
const SELECTED_IDS_FORMAT: &str = "borsuk-v36-prefix-selected-identities-v2";
const ROLE_ASSIGNMENT_FORMAT: &str = "borsuk-v36-prefix-role-assignments-v1";
const ROLE_ASSIGNMENT_MAX_OWNED_BYTES: u64 = 48 * 1024 * 1024;

fn invalid(message: &str) -> BorsukError {
    BorsukError::InvalidStorage(message.to_owned())
}

fn resource_limit(message: &str) -> BorsukError {
    BorsukError::V36PrefixResourceLimit(message.to_owned())
}

fn temporary_output(path: &Path) -> Result<tempfile::NamedTempFile> {
    let parent = path
        .parent()
        .ok_or_else(|| invalid("V36 prefix output path has no parent"))?;
    tempfile::NamedTempFile::new_in(parent).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })
}

fn publish_output(temporary: tempfile::NamedTempFile, path: &Path) -> Result<()> {
    temporary
        .as_file()
        .sync_all()
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
    temporary.persist(path).map_err(|error| BorsukError::Io {
        path: path.to_owned(),
        source: error.error,
    })?;
    Ok(())
}

fn publish_output_noclobber(temporary: tempfile::NamedTempFile, path: &Path) -> Result<()> {
    temporary
        .as_file()
        .sync_all()
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
    temporary
        .persist_noclobber(path)
        .map_err(|error| BorsukError::Io {
            path: path.to_owned(),
            source: error.error,
        })?;
    sync_directory(
        path.parent()
            .ok_or_else(|| invalid("V36 prefix output path has no parent"))?,
    )
}

fn sync_directory(path: &Path) -> Result<()> {
    File::open(path)
        .and_then(|directory| directory.sync_all())
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })
}

fn install_content_addressed(path: &Path, bytes: &[u8]) -> Result<()> {
    if path.exists() {
        if read_file(path)? == bytes {
            return Ok(());
        }
        return Err(invalid("V36 checkpoint outbox object conflicts"));
    }
    let mut temporary = temporary_output(path)?;
    temporary
        .write_all(bytes)
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
    temporary
        .as_file()
        .sync_all()
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
    temporary
        .persist_noclobber(path)
        .map_err(|error| BorsukError::Io {
            path: path.to_owned(),
            source: error.error,
        })?;
    sync_directory(
        path.parent()
            .ok_or_else(|| invalid("V36 checkpoint outbox parent is missing"))?,
    )
}

fn install_content_addressed_file(
    path: &Path,
    source_path: &Path,
    identity: &V36ArtifactIdentity,
) -> Result<()> {
    if path.exists() {
        authenticate_file(path, identity)?;
        return Ok(());
    }
    let file_type = fs::symlink_metadata(source_path)
        .map_err(|source| BorsukError::Io {
            path: source_path.to_owned(),
            source,
        })?
        .file_type();
    if !file_type.is_file() || file_type.is_symlink() {
        return Err(invalid("V36 checkpoint dependency path differs"));
    }
    let mut source = File::open(source_path).map_err(|source| BorsukError::Io {
        path: source_path.to_owned(),
        source,
    })?;
    let mut temporary = temporary_output(path)?;
    let (sha256, blake3) = copy_v36_prefix_snapshot_exact(
        &mut source,
        &mut temporary,
        (source_path, path),
        identity.encoded_bytes,
        65_536,
    )?;
    if sha256 != identity.sha256 || blake3 != identity.blake3 {
        return Err(invalid(
            "V36 checkpoint outbox dependency authority differs",
        ));
    }
    publish_output_noclobber(temporary, path)
}

#[derive(serde::Serialize)]
struct V36PrefixCheckpointReady<'a> {
    dependencies: &'a [V36ArtifactIdentity],
    generation: u32,
    manifest: &'a V36ArtifactIdentity,
    pointer_encoded_bytes: u64,
    pointer_sha256: String,
    pointer_uri: &'a str,
    previous_pointer_sha256: &'a Option<String>,
    schema: &'static str,
}

#[derive(Debug)]
/// Private durable filesystem bridge from Rust science to the S3 supervisor.
pub struct V36PrefixCheckpointOutbox {
    root: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated local dependency installed without resident payload bytes.
pub struct V36PrefixCheckpointDependencyFile {
    /// Exact immutable artifact identity.
    pub identity: V36ArtifactIdentity,
    /// Exact local regular-file path.
    pub path: PathBuf,
}

impl V36PrefixCheckpointOutbox {
    /// Create one empty private outbox and its fixed subdirectories.
    pub fn create(root: &Path) -> Result<Self> {
        let metadata = fs::symlink_metadata(root).map_err(|source| BorsukError::Io {
            path: root.to_owned(),
            source,
        })?;
        if !metadata.file_type().is_dir()
            || metadata.file_type().is_symlink()
            || root
                .read_dir()
                .map_err(|source| BorsukError::Io {
                    path: root.to_owned(),
                    source,
                })?
                .next()
                .is_some()
        {
            return Err(invalid("V36 checkpoint outbox root differs"));
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(root, fs::Permissions::from_mode(0o700)).map_err(|source| {
                BorsukError::Io {
                    path: root.to_owned(),
                    source,
                }
            })?;
        }
        for child in ["objects", "manifests", "pointers", "commits"] {
            fs::create_dir(root.join(child)).map_err(|source| BorsukError::Io {
                path: root.join(child),
                source,
            })?;
        }
        sync_directory(root)?;
        Ok(Self {
            root: root.to_owned(),
        })
    }

    /// Commit one already validated publication, exposing its descriptor last.
    pub fn commit(
        &self,
        publication: &V36PrefixCheckpointPublication,
        dependencies: &[(V36ArtifactIdentity, Vec<u8>)],
    ) -> Result<PathBuf> {
        if dependencies.len() != publication.dependencies.len()
            || dependencies
                .iter()
                .zip(&publication.dependencies)
                .any(|((identity, _), expected)| identity != expected)
        {
            return Err(invalid("V36 checkpoint outbox dependencies differ"));
        }
        for (identity, bytes) in dependencies {
            if identity.encoded_bytes != u64::try_from(bytes.len()).unwrap_or(u64::MAX)
                || identity.sha256 != format!("{:x}", Sha256::digest(bytes))
                || identity.blake3 != blake3::hash(bytes).to_hex().as_str()
            {
                return Err(invalid(
                    "V36 checkpoint outbox dependency authority differs",
                ));
            }
        }
        for (identity, bytes) in dependencies {
            install_content_addressed(
                &self
                    .root
                    .join("objects")
                    .join(format!("{}.blob", identity.sha256)),
                bytes,
            )?;
        }
        self.commit_metadata(publication)
    }

    /// Commit file-backed dependencies without materializing their payloads.
    pub fn commit_files(
        &self,
        publication: &V36PrefixCheckpointPublication,
        dependencies: &[V36PrefixCheckpointDependencyFile],
    ) -> Result<PathBuf> {
        if dependencies.len() != publication.dependencies.len()
            || dependencies
                .iter()
                .zip(&publication.dependencies)
                .any(|(dependency, expected)| &dependency.identity != expected)
        {
            return Err(invalid("V36 checkpoint outbox dependencies differ"));
        }
        for dependency in dependencies {
            install_content_addressed_file(
                &self
                    .root
                    .join("objects")
                    .join(format!("{}.blob", dependency.identity.sha256)),
                &dependency.path,
                &dependency.identity,
            )?;
        }
        self.commit_metadata(publication)
    }

    fn commit_metadata(&self, publication: &V36PrefixCheckpointPublication) -> Result<PathBuf> {
        let manifest: V36PrefixCheckpointManifest =
            serde_json::from_slice(&publication.manifest_bytes)
                .map_err(|_| invalid("V36 checkpoint outbox manifest JSON differs"))?;
        let pointer: V36PrefixCheckpointPointer =
            serde_json::from_slice(&publication.pointer_bytes)
                .map_err(|_| invalid("V36 checkpoint outbox pointer JSON differs"))?;
        if publication.manifest.encoded_bytes
            != u64::try_from(publication.manifest_bytes.len()).unwrap_or(u64::MAX)
            || publication.manifest.sha256
                != format!("{:x}", Sha256::digest(&publication.manifest_bytes))
            || publication.manifest.blake3
                != blake3::hash(&publication.manifest_bytes).to_hex().as_str()
            || manifest.generation != pointer.generation
            || pointer.manifest != publication.manifest
        {
            return Err(invalid(
                "V36 checkpoint outbox publication authority differs",
            ));
        }
        install_content_addressed(
            &self
                .root
                .join("manifests")
                .join(format!("{}.json", publication.manifest.sha256)),
            &publication.manifest_bytes,
        )?;
        let pointer_sha256 = format!("{:x}", Sha256::digest(&publication.pointer_bytes));
        install_content_addressed(
            &self
                .root
                .join("pointers")
                .join(format!("{pointer_sha256}.json")),
            &publication.pointer_bytes,
        )?;
        let ready = V36PrefixCheckpointReady {
            dependencies: &publication.dependencies,
            generation: manifest.generation,
            manifest: &publication.manifest,
            pointer_encoded_bytes: publication.pointer_bytes.len() as u64,
            pointer_sha256,
            pointer_uri: &publication.pointer_uri,
            previous_pointer_sha256: &publication.previous_pointer_sha256,
            schema: "borsuk-v36-prefix-checkpoint-outbox-v1",
        };
        let mut ready_bytes = serde_json::to_vec(&ready)
            .map_err(|_| invalid("V36 checkpoint outbox commit JSON differs"))?;
        ready_bytes.push(b'\n');
        let ready_path = self
            .root
            .join("commits")
            .join(format!("generation-{:08}.json", manifest.generation));
        install_content_addressed(&ready_path, &ready_bytes)?;
        Ok(ready_path)
    }
}

#[derive(Debug)]
/// Stateful producer for crash-atomic complete-object population checkpoints.
pub struct V36PrefixPopulationCheckpointWriter {
    context: V36PrefixCheckpointContext,
    dependencies: Vec<V36PrefixCheckpointDependencyFile>,
    execution_authority_sha256: String,
    outbox: V36PrefixCheckpointOutbox,
    previous_manifest: Option<V36PrefixCheckpointManifest>,
    previous_manifest_identity: Option<V36ArtifactIdentity>,
    previous_pointer_bytes: Option<Vec<u8>>,
    producer_attempt_id: String,
    producer_attempt_ordinal: u8,
    producer_instance_id: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Fully authenticated local material needed to continue one published head.
pub struct V36PrefixCheckpointHead {
    authenticated_corpus_rows: u64,
    authenticated_dependencies: Vec<V36PrefixCheckpointDependencyFile>,
    authenticated_manifest: V36PrefixCheckpointManifest,
    authenticated_pointer_bytes: Vec<u8>,
    /// Cumulative identity-run artifacts and their authenticated local files.
    pub dependencies: Vec<V36PrefixCheckpointDependencyFile>,
    /// Newest immutable population manifest.
    pub manifest: V36PrefixCheckpointManifest,
    /// Exact canonical pointer bytes naming `manifest`.
    pub pointer_bytes: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated local files produced by the completed materialization phase.
pub struct V36PrefixMaterializedCheckpointFiles {
    authenticated_dependencies: Vec<V36PrefixCheckpointDependencyFile>,
    authenticated_ground_truth: Option<(V36PrefixCheckpointDependencyFile, u64)>,
    expected_source_rows: u64,
    /// Canonical population authority JSON.
    pub population_authority: V36PrefixCheckpointDependencyFile,
    /// Query-excluded source Parquet.
    pub source: V36PrefixCheckpointDependencyFile,
    /// Development query Parquet.
    pub development_query: V36PrefixCheckpointDependencyFile,
    /// Validation query Parquet.
    pub validation_query: V36PrefixCheckpointDependencyFile,
    /// Sealed-holdout query Parquet.
    pub sealed_holdout_query: V36PrefixCheckpointDependencyFile,
    /// Performance query Parquet.
    pub performance_query: V36PrefixCheckpointDependencyFile,
}

impl V36PrefixMaterializedCheckpointFiles {
    fn validate_authenticated_seal(&self) -> Result<()> {
        let current = [
            &self.population_authority,
            &self.source,
            &self.development_query,
            &self.validation_query,
            &self.sealed_holdout_query,
            &self.performance_query,
        ];
        if self.authenticated_dependencies.len() != current.len()
            || self
                .authenticated_dependencies
                .iter()
                .zip(current)
                .any(|(authenticated, current)| authenticated != current)
        {
            return Err(invalid(
                "V36 checkpoint authenticated materialization differs",
            ));
        }
        Ok(())
    }

    fn validate_ground_truth_seal(
        &self,
        heaps: &V36PrefixCheckpointDependencyFile,
        next_source_ordinal: u64,
    ) -> Result<()> {
        self.validate_authenticated_seal()?;
        if self.authenticated_ground_truth.as_ref() != Some(&(heaps.clone(), next_source_ordinal)) {
            return Err(invalid("V36 checkpoint authenticated ground truth differs"));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Typed file-backed continuation point reconstructed from one checkpoint head.
pub enum V36PrefixCheckpointResumeState {
    /// Continue the incomplete complete-object population scan.
    Population {
        /// Authenticated complete-object population prefix.
        population: V36PrefixFileBackedPopulationScan,
    },
    /// Population selection is complete; continue role assignment/materialization.
    Selected {
        /// Authenticated complete-object population prefix.
        population: V36PrefixFileBackedPopulationScan,
        /// Authenticated selected-identity Arrow file.
        selected: V36PrefixSelectedIdsFile,
    },
    /// Role Parquets are complete; continue exact ground truth.
    Materialized {
        /// Authenticated materialized output files.
        artifacts: Box<V36PrefixMaterializedCheckpointFiles>,
        /// Authenticated complete-object population prefix.
        population: V36PrefixFileBackedPopulationScan,
        /// Authenticated selected-identity Arrow file.
        selected: V36PrefixSelectedIdsFile,
    },
    /// Ground-truth heaps are complete through one source-row boundary.
    GroundTruth {
        /// Authenticated materialized output files.
        artifacts: Box<V36PrefixMaterializedCheckpointFiles>,
        /// Authenticated heap Arrow file.
        heaps: V36PrefixCheckpointDependencyFile,
        /// First source ordinal not represented by `heaps`.
        next_source_ordinal: u64,
        /// Authenticated complete-object population prefix.
        population: V36PrefixFileBackedPopulationScan,
        /// Authenticated selected-identity Arrow file.
        selected: V36PrefixSelectedIdsFile,
    },
    /// Exact quality GT Parquets are complete and authenticated.
    Complete {
        /// Authenticated materialized output files.
        artifacts: Box<V36PrefixMaterializedCheckpointFiles>,
        /// Authenticated heap and three exact-GT Parquet files.
        ground_truth: Box<[V36PrefixCheckpointDependencyFile; 4]>,
        /// Authenticated complete-object population prefix.
        population: V36PrefixFileBackedPopulationScan,
        /// Authenticated selected-identity Arrow file.
        selected: V36PrefixSelectedIdsFile,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
/// Next bounded action implied by an authenticated checkpoint phase.
pub enum V36PrefixCheckpointAction {
    /// Build or resume the complete file-backed population prefix.
    Populate,
    /// Select the registered population without resident bulk state.
    Select,
    /// Materialize the source and disjoint query roles.
    Materialize,
    /// Compute or resume exact ground truth from materialized Parquet.
    GroundTruth,
    /// Materialize exact-GT Parquet and publish the terminal checkpoint.
    Complete,
    /// The terminal checkpoint is already authenticated.
    Finished,
}

/// Resolve exactly one next action from the durable phase boundary.
pub fn next_v36_prefix_checkpoint_action(
    manifest: Option<&V36PrefixCheckpointManifest>,
    corpus_rows: u64,
    distinct_candidates: u64,
) -> Result<V36PrefixCheckpointAction> {
    if corpus_rows == 0 || distinct_candidates == 0 {
        return Err(invalid("V36 prefix checkpoint corpus rows differ"));
    }
    Ok(match manifest {
        None => V36PrefixCheckpointAction::Populate,
        Some(
            manifest @ V36PrefixCheckpointManifest {
                phase: V36PrefixCheckpointPhase::Population,
                ..
            },
        ) => {
            if manifest.population.completed_objects < manifest.population.selected_object_count {
                V36PrefixCheckpointAction::Populate
            } else if manifest.population.completed_objects
                == manifest.population.selected_object_count
            {
                if manifest.population.distinct_rows < distinct_candidates {
                    return Err(BorsukError::V36PrefixSourceInsufficient);
                }
                V36PrefixCheckpointAction::Select
            } else {
                return Err(invalid("V36 prefix checkpoint population progress differs"));
            }
        }
        Some(V36PrefixCheckpointManifest {
            phase: V36PrefixCheckpointPhase::Selected { .. },
            ..
        }) => V36PrefixCheckpointAction::Materialize,
        Some(V36PrefixCheckpointManifest {
            phase: V36PrefixCheckpointPhase::Materialized { .. },
            ..
        }) => V36PrefixCheckpointAction::GroundTruth,
        Some(V36PrefixCheckpointManifest {
            phase:
                V36PrefixCheckpointPhase::GroundTruth {
                    next_source_ordinal,
                    ..
                },
            ..
        }) => {
            if *next_source_ordinal < corpus_rows {
                V36PrefixCheckpointAction::GroundTruth
            } else if *next_source_ordinal == corpus_rows {
                V36PrefixCheckpointAction::Complete
            } else {
                return Err(invalid("V36 prefix checkpoint GT progress differs"));
            }
        }
        Some(V36PrefixCheckpointManifest {
            phase: V36PrefixCheckpointPhase::Complete { .. },
            ..
        }) => V36PrefixCheckpointAction::Finished,
    })
}

impl V36PrefixCheckpointHead {
    fn validate_authenticated_seal(&self) -> Result<()> {
        if self.dependencies != self.authenticated_dependencies
            || self.manifest != self.authenticated_manifest
            || self.pointer_bytes != self.authenticated_pointer_bytes
        {
            return Err(invalid("V36 checkpoint authenticated head differs"));
        }
        Ok(())
    }

    fn identity_runs(&self) -> Result<Vec<V36PrefixIdentityRun>> {
        self.validate_authenticated_seal()?;
        let selected_object_start = self.manifest.population.selected_object_start;
        self.dependencies
            .iter()
            .take(self.manifest.population.identity_runs.len())
            .enumerate()
            .map(|(ordinal, dependency)| {
                let selected_object_ordinal = selected_object_start
                    .checked_add(
                        u16::try_from(ordinal)
                            .map_err(|_| invalid("V36 population checkpoint ordinal overflows"))?,
                    )
                    .ok_or_else(|| invalid("V36 population checkpoint ordinal overflows"))?;
                let source = self
                    .manifest
                    .population
                    .consumed_objects
                    .get(ordinal)
                    .ok_or_else(|| invalid("V36 population checkpoint resume state differs"))?;
                let bytes = read_file(&dependency.path)?;
                decode_v36_prefix_identity_run(
                    &bytes,
                    &dependency.identity,
                    source,
                    selected_object_ordinal,
                )
            })
            .collect()
    }
}

/// Load one exact locally staged newest checkpoint head without history fallback.
pub fn load_v36_prefix_checkpoint_head(
    root: &Path,
    context: &V36PrefixCheckpointContext,
) -> Result<V36PrefixCheckpointHead> {
    let regular_bytes = |path: &Path| -> Result<Vec<u8>> {
        let metadata = fs::symlink_metadata(path).map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
        if !metadata.file_type().is_file() {
            return Err(invalid("V36 population checkpoint staged file differs"));
        }
        read_file(path)
    };
    if !root.is_dir() || root.is_symlink() || !root.join("objects").is_dir() {
        return Err(invalid("V36 population checkpoint staged root differs"));
    }
    let pointer_bytes = regular_bytes(&root.join("pointer.json"))?;
    let pointer: V36PrefixCheckpointPointer = serde_json::from_slice(&pointer_bytes)
        .map_err(|_| invalid("V36 population checkpoint pointer JSON differs"))?;
    if canonical_v36_prefix_checkpoint_pointer_bytes(context, &pointer)? != pointer_bytes {
        return Err(invalid("V36 population checkpoint pointer bytes differ"));
    }
    let manifest_bytes = regular_bytes(&root.join("manifest.json"))?;
    if pointer.manifest.encoded_bytes != manifest_bytes.len() as u64
        || pointer.manifest.sha256 != format!("{:x}", Sha256::digest(&manifest_bytes))
        || pointer.manifest.blake3 != blake3::hash(&manifest_bytes).to_hex().as_str()
    {
        return Err(invalid(
            "V36 population checkpoint manifest authority differs",
        ));
    }
    let manifest: V36PrefixCheckpointManifest = serde_json::from_slice(&manifest_bytes)
        .map_err(|_| invalid("V36 population checkpoint manifest JSON differs"))?;
    if canonical_v36_prefix_checkpoint_manifest_bytes(&manifest)? != manifest_bytes
        || manifest.generation != pointer.generation
    {
        return Err(invalid("V36 population checkpoint manifest bytes differ"));
    }
    validate_v36_prefix_checkpoint_manifest_with_context(context, &manifest)?;
    let identities = plan_v36_prefix_checkpoint_dependency_closure(&manifest)?;
    let mut dependencies = Vec::with_capacity(identities.len());
    for identity in &identities {
        let maximum_bytes = if identity.role == "source" {
            context.source_byte_cap
        } else {
            256 * 1024 * 1024
        };
        if identity.encoded_bytes > maximum_bytes {
            return Err(invalid(
                "V36 population checkpoint dependency limit differs",
            ));
        }
        let path = root
            .join("objects")
            .join(format!("{}.blob", identity.sha256));
        authenticate_file(&path, identity)?;
        dependencies.push(V36PrefixCheckpointDependencyFile {
            identity: identity.clone(),
            path,
        });
    }
    Ok(V36PrefixCheckpointHead {
        authenticated_corpus_rows: context.corpus_rows,
        authenticated_dependencies: dependencies.clone(),
        authenticated_manifest: manifest.clone(),
        authenticated_pointer_bytes: pointer_bytes.clone(),
        dependencies,
        manifest,
        pointer_bytes,
    })
}

impl V36PrefixPopulationCheckpointWriter {
    /// Create an empty writer bound to one exact attempt and campaign authority.
    pub fn create(
        root: &Path,
        context: V36PrefixCheckpointContext,
        execution_authority_sha256: String,
        producer_attempt_id: String,
        producer_attempt_ordinal: u8,
        producer_instance_id: String,
    ) -> Result<Self> {
        digest_bytes(&execution_authority_sha256)?;
        if producer_attempt_id
            != format!("{}-attempt-{producer_attempt_ordinal:04}", context.run_id)
            || producer_attempt_ordinal >= 3
            || producer_instance_id.is_empty()
        {
            return Err(invalid("V36 population checkpoint producer differs"));
        }
        Ok(Self {
            context,
            dependencies: Vec::new(),
            execution_authority_sha256,
            outbox: V36PrefixCheckpointOutbox::create(root)?,
            previous_manifest: None,
            previous_manifest_identity: None,
            previous_pointer_bytes: None,
            producer_attempt_id,
            producer_attempt_ordinal,
            producer_instance_id,
        })
    }

    /// Resume from one fully authenticated published population head.
    pub fn resume(
        root: &Path,
        context: V36PrefixCheckpointContext,
        execution_authority_sha256: String,
        producer_attempt_id: String,
        producer_attempt_ordinal: u8,
        producer_instance_id: String,
        head: V36PrefixCheckpointHead,
    ) -> Result<Self> {
        let runs = head.identity_runs()?;
        let authenticated_corpus_rows = head.authenticated_corpus_rows;
        let V36PrefixCheckpointHead {
            authenticated_corpus_rows: _,
            authenticated_dependencies: _,
            authenticated_manifest: _,
            authenticated_pointer_bytes: _,
            dependencies,
            manifest: previous_manifest,
            pointer_bytes: previous_pointer_bytes,
        } = head;
        digest_bytes(&execution_authority_sha256)?;
        validate_v36_prefix_checkpoint_manifest_with_context(&context, &previous_manifest)?;
        let pointer: V36PrefixCheckpointPointer =
            serde_json::from_slice(&previous_pointer_bytes)
                .map_err(|_| invalid("V36 population checkpoint pointer JSON differs"))?;
        if authenticated_corpus_rows != context.corpus_rows
            || canonical_v36_prefix_checkpoint_pointer_bytes(&context, &pointer)?
                != previous_pointer_bytes
            || pointer.generation != previous_manifest.generation
            || pointer.run_id != previous_manifest.run_id
            || pointer.producer_attempt_id != previous_manifest.producer_attempt_id
            || pointer.producer_attempt_ordinal != previous_manifest.producer_attempt_ordinal
            || !matches!(
                &previous_manifest.phase,
                V36PrefixCheckpointPhase::Population
            )
            || dependencies.len() != previous_manifest.population.identity_runs.len()
            || dependencies
                .iter()
                .zip(&previous_manifest.population.identity_runs)
                .any(|(dependency, expected)| {
                    &dependency.identity != expected
                        || authenticate_file(&dependency.path, &dependency.identity).is_err()
                })
        {
            return Err(invalid(
                "V36 population checkpoint resume authority differs",
            ));
        }
        let restored = restore_v36_prefix_population_state(
            &runs,
            usize::try_from(context.distinct_candidates)
                .map_err(|_| invalid("V36 population checkpoint row count overflows"))?,
        )?;
        if restored.consumed_objects != previous_manifest.population.consumed_objects
            || restored.distinct_rows_observed != previous_manifest.population.distinct_rows
            || restored.duplicate_rows != previous_manifest.population.duplicate_rows
            || restored.next_object_ordinal
                != previous_manifest
                    .population
                    .selected_object_start
                    .checked_add(previous_manifest.population.completed_objects)
                    .ok_or_else(|| invalid("V36 population checkpoint ordinal overflows"))?
            || restored.physical_rows != previous_manifest.population.physical_rows
        {
            return Err(invalid("V36 population checkpoint resume state differs"));
        }
        let manifest_bytes = canonical_v36_prefix_checkpoint_manifest_bytes(&previous_manifest)?;
        if pointer.manifest.encoded_bytes != manifest_bytes.len() as u64
            || pointer.manifest.sha256 != format!("{:x}", Sha256::digest(&manifest_bytes))
            || pointer.manifest.blake3 != blake3::hash(&manifest_bytes).to_hex().as_str()
            || producer_attempt_id
                != format!("{}-attempt-{producer_attempt_ordinal:04}", context.run_id)
            || producer_attempt_ordinal >= 3
            || producer_attempt_ordinal < previous_manifest.producer_attempt_ordinal
            || producer_instance_id.is_empty()
        {
            return Err(invalid(
                "V36 population checkpoint resume authority differs",
            ));
        }
        let outbox = V36PrefixCheckpointOutbox::create(root)?;
        let mut installed_dependencies = Vec::with_capacity(dependencies.len());
        for dependency in dependencies {
            let path = outbox
                .root
                .join("objects")
                .join(format!("{}.blob", dependency.identity.sha256));
            install_content_addressed_file(&path, &dependency.path, &dependency.identity)?;
            installed_dependencies.push(V36PrefixCheckpointDependencyFile {
                identity: dependency.identity,
                path,
            });
        }
        Ok(Self {
            context,
            dependencies: installed_dependencies,
            execution_authority_sha256,
            outbox,
            previous_manifest: Some(previous_manifest),
            previous_manifest_identity: Some(pointer.manifest),
            previous_pointer_bytes: Some(previous_pointer_bytes),
            producer_attempt_id,
            producer_attempt_ordinal,
            producer_instance_id,
        })
    }

    /// Resume from one population head without decoding identity rows into resident state.
    pub fn resume_file_backed(
        request: V36PrefixFileBackedResumeRequest<'_>,
    ) -> Result<(Self, V36PrefixFileBackedPopulationScan)> {
        let V36PrefixFileBackedResumeRequest {
            execution_authority_sha256,
            head,
            context,
            limits,
            producer_attempt_id,
            producer_attempt_ordinal,
            producer_instance_id,
            root,
            scratch_root,
        } = request;
        if !matches!(&head.manifest.phase, V36PrefixCheckpointPhase::Population) {
            return Err(invalid("V36 population checkpoint resume phase differs"));
        }
        let authenticated_corpus_rows = head.authenticated_corpus_rows;
        let mut restored =
            restore_v36_prefix_file_backed_population_scan(&head, limits, scratch_root)?;
        let V36PrefixCheckpointHead {
            authenticated_corpus_rows: _,
            authenticated_dependencies: _,
            authenticated_manifest: _,
            authenticated_pointer_bytes: _,
            dependencies,
            manifest: previous_manifest,
            pointer_bytes: previous_pointer_bytes,
        } = head;
        digest_bytes(&execution_authority_sha256)?;
        validate_v36_prefix_checkpoint_manifest_with_context(&context, &previous_manifest)?;
        let pointer: V36PrefixCheckpointPointer =
            serde_json::from_slice(&previous_pointer_bytes)
                .map_err(|_| invalid("V36 population checkpoint pointer JSON differs"))?;
        if authenticated_corpus_rows != context.corpus_rows
            || canonical_v36_prefix_checkpoint_pointer_bytes(&context, &pointer)?
                != previous_pointer_bytes
            || pointer.generation != previous_manifest.generation
            || pointer.run_id != previous_manifest.run_id
            || pointer.producer_attempt_id != previous_manifest.producer_attempt_id
            || pointer.producer_attempt_ordinal != previous_manifest.producer_attempt_ordinal
            || producer_attempt_id
                != format!("{}-attempt-{producer_attempt_ordinal:04}", context.run_id)
            || producer_attempt_ordinal >= 3
            || producer_attempt_ordinal < previous_manifest.producer_attempt_ordinal
            || producer_instance_id.is_empty()
        {
            return Err(invalid(
                "V36 population checkpoint resume authority differs",
            ));
        }
        let outbox = V36PrefixCheckpointOutbox::create(root)?;
        let mut installed_dependencies = Vec::with_capacity(dependencies.len());
        for dependency in dependencies {
            let path = outbox
                .root
                .join("objects")
                .join(format!("{}.blob", dependency.identity.sha256));
            install_content_addressed_file(&path, &dependency.path, &dependency.identity)?;
            installed_dependencies.push(V36PrefixCheckpointDependencyFile {
                identity: dependency.identity,
                path,
            });
        }
        for (run, dependency) in restored.runs.iter_mut().zip(&installed_dependencies) {
            if run.identity != dependency.identity {
                return Err(invalid("V36 population checkpoint dependencies differ"));
            }
            run.path = dependency.path.clone();
        }
        Ok((
            Self {
                context,
                dependencies: installed_dependencies,
                execution_authority_sha256,
                outbox,
                previous_manifest: Some(previous_manifest),
                previous_manifest_identity: Some(pointer.manifest),
                previous_pointer_bytes: Some(previous_pointer_bytes),
                producer_attempt_id,
                producer_attempt_ordinal,
                producer_instance_id,
            },
            restored,
        ))
    }

    /// Resume a writer and typed continuation from any authenticated checkpoint phase.
    pub fn resume_phase(
        request: V36PrefixPhaseResumeRequest<'_>,
    ) -> Result<(Self, V36PrefixCheckpointResumeState)> {
        let V36PrefixPhaseResumeRequest {
            execution_authority_sha256,
            head,
            context,
            limits,
            producer_attempt_id,
            producer_attempt_ordinal,
            producer_instance_id,
            root,
            scratch_root,
            selected_contract,
        } = request;
        head.validate_authenticated_seal()?;
        digest_bytes(&execution_authority_sha256)?;
        validate_v36_prefix_checkpoint_manifest_with_context(&context, &head.manifest)?;
        let pointer: V36PrefixCheckpointPointer = serde_json::from_slice(&head.pointer_bytes)
            .map_err(|_| invalid("V36 population checkpoint pointer JSON differs"))?;
        let same_attempt_valid = producer_attempt_ordinal != head.manifest.producer_attempt_ordinal
            || (producer_attempt_id == head.manifest.producer_attempt_id
                && execution_authority_sha256 == head.manifest.execution_authority_sha256
                && producer_instance_id == head.manifest.producer_instance_id);
        if head.authenticated_corpus_rows != context.corpus_rows
            || canonical_v36_prefix_checkpoint_pointer_bytes(&context, &pointer)?
                != head.pointer_bytes
            || pointer.generation != head.manifest.generation
            || pointer.run_id != head.manifest.run_id
            || pointer.producer_attempt_id != head.manifest.producer_attempt_id
            || pointer.producer_attempt_ordinal != head.manifest.producer_attempt_ordinal
            || producer_attempt_id
                != format!("{}-attempt-{producer_attempt_ordinal:04}", context.run_id)
            || producer_attempt_ordinal >= 3
            || producer_attempt_ordinal < head.manifest.producer_attempt_ordinal
            || producer_instance_id.is_empty()
            || !same_attempt_valid
        {
            return Err(invalid(
                "V36 population checkpoint resume authority differs",
            ));
        }

        let outbox = V36PrefixCheckpointOutbox::create(root)?;
        let mut installed_dependencies = Vec::with_capacity(head.dependencies.len());
        for dependency in &head.dependencies {
            let path = outbox
                .root
                .join("objects")
                .join(format!("{}.blob", dependency.identity.sha256));
            install_content_addressed_file(&path, &dependency.path, &dependency.identity)?;
            installed_dependencies.push(V36PrefixCheckpointDependencyFile {
                identity: dependency.identity.clone(),
                path,
            });
        }
        let installed_head = V36PrefixCheckpointHead {
            authenticated_corpus_rows: context.corpus_rows,
            authenticated_dependencies: installed_dependencies.clone(),
            authenticated_manifest: head.manifest.clone(),
            authenticated_pointer_bytes: head.pointer_bytes.clone(),
            dependencies: installed_dependencies.clone(),
            manifest: head.manifest.clone(),
            pointer_bytes: head.pointer_bytes.clone(),
        };
        let restored = restore_v36_prefix_checkpoint_phase(
            &installed_head,
            selected_contract,
            limits,
            scratch_root,
        )?;
        Ok((
            Self {
                context,
                dependencies: installed_dependencies,
                execution_authority_sha256,
                outbox,
                previous_manifest: Some(head.manifest),
                previous_manifest_identity: Some(pointer.manifest),
                previous_pointer_bytes: Some(head.pointer_bytes),
                producer_attempt_id,
                producer_attempt_ordinal,
                producer_instance_id,
            },
            restored,
        ))
    }

    /// Authenticate completed identity-run sidecars for file-backed selection.
    pub fn identity_run_files(&self) -> Result<Vec<V36PrefixIdentityRunFile>> {
        let population = self
            .previous_manifest
            .as_ref()
            .map(|manifest| &manifest.population)
            .ok_or_else(|| invalid("V36 population checkpoint is empty"))?;
        if self.dependencies.len() != population.identity_runs.len()
            || self.dependencies.len() != population.consumed_objects.len()
        {
            return Err(invalid("V36 population checkpoint dependencies differ"));
        }
        self.dependencies
            .iter()
            .zip(&population.identity_runs)
            .zip(&population.consumed_objects)
            .enumerate()
            .map(|(index, ((dependency, registered), source))| {
                if &dependency.identity != registered {
                    return Err(invalid("V36 population checkpoint dependencies differ"));
                }
                let selected_object_ordinal = population
                    .selected_object_start
                    .checked_add(
                        u16::try_from(index)
                            .map_err(|_| invalid("V36 population checkpoint ordinal overflows"))?,
                    )
                    .ok_or_else(|| invalid("V36 population checkpoint ordinal overflows"))?;
                let path = self
                    .outbox
                    .root
                    .join("objects")
                    .join(format!("{}.blob", dependency.identity.sha256));
                authenticate_file(&path, &dependency.identity)?;
                Ok(V36PrefixIdentityRunFile {
                    identity: dependency.identity.clone(),
                    path,
                    selected_object_ordinal,
                    source: source.clone(),
                })
            })
            .collect()
    }

    fn publish_phase(
        &mut self,
        phase: V36PrefixCheckpointPhase,
        new_dependencies: &[V36PrefixCheckpointDependencyFile],
    ) -> Result<PathBuf> {
        let previous = self
            .previous_manifest
            .as_ref()
            .ok_or_else(|| invalid("V36 population checkpoint is empty"))?;
        let generation = previous
            .generation
            .checked_add(1)
            .ok_or_else(|| invalid("V36 population checkpoint generation overflows"))?;
        let manifest = V36PrefixCheckpointManifest {
            claim_eligible: false,
            execution_authority_sha256: self.execution_authority_sha256.clone(),
            freeze_authority_sha256: self.context.freeze_authority_sha256.clone(),
            generation,
            phase,
            population: previous.population.clone(),
            previous_checkpoint: self.previous_manifest_identity.clone(),
            producer_attempt_id: self.producer_attempt_id.clone(),
            producer_attempt_ordinal: self.producer_attempt_ordinal,
            producer_instance_id: self.producer_instance_id.clone(),
            run_id: self.context.run_id.clone(),
            schema: "borsuk-v36-prefix-freeze-checkpoint-v2".to_owned(),
            source_archive_sha256: self.context.source_archive_sha256.clone(),
            source_commit: self.context.source_commit.clone(),
            source_registry_sha256: self.context.source_registry_sha256.clone(),
        };
        validate_v36_prefix_checkpoint_transition(&self.context, previous, &manifest)?;
        let publication = plan_v36_prefix_checkpoint_publication(
            &self.context,
            &manifest,
            Some(previous),
            self.previous_pointer_bytes
                .as_deref()
                .map(|pointer| (pointer, "local-predecessor")),
        )?;
        let dependencies = publication
            .dependencies
            .iter()
            .map(|identity| {
                new_dependencies
                    .iter()
                    .find(|dependency| &dependency.identity == identity)
                    .cloned()
                    .unwrap_or_else(|| V36PrefixCheckpointDependencyFile {
                        identity: identity.clone(),
                        path: self
                            .outbox
                            .root
                            .join("objects")
                            .join(format!("{}.blob", identity.sha256)),
                    })
            })
            .collect::<Vec<_>>();
        let ready = self.outbox.commit_files(&publication, &dependencies)?;
        self.previous_manifest = Some(manifest);
        self.previous_manifest_identity = Some(publication.manifest.clone());
        self.previous_pointer_bytes = Some(publication.pointer_bytes);
        Ok(ready)
    }

    /// Publish a complete authenticated population selection.
    pub fn commit_selected(
        &mut self,
        selection: &V36PrefixPopulationSelection,
        selected_path: &Path,
    ) -> Result<PathBuf> {
        self.publish_phase(
            V36PrefixCheckpointPhase::Selected {
                selection: Box::new(selection.clone()),
            },
            &[V36PrefixCheckpointDependencyFile {
                identity: selection.selected_ids.clone(),
                path: selected_path.to_owned(),
            }],
        )
    }

    /// Publish complete authenticated source and query materialization files.
    pub fn commit_materialized(
        &mut self,
        artifacts: &V36PrefixMaterializedArtifacts,
        dependencies: &[V36PrefixCheckpointDependencyFile],
    ) -> Result<PathBuf> {
        let expected = [
            &artifacts.population_authority,
            &artifacts.source,
            &artifacts.development_query,
            &artifacts.validation_query,
            &artifacts.sealed_holdout_query,
            &artifacts.performance_query,
        ];
        if dependencies.len() != expected.len()
            || dependencies
                .iter()
                .zip(expected)
                .any(|(dependency, identity)| &dependency.identity != identity)
        {
            return Err(invalid("V36 materialized checkpoint dependencies differ"));
        }
        let selection = match self
            .previous_manifest
            .as_ref()
            .map(|manifest| &manifest.phase)
        {
            Some(V36PrefixCheckpointPhase::Selected { selection }) => selection.clone(),
            _ => return Err(invalid("V36 materialized checkpoint predecessor differs")),
        };
        self.publish_phase(
            V36PrefixCheckpointPhase::Materialized {
                selection,
                artifacts: Box::new(artifacts.clone()),
            },
            dependencies,
        )
    }

    /// Publish an authenticated exact-ground-truth heap boundary.
    pub fn commit_ground_truth(
        &mut self,
        heaps: &V36PrefixCheckpointDependencyFile,
        next_source_ordinal: u64,
    ) -> Result<PathBuf> {
        let (selection, materialized) = match self
            .previous_manifest
            .as_ref()
            .map(|manifest| &manifest.phase)
        {
            Some(V36PrefixCheckpointPhase::Materialized {
                selection,
                artifacts,
            })
            | Some(V36PrefixCheckpointPhase::GroundTruth {
                selection,
                materialized: artifacts,
                ..
            }) => (selection.clone(), artifacts.clone()),
            _ => return Err(invalid("V36 ground-truth checkpoint predecessor differs")),
        };
        self.publish_phase(
            V36PrefixCheckpointPhase::GroundTruth {
                selection,
                materialized,
                heaps: Box::new(heaps.identity.clone()),
                next_source_ordinal,
            },
            std::slice::from_ref(heaps),
        )
    }

    /// Publish terminal authenticated exact-GT Parquets from a complete heap boundary.
    pub fn commit_complete(
        &mut self,
        ground_truth: &crate::V36PrefixGroundTruthArtifacts,
        dependencies: &[V36PrefixCheckpointDependencyFile],
    ) -> Result<PathBuf> {
        let (selection, materialized, heaps, next_source_ordinal) = match self
            .previous_manifest
            .as_ref()
            .map(|manifest| &manifest.phase)
        {
            Some(V36PrefixCheckpointPhase::GroundTruth {
                selection,
                materialized,
                heaps,
                next_source_ordinal,
            }) => (
                selection.clone(),
                materialized.clone(),
                heaps,
                *next_source_ordinal,
            ),
            _ => return Err(invalid("V36 complete checkpoint predecessor differs")),
        };
        if next_source_ordinal != self.context.corpus_rows
            || ground_truth.heaps != **heaps
            || dependencies.len() != 3
            || dependencies
                .iter()
                .map(|dependency| &dependency.identity)
                .ne([
                    &ground_truth.development,
                    &ground_truth.validation,
                    &ground_truth.sealed_holdout,
                ])
        {
            return Err(invalid("V36 complete checkpoint authority differs"));
        }
        let object_path = |identity: &V36ArtifactIdentity| {
            self.outbox
                .root
                .join("objects")
                .join(format!("{}.blob", identity.sha256))
        };
        let mut remaining_queries = u32::try_from(GT_HEAP_CHECKPOINT_MAX_QUERIES).unwrap();
        let mut query_counts = [0_u32; 3];
        for (count, identity) in query_counts.iter_mut().zip([
            &materialized.development_query,
            &materialized.validation_query,
            &materialized.sealed_holdout_query,
        ]) {
            *count = validate_v36_prefix_checkpoint_query_file(
                &object_path(identity),
                remaining_queries,
            )?;
            remaining_queries = remaining_queries
                .checked_sub(*count)
                .ok_or_else(|| invalid("V36 complete checkpoint query count differs"))?;
        }
        let heap_path = object_path(heaps);
        authenticate_file(&heap_path, heaps)?;
        let checkpoint = decode_v36_prefix_gt_heap_checkpoint(
            &read_file(&heap_path)?,
            heaps,
            next_source_ordinal,
            query_counts,
        )?;
        let mut expected_truth = [Vec::new(), Vec::new(), Vec::new()];
        for entry in checkpoint
            .entries
            .into_iter()
            .filter(|entry| usize::from(entry.rank) < GT_NEIGHBORS)
        {
            expected_truth[usize::from(v36_prefix_gt_role_ordinal(entry.role))].push(
                V36PrefixGtNeighbor {
                    query_ordinal: entry.query_ordinal,
                    rank: entry.rank,
                    feature_row_id: entry.feature_row_id,
                    squared_distance: entry.squared_distance,
                },
            );
        }
        for ((dependency, expected_queries), expected) in
            dependencies.iter().zip(query_counts).zip(&expected_truth)
        {
            authenticate_file(&dependency.path, &dependency.identity)?;
            validate_v36_prefix_gt100_matches_heap(&dependency.path, expected, expected_queries)?;
        }
        self.publish_phase(
            V36PrefixCheckpointPhase::Complete {
                selection,
                materialized,
                ground_truth: Box::new(ground_truth.clone()),
            },
            dependencies,
        )
    }

    /// Commit one complete authenticated source-object boundary from a durable run file.
    pub fn commit_file(&mut self, boundary: &V36PrefixPopulationFileCommit) -> Result<PathBuf> {
        let ordinal = self.dependencies.len();
        let previous_population = self
            .previous_manifest
            .as_ref()
            .map(|manifest| &manifest.population);
        let expected_global_ordinal = self
            .context
            .selected_object_start
            .checked_add(
                u16::try_from(ordinal)
                    .map_err(|_| invalid("V36 population checkpoint ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 population checkpoint ordinal overflows"))?;
        if boundary.run.selected_object_ordinal != expected_global_ordinal
            || boundary.run.identity.uri
                != format!(
                    "{}{}-population-identity-run-{expected_global_ordinal:04}.arrow",
                    self.context.object_prefix, boundary.run.identity.sha256
                )
            || self
                .context
                .ranked_objects
                .get(ordinal)
                .is_none_or(|registered| {
                    registered.path != boundary.run.source.path
                        || registered.uri != boundary.run.source.uri
                        || registered.sha256 != boundary.run.source.sha256
                        || registered.encoded_bytes != boundary.run.source.encoded_bytes
                })
        {
            return Err(invalid("V36 population checkpoint object differs"));
        }
        let previous_distinct =
            previous_population.map_or(0, |population| population.distinct_rows);
        let attempt =
            tempfile::tempdir_in(&self.outbox.root).map_err(|source| BorsukError::Io {
                path: self.outbox.root.clone(),
                source,
            })?;
        let limits = V36PrefixExternalSelectionLimits {
            io_buffer_bytes: 65_536,
            max_input_bytes: boundary.run.identity.encoded_bytes,
            max_scratch_bytes: boundary.run.identity.encoded_bytes,
            max_spills: 1,
            merge_fan_in: 2,
            sort_buffer_records: 1,
        };
        let (run_rows, run_physical_rows) = stream_v36_prefix_identity_run_file(
            &boundary.run,
            &limits,
            attempt.path(),
            &[0_u8; 32],
            &[0_u8; 32],
            &mut |_| Ok(()),
        )?;
        let installed_path = self
            .outbox
            .root
            .join("objects")
            .join(format!("{}.blob", boundary.run.identity.sha256));
        install_content_addressed_file(
            &installed_path,
            &boundary.run.path,
            &boundary.run.identity,
        )?;
        for previous in &self.dependencies {
            authenticate_file(&previous.path, &previous.identity)?;
            validate_v36_prefix_identity_run_files_disjoint(&previous.path, &installed_path)?;
        }
        let identity = boundary.run.identity.clone();
        let mut consumed_objects = self
            .previous_manifest
            .as_ref()
            .map_or_else(Vec::new, |manifest| {
                manifest.population.consumed_objects.clone()
            });
        consumed_objects.push(boundary.run.source.clone());
        let mut identity_runs = self
            .previous_manifest
            .as_ref()
            .map_or_else(Vec::new, |manifest| {
                manifest.population.identity_runs.clone()
            });
        identity_runs.push(identity.clone());
        let generation = self.previous_manifest.as_ref().map_or(Ok(0), |manifest| {
            manifest
                .generation
                .checked_add(1)
                .ok_or_else(|| invalid("V36 population checkpoint generation overflows"))
        })?;
        let previous_physical =
            previous_population.map_or(0, |population| population.physical_rows);
        let distinct_rows = previous_distinct
            .checked_add(run_rows)
            .ok_or_else(|| invalid("V36 population checkpoint distinct rows overflow"))?;
        let physical_rows = previous_physical
            .checked_add(run_physical_rows)
            .ok_or_else(|| invalid("V36 population checkpoint physical rows overflow"))?;
        let duplicate_rows = physical_rows
            .checked_sub(distinct_rows)
            .ok_or_else(|| invalid("V36 population checkpoint duplicate rows underflow"))?;
        if boundary.distinct_rows != distinct_rows
            || boundary.duplicate_rows != duplicate_rows
            || boundary.physical_rows != physical_rows
        {
            return Err(invalid("V36 population checkpoint accounting differs"));
        }
        let manifest = V36PrefixCheckpointManifest {
            claim_eligible: false,
            execution_authority_sha256: self.execution_authority_sha256.clone(),
            freeze_authority_sha256: self.context.freeze_authority_sha256.clone(),
            generation,
            phase: V36PrefixCheckpointPhase::Population,
            population: V36PrefixPopulationCheckpoint {
                completed_objects: u16::try_from(identity_runs.len())
                    .map_err(|_| invalid("V36 population checkpoint ordinal overflows"))?,
                consumed_objects,
                distinct_rows,
                duplicate_rows,
                identity_runs,
                physical_rows,
                selected_object_count: self.context.selected_object_count,
                selected_object_start: self.context.selected_object_start,
            },
            previous_checkpoint: self.previous_manifest_identity.clone(),
            producer_attempt_id: self.producer_attempt_id.clone(),
            producer_attempt_ordinal: self.producer_attempt_ordinal,
            producer_instance_id: self.producer_instance_id.clone(),
            schema: "borsuk-v36-prefix-freeze-checkpoint-v2".to_owned(),
            run_id: self.context.run_id.clone(),
            source_archive_sha256: self.context.source_archive_sha256.clone(),
            source_commit: self.context.source_commit.clone(),
            source_registry_sha256: self.context.source_registry_sha256.clone(),
        };
        if let Some(previous) = &self.previous_manifest {
            validate_v36_prefix_checkpoint_transition(&self.context, previous, &manifest)?;
        }
        let publication = plan_v36_prefix_checkpoint_publication(
            &self.context,
            &manifest,
            self.previous_manifest.as_ref(),
            self.previous_pointer_bytes
                .as_deref()
                .map(|pointer| (pointer, "local-predecessor")),
        )?;
        self.dependencies.push(V36PrefixCheckpointDependencyFile {
            identity,
            path: boundary.run.path.clone(),
        });
        let ready = match self.outbox.commit_files(&publication, &self.dependencies) {
            Ok(ready) => ready,
            Err(error) => {
                self.dependencies.pop();
                return Err(error);
            }
        };
        self.dependencies
            .last_mut()
            .ok_or_else(|| invalid("V36 population checkpoint dependency is missing"))?
            .path = installed_path;
        self.previous_manifest = Some(manifest);
        self.previous_manifest_identity = Some(publication.manifest.clone());
        self.previous_pointer_bytes = Some(publication.pointer_bytes);
        Ok(ready)
    }

    /// Encode and commit one resident run through the file-backed publication boundary.
    pub fn commit(&mut self, boundary: &V36PrefixPopulationCommit) -> Result<PathBuf> {
        let bytes = encode_v36_prefix_identity_run(&boundary.run)?;
        let sha256 = format!("{:x}", Sha256::digest(&bytes));
        let identity = V36ArtifactIdentity {
            blake3: blake3::hash(&bytes).to_hex().to_string(),
            encoded_bytes: bytes.len().try_into().unwrap_or(u64::MAX),
            role: format!(
                "population-identity-run-{:04}",
                boundary.run.selected_object_ordinal
            ),
            sha256: sha256.clone(),
            uri: format!(
                "{}{sha256}-population-identity-run-{:04}.arrow",
                self.context.object_prefix, boundary.run.selected_object_ordinal
            ),
        };
        let path = self
            .outbox
            .root
            .join("objects")
            .join(format!("{}.blob", identity.sha256));
        install_content_addressed(&path, &bytes)?;
        self.commit_file(&V36PrefixPopulationFileCommit {
            distinct_rows: boundary.distinct_rows,
            duplicate_rows: boundary.duplicate_rows,
            physical_rows: boundary.physical_rows,
            run: V36PrefixIdentityRunFile {
                identity,
                path,
                selected_object_ordinal: boundary.run.selected_object_ordinal,
                source: boundary.run.source.clone(),
            },
        })
    }
}

fn parquet_writer_properties() -> WriterProperties {
    WriterProperties::builder()
        .set_max_row_group_row_count(Some(PARQUET_ROW_GROUP_ROWS))
        .set_data_page_size_limit(1024 * 1024)
        .build()
}

fn validate_parquet_descriptor(actual: &SchemaDescriptor, expected: &Schema) -> Result<()> {
    let expected = ArrowSchemaConverter::new().convert(expected)?;
    // Parquet root-group names are writer metadata (`schema` in PyArrow and
    // `arrow_schema` in parquet-rs), not a column or logical-type authority.
    if actual.columns() != expected.columns()
        || actual.root_schema().get_fields().len() != expected.root_schema().get_fields().len()
    {
        return Err(invalid("V36 prefix Parquet physical schema differs"));
    }
    Ok(())
}

fn digest_bytes(value: &str) -> Result<[u8; 32]> {
    if value.len() != 64
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(invalid("V36 prefix digest differs"));
    }
    let mut decoded = [0_u8; 32];
    for (index, chunk) in value.as_bytes().as_chunks::<2>().0.iter().enumerate() {
        let pair = std::str::from_utf8(chunk).map_err(|_| invalid("V36 prefix digest differs"))?;
        decoded[index] =
            u8::from_str_radix(pair, 16).map_err(|_| invalid("V36 prefix digest differs"))?;
    }
    if decoded.iter().all(|byte| *byte == 0) {
        return Err(invalid("V36 prefix digest differs"));
    }
    Ok(decoded)
}

fn digest_hex(digest: &[u8; 32]) -> String {
    digest
        .iter()
        .fold(String::with_capacity(64), |mut output, byte| {
            std::fmt::Write::write_fmt(&mut output, format_args!("{byte:02x}"))
                .expect("writing to a String cannot fail");
            output
        })
}

fn validate_embedding(embedding: &[f32]) -> Result<()> {
    if embedding.len() != DIMENSIONS
        || embedding.iter().any(|value| !value.is_finite())
        || embedding.iter().all(|value| *value == 0.0)
    {
        return Err(invalid("V36 prefix embedding differs"));
    }
    Ok(())
}

#[derive(Debug, Clone, PartialEq)]
/// One physical input row before duplicate resolution and role selection.
pub struct V36PrefixInputRow {
    /// Signed physical feature ID; negative IDs are invalid.
    pub feature_row_id: i64,
    /// Position of the complete object in the registered sampled order.
    pub selected_object_ordinal: u16,
    /// Zero-based physical row offset inside that object.
    pub row_offset: u64,
    /// Exact source-domain f32 vector.
    pub embedding: Vec<f32>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Compact identity retained after a streamed row passes vector validation.
pub struct V36PrefixRowIdentity {
    /// Unsigned logical feature ID.
    pub feature_row_id: u64,
    /// Corpus ordinal, absent until query removal and source ordering finish.
    pub source_ordinal: Option<u64>,
    /// Position of the complete object in the registered sampled order.
    pub selected_object_ordinal: u16,
    /// Zero-based physical row offset inside that object.
    pub row_offset: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Complete-object first-occurrence evidence stored in one Arrow IPC identity run.
pub struct V36PrefixIdentityRun {
    /// Physical rows validated in the complete source object.
    pub physical_rows: u64,
    /// Global first occurrences contributed by this object in feature-ID order.
    pub rows: Vec<V36PrefixRowIdentity>,
    /// Position of the complete object in registered sample order.
    pub selected_object_ordinal: u16,
    /// Exact complete source object authenticated before the run was committed.
    pub source: V36PrefixSourceObject,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// One authenticated local durable identity-run input for external selection.
pub struct V36PrefixIdentityRunFile {
    /// Registered immutable Arrow artifact identity.
    pub identity: V36ArtifactIdentity,
    /// Exact local regular-file path.
    pub path: PathBuf,
    /// Global object ordinal bound into the artifact.
    pub selected_object_ordinal: u16,
    /// Authenticated source object bound into the artifact.
    pub source: V36PrefixSourceObject,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
/// Hard resource limits for one attempt-local external population selection.
pub struct V36PrefixExternalSelectionLimits {
    /// Per-stream buffered I/O bytes.
    pub io_buffer_bytes: usize,
    /// Maximum encoded bytes accepted for any durable input artifact.
    pub max_input_bytes: u64,
    /// Maximum bytes created beneath the attempt scratch directory; excludes the final artifact.
    pub max_scratch_bytes: u64,
    /// Maximum private spills permitted in one merge generation.
    pub max_spills: usize,
    /// Maximum number of input spills opened by one merge.
    pub merge_fan_in: usize,
    /// Maximum scored records retained for one in-memory sort.
    pub sort_buffer_records: usize,
}

/// File-backed request to construct one v3 first-occurrence identity run.
pub struct V36PrefixExternalIdentityRunRequest<'a> {
    /// One-based local distinct-row rank whose physical offset is requested.
    pub cutoff_local_rank: Option<u64>,
    /// Complete authenticated source Parquet path.
    pub input: &'a Path,
    /// Hard memory, spill, and disk limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Final canonical Arrow IPC output path.
    pub output: &'a Path,
    /// Content-addressed object-store prefix for the result identity.
    pub output_uri_prefix: &'a str,
    /// Earlier feature-ID-ordered runs used for global first-occurrence exclusion.
    pub prior_runs: &'a [V36PrefixIdentityRunFile],
    /// Existing private directory beneath which one attempt directory is created.
    pub scratch_root: &'a Path,
    /// Global ordinal of this complete selected object.
    pub selected_object_ordinal: u16,
    /// Registered immutable source object.
    pub source: &'a V36PrefixRankedSourceObject,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated accounting and durable v3 run produced without resident object rows.
pub struct V36PrefixExternalIdentityRunReceipt {
    /// Physical source offset at the requested local rank, if that rank was reached.
    pub cutoff_row_offset: Option<u64>,
    /// Physical source rows rejected as local or prior-run duplicates.
    pub duplicate_rows: u64,
    /// New global first occurrences written to the run.
    pub distinct_rows: u64,
    /// Complete physical rows authenticated in the source object.
    pub physical_rows: u64,
    /// Canonical file-backed v3 run.
    pub run: V36PrefixIdentityRunFile,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated receipt for one file-backed selected-population artifact.
pub struct V36PrefixSelectedFileReceipt {
    /// Feature-row ID at the inclusive population-score cutoff.
    pub cutoff_feature_row_id: u64,
    /// Population score at the inclusive cutoff.
    pub cutoff_score_sha256: String,
    /// Final artifact contract including counts derived by the complete anti-join.
    pub contract: V36PrefixSelectedIdsContract,
    /// Exact content-addressed selected-ID Arrow identity.
    pub identity: V36ArtifactIdentity,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Precomputable authority for one external population selection.
pub struct V36PrefixExternalSelectionAuthority {
    /// Zero-based independently registered population cohort.
    pub cohort_ordinal: u8,
    /// Complete distinct first-occurrence population before cohort exclusion.
    pub distinct_rows: u64,
    /// Exact predecessor selected-ID artifact, absent only for cohort zero.
    pub excluded_population_identity: Option<V36ArtifactIdentity>,
    /// SHA-256 of the complete ordered source manifest.
    pub ordered_source_manifest_sha256: String,
    /// SHA-256 population-row seed.
    pub population_seed_sha256: String,
    /// Number of complete source objects in the registered window.
    pub selected_object_count: u16,
    /// Global ordinal of the first source object in the window.
    pub selected_object_start: u16,
    /// Exact number of population rows to select.
    pub selected_rows: u64,
}

/// Bind a complete file-backed population count to the frozen external
/// selection authority used by the checkpoint pipeline.
pub fn bind_v36_prefix_external_selection_authority(
    authority: &V36PrefixFreezeAuthority,
    complete_distinct_rows: u64,
) -> Result<V36PrefixExternalSelectionAuthority> {
    let bound = V36PrefixExternalSelectionAuthority {
        cohort_ordinal: authority.cohort_ordinal,
        distinct_rows: complete_distinct_rows,
        excluded_population_identity: authority.excluded_population_identity.clone(),
        ordered_source_manifest_sha256: authority.ordered_source_manifest_sha256.clone(),
        population_seed_sha256: authority.population_seed_sha256.clone(),
        selected_object_count: authority.selected_object_count,
        selected_object_start: authority.selected_object_start,
        selected_rows: authority.distinct_candidates,
    };
    validate_external_selection_authority(&bound)?;
    Ok(bound)
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// One authenticated predecessor selected-ID file used for cohort exclusion.
pub struct V36PrefixSelectedIdsFile {
    /// Exact contract encoded by the predecessor artifact.
    pub contract: V36PrefixSelectedIdsContract,
    /// Registered immutable Arrow artifact identity.
    pub identity: V36ArtifactIdentity,
    /// Exact local regular-file path.
    pub path: PathBuf,
}

/// Complete file-backed request for one bounded external population selection.
pub struct V36PrefixExternalSelectionRequest<'a> {
    /// Selection authority containing only values knowable before the anti-join.
    pub authority: &'a V36PrefixExternalSelectionAuthority,
    /// Optional authenticated predecessor selected-ID artifact.
    pub exclusion: Option<&'a V36PrefixSelectedIdsFile>,
    /// Hard resource limits for the attempt.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Final canonical selected-ID Arrow destination.
    pub output: &'a Path,
    /// S3 URI prefix used to form the content-addressed receipt.
    pub output_uri_prefix: &'a str,
    /// Complete authenticated identity-run window.
    pub runs: &'a [V36PrefixIdentityRunFile],
    /// Existing directory beneath which attempt-owned scratch is created.
    pub scratch_root: &'a Path,
}

/// Inputs for the atomic file-backed Population-to-Selected checkpoint transition.
pub struct V36PrefixCheckpointSelectionRequest<'a> {
    /// Frozen authority for the complete external selection.
    pub authority: &'a V36PrefixExternalSelectionAuthority,
    /// Optional authenticated predecessor selection used for cohort exclusion.
    pub exclusion: Option<&'a V36PrefixSelectedIdsFile>,
    /// Hard external-memory and scratch limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Final canonical selected-ID Arrow destination.
    pub output: &'a Path,
    /// S3 URI prefix used to form the content-addressed receipt.
    pub output_uri_prefix: &'a str,
    /// Complete authenticated population state being selected.
    pub population: &'a V36PrefixFileBackedPopulationScan,
    /// Existing directory beneath which attempt-owned scratch is created.
    pub scratch_root: &'a Path,
    /// Checkpoint writer whose installed population dependencies must match `population`.
    pub writer: &'a mut V36PrefixPopulationCheckpointWriter,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated selected file and checkpoint publication produced by one transition.
pub struct V36PrefixCheckpointSelection {
    /// Content-addressed selected-ID file ready for later role assignment.
    pub selected: V36PrefixSelectedIdsFile,
    /// Selection receipt produced by the bounded external merge.
    pub receipt: V36PrefixSelectedFileReceipt,
    /// Exact selection embedded in the checkpoint manifest.
    pub selection: V36PrefixPopulationSelection,
    /// Ready-file path for the atomic checkpoint publication.
    pub checkpoint_ready: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Exact authority for assigning one selected population to disjoint roles.
pub struct V36PrefixRoleAssignmentContract {
    /// Exact number of source-corpus rows retained after query removal.
    pub corpus_rows: u64,
    /// Frozen corpus ordering seed label.
    pub corpus_seed_label: String,
    /// SHA-256 of the corpus seed label.
    pub corpus_seed_sha256: String,
    /// SHA-256 of the complete ordered source manifest.
    pub ordered_source_manifest_sha256: String,
    /// Priority-ordered disjoint query roles.
    pub roles: Vec<V36PrefixRoleAuthority>,
    /// Number of selected source objects.
    pub selected_object_count: u16,
    /// Global ordinal of the first selected source object.
    pub selected_object_start: u16,
    /// Exact immutable selected-population artifact.
    pub selected_population_identity: V36ArtifactIdentity,
    /// Exact selected-population row count.
    pub selected_rows: u64,
}

/// Derive the exact role-assignment contract from frozen freeze authority and
/// one authenticated selected-ID artifact.
pub fn bind_v36_prefix_role_assignment_contract(
    authority: &V36PrefixFreezeAuthority,
    selection: &V36PrefixPopulationSelection,
    selected: &V36PrefixSelectedIdsFile,
) -> Result<V36PrefixRoleAssignmentContract> {
    let expected_selected_contract = bind_v36_prefix_selected_ids_contract(authority, selection)?;
    validate_selected_ids_contract(&selected.contract)?;
    if selected.identity != selection.selected_ids
        || selected.contract != expected_selected_contract
        || selected.contract.cohort_ordinal != authority.cohort_ordinal
        || selected.contract.excluded_population_identity != authority.excluded_population_identity
        || selected.contract.ordered_source_manifest_sha256
            != authority.ordered_source_manifest_sha256
        || selected.contract.population_seed_sha256 != authority.population_seed_sha256
        || selected.contract.selected_object_count != authority.selected_object_count
        || selected.contract.selected_object_start != authority.selected_object_start
        || selected.contract.selected_rows != authority.distinct_candidates
    {
        return Err(invalid("V36 prefix checkpoint role authority differs"));
    }
    let contract = V36PrefixRoleAssignmentContract {
        corpus_rows: authority.corpus_rows,
        corpus_seed_label: authority.corpus_seed_label.clone(),
        corpus_seed_sha256: authority.corpus_seed_sha256.clone(),
        ordered_source_manifest_sha256: authority.ordered_source_manifest_sha256.clone(),
        roles: authority.roles.clone(),
        selected_object_count: authority.selected_object_count,
        selected_object_start: authority.selected_object_start,
        selected_population_identity: selected.identity.clone(),
        selected_rows: selected.contract.selected_rows,
    };
    validate_v36_prefix_role_assignment_contract(&contract, selected)?;
    Ok(contract)
}

/// File-backed request for bounded deterministic role assignment.
pub struct V36PrefixRoleAssignmentRequest<'a> {
    /// Role and selected-population authority.
    pub contract: &'a V36PrefixRoleAssignmentContract,
    /// Hard external-memory limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Final canonical Arrow destination.
    pub output: &'a Path,
    /// S3 URI prefix used for the content-addressed receipt.
    pub output_uri_prefix: &'a str,
    /// Existing directory beneath which attempt-owned scratch is created.
    pub scratch_root: &'a Path,
    /// Authenticated selected-population Arrow file.
    pub selected: &'a V36PrefixSelectedIdsFile,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated receipt for one physical-order role-assignment artifact.
pub struct V36PrefixRoleAssignmentReceipt {
    /// Exact content-addressed Arrow identity.
    pub identity: V36ArtifactIdentity,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated local role-assignment Arrow used for physical materialization.
pub struct V36PrefixRoleAssignmentFile {
    /// Exact assignment authority encoded by the artifact.
    pub contract: V36PrefixRoleAssignmentContract,
    /// Registered immutable Arrow identity.
    pub identity: V36ArtifactIdentity,
    /// Exact local regular-file path.
    pub path: PathBuf,
}

/// File-backed request for one physical merge-join materialization.
pub struct V36PrefixExternalMaterializationRequest<'a> {
    /// Authenticated physical-order role assignment.
    pub assignment: &'a V36PrefixRoleAssignmentFile,
    /// Hard file and buffer limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Existing empty output directory receiving no-clobber role files after all roles close.
    pub output: &'a Path,
    /// Complete source registry in frozen sample-rank order.
    pub ranked_objects: &'a [V36PrefixRankedSourceObject],
    /// Existing directory for attempt-owned private spools.
    pub scratch_root: &'a Path,
    /// Authenticated local source objects corresponding one-to-one with the window.
    pub source_paths: &'a [PathBuf],
}

/// Inputs for the atomic file-backed Selected-to-Materialized checkpoint transition.
pub struct V36PrefixCheckpointMaterializationRequest<'a> {
    /// Exact role-assignment authority for the selected population.
    pub contract: &'a V36PrefixRoleAssignmentContract,
    /// Hard external-memory and scratch limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Existing empty output directory receiving the materialized artifacts.
    pub output: &'a Path,
    /// Content-addressed checkpoint object prefix.
    pub output_uri_prefix: &'a str,
    /// Complete typed population authority written alongside role Parquets.
    pub population: &'a V36PrefixPopulationAuthority,
    /// Complete registered source window in frozen rank order.
    pub ranked_objects: &'a [V36PrefixRankedSourceObject],
    /// Complete registered source-object list bound by `population`.
    pub source_registry: &'a [V36PrefixRegisteredSourceObject],
    /// Existing directory for bounded attempt-owned private scratch.
    pub scratch_root: &'a Path,
    /// Exact selected-ID file bound by the preceding checkpoint.
    pub selected: &'a V36PrefixSelectedIdsFile,
    /// Authenticated local source objects corresponding to the registered window.
    pub source_paths: &'a [PathBuf],
    /// Checkpoint writer whose preceding phase must bind `selected`.
    pub writer: &'a mut V36PrefixPopulationCheckpointWriter,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated materialization and checkpoint publication produced by one transition.
pub struct V36PrefixCheckpointMaterialization {
    /// Exact immutable identities embedded in the Materialized checkpoint.
    pub artifacts: V36PrefixMaterializedArtifacts,
    /// Ready-file path for the atomic checkpoint publication.
    pub checkpoint_ready: PathBuf,
    /// Final role-separated Parquet paths.
    pub paths: V36PrefixRoleParquetPaths,
}

/// Inputs for one bounded Materialized-to-GroundTruth checkpoint transition.
pub struct V36PrefixCheckpointGroundTruthRequest<'a> {
    /// Complete source-row block size used by the existing exact-GT engine.
    pub block_rows: usize,
    /// Existing directory receiving immutable heap Arrow files.
    pub output_root: &'a Path,
    /// Content-addressed checkpoint object prefix.
    pub output_uri_prefix: &'a str,
    /// Authenticated Materialized continuation state.
    pub state: &'a V36PrefixCheckpointResumeState,
    /// Fixed worker count for the exact kernel.
    pub worker_threads: usize,
    /// Checkpoint writer restored from the same Materialized head.
    pub writer: &'a mut V36PrefixPopulationCheckpointWriter,
}

#[derive(Debug, Clone, PartialEq)]
/// Exact truth and durable heap boundary produced by one transition.
pub struct V36PrefixCheckpointGroundTruth {
    /// Ready-file path for a newly published boundary, absent at authenticated EOF.
    pub checkpoint_ready: Option<PathBuf>,
    /// Authenticated newest all-query heap Arrow file.
    pub heaps: V36PrefixCheckpointDependencyFile,
    /// Bounded work evidence from the exact-GT engine.
    pub stats: V36PrefixGtRunStats,
    /// Exact GT@100 for the three quality roles.
    pub truth: [Vec<V36PrefixGtNeighbor>; 3],
}

/// Inputs for one terminal GroundTruth-to-Complete checkpoint transition.
pub struct V36PrefixCheckpointCompletionRequest<'a> {
    /// Existing empty directory receiving exact-GT Parquets.
    pub output_root: &'a Path,
    /// Content-addressed checkpoint object prefix.
    pub output_uri_prefix: &'a str,
    /// Authenticated GroundTruth state at corpus EOF.
    pub state: &'a V36PrefixCheckpointResumeState,
    /// Writer restored from the same GroundTruth head.
    pub writer: &'a mut V36PrefixPopulationCheckpointWriter,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Terminal exact-GT artifacts and checkpoint publication.
pub struct V36PrefixCheckpointCompletion {
    /// Ready-file path for the atomic Complete publication.
    pub checkpoint_ready: PathBuf,
    /// Exact heap plus development, validation, and sealed-holdout identities.
    pub ground_truth: crate::V36PrefixGroundTruthArtifacts,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Exact authority embedded in one immutable selected-population Arrow artifact.
pub struct V36PrefixSelectedIdsContract {
    /// Zero-based independently registered population cohort.
    pub cohort_ordinal: u8,
    /// Distinct rows eligible after applying the prior-cohort exclusion.
    pub eligible_rows: u64,
    /// Exact prior-cohort selected-ID artifact, absent only for cohort zero.
    pub excluded_population_identity: Option<V36ArtifactIdentity>,
    /// Distinct rows removed by the authenticated exclusion.
    pub excluded_rows: u64,
    /// SHA-256 of the complete ordered source manifest.
    pub ordered_source_manifest_sha256: String,
    /// SHA-256 population-row seed.
    pub population_seed_sha256: String,
    /// Number of complete source objects in the registered window.
    pub selected_object_count: u16,
    /// Global ordinal of the first source object in the window.
    pub selected_object_start: u16,
    /// Exact number of selected population rows.
    pub selected_rows: u64,
}

/// Derive the exact selected-ID file contract from frozen freeze authority and
/// a checkpointed selection receipt.
pub fn bind_v36_prefix_selected_ids_contract(
    authority: &V36PrefixFreezeAuthority,
    selection: &V36PrefixPopulationSelection,
) -> Result<V36PrefixSelectedIdsContract> {
    if selection.selected_rows != authority.distinct_candidates
        || selection.excluded_population_identity != authority.excluded_population_identity
        || selection.selected_ids.role != "population-selected-identities"
        || selection.selected_ids.encoded_bytes == 0
        || selection.selected_ids.uri.is_empty()
        || digest_bytes(&selection.selected_ids.sha256).is_err()
        || digest_bytes(&selection.selected_ids.blake3).is_err()
        || digest_bytes(&selection.cutoff_score_sha256).is_err()
    {
        return Err(invalid("V36 prefix checkpoint selection authority differs"));
    }
    let contract = V36PrefixSelectedIdsContract {
        cohort_ordinal: authority.cohort_ordinal,
        eligible_rows: selection.eligible_rows,
        excluded_population_identity: selection.excluded_population_identity.clone(),
        excluded_rows: selection.excluded_rows,
        ordered_source_manifest_sha256: authority.ordered_source_manifest_sha256.clone(),
        population_seed_sha256: authority.population_seed_sha256.clone(),
        selected_object_count: authority.selected_object_count,
        selected_object_start: authority.selected_object_start,
        selected_rows: selection.selected_rows,
    };
    validate_selected_ids_contract(&contract)?;
    Ok(contract)
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated selected population decoded from its immutable Arrow artifact.
pub struct V36PrefixSelectedIds {
    /// Feature-row ID at the inclusive population-score cutoff.
    pub cutoff_feature_row_id: u64,
    /// Population score at the inclusive cutoff.
    pub cutoff_score_sha256: String,
    /// Selected rows in strict `(score, unsigned feature ID)` order.
    pub rows: Vec<V36PrefixRowIdentity>,
}

fn selected_ids_metadata(
    contract: &V36PrefixSelectedIdsContract,
    cutoff_feature_row_id: u64,
    cutoff_score_sha256: &str,
) -> HashMap<String, String> {
    let mut metadata = HashMap::from([
        (
            "cohort_ordinal".to_owned(),
            contract.cohort_ordinal.to_string(),
        ),
        (
            "cutoff_feature_row_id".to_owned(),
            cutoff_feature_row_id.to_string(),
        ),
        (
            "cutoff_score_sha256".to_owned(),
            cutoff_score_sha256.to_owned(),
        ),
        (
            "eligible_rows".to_owned(),
            contract.eligible_rows.to_string(),
        ),
        (
            "excluded_rows".to_owned(),
            contract.excluded_rows.to_string(),
        ),
        ("format".to_owned(), SELECTED_IDS_FORMAT.to_owned()),
        (
            "ordered_source_manifest_sha256".to_owned(),
            contract.ordered_source_manifest_sha256.clone(),
        ),
        (
            "population_seed_sha256".to_owned(),
            contract.population_seed_sha256.clone(),
        ),
        (
            "score_algorithm".to_owned(),
            POPULATION_SCORE_ALGORITHM.to_owned(),
        ),
        (
            "selected_object_count".to_owned(),
            contract.selected_object_count.to_string(),
        ),
        (
            "selected_object_start".to_owned(),
            contract.selected_object_start.to_string(),
        ),
        (
            "selected_rows".to_owned(),
            contract.selected_rows.to_string(),
        ),
    ]);
    match &contract.excluded_population_identity {
        Some(identity) => {
            metadata.insert(
                "excluded_population_blake3".to_owned(),
                identity.blake3.clone(),
            );
            metadata.insert(
                "excluded_population_encoded_bytes".to_owned(),
                identity.encoded_bytes.to_string(),
            );
            metadata.insert("excluded_population_role".to_owned(), identity.role.clone());
            metadata.insert(
                "excluded_population_sha256".to_owned(),
                identity.sha256.clone(),
            );
            metadata.insert("excluded_population_uri".to_owned(), identity.uri.clone());
        }
        None => {
            for key in [
                "excluded_population_blake3",
                "excluded_population_encoded_bytes",
                "excluded_population_role",
                "excluded_population_sha256",
                "excluded_population_uri",
            ] {
                metadata.insert(key.to_owned(), "none".to_owned());
            }
        }
    }
    metadata
}

fn selected_ids_schema(
    contract: &V36PrefixSelectedIdsContract,
    cutoff_feature_row_id: u64,
    cutoff_score_sha256: &str,
) -> Schema {
    Schema::new_with_metadata(
        vec![
            Field::new("feature_row_id", DataType::UInt64, false),
            Field::new("population_score", DataType::FixedSizeBinary(32), false),
            Field::new("selected_object_ordinal", DataType::UInt16, false),
            Field::new("row_offset", DataType::UInt64, false),
        ],
        selected_ids_metadata(contract, cutoff_feature_row_id, cutoff_score_sha256),
    )
}

fn validate_selected_ids_contract(
    contract: &V36PrefixSelectedIdsContract,
) -> Result<([u8; 32], [u8; 32])> {
    let seed = digest_bytes(&contract.population_seed_sha256)?;
    let manifest = digest_bytes(&contract.ordered_source_manifest_sha256)?;
    let window_end = contract
        .selected_object_start
        .checked_add(contract.selected_object_count)
        .ok_or_else(|| invalid("V36 prefix selected-ID object window overflows"))?;
    if contract.population_seed_sha256 != POPULATION_SEED_SHA256
        || contract.selected_object_count == 0
        || contract.selected_rows == 0
        || contract.selected_rows > contract.eligible_rows
        || (contract.cohort_ordinal == 0
            && (contract.excluded_rows != 0 || contract.excluded_population_identity.is_some()))
        || (contract.cohort_ordinal != 0 && contract.excluded_population_identity.is_none())
        || contract
            .excluded_population_identity
            .as_ref()
            .is_some_and(|identity| {
                identity.encoded_bytes == 0
                    || identity.role != "population-selected-identities"
                    || digest_bytes(&identity.sha256).is_err()
                    || digest_bytes(&identity.blake3).is_err()
                    || identity.uri.is_empty()
            })
        || window_end <= contract.selected_object_start
    {
        return Err(invalid("V36 prefix selected-ID contract differs"));
    }
    Ok((seed, manifest))
}

fn validate_external_selection_authority(
    authority: &V36PrefixExternalSelectionAuthority,
) -> Result<([u8; 32], [u8; 32])> {
    let seed = digest_bytes(&authority.population_seed_sha256)?;
    let manifest = digest_bytes(&authority.ordered_source_manifest_sha256)?;
    let window_end = authority
        .selected_object_start
        .checked_add(authority.selected_object_count)
        .ok_or_else(|| invalid("V36 prefix selected-ID object window overflows"))?;
    if authority.population_seed_sha256 != POPULATION_SEED_SHA256
        || authority.selected_object_count == 0
        || authority.distinct_rows == 0
        || authority.selected_rows == 0
        || authority.selected_rows > authority.distinct_rows
        || (authority.cohort_ordinal == 0 && authority.excluded_population_identity.is_some())
        || (authority.cohort_ordinal != 0 && authority.excluded_population_identity.is_none())
        || authority
            .excluded_population_identity
            .as_ref()
            .is_some_and(|identity| {
                identity.encoded_bytes == 0
                    || identity.role != "population-selected-identities"
                    || digest_bytes(&identity.sha256).is_err()
                    || digest_bytes(&identity.blake3).is_err()
                    || identity.uri.is_empty()
            })
        || window_end <= authority.selected_object_start
    {
        return Err(invalid("V36 prefix external selection authority differs"));
    }
    Ok((seed, manifest))
}

fn validate_selected_id_rows(
    contract: &V36PrefixSelectedIdsContract,
    rows: &[V36PrefixRowIdentity],
) -> Result<()> {
    let (seed, manifest) = validate_selected_ids_contract(contract)?;
    if rows.len() as u64 != contract.selected_rows {
        return Err(invalid("V36 prefix selected-ID row count differs"));
    }
    let window_end = contract.selected_object_start + contract.selected_object_count;
    let mut physical = HashSet::with_capacity(rows.len());
    let mut previous = None;
    for row in rows {
        let score = score(&seed, &manifest, row.feature_row_id);
        let rank = (score, row.feature_row_id);
        if row.source_ordinal.is_some()
            || row.selected_object_ordinal < contract.selected_object_start
            || row.selected_object_ordinal >= window_end
            || !physical.insert((row.selected_object_ordinal, row.row_offset))
            || previous.is_some_and(|prior| prior >= rank)
        {
            return Err(invalid("V36 prefix selected-ID rows differ"));
        }
        previous = Some(rank);
    }
    Ok(())
}

/// Encode one strict, deterministic selected-population Arrow IPC artifact.
pub fn encode_v36_prefix_selected_ids(
    contract: &V36PrefixSelectedIdsContract,
    rows: &[V36PrefixRowIdentity],
) -> Result<Vec<u8>> {
    validate_selected_id_rows(contract, rows)?;
    let cutoff = rows
        .last()
        .ok_or_else(|| invalid("V36 prefix selected-ID cutoff is missing"))?;
    let (seed, manifest) = validate_selected_ids_contract(contract)?;
    let cutoff_score = score(&seed, &manifest, cutoff.feature_row_id);
    let schema = Arc::new(selected_ids_schema(
        contract,
        cutoff.feature_row_id,
        &digest_hex(&cutoff_score),
    ));
    let options = IpcWriteOptions::try_new(8, false, MetadataVersion::V5)?;
    let mut bytes = Vec::new();
    let mut writer = ArrowFileWriter::try_new_with_options(&mut bytes, schema.as_ref(), options)?;
    for rows in rows.chunks(SELECTED_IDS_BATCH_ROWS) {
        let scores = rows
            .iter()
            .map(|row| score(&seed, &manifest, row.feature_row_id))
            .collect::<Vec<_>>();
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(UInt64Array::from(
                    rows.iter()
                        .map(|row| row.feature_row_id)
                        .collect::<Vec<_>>(),
                )),
                Arc::new(FixedSizeBinaryArray::try_from_iter(
                    scores.iter().map(<[u8; 32]>::as_slice),
                )?),
                Arc::new(UInt16Array::from(
                    rows.iter()
                        .map(|row| row.selected_object_ordinal)
                        .collect::<Vec<_>>(),
                )),
                Arc::new(UInt64Array::from(
                    rows.iter().map(|row| row.row_offset).collect::<Vec<_>>(),
                )),
            ],
        )?;
        writer.write(&batch)?;
    }
    writer.finish()?;
    drop(writer);
    Ok(bytes)
}

/// Authenticate and decode one immutable selected-population Arrow IPC artifact.
pub fn decode_v36_prefix_selected_ids(
    bytes: &[u8],
    registered: &V36ArtifactIdentity,
    contract: &V36PrefixSelectedIdsContract,
) -> Result<V36PrefixSelectedIds> {
    validate_selected_ids_contract(contract)?;
    let sha256 = format!("{:x}", Sha256::digest(bytes));
    let blake3 = blake3::hash(bytes).to_hex().to_string();
    let content_addressed = url::Url::parse(&registered.uri)
        .ok()
        .filter(|uri| uri.scheme() == "s3" && uri.host_str().is_some())
        .and_then(|uri| uri.path().rsplit('/').next().map(str::to_owned))
        .is_some_and(|name| name.starts_with(&format!("{sha256}-")));
    if registered.role != "population-selected-identities"
        || registered.encoded_bytes != bytes.len() as u64
        || registered.sha256 != sha256
        || registered.blake3 != blake3
        || !content_addressed
    {
        return Err(invalid("V36 prefix selected-ID artifact differs"));
    }
    let mut reader = ArrowFileReader::try_new(std::io::Cursor::new(bytes), None)?;
    let selected_rows = usize::try_from(contract.selected_rows)
        .map_err(|_| invalid("V36 prefix selected-ID row count overflows"))?;
    let expected_batches = selected_rows.div_ceil(SELECTED_IDS_BATCH_ROWS);
    if reader.num_batches() != expected_batches {
        return Err(invalid("V36 prefix selected-ID batches differ"));
    }
    let schema = reader.schema();
    let cutoff_feature_row_id = schema
        .metadata()
        .get("cutoff_feature_row_id")
        .and_then(|value| value.parse::<u64>().ok())
        .ok_or_else(|| invalid("V36 prefix selected-ID schema differs"))?;
    let cutoff_score_sha256 = schema
        .metadata()
        .get("cutoff_score_sha256")
        .ok_or_else(|| invalid("V36 prefix selected-ID schema differs"))?;
    digest_bytes(cutoff_score_sha256)?;
    if schema.as_ref() != &selected_ids_schema(contract, cutoff_feature_row_id, cutoff_score_sha256)
    {
        return Err(invalid("V36 prefix selected-ID schema differs"));
    }
    let (seed, manifest) = validate_selected_ids_contract(contract)?;
    let mut rows = Vec::with_capacity(selected_rows);
    for batch_ordinal in 0..expected_batches {
        let batch = reader
            .next()
            .transpose()?
            .ok_or_else(|| invalid("V36 prefix selected-ID batch is missing"))?;
        let remaining = selected_rows - rows.len();
        let expected_rows = remaining.min(SELECTED_IDS_BATCH_ROWS);
        if batch.num_rows() != expected_rows || batch.num_columns() != 4 {
            return Err(invalid("V36 prefix selected-ID batches differ"));
        }
        let feature_ids = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix selected-ID feature IDs differ"))?;
        let encoded_scores = batch
            .column(1)
            .as_any()
            .downcast_ref::<FixedSizeBinaryArray>()
            .ok_or_else(|| invalid("V36 prefix selected-ID scores differ"))?;
        let object_ordinals = batch
            .column(2)
            .as_any()
            .downcast_ref::<UInt16Array>()
            .ok_or_else(|| invalid("V36 prefix selected-ID object ordinals differ"))?;
        let row_offsets = batch
            .column(3)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix selected-ID row offsets differ"))?;
        for index in 0..batch.num_rows() {
            let feature_row_id = feature_ids.value(index);
            let expected_score = score(&seed, &manifest, feature_row_id);
            if encoded_scores.value(index) != expected_score {
                return Err(invalid("V36 prefix selected-ID scores differ"));
            }
            rows.push(V36PrefixRowIdentity {
                feature_row_id,
                source_ordinal: None,
                selected_object_ordinal: object_ordinals.value(index),
                row_offset: row_offsets.value(index),
            });
        }
        if batch_ordinal + 1 < expected_batches && batch.num_rows() != SELECTED_IDS_BATCH_ROWS {
            return Err(invalid("V36 prefix selected-ID batches differ"));
        }
    }
    if reader.next().is_some() || rows.len() != selected_rows {
        return Err(invalid("V36 prefix selected-ID row count differs"));
    }
    validate_selected_id_rows(contract, &rows)?;
    let cutoff = rows
        .last()
        .ok_or_else(|| invalid("V36 prefix selected-ID cutoff is missing"))?;
    let derived_cutoff_score_sha256 = digest_hex(&score(&seed, &manifest, cutoff.feature_row_id));
    if cutoff.feature_row_id != cutoff_feature_row_id
        || derived_cutoff_score_sha256 != *cutoff_score_sha256
    {
        return Err(invalid("V36 prefix selected-ID cutoff differs"));
    }
    Ok(V36PrefixSelectedIds {
        cutoff_feature_row_id: cutoff.feature_row_id,
        cutoff_score_sha256: derived_cutoff_score_sha256,
        rows,
    })
}

fn v36_prefix_identity_run_schema(run: &V36PrefixIdentityRun, row_count: usize) -> Schema {
    Schema::new_with_metadata(
        vec![
            Field::new("feature_row_id", DataType::UInt64, false),
            Field::new("row_offset", DataType::UInt64, false),
        ],
        HashMap::from([
            ("format".to_owned(), IDENTITY_RUN_FORMAT.to_owned()),
            (
                "selected_object_ordinal".to_owned(),
                run.selected_object_ordinal.to_string(),
            ),
            ("physical_rows".to_owned(), run.physical_rows.to_string()),
            ("rows".to_owned(), row_count.to_string()),
            ("source_blake3".to_owned(), run.source.blake3.clone()),
            (
                "source_encoded_bytes".to_owned(),
                run.source.encoded_bytes.to_string(),
            ),
            ("source_path".to_owned(), run.source.path.clone()),
            (
                "source_sample_sha256".to_owned(),
                run.source.sample_sha256.clone(),
            ),
            ("source_sha256".to_owned(), run.source.sha256.clone()),
            ("source_uri".to_owned(), run.source.uri.clone()),
        ]),
    )
}

fn v36_prefix_object_sample_sha256(path: &str, encoded_bytes: u64) -> String {
    let mut sample = Sha256::new();
    sample.update(b"borsuk-v36-screen-object-v1");
    sample.update(path.as_bytes());
    sample.update(encoded_bytes.to_le_bytes());
    format!("{:x}", sample.finalize())
}

fn validate_v36_prefix_identity_run(run: &V36PrefixIdentityRun) -> Result<()> {
    let mut row_offsets = HashSet::with_capacity(run.rows.len());
    if run.physical_rows == 0
        || run.rows.len() as u64 > run.physical_rows
        || run.source.path.is_empty()
        || run.source.uri.is_empty()
        || run.source.encoded_bytes == 0
        || digest_bytes(&run.source.sha256).is_err()
        || digest_bytes(&run.source.blake3).is_err()
        || digest_bytes(&run.source.sample_sha256).is_err()
        || run.source.sample_sha256
            != v36_prefix_object_sample_sha256(&run.source.path, run.source.encoded_bytes)
        || run.rows.iter().any(|row| {
            row.selected_object_ordinal != run.selected_object_ordinal
                || row.source_ordinal.is_some()
                || row.row_offset >= run.physical_rows
                || !row_offsets.insert(row.row_offset)
        })
        || run
            .rows
            .windows(2)
            .any(|pair| pair[0].feature_row_id >= pair[1].feature_row_id)
    {
        return Err(invalid("V36 prefix identity-run rows differ"));
    }
    Ok(())
}

fn write_v36_prefix_identity_run_batch<W: Write>(
    writer: &mut ArrowFileWriter<W>,
    schema: Arc<Schema>,
    rows: &[V36PrefixRowIdentity],
) -> Result<()> {
    writer.write(&RecordBatch::try_new(
        schema,
        vec![
            Arc::new(UInt64Array::from(
                rows.iter()
                    .map(|row| row.feature_row_id)
                    .collect::<Vec<_>>(),
            )),
            Arc::new(UInt64Array::from(
                rows.iter().map(|row| row.row_offset).collect::<Vec<_>>(),
            )),
        ],
    )?)?;
    Ok(())
}

/// Encode the first-occurrence identities contributed by one complete source object.
pub fn encode_v36_prefix_identity_run(run: &V36PrefixIdentityRun) -> Result<Vec<u8>> {
    validate_v36_prefix_identity_run(run)?;
    let schema = Arc::new(v36_prefix_identity_run_schema(run, run.rows.len()));
    let options = IpcWriteOptions::try_new(8, false, MetadataVersion::V5)?;
    let mut bytes = Vec::new();
    let mut writer = ArrowFileWriter::try_new_with_options(&mut bytes, schema.as_ref(), options)?;
    for rows in run.rows.chunks(IDENTITY_RUN_BATCH_ROWS) {
        write_v36_prefix_identity_run_batch(&mut writer, schema.clone(), rows)?;
    }
    writer.finish()?;
    drop(writer);
    Ok(bytes)
}

/// Authenticate and decode one complete immutable source-object identity run.
pub fn decode_v36_prefix_identity_run(
    bytes: &[u8],
    registered: &V36ArtifactIdentity,
    source: &V36PrefixSourceObject,
    selected_object_ordinal: u16,
) -> Result<V36PrefixIdentityRun> {
    let expected_role = format!("population-identity-run-{selected_object_ordinal:04}");
    let sha256 = format!("{:x}", Sha256::digest(bytes));
    let blake3 = blake3::hash(bytes).to_hex().to_string();
    let content_addressed = url::Url::parse(&registered.uri)
        .ok()
        .filter(|uri| uri.scheme() == "s3" && uri.host_str().is_some())
        .and_then(|uri| uri.path().rsplit('/').next().map(str::to_owned))
        .is_some_and(|name| name.starts_with(&format!("{sha256}-")));
    if registered.role != expected_role
        || registered.encoded_bytes != bytes.len() as u64
        || registered.sha256 != sha256
        || registered.blake3 != blake3
        || !content_addressed
    {
        return Err(invalid("V36 prefix identity-run artifact differs"));
    }

    let mut reader = ArrowFileReader::try_new(std::io::Cursor::new(bytes), None)?;
    let schema = reader.schema();
    let row_count = schema
        .metadata()
        .get("rows")
        .and_then(|value| value.parse::<u64>().ok())
        .ok_or_else(|| invalid("V36 prefix identity-run schema differs"))?;
    let physical_rows = schema
        .metadata()
        .get("physical_rows")
        .and_then(|value| value.parse::<u64>().ok())
        .ok_or_else(|| invalid("V36 prefix identity-run schema differs"))?;
    if row_count > physical_rows {
        return Err(invalid("V36 prefix identity-run row count differs"));
    }
    let row_count = usize::try_from(row_count)
        .map_err(|_| invalid("V36 prefix identity-run row count differs"))?;
    let expected_run = V36PrefixIdentityRun {
        physical_rows,
        rows: Vec::new(),
        selected_object_ordinal,
        source: source.clone(),
    };
    let expected_batches = row_count.div_ceil(IDENTITY_RUN_BATCH_ROWS);
    if schema.as_ref() != &v36_prefix_identity_run_schema(&expected_run, row_count)
        || reader.num_batches() != expected_batches
    {
        return Err(invalid("V36 prefix identity-run schema differs"));
    }
    let mut rows = Vec::with_capacity(row_count);
    for batch_index in 0..expected_batches {
        let batch = reader
            .next()
            .transpose()?
            .ok_or_else(|| invalid("V36 prefix identity-run batch is missing"))?;
        let expected_rows =
            (row_count - batch_index * IDENTITY_RUN_BATCH_ROWS).min(IDENTITY_RUN_BATCH_ROWS);
        if batch.num_rows() != expected_rows
            || batch.num_columns() != 2
            || batch
                .columns()
                .iter()
                .any(|column| column.null_count() != 0)
        {
            return Err(invalid("V36 prefix identity-run batches differ"));
        }
        let feature_ids = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix identity-run feature IDs differ"))?;
        let row_offsets = batch
            .column(1)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix identity-run row offsets differ"))?;
        rows.extend(feature_ids.values().iter().zip(row_offsets.values()).map(
            |(&feature_row_id, &row_offset)| V36PrefixRowIdentity {
                feature_row_id,
                source_ordinal: None,
                selected_object_ordinal,
                row_offset,
            },
        ));
    }
    if reader.next().is_some() || rows.len() != row_count {
        return Err(invalid("V36 prefix identity-run batches differ"));
    }
    let run = V36PrefixIdentityRun {
        physical_rows,
        rows,
        selected_object_ordinal,
        source: source.clone(),
    };
    validate_v36_prefix_identity_run(&run)?;
    Ok(run)
}

/// Reconstruct the exact completed population prefix from authenticated identity runs.
pub fn restore_v36_prefix_population(
    runs: &[V36PrefixIdentityRun],
    distinct_candidates: usize,
) -> Result<V36PrefixObjectPrefixScan> {
    let restored = restore_v36_prefix_population_state(runs, distinct_candidates)?;
    let (cutoff_object_ordinal, cutoff_row_offset) = restored
        .cutoff
        .ok_or(BorsukError::V36PrefixSourceInsufficient)?;
    Ok(V36PrefixObjectPrefixScan {
        consumed_objects: restored.consumed_objects,
        cutoff_object_ordinal,
        cutoff_row_offset,
        distinct_rows_observed: restored.distinct_rows_observed,
        duplicate_rows: restored.duplicate_rows,
        physical_rows: restored.physical_rows,
        unique_rows: restored.unique_rows,
    })
}

/// Reconstruct resumable population state at a complete source-object boundary.
pub fn restore_v36_prefix_population_state(
    runs: &[V36PrefixIdentityRun],
    distinct_candidates: usize,
) -> Result<V36PrefixRestoredPopulation> {
    if runs.is_empty() || runs.len() > 16 || distinct_candidates == 0 {
        return Err(invalid("V36 prefix identity-run replay limits differ"));
    }
    let mut source_paths = BTreeSet::new();
    let mut feature_ids = HashSet::with_capacity(distinct_candidates);
    let mut consumed_objects = Vec::with_capacity(runs.len());
    let mut unique_rows = Vec::with_capacity(distinct_candidates);
    let mut physical_rows = 0_u64;
    let mut cutoff = None;
    let selected_object_start = runs[0].selected_object_ordinal;
    for (ordinal, run) in runs.iter().enumerate() {
        validate_v36_prefix_identity_run(run)?;
        let expected_ordinal = selected_object_start
            .checked_add(
                u16::try_from(ordinal)
                    .map_err(|_| invalid("V36 prefix identity-run ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix identity-run ordinal overflows"))?;
        if run.selected_object_ordinal != expected_ordinal
            || !source_paths.insert(run.source.path.as_str())
        {
            return Err(invalid("V36 prefix identity-run sequence differs"));
        }
        physical_rows = physical_rows
            .checked_add(run.physical_rows)
            .ok_or_else(|| invalid("V36 prefix identity-run physical rows overflow"))?;
        let previous_distinct = feature_ids.len();
        for row in &run.rows {
            if !feature_ids.insert(row.feature_row_id) {
                return Err(invalid("V36 prefix identity-run global ID repeats"));
            }
            unique_rows.push(row.clone());
        }
        if previous_distinct < distinct_candidates && feature_ids.len() >= distinct_candidates {
            let local_index = distinct_candidates
                .checked_sub(previous_distinct)
                .and_then(|count| count.checked_sub(1))
                .ok_or_else(|| invalid("V36 prefix identity-run cutoff overflows"))?;
            let mut physical_offsets = run
                .rows
                .iter()
                .map(|row| row.row_offset)
                .collect::<Vec<_>>();
            physical_offsets.sort_unstable();
            cutoff = Some((
                run.selected_object_ordinal,
                *physical_offsets
                    .get(local_index)
                    .ok_or_else(|| invalid("V36 prefix identity-run cutoff differs"))?,
            ));
        }
        consumed_objects.push(run.source.clone());
    }
    let distinct_rows_observed = u64::try_from(feature_ids.len()).unwrap_or(u64::MAX);
    let duplicate_rows = physical_rows
        .checked_sub(distinct_rows_observed)
        .ok_or_else(|| invalid("V36 prefix identity-run duplicate rows underflow"))?;
    Ok(V36PrefixRestoredPopulation {
        consumed_objects,
        cutoff,
        distinct_rows_observed,
        duplicate_rows,
        next_object_ordinal: selected_object_start
            .checked_add(
                runs.len()
                    .try_into()
                    .map_err(|_| invalid("V36 prefix identity-run ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix identity-run ordinal overflows"))?,
        physical_rows,
        unique_rows,
    })
}

#[derive(Debug, Clone, PartialEq)]
/// One valid unique row after materialization ordering.
pub struct V36PrefixMaterializedRow {
    /// Unsigned logical feature ID.
    pub feature_row_id: u64,
    /// Corpus ordinal, absent for a query row.
    pub source_ordinal: Option<u64>,
    /// Exact source-domain f32 vector.
    pub embedding: Vec<f32>,
}

#[derive(Debug, Clone, PartialEq)]
/// One query row with its role-local ordinal.
pub struct V36PrefixQueryRow {
    /// Zero-based ordinal within a query role.
    pub query_ordinal: u32,
    /// Unsigned logical feature ID.
    pub feature_row_id: u64,
    /// Exact source-domain f32 vector.
    pub embedding: Vec<f32>,
}

#[derive(Debug, Clone, PartialEq)]
/// Disjoint role selection plus the query-excluded corpus.
pub struct V36PrefixRoleSplit {
    /// Development queries.
    pub development: Vec<V36PrefixRowIdentity>,
    /// Validation queries.
    pub validation: Vec<V36PrefixRowIdentity>,
    /// Once-opened sealed holdout queries.
    pub sealed_holdout: Vec<V36PrefixRowIdentity>,
    /// Timing-only queries with no exact-GT obligation.
    pub performance: Vec<V36PrefixRowIdentity>,
    /// Remaining rows ordered by the registered source score.
    pub corpus: Vec<V36PrefixRowIdentity>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// One registered source object with its query-independent sample score.
pub struct V36PrefixRankedSourceObject {
    /// Complete encoded length.
    pub encoded_bytes: u64,
    /// Registered path.
    pub path: String,
    /// Query-independent sample digest.
    pub sample_sha256: String,
    /// Complete-object SHA-256.
    pub sha256: String,
    /// Immutable object URI.
    pub uri: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Local immutable inputs for one bounded V36 prefix-freeze attempt.
pub struct V36PrefixFreezeRequest {
    /// Pre-freeze scientific authority path.
    pub authority: PathBuf,
    /// Empty private directory used for crash-atomic checkpoint handoff.
    pub checkpoint_outbox: PathBuf,
    /// Executable whose exact bytes are bound by the attempt authority.
    pub executable: PathBuf,
    /// Attempt lifecycle and provenance authority path.
    pub execution_authority: PathBuf,
    /// Empty output directory owned by this attempt.
    pub output: PathBuf,
    /// Exact EC2 instance producing this attempt's checkpoints.
    pub producer_instance_id: String,
    /// Exact locally staged newest population head, absent for a fresh attempt.
    pub resume_checkpoint: Option<PathBuf>,
    /// Empty encrypted scratch directory owned by this attempt.
    pub scratch: PathBuf,
    /// Exact source-code archive evidence path.
    pub source_archive: PathBuf,
    /// Complete registered source-object list path.
    pub source_registry: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated local state produced before any source-object network access.
pub struct V36PrefixFreezePreflight {
    /// Validated pre-freeze scientific authority.
    pub authority: V36PrefixFreezeAuthority,
    /// Trusted campaign authority used for every population checkpoint.
    pub checkpoint_context: V36PrefixCheckpointContext,
    /// Validated lifecycle and provenance authority.
    pub execution_authority: V36PrefixFreezeExecutionAuthority,
    /// Zero-based attempt ordinal parsed from the exact attempt identity.
    pub producer_attempt_ordinal: u8,
    /// Complete source registry in its canonical encoded order.
    pub registry: Vec<V36PrefixRegisteredSourceObject>,
    /// Query-independently ranked complete objects.
    pub ranked_objects: Vec<V36PrefixRankedSourceObject>,
    /// Fully authenticated prior population head, absent for a fresh attempt.
    pub resume_head: Option<V36PrefixCheckpointHead>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Complete bounded source-window scan evidence before role selection.
pub struct V36PrefixObjectPrefixScan {
    /// Every authenticated object in the registered window.
    pub consumed_objects: Vec<crate::V36PrefixSourceObject>,
    /// Selected-object ordinal containing the target distinct row.
    pub cutoff_object_ordinal: u16,
    /// Physical row offset of the target distinct row.
    pub cutoff_row_offset: u64,
    /// Distinct IDs observed across every complete consumed object.
    pub distinct_rows_observed: u64,
    /// Physical rows whose ID repeated an earlier occurrence.
    pub duplicate_rows: u64,
    /// Physical rows scanned across every complete consumed object.
    pub physical_rows: u64,
    /// Every first-occurrence identity in the registered window.
    pub unique_rows: Vec<V36PrefixRowIdentity>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// File-backed population progress without a resident cross-object identity set.
pub struct V36PrefixFileBackedPopulationScan {
    /// Complete authenticated source objects incorporated in ranked order.
    pub consumed_objects: Vec<V36PrefixSourceObject>,
    /// Complete distinct first occurrences observed so far.
    pub distinct_rows: u64,
    /// Complete duplicate physical rows observed so far.
    pub duplicate_rows: u64,
    /// Complete physical rows observed so far.
    pub physical_rows: u64,
    /// Authenticated per-object first-occurrence runs in source order.
    pub runs: Vec<V36PrefixIdentityRunFile>,
}

/// Inputs for bounded restoration of one population checkpoint writer and scan state.
pub struct V36PrefixFileBackedResumeRequest<'a> {
    /// Exact execution-authority digest for the replacement attempt.
    pub execution_authority_sha256: String,
    /// Fully staged checkpoint head to authenticate and install.
    pub head: V36PrefixCheckpointHead,
    /// Frozen campaign and source-window authority.
    pub context: V36PrefixCheckpointContext,
    /// Hard external-memory and scratch limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Exact replacement-attempt identifier.
    pub producer_attempt_id: String,
    /// Zero-based replacement-attempt ordinal.
    pub producer_attempt_ordinal: u8,
    /// Exact replacement instance identifier.
    pub producer_instance_id: String,
    /// Existing empty checkpoint outbox root.
    pub root: &'a Path,
    /// Existing private directory for bounded authentication scratch.
    pub scratch_root: &'a Path,
}

/// Inputs for resuming a writer and typed continuation from any checkpoint phase.
pub struct V36PrefixPhaseResumeRequest<'a> {
    /// Exact execution-authority digest for the replacement attempt.
    pub execution_authority_sha256: String,
    /// Fully staged checkpoint head to authenticate and install.
    pub head: V36PrefixCheckpointHead,
    /// Frozen campaign and source-window authority.
    pub context: V36PrefixCheckpointContext,
    /// Hard external-memory and scratch limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Exact replacement-attempt identifier.
    pub producer_attempt_id: String,
    /// Zero-based replacement-attempt ordinal.
    pub producer_attempt_ordinal: u8,
    /// Exact replacement instance identifier.
    pub producer_instance_id: String,
    /// Existing empty checkpoint outbox root.
    pub root: &'a Path,
    /// Existing private directory for bounded authentication scratch.
    pub scratch_root: &'a Path,
    /// Exact selected-ID contract for Selected and later phases.
    pub selected_contract: Option<&'a V36PrefixSelectedIdsContract>,
}

/// Request for one bounded, checkpointed, file-backed population scan.
pub struct V36PrefixFileBackedScanRequest<'a> {
    /// Maximum encoded bytes across the complete consumed source prefix.
    pub byte_cap: u64,
    /// Exact distinct population target.
    pub distinct_candidates: u64,
    /// Hard external-memory and scratch limits.
    pub limits: &'a V36PrefixExternalSelectionLimits,
    /// Content-addressed object prefix for identity-run receipts.
    pub output_uri_prefix: &'a str,
    /// Optional authenticated complete-object prefix from an interrupted attempt.
    pub prior: Option<&'a V36PrefixFileBackedPopulationScan>,
    /// Complete query-independent ranked source window.
    pub ranked_objects: &'a [V36PrefixRankedSourceObject],
    /// Existing empty directory for completed attempt-local run files.
    pub run_output_root: &'a Path,
    /// Existing private directory for bounded merge scratch.
    pub scratch_root: &'a Path,
    /// Global ordinal of the first source object in this cohort.
    pub selected_object_start: u16,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated population progress at any complete source-object boundary.
pub struct V36PrefixRestoredPopulation {
    /// Complete source objects incorporated in ranked order.
    pub consumed_objects: Vec<crate::V36PrefixSourceObject>,
    /// Registered cutoff, absent while more complete objects are required.
    pub cutoff: Option<(u16, u64)>,
    /// Distinct IDs observed through the complete object prefix.
    pub distinct_rows_observed: u64,
    /// Duplicate physical rows observed through the complete object prefix.
    pub duplicate_rows: u64,
    /// First registered object ordinal not yet incorporated.
    pub next_object_ordinal: u16,
    /// Physical rows observed through the complete object prefix.
    pub physical_rows: u64,
    /// Every first occurrence retained through the completed object prefix.
    pub unique_rows: Vec<V36PrefixRowIdentity>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// One durable population boundary emitted after a complete authenticated object.
pub struct V36PrefixPopulationCommit {
    /// Cutoff position once the requested distinct prefix has been reached.
    pub cutoff: Option<(u16, u64)>,
    /// Distinct IDs observed through this complete object.
    pub distinct_rows: u64,
    /// Duplicate physical rows observed through this complete object.
    pub duplicate_rows: u64,
    /// Physical rows observed through this complete object.
    pub physical_rows: u64,
    /// Complete-object first-occurrence evidence.
    pub run: V36PrefixIdentityRun,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// One file-backed durable population boundary after a complete authenticated object.
pub struct V36PrefixPopulationFileCommit {
    /// Distinct IDs observed through this complete object.
    pub distinct_rows: u64,
    /// Duplicate physical rows observed through this complete object.
    pub duplicate_rows: u64,
    /// Physical rows observed through this complete object.
    pub physical_rows: u64,
    /// Authenticated complete-object first-occurrence Arrow file.
    pub run: V36PrefixIdentityRunFile,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Strict role-separated Parquet outputs from one prefix population.
pub struct V36PrefixRoleParquetPaths {
    /// Development queries.
    pub development: PathBuf,
    /// Performance queries.
    pub performance: PathBuf,
    /// Sealed-holdout queries.
    pub sealed_holdout: PathBuf,
    /// Canonically ordered corpus.
    pub source: PathBuf,
    /// Validation queries.
    pub validation: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Query-blind inputs available while constructing V36 geometry.
pub struct V36PrefixGeometryConstructionInput {
    cohort_ordinal: u8,
    corpus_rows: u64,
    source: V36ArtifactIdentity,
}

impl V36PrefixGeometryConstructionInput {
    /// Return the independently registered screen cohort.
    pub const fn cohort_ordinal(&self) -> u8 {
        self.cohort_ordinal
    }

    /// Return the exact query-excluded corpus population.
    pub const fn corpus_rows(&self) -> u64 {
        self.corpus_rows
    }

    /// Return the complete authenticated source Parquet identity.
    pub const fn source(&self) -> &V36ArtifactIdentity {
        &self.source
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Development-only inputs available while evaluating V36 geometry.
pub struct V36PrefixGeometryDevelopmentInput {
    ground_truth: V36ArtifactIdentity,
    ground_truth_rows: u64,
    query: V36ArtifactIdentity,
    query_rows: u64,
}

impl V36PrefixGeometryDevelopmentInput {
    /// Return the complete authenticated development GT@100 Parquet identity.
    pub const fn ground_truth(&self) -> &V36ArtifactIdentity {
        &self.ground_truth
    }

    /// Return the exact development GT@100 row count.
    pub const fn ground_truth_rows(&self) -> u64 {
        self.ground_truth_rows
    }

    /// Return the complete authenticated development query Parquet identity.
    pub const fn query(&self) -> &V36ArtifactIdentity {
        &self.query
    }

    /// Return the exact development query count.
    pub const fn query_rows(&self) -> u64 {
        self.query_rows
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Capability-separated authenticated inputs for V36 geometry work.
pub struct V36PrefixGeometryInputs {
    construction: V36PrefixGeometryConstructionInput,
    development: V36PrefixGeometryDevelopmentInput,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Exact local files consumed by the bounded 1M geometry diagnostic.
pub struct V36PrefixGeometryLocalRequest {
    /// Canonical prefix-freeze authority JSON.
    pub authority: PathBuf,
    /// Complete authenticated development GT@100 Parquet.
    pub development_ground_truth: PathBuf,
    /// Complete authenticated development-query Parquet.
    pub development_query: PathBuf,
    /// Canonical prefix-freeze execution authority JSON.
    pub execution_authority: PathBuf,
    /// Canonical completed prefix-freeze receipt JSON.
    pub receipt: PathBuf,
    /// Complete authenticated one-million-row source Parquet.
    pub source: PathBuf,
    /// Canonical complete source-registry JSON.
    pub source_registry: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Query-blind local files consumed by V36 geometry construction.
pub struct V36PrefixGeometryConstructionLocalRequest {
    /// Canonical prefix-freeze authority JSON.
    pub authority: PathBuf,
    /// Canonical prefix-freeze execution authority JSON.
    pub execution_authority: PathBuf,
    /// Canonical completed prefix-freeze receipt JSON.
    pub receipt: PathBuf,
    /// Complete authenticated one-million-row source Parquet.
    pub source: PathBuf,
    /// Canonical complete source-registry JSON.
    pub source_registry: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Evaluation-only local files opened after query-blind geometry construction.
pub struct V36PrefixGeometryDevelopmentLocalRequest {
    /// Complete authenticated development GT@100 Parquet.
    pub development_ground_truth: PathBuf,
    /// Complete authenticated development-query Parquet.
    pub development_query: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated query-blind local capability for V36 geometry construction.
pub struct V36PrefixGeometryConstructionLocalFiles {
    inputs: V36PrefixGeometryInputs,
    source: PathBuf,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated burnable development capability without a source handle.
pub struct V36PrefixGeometryDevelopmentLocalFiles {
    development: V36PrefixGeometryDevelopmentInput,
    development_ground_truth: PathBuf,
    development_query: PathBuf,
}

impl V36PrefixGeometryDevelopmentLocalFiles {
    /// Return the registered development identities and row counts.
    pub const fn input(&self) -> &V36PrefixGeometryDevelopmentInput {
        &self.development
    }

    /// Return the authenticated development-query path.
    pub fn development_query_path(&self) -> &Path {
        &self.development_query
    }

    /// Return the authenticated development GT@100 path.
    pub fn development_ground_truth_path(&self) -> &Path {
        &self.development_ground_truth
    }
}

impl V36PrefixGeometryConstructionLocalFiles {
    /// Return the capability-separated semantic authority without opening evaluation files.
    pub const fn inputs(&self) -> &V36PrefixGeometryInputs {
        &self.inputs
    }

    /// Return the authenticated one-million-row source path.
    pub fn source_path(&self) -> &Path {
        &self.source
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Authenticated local capabilities for one bounded 1M geometry diagnostic.
pub struct V36PrefixGeometryLocalFiles {
    development_ground_truth: PathBuf,
    development_query: PathBuf,
    inputs: V36PrefixGeometryInputs,
    source: PathBuf,
}

#[derive(Debug, Clone, PartialEq)]
/// Bounded replayable SRHT192 projection of one authenticated prefix source.
pub struct V36PrefixResidentProjectedSource {
    feature_ids: Vec<u64>,
    maximum_block_rows: usize,
    projected: Vec<f32>,
    projected_corpus_sha256: String,
}

impl V36PrefixResidentProjectedSource {
    /// Return source feature IDs in exact source-ordinal order.
    pub fn feature_ids(&self) -> &[u64] {
        &self.feature_ids
    }

    /// Return the exact projected row count.
    pub fn row_count(&self) -> usize {
        self.feature_ids.len()
    }

    /// Return the fixed routing dimension count.
    pub const fn dimensions(&self) -> usize {
        192
    }

    /// Return the domain-separated replay digest consumed by geometry training.
    pub fn projected_corpus_sha256(&self) -> &str {
        &self.projected_corpus_sha256
    }

    /// Borrow the contiguous projected f32 coordinates for an in-crate diagnostic.
    pub(crate) fn projected_coordinates(&self) -> &[f32] {
        &self.projected
    }
}

impl V36ProjectedCorpusSource for V36PrefixResidentProjectedSource {
    fn scan(&mut self, visitor: &mut V36ProjectedCorpusBlockVisitor<'_>) -> Result<()> {
        for start in (0..self.feature_ids.len()).step_by(self.maximum_block_rows) {
            let end = (start + self.maximum_block_rows).min(self.feature_ids.len());
            let ordinals = (start..end)
                .map(|ordinal| u64::try_from(ordinal).unwrap())
                .collect::<Vec<_>>();
            visitor(&ordinals, &self.projected[start * 192..end * 192])?;
        }
        Ok(())
    }
}

impl V36PrefixGeometryLocalFiles {
    /// Return the capability-separated semantic input authority.
    pub const fn inputs(&self) -> &V36PrefixGeometryInputs {
        &self.inputs
    }

    /// Return the authenticated one-million-row source path.
    pub fn source_path(&self) -> &Path {
        &self.source
    }

    /// Return the authenticated development-query path.
    pub fn development_query_path(&self) -> &Path {
        &self.development_query
    }

    /// Return the authenticated development GT@100 path.
    pub fn development_ground_truth_path(&self) -> &Path {
        &self.development_ground_truth
    }
}

impl V36PrefixGeometryInputs {
    /// Return the query-blind construction capability.
    pub const fn construction(&self) -> &V36PrefixGeometryConstructionInput {
        &self.construction
    }

    /// Return the burnable development evaluation capability.
    pub const fn development(&self) -> &V36PrefixGeometryDevelopmentInput {
        &self.development
    }
}

/// Project a validated prefix-freeze receipt into capability-separated geometry inputs.
pub fn bind_v36_prefix_geometry_inputs(
    receipt: &V36PrefixFreezeReceipt,
    authority: &V36PrefixFreezeAuthority,
    execution: &V36PrefixFreezeExecutionAuthority,
    source_registry: &[V36PrefixRegisteredSourceObject],
) -> Result<V36PrefixGeometryInputs> {
    validate_v36_prefix_freeze_receipt(receipt, authority, execution, source_registry)?;

    let output = |index: usize, role: &str| {
        receipt
            .outputs
            .get(index)
            .filter(|artifact| artifact.role == role)
            .cloned()
            .ok_or_else(|| invalid("V36 prefix geometry input role differs"))
    };
    let development = receipt
        .population
        .roles
        .iter()
        .find(|role| role.role == "development")
        .ok_or_else(|| invalid("V36 prefix geometry development role differs"))?;
    let ground_truth_rows = development
        .rows
        .checked_mul(GT_NEIGHBORS_U64)
        .ok_or_else(|| invalid("V36 prefix geometry GT row count overflows"))?;

    Ok(V36PrefixGeometryInputs {
        construction: V36PrefixGeometryConstructionInput {
            cohort_ordinal: receipt.population.cohort_ordinal,
            corpus_rows: receipt.population.corpus_rows,
            source: output(1, "source")?,
        },
        development: V36PrefixGeometryDevelopmentInput {
            ground_truth: output(3, "development-gt100")?,
            ground_truth_rows,
            query: output(2, "development-query")?,
            query_rows: development.rows,
        },
    })
}

pub(crate) fn load_v36_prefix_geometry_authority_bytes(
    authority_bytes: &[u8],
    execution_bytes: &[u8],
    receipt_bytes: &[u8],
    registry_bytes: &[u8],
) -> Result<V36PrefixGeometryInputs> {
    let authority: V36PrefixFreezeAuthority = serde_json::from_slice(authority_bytes)
        .map_err(|_| invalid("V36 prefix geometry authority JSON differs"))?;
    let execution: V36PrefixFreezeExecutionAuthority = serde_json::from_slice(execution_bytes)
        .map_err(|_| invalid("V36 prefix geometry execution JSON differs"))?;
    let receipt: V36PrefixFreezeReceipt = serde_json::from_slice(receipt_bytes)
        .map_err(|_| invalid("V36 prefix geometry receipt JSON differs"))?;
    let registry: Vec<V36PrefixRegisteredSourceObject> = serde_json::from_slice(registry_bytes)
        .map_err(|_| invalid("V36 prefix geometry registry JSON differs"))?;
    if canonical_v36_prefix_freeze_authority_bytes(&authority, &registry)? != authority_bytes
        || canonical_v36_prefix_freeze_execution_authority_bytes(&execution)? != execution_bytes
        || crate::canonical_v36_prefix_source_registry_bytes(&authority, &registry)?
            != registry_bytes
        || canonical_v36_prefix_freeze_receipt_bytes(&receipt, &authority, &execution, &registry)?
            != receipt_bytes
    {
        return Err(invalid("V36 prefix geometry canonical authority differs"));
    }
    let input = |role: &str| {
        execution
            .inputs
            .iter()
            .find(|identity| identity.role == role)
            .ok_or_else(|| invalid("V36 prefix geometry execution input differs"))
    };
    let matches_identity = |bytes: &[u8], identity: &V36ArtifactIdentity| {
        bytes.len() as u64 == identity.encoded_bytes
            && format!("{:x}", Sha256::digest(bytes)) == identity.sha256
            && blake3::hash(bytes).to_hex().as_str() == identity.blake3
    };
    if !matches_identity(authority_bytes, input("freeze-authority")?)
        || !matches_identity(registry_bytes, input("source-registry")?)
    {
        return Err(invalid("V36 prefix local input authority differs"));
    }
    bind_v36_prefix_geometry_inputs(&receipt, &authority, &execution, &registry)
}

fn load_v36_prefix_geometry_authority(
    authority_path: &Path,
    execution_path: &Path,
    receipt_path: &Path,
    registry_path: &Path,
) -> Result<V36PrefixGeometryInputs> {
    const MAXIMUM_AUTHORITY_BYTES: u64 = 16 * 1_048_576;

    let paths = [authority_path, execution_path, receipt_path, registry_path];
    let mut distinct = BTreeSet::new();
    if paths.iter().any(|path| !distinct.insert(*path)) {
        return Err(invalid("V36 prefix geometry local path roles overlap"));
    }
    let read_authority = |path: &Path| -> Result<Vec<u8>> {
        let length = fs::metadata(path)
            .map_err(|source| BorsukError::Io {
                path: path.to_owned(),
                source,
            })?
            .len();
        if length == 0 || length > MAXIMUM_AUTHORITY_BYTES {
            return Err(invalid("V36 prefix geometry authority length differs"));
        }
        read_file(path)
    };
    let authority_bytes = read_authority(authority_path)?;
    let execution_bytes = read_authority(execution_path)?;
    let receipt_bytes = read_authority(receipt_path)?;
    let registry_bytes = read_authority(registry_path)?;
    load_v36_prefix_geometry_authority_bytes(
        &authority_bytes,
        &execution_bytes,
        &receipt_bytes,
        &registry_bytes,
    )
}

/// Authenticate construction authority and source without opening query or truth objects.
pub fn load_v36_prefix_geometry_construction_local_files(
    request: V36PrefixGeometryConstructionLocalRequest,
) -> Result<V36PrefixGeometryConstructionLocalFiles> {
    let mut distinct = BTreeSet::new();
    if [
        &request.authority,
        &request.execution_authority,
        &request.receipt,
        &request.source,
        &request.source_registry,
    ]
    .into_iter()
    .any(|path| !distinct.insert(path.as_path()))
    {
        return Err(invalid("V36 prefix geometry local path roles overlap"));
    }
    let inputs = load_v36_prefix_geometry_authority(
        &request.authority,
        &request.execution_authority,
        &request.receipt,
        &request.source_registry,
    )?;
    authenticate_file(&request.source, inputs.construction().source())?;
    Ok(V36PrefixGeometryConstructionLocalFiles {
        inputs,
        source: request.source,
    })
}

/// Authenticate only the burnable development artifacts after construction is terminal.
pub fn load_v36_prefix_geometry_development_local_files(
    inputs: &V36PrefixGeometryInputs,
    request: V36PrefixGeometryDevelopmentLocalRequest,
) -> Result<V36PrefixGeometryDevelopmentLocalFiles> {
    if request.development_ground_truth == request.development_query {
        return Err(invalid("V36 prefix geometry local path roles overlap"));
    }
    authenticate_file(&request.development_query, inputs.development().query())?;
    authenticate_file(
        &request.development_ground_truth,
        inputs.development().ground_truth(),
    )?;
    Ok(V36PrefixGeometryDevelopmentLocalFiles {
        development: inputs.development().clone(),
        development_ground_truth: request.development_ground_truth,
        development_query: request.development_query,
    })
}

struct V36PrefixGeometryDevelopmentEvidence {
    projected_queries: Vec<Vec<f32>>,
    ground_truth_source_ordinals: Vec<Vec<u64>>,
}

fn load_v36_prefix_geometry_development_evidence(
    files: &V36PrefixGeometryDevelopmentLocalFiles,
    source_feature_ids: &[u64],
    diagnostic: &V36ResidentPostingDiagnostic,
) -> Result<V36PrefixGeometryDevelopmentEvidence> {
    if source_feature_ids.len() != diagnostic.assignments().source_ordinals().len()
        || diagnostic
            .assignments()
            .source_ordinals()
            .iter()
            .enumerate()
            .any(|(ordinal, observed)| *observed != u64::try_from(ordinal).unwrap_or(u64::MAX))
    {
        return Err(invalid(
            "V36 prefix geometry source ordinal binding differs",
        ));
    }
    let mut source_ordinals = HashMap::with_capacity(source_feature_ids.len());
    for (ordinal, feature_id) in source_feature_ids.iter().copied().enumerate() {
        if source_ordinals
            .insert(feature_id, u64::try_from(ordinal).unwrap_or(u64::MAX))
            .is_some()
        {
            return Err(invalid("V36 prefix geometry source membership differs"));
        }
    }
    let expected_queries = u32::try_from(files.development.query_rows)
        .map_err(|_| invalid("V36 prefix geometry query count differs"))?;
    let projection = build_v36_srht192_control()?;
    let mut projected_queries = Vec::with_capacity(expected_queries as usize);
    scan_v36_prefix_query_parquet(
        &files.development_query,
        u64::from(expected_queries),
        |batch| {
            for row in v36_prefix_query_rows_from_batch(&batch, 0, batch.num_rows())? {
                let projected = project_v35_query_simd(&projection, &row.embedding)?;
                projected_queries.push(
                    projected
                        .coordinates()
                        .iter()
                        .map(|value| {
                            let value = *value as f32;
                            if value == 0.0 { 0.0 } else { value }
                        })
                        .collect::<Vec<_>>(),
                );
            }
            Ok(())
        },
    )?;
    let mut ground_truth_source_ordinals =
        vec![Vec::with_capacity(GT_NEIGHBORS); expected_queries as usize];
    scan_v36_prefix_gt100_parquet(&files.development_ground_truth, expected_queries, |batch| {
        let queries = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt32Array>()
            .ok_or_else(|| invalid("V36 prefix GT query column differs"))?;
        let ids = batch
            .column(2)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix GT ID column differs"))?;
        for row in 0..batch.num_rows() {
            let query = usize::try_from(queries.value(row))
                .map_err(|_| invalid("V36 prefix geometry query ordinal differs"))?;
            let source_ordinal = source_ordinals
                .get(&ids.value(row))
                .copied()
                .ok_or_else(|| invalid("V36 prefix geometry GT membership differs"))?;
            ground_truth_source_ordinals
                .get_mut(query)
                .ok_or_else(|| invalid("V36 prefix geometry query ordinal differs"))?
                .push(source_ordinal);
        }
        Ok(())
    })?;
    if ground_truth_source_ordinals
        .iter()
        .any(|neighbors| neighbors.len() != GT_NEIGHBORS)
    {
        return Err(invalid("V36 prefix geometry GT cardinality differs"));
    }
    Ok(V36PrefixGeometryDevelopmentEvidence {
        projected_queries,
        ground_truth_source_ordinals,
    })
}

/// Evaluate exact GT containment for every centroid-ranked posting prefix.
///
/// The complete development query and GT Parquets are validated before their
/// scientific values are consumed. This computes a routing ceiling only and
/// performs no page or object-store reads.
pub fn evaluate_v36_prefix_geometry_development(
    files: &V36PrefixGeometryDevelopmentLocalFiles,
    source_feature_ids: &[u64],
    diagnostic: &V36ResidentPostingDiagnostic,
) -> Result<V36PostingContainmentDiagnostic> {
    let evidence =
        load_v36_prefix_geometry_development_evidence(files, source_feature_ids, diagnostic)?;
    evaluate_v36_posting_prefix_containment(
        diagnostic,
        &evidence.projected_queries,
        &evidence.ground_truth_source_ordinals,
    )
}

/// Evaluate the complete frozen equal-byte score ladder on authenticated development truth.
///
/// All summaries are trained before this function consumes query or truth values. The result is
/// a page-read-free routing ceiling and cannot make a serving or holdout claim.
pub fn evaluate_v36_prefix_geometry_development_scores(
    files: &V36PrefixGeometryDevelopmentLocalFiles,
    source_feature_ids: &[u64],
    diagnostic: &V36ResidentPostingDiagnostic,
    model: &V36ResidentPostingScoreModel,
) -> Result<Vec<V36PostingScoreContainment>> {
    let evidence =
        load_v36_prefix_geometry_development_evidence(files, source_feature_ids, diagnostic)?;
    evaluate_v36_posting_score_containment_with_model(
        diagnostic,
        model,
        &evidence.projected_queries,
        &evidence.ground_truth_source_ordinals,
    )
}

/// Authenticate the frozen prefix authority and three scientific objects before use.
pub fn load_v36_prefix_geometry_local_files(
    request: V36PrefixGeometryLocalRequest,
) -> Result<V36PrefixGeometryLocalFiles> {
    let paths = [
        &request.authority,
        &request.development_ground_truth,
        &request.development_query,
        &request.execution_authority,
        &request.receipt,
        &request.source,
        &request.source_registry,
    ];
    let mut distinct = BTreeSet::new();
    if paths.iter().any(|path| !distinct.insert(path.as_path())) {
        return Err(invalid("V36 prefix geometry local path roles overlap"));
    }
    let inputs = load_v36_prefix_geometry_authority(
        &request.authority,
        &request.execution_authority,
        &request.receipt,
        &request.source_registry,
    )?;
    authenticate_file(&request.source, inputs.construction().source())?;
    authenticate_file(&request.development_query, inputs.development().query())?;
    authenticate_file(
        &request.development_ground_truth,
        inputs.development().ground_truth(),
    )?;
    Ok(V36PrefixGeometryLocalFiles {
        development_ground_truth: request.development_ground_truth,
        development_query: request.development_query,
        inputs,
        source: request.source,
    })
}

/// Stream a validated source Parquet once into the bounded SRHT192 diagnostic buffer.
///
/// The caller must authenticate the complete source object first through
/// [`load_v36_prefix_geometry_local_files`]. Original 768-dimensional rows are
/// retained only for the current Parquet batch.
pub fn project_v36_prefix_source_resident(
    path: &Path,
    expected_feature_ids: &[u64],
    maximum_block_rows: usize,
) -> Result<V36PrefixResidentProjectedSource> {
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    project_v36_prefix_source_resident_file(file, path, expected_feature_ids, maximum_block_rows)
}

pub(crate) fn project_v36_prefix_source_resident_file(
    file: File,
    display_path: &Path,
    expected_feature_ids: &[u64],
    maximum_block_rows: usize,
) -> Result<V36PrefixResidentProjectedSource> {
    if maximum_block_rows == 0 || maximum_block_rows > 65_536 {
        return Err(invalid("V36 prefix projected block rows differ"));
    }
    let value_count = expected_feature_ids
        .len()
        .checked_mul(192)
        .ok_or_else(|| invalid("V36 prefix projected corpus size overflows"))?;
    let mut projected = Vec::new();
    projected
        .try_reserve_exact(value_count)
        .map_err(|_| invalid("V36 prefix projected corpus exceeds capacity"))?;
    let projection = build_v36_srht192_control()?;
    scan_v36_prefix_source_parquet_file_with_batch_size(
        file,
        display_path,
        expected_feature_ids,
        Some(maximum_block_rows),
        |batch| {
            let embeddings = batch
                .column(1)
                .as_any()
                .downcast_ref::<FixedSizeListArray>()
                .ok_or_else(|| invalid("V36 prefix projected source embedding differs"))?;
            let values = embeddings
                .values()
                .as_any()
                .downcast_ref::<Float32Array>()
                .ok_or_else(|| invalid("V36 prefix projected source child differs"))?;
            for row in 0..batch.num_rows() {
                let start = row
                    .checked_mul(DIMENSIONS)
                    .ok_or_else(|| invalid("V36 prefix projected source offset overflows"))?;
                let output = project_v35_query_simd(
                    &projection,
                    &values.values()[start..start + DIMENSIONS],
                )?;
                for value in output.coordinates() {
                    let value = *value as f32;
                    if !value.is_finite() {
                        return Err(invalid("V36 prefix projected coordinate is nonfinite"));
                    }
                    projected.push(if value == 0.0 { 0.0 } else { value });
                }
            }
            Ok(())
        },
    )?;
    if projected.len() != value_count {
        return Err(invalid("V36 prefix projected corpus row count differs"));
    }
    let mut digest = Sha256::new();
    digest.update(b"borsuk-v36-projected-corpus-replay-v1");
    for (ordinal, vector) in projected.as_chunks::<192>().0.iter().enumerate() {
        digest.update(u64::try_from(ordinal).unwrap().to_le_bytes());
        for value in vector {
            digest.update(value.to_bits().to_le_bytes());
        }
    }
    Ok(V36PrefixResidentProjectedSource {
        feature_ids: expected_feature_ids.to_vec(),
        maximum_block_rows,
        projected,
        projected_corpus_sha256: format!("{:x}", digest.finalize()),
    })
}

#[derive(Debug, Clone, PartialEq)]
/// One exact GT@100 row.
pub struct V36PrefixGtNeighbor {
    /// Query ordinal.
    pub query_ordinal: u32,
    /// Zero-based neighbor rank.
    pub rank: u16,
    /// Unsigned logical feature ID.
    pub feature_row_id: u64,
    /// Exact binary64 squared-L2 distance.
    pub squared_distance: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
/// One query role authorized to receive exact GT@100.
pub enum V36PrefixQualityRole {
    /// Development queries.
    Development,
    /// Validation queries.
    Validation,
    /// Once-opened sealed holdout queries.
    SealedHoldout,
}

#[derive(Debug, Clone, PartialEq)]
/// One canonically ranked candidate in a durable all-query GT heap checkpoint.
pub struct V36PrefixGtHeapEntry {
    /// Unsigned logical feature ID.
    pub feature_row_id: u64,
    /// Query ordinal within `role`.
    pub query_ordinal: u32,
    /// Zero-based best-first candidate rank.
    pub rank: u16,
    /// Closed quality-query role.
    pub role: V36PrefixQualityRole,
    /// Exact binary64 squared-L2 distance.
    pub squared_distance: f64,
}

#[derive(Debug, Clone, PartialEq)]
/// Durable all-query exact-GT state after one complete source-row prefix.
pub struct V36PrefixGtHeapCheckpoint {
    /// Entries ordered by `(role, query_ordinal, rank)`.
    pub entries: Vec<V36PrefixGtHeapEntry>,
    /// First source ordinal not incorporated into every query heap.
    pub next_source_ordinal: u64,
    /// Development, validation, and sealed-holdout query counts.
    pub query_counts: [u32; 3],
}

const GT_HEAP_CHECKPOINT_FORMAT: &str = "borsuk-v36-prefix-gt-heaps-v1";
const GT_HEAP_CHECKPOINT_BATCH_ROWS: usize = 65_536;
const GT_HEAP_CHECKPOINT_MAX_QUERIES: u64 = 3_000;
const GT_HEAP_CHECKPOINT_NEIGHBORS: usize = GT_NEIGHBORS + 1;
const GT_PREFLIGHT_ROWS: usize = 1_024;

/// Project an exact-GT measurement by the row-times-query work ratio and
/// require it to finish strictly below half the active attempt wall cap.
pub fn validate_v36_prefix_gt_preflight_projection(
    elapsed_ns: u128,
    sampled_rows: u64,
    sampled_queries: u64,
    corpus_rows: u64,
    quality_queries: u64,
    active_wall_seconds: u64,
) -> Result<u128> {
    if elapsed_ns == 0
        || sampled_rows == 0
        || sampled_queries == 0
        || corpus_rows < sampled_rows
        || quality_queries < sampled_queries
        || active_wall_seconds == 0
    {
        return Err(invalid("V36 prefix GT preflight observation differs"));
    }
    let sampled_work = u128::from(sampled_rows)
        .checked_mul(u128::from(sampled_queries))
        .ok_or_else(|| invalid("V36 prefix GT preflight work overflows"))?;
    let complete_work = u128::from(corpus_rows)
        .checked_mul(u128::from(quality_queries))
        .ok_or_else(|| invalid("V36 prefix GT preflight work overflows"))?;
    let numerator = elapsed_ns
        .checked_mul(complete_work)
        .ok_or_else(|| invalid("V36 prefix GT preflight projection overflows"))?;
    let projected_ns = numerator
        .checked_add(sampled_work - 1)
        .ok_or_else(|| invalid("V36 prefix GT preflight projection overflows"))?
        / sampled_work;
    let wall_ns = u128::from(active_wall_seconds)
        .checked_mul(1_000_000_000)
        .ok_or_else(|| invalid("V36 prefix GT preflight wall overflows"))?;
    if projected_ns
        .checked_mul(2)
        .is_none_or(|projection| projection >= wall_ns)
    {
        return Err(resource_limit("exact-GT projected wall"));
    }
    Ok(projected_ns)
}

fn v36_prefix_gt_role_ordinal(role: V36PrefixQualityRole) -> u8 {
    match role {
        V36PrefixQualityRole::Development => 0,
        V36PrefixQualityRole::Validation => 1,
        V36PrefixQualityRole::SealedHoldout => 2,
    }
}

fn v36_prefix_gt_role_from_ordinal(ordinal: u8) -> Result<V36PrefixQualityRole> {
    match ordinal {
        0 => Ok(V36PrefixQualityRole::Development),
        1 => Ok(V36PrefixQualityRole::Validation),
        2 => Ok(V36PrefixQualityRole::SealedHoldout),
        _ => Err(invalid("V36 prefix GT heap role differs")),
    }
}

fn v36_prefix_gt_heap_checkpoint_schema(
    next_source_ordinal: u64,
    query_counts: [u32; 3],
) -> Schema {
    Schema::new_with_metadata(
        vec![
            Field::new("role", DataType::UInt8, false),
            Field::new("query_ordinal", DataType::UInt32, false),
            Field::new("rank", DataType::UInt16, false),
            Field::new("feature_row_id", DataType::UInt64, false),
            Field::new("squared_distance", DataType::Float64, false),
        ],
        HashMap::from([
            ("format".to_owned(), GT_HEAP_CHECKPOINT_FORMAT.to_owned()),
            (
                "next_source_ordinal".to_owned(),
                next_source_ordinal.to_string(),
            ),
            (
                "development_queries".to_owned(),
                query_counts[0].to_string(),
            ),
            ("validation_queries".to_owned(), query_counts[1].to_string()),
            (
                "sealed_holdout_queries".to_owned(),
                query_counts[2].to_string(),
            ),
        ]),
    )
}

fn validate_v36_prefix_gt_heap_checkpoint(checkpoint: &V36PrefixGtHeapCheckpoint) -> Result<()> {
    let expected_entries = v36_prefix_gt_heap_expected_rows(checkpoint.query_counts)?;
    if checkpoint.next_source_ordinal < GT_HEAP_CHECKPOINT_NEIGHBORS as u64
        || checkpoint.entries.len() != expected_entries
    {
        return Err(invalid("V36 prefix GT heap checkpoint differs"));
    }
    let mut entry_index = 0_usize;
    for (role_ordinal, query_count) in checkpoint.query_counts.into_iter().enumerate() {
        let role = v36_prefix_gt_role_from_ordinal(u8::try_from(role_ordinal).unwrap())?;
        for query_ordinal in 0..query_count {
            let mut feature_ids = BTreeSet::new();
            let mut previous: Option<(f64, u64)> = None;
            for rank in 0..GT_HEAP_CHECKPOINT_NEIGHBORS {
                let entry = &checkpoint.entries[entry_index];
                let ordered = previous.is_none_or(|(distance, feature_row_id)| {
                    distance
                        .total_cmp(&entry.squared_distance)
                        .then(feature_row_id.cmp(&entry.feature_row_id))
                        .is_le()
                });
                if entry.role != role
                    || entry.query_ordinal != query_ordinal
                    || usize::from(entry.rank) != rank
                    || !entry.squared_distance.is_finite()
                    || entry.squared_distance.is_sign_negative()
                    || !feature_ids.insert(entry.feature_row_id)
                    || !ordered
                {
                    return Err(invalid("V36 prefix GT heap entry differs"));
                }
                previous = Some((entry.squared_distance, entry.feature_row_id));
                entry_index += 1;
            }
        }
    }
    Ok(())
}

fn v36_prefix_gt_heap_expected_rows(query_counts: [u32; 3]) -> Result<usize> {
    let query_total = query_counts.into_iter().try_fold(0_u64, |sum, count| {
        sum.checked_add(u64::from(count))
            .ok_or_else(|| invalid("V36 prefix GT heap query count overflows"))
    })?;
    if query_counts.contains(&0) || query_total > GT_HEAP_CHECKPOINT_MAX_QUERIES {
        return Err(invalid("V36 prefix GT heap query count differs"));
    }
    query_total
        .checked_mul(GT_HEAP_CHECKPOINT_NEIGHBORS as u64)
        .and_then(|count| usize::try_from(count).ok())
        .ok_or_else(|| invalid("V36 prefix GT heap row count overflows"))
}

fn validate_v36_prefix_gt_heap_batch_body(rows: u64, body_bytes: u64) -> Result<()> {
    let validity = rows
        .checked_add(7)
        .map(|bits| bits / 8)
        .ok_or_else(|| resource_limit("GT heap Arrow batch body bytes"))
        .and_then(align_v36_prefix_arrow_buffer)?;
    let values = [1_u64, 4, 2, 8, 8]
        .into_iter()
        .try_fold(0_u64, |total, width| {
            rows.checked_mul(width)
                .ok_or_else(|| resource_limit("GT heap Arrow batch body bytes"))
                .and_then(align_v36_prefix_arrow_buffer)
                .and_then(|bytes| {
                    total
                        .checked_add(bytes)
                        .ok_or_else(|| resource_limit("GT heap Arrow batch body bytes"))
                })
        })?;
    let expected = validity
        .checked_mul(5)
        .and_then(|bytes| bytes.checked_add(values))
        .ok_or_else(|| resource_limit("GT heap Arrow batch body bytes"))?;
    if body_bytes != expected {
        return Err(invalid("V36 prefix GT heap batch body differs"));
    }
    Ok(())
}

/// Encode one strict all-query GT heap checkpoint as Arrow IPC v5.
pub fn encode_v36_prefix_gt_heap_checkpoint(
    checkpoint: &V36PrefixGtHeapCheckpoint,
) -> Result<Vec<u8>> {
    validate_v36_prefix_gt_heap_checkpoint(checkpoint)?;
    let schema = Arc::new(v36_prefix_gt_heap_checkpoint_schema(
        checkpoint.next_source_ordinal,
        checkpoint.query_counts,
    ));
    let options = IpcWriteOptions::try_new(8, false, MetadataVersion::V5)?;
    let mut bytes = Vec::new();
    let mut writer = ArrowFileWriter::try_new_with_options(&mut bytes, schema.as_ref(), options)?;
    for entries in checkpoint.entries.chunks(GT_HEAP_CHECKPOINT_BATCH_ROWS) {
        writer.write(&RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(UInt8Array::from(
                    entries
                        .iter()
                        .map(|entry| v36_prefix_gt_role_ordinal(entry.role))
                        .collect::<Vec<_>>(),
                )),
                Arc::new(UInt32Array::from(
                    entries
                        .iter()
                        .map(|entry| entry.query_ordinal)
                        .collect::<Vec<_>>(),
                )),
                Arc::new(UInt16Array::from(
                    entries.iter().map(|entry| entry.rank).collect::<Vec<_>>(),
                )),
                Arc::new(UInt64Array::from(
                    entries
                        .iter()
                        .map(|entry| entry.feature_row_id)
                        .collect::<Vec<_>>(),
                )),
                Arc::new(Float64Array::from(
                    entries
                        .iter()
                        .map(|entry| entry.squared_distance)
                        .collect::<Vec<_>>(),
                )),
            ],
        )?)?;
    }
    writer.finish()?;
    drop(writer);
    Ok(bytes)
}

/// Authenticate and decode one strict all-query GT heap checkpoint.
pub fn decode_v36_prefix_gt_heap_checkpoint(
    bytes: &[u8],
    registered: &V36ArtifactIdentity,
    expected_next_source_ordinal: u64,
    expected_query_counts: [u32; 3],
) -> Result<V36PrefixGtHeapCheckpoint> {
    let sha256 = format!("{:x}", Sha256::digest(bytes));
    let blake3 = blake3::hash(bytes).to_hex().to_string();
    let content_addressed = url::Url::parse(&registered.uri)
        .ok()
        .filter(|uri| uri.scheme() == "s3" && uri.host_str().is_some())
        .and_then(|uri| uri.path().rsplit('/').next().map(str::to_owned))
        .is_some_and(|name| name.starts_with(&format!("{sha256}-")));
    if registered.role != "gt-heaps"
        || registered.encoded_bytes != bytes.len() as u64
        || registered.sha256 != sha256
        || registered.blake3 != blake3
        || !content_addressed
    {
        return Err(invalid("V36 prefix GT heap artifact differs"));
    }
    let expected_entries = v36_prefix_gt_heap_expected_rows(expected_query_counts)?;
    let trailer: [u8; 10] = bytes
        .get(bytes.len().saturating_sub(10)..)
        .and_then(|bytes| bytes.try_into().ok())
        .ok_or_else(|| invalid("V36 prefix GT heap footer differs"))?;
    let footer_len =
        read_footer_length(trailer).map_err(|_| invalid("V36 prefix GT heap footer differs"))?;
    if footer_len == 0 || footer_len > EXTERNAL_MAX_ARROW_FOOTER_BYTES {
        return Err(resource_limit("GT heap Arrow footer bytes"));
    }
    let footer_start = bytes
        .len()
        .checked_sub(10)
        .and_then(|end| end.checked_sub(footer_len))
        .ok_or_else(|| invalid("V36 prefix GT heap footer differs"))?;
    let footer = root_as_footer(&bytes[footer_start..bytes.len() - 10])
        .map_err(|_| invalid("V36 prefix GT heap footer differs"))?;
    if footer.version() != MetadataVersion::V5
        || footer
            .dictionaries()
            .is_some_and(|dictionaries| !dictionaries.is_empty())
    {
        return Err(invalid("V36 prefix GT heap footer differs"));
    }
    let batches = footer
        .recordBatches()
        .ok_or_else(|| invalid("V36 prefix GT heap batches differ"))?;
    let expected_batches = expected_entries.div_ceil(GT_HEAP_CHECKPOINT_BATCH_ROWS);
    if batches.len() != expected_batches {
        return Err(invalid("V36 prefix GT heap batches differ"));
    }
    let mut previous_end = 0_usize;
    for (batch_index, block) in batches.iter().enumerate() {
        let offset = usize::try_from(block.offset())
            .map_err(|_| invalid("V36 prefix GT heap block differs"))?;
        let metadata = usize::try_from(block.metaDataLength())
            .map_err(|_| invalid("V36 prefix GT heap block differs"))?;
        let body = usize::try_from(block.bodyLength())
            .map_err(|_| invalid("V36 prefix GT heap block differs"))?;
        let end = offset
            .checked_add(metadata)
            .and_then(|value| value.checked_add(body))
            .ok_or_else(|| invalid("V36 prefix GT heap block differs"))?;
        if !(4..=EXTERNAL_MAX_ARROW_FOOTER_BYTES).contains(&metadata)
            || offset < previous_end
            || end > footer_start
        {
            return Err(invalid("V36 prefix GT heap block differs"));
        }
        let message_bytes = &bytes[offset..offset + metadata];
        let (declared, message_start) = if message_bytes[..4] == [0xff; 4] {
            if message_bytes.len() < 8 {
                return Err(invalid("V36 prefix GT heap message differs"));
            }
            (
                u32::from_le_bytes(message_bytes[4..8].try_into().unwrap()) as usize,
                8_usize,
            )
        } else {
            (
                u32::from_le_bytes(message_bytes[..4].try_into().unwrap()) as usize,
                4_usize,
            )
        };
        let message_end = message_start
            .checked_add(declared)
            .filter(|end| *end <= message_bytes.len())
            .ok_or_else(|| invalid("V36 prefix GT heap message differs"))?;
        let message = root_as_message(&message_bytes[message_start..message_end])
            .map_err(|_| invalid("V36 prefix GT heap message differs"))?;
        let batch = message
            .header_as_record_batch()
            .ok_or_else(|| invalid("V36 prefix GT heap message differs"))?;
        let expected_rows = (expected_entries - batch_index * GT_HEAP_CHECKPOINT_BATCH_ROWS)
            .min(GT_HEAP_CHECKPOINT_BATCH_ROWS);
        if batch.compression().is_some()
            || usize::try_from(batch.length()).ok() != Some(expected_rows)
            || usize::try_from(message.bodyLength()).ok() != Some(body)
        {
            return Err(invalid("V36 prefix GT heap message differs"));
        }
        validate_v36_prefix_gt_heap_batch_body(expected_rows as u64, body as u64)?;
        previous_end = end;
    }
    let expected_schema =
        v36_prefix_gt_heap_checkpoint_schema(expected_next_source_ordinal, expected_query_counts);
    let mut reader = ArrowFileReader::try_new(std::io::Cursor::new(bytes), None)?;
    if reader.schema().as_ref() != &expected_schema {
        return Err(invalid("V36 prefix GT heap schema differs"));
    }
    let mut entries = Vec::with_capacity(expected_entries);
    for batch in &mut reader {
        let batch = batch?;
        let expected_batch_rows = expected_entries
            .checked_sub(entries.len())
            .map(|remaining| remaining.min(GT_HEAP_CHECKPOINT_BATCH_ROWS))
            .ok_or_else(|| invalid("V36 prefix GT heap row count differs"))?;
        if batch.num_rows() != expected_batch_rows
            || batch.num_columns() != 5
            || batch
                .columns()
                .iter()
                .any(|column| column.null_count() != 0)
        {
            return Err(invalid("V36 prefix GT heap batch differs"));
        }
        let roles = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt8Array>()
            .ok_or_else(|| invalid("V36 prefix GT heap role column differs"))?;
        let query_ordinals = batch
            .column(1)
            .as_any()
            .downcast_ref::<UInt32Array>()
            .ok_or_else(|| invalid("V36 prefix GT heap query column differs"))?;
        let ranks = batch
            .column(2)
            .as_any()
            .downcast_ref::<UInt16Array>()
            .ok_or_else(|| invalid("V36 prefix GT heap rank column differs"))?;
        let feature_ids = batch
            .column(3)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix GT heap feature column differs"))?;
        let distances = batch
            .column(4)
            .as_any()
            .downcast_ref::<Float64Array>()
            .ok_or_else(|| invalid("V36 prefix GT heap distance column differs"))?;
        for row in 0..batch.num_rows() {
            entries.push(V36PrefixGtHeapEntry {
                feature_row_id: feature_ids.value(row),
                query_ordinal: query_ordinals.value(row),
                rank: ranks.value(row),
                role: v36_prefix_gt_role_from_ordinal(roles.value(row))?,
                squared_distance: distances.value(row),
            });
        }
    }
    if entries.len() != expected_entries {
        return Err(invalid("V36 prefix GT heap row count differs"));
    }
    let checkpoint = V36PrefixGtHeapCheckpoint {
        entries,
        next_source_ordinal: expected_next_source_ordinal,
        query_counts: expected_query_counts,
    };
    validate_v36_prefix_gt_heap_checkpoint(&checkpoint)?;
    Ok(checkpoint)
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// One quality-query Parquet input and exact-GT output role.
pub struct V36PrefixGtParquetJob {
    /// Exact number of queries in this role.
    pub expected_queries: u32,
    /// Destination exact-GT Parquet path.
    pub output: PathBuf,
    /// Source query Parquet path.
    pub query: PathBuf,
    /// Closed quality role.
    pub role: V36PrefixQualityRole,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
/// Bounded work evidence from one corpus-outer exact-GT pass.
pub struct V36PrefixGtRunStats {
    /// Quality queries updated for every source row.
    pub quality_queries: u32,
    /// Complete source scans performed.
    pub source_scans: u32,
    /// Source rows processed in canonical order.
    pub source_rows: u64,
}

/// Rank a complete authenticated registry by the frozen sample rule.
pub fn rank_v36_prefix_source_objects(
    authority: &V36PrefixFreezeAuthority,
    registry: &[V36PrefixRegisteredSourceObject],
) -> Result<Vec<V36PrefixRankedSourceObject>> {
    validate_v36_prefix_freeze_authority(authority, registry)?;
    let mut paths = BTreeSet::new();
    let mut uris = BTreeSet::new();
    let mut ranked = registry
        .iter()
        .map(|object| {
            if object.encoded_bytes == 0
                || object.path.is_empty()
                || !paths.insert(object.path.as_str())
                || !uris.insert(object.uri.as_str())
            {
                return Err(invalid("V36 prefix source registry differs"));
            }
            digest_bytes(&object.sha256)?;
            let mut hasher = Sha256::new();
            hasher.update(b"borsuk-v36-screen-object-v1");
            hasher.update(object.path.as_bytes());
            hasher.update(object.encoded_bytes.to_le_bytes());
            Ok(V36PrefixRankedSourceObject {
                encoded_bytes: object.encoded_bytes,
                path: object.path.clone(),
                sample_sha256: format!("{:x}", hasher.finalize()),
                sha256: object.sha256.clone(),
                uri: object.uri.clone(),
            })
        })
        .collect::<Result<Vec<_>>>()?;
    ranked.sort_by(|left, right| {
        (&left.sample_sha256, &left.path).cmp(&(&right.sample_sha256, &right.path))
    });
    Ok(ranked)
}

/// Validate one streamed physical row and retain only its compact identity.
pub fn validate_v36_prefix_input_row(row: &V36PrefixInputRow) -> Result<V36PrefixRowIdentity> {
    if row.feature_row_id < 0 {
        return Err(invalid("V36 prefix feature ID differs"));
    }
    validate_embedding(&row.embedding)?;
    Ok(V36PrefixRowIdentity {
        feature_row_id: u64::try_from(row.feature_row_id)
            .map_err(|_| invalid("V36 prefix feature ID differs"))?,
        source_ordinal: None,
        selected_object_ordinal: row.selected_object_ordinal,
        row_offset: row.row_offset,
    })
}

/// Keep the first sampled-object occurrence per ID without retaining vectors.
pub fn deduplicate_v36_prefix_row_identities(
    mut rows: Vec<V36PrefixRowIdentity>,
) -> Result<Vec<V36PrefixRowIdentity>> {
    rows.sort_by_key(|row| (row.selected_object_ordinal, row.row_offset));
    let mut physical = BTreeSet::new();
    let mut feature_ids = BTreeSet::new();
    let mut unique = Vec::new();
    for row in rows {
        if row.source_ordinal.is_some()
            || !physical.insert((row.selected_object_ordinal, row.row_offset))
        {
            return Err(invalid("V36 prefix physical row differs"));
        }
        if feature_ids.insert(row.feature_row_id) {
            unique.push(row);
        }
    }
    Ok(unique)
}

/// Select the lowest v2 population-row hashes after physical-first deduplication.
pub fn select_v36_prefix_population_rows(
    rows: Vec<V36PrefixRowIdentity>,
    ordered_source_manifest_sha256: &str,
    count: usize,
) -> Result<Vec<V36PrefixRowIdentity>> {
    if count == 0 {
        return Err(invalid("V36 prefix population row count differs"));
    }
    let source_identity = digest_bytes(ordered_source_manifest_sha256)?;
    let seed: [u8; 32] = Sha256::digest(b"borsuk-v36-prefix-screen-population-row-v2").into();
    let mut ranked = deduplicate_v36_prefix_row_identities(rows)?
        .into_iter()
        .map(|row| (score(&seed, &source_identity, row.feature_row_id), row))
        .collect::<Vec<_>>();
    if ranked.len() < count {
        return Err(invalid("V36 prefix population is insufficient"));
    }
    ranked.sort_by(|left, right| {
        (&left.0, left.1.feature_row_id).cmp(&(&right.0, right.1.feature_row_id))
    });
    ranked.truncate(count);
    Ok(ranked.into_iter().map(|(_, row)| row).collect())
}

const EXTERNAL_SPILL_MAGIC: [u8; 8] = *b"V36SCR02";
const EXTERNAL_SPILL_HEADER_BYTES: u64 = 16;
const EXTERNAL_SPILL_DIGEST_BYTES: u64 = 32;
const EXTERNAL_SPILL_RECORD_BYTES: u64 = 50;
const EXTERNAL_MAX_FAN_IN: usize = 16;
const EXTERNAL_MAX_IO_BUFFER_BYTES: usize = 65_536;
const EXTERNAL_MAX_SORT_BUFFER_RECORDS: usize = 65_536;
const EXTERNAL_MAX_SPILLS: usize = 65_536;
const EXTERNAL_MAX_ARROW_BATCHES: usize = 65_536;
const EXTERNAL_MAX_ARROW_FOOTER_BYTES: usize = 1 << 20;
const EXTERNAL_MAX_CUTOFF_BITMAP_BYTES: usize = 32 << 20;

fn allocate_v36_prefix_cutoff_bitmap(physical_rows: u64) -> Result<Vec<u64>> {
    let words = usize::try_from(physical_rows.div_ceil(64))
        .map_err(|_| resource_limit("cutoff bitmap bytes"))?;
    let bytes = words
        .checked_mul(size_of::<u64>())
        .ok_or_else(|| resource_limit("cutoff bitmap bytes"))?;
    if bytes > EXTERNAL_MAX_CUTOFF_BITMAP_BYTES {
        return Err(resource_limit("cutoff bitmap bytes"));
    }
    let mut bitmap = Vec::new();
    bitmap
        .try_reserve_exact(words)
        .map_err(|_| resource_limit("cutoff bitmap bytes"))?;
    bitmap.resize(words, 0_u64);
    Ok(bitmap)
}

fn select_v36_prefix_cutoff_offset(bitmap: &[u64], rank: u64) -> Option<u64> {
    if rank == 0 {
        return None;
    }
    let mut remaining = rank;
    for (word_index, &word) in bitmap.iter().enumerate() {
        let population = u64::from(word.count_ones());
        if remaining > population {
            remaining -= population;
            continue;
        }
        let mut candidates = word;
        for _ in 1..remaining {
            candidates &= candidates - 1;
        }
        let bit = u64::from(candidates.trailing_zeros());
        return u64::try_from(word_index)
            .ok()
            .and_then(|index| index.checked_mul(64))
            .and_then(|base| base.checked_add(bit));
    }
    None
}

fn v36_prefix_identity_offset_bitmap_selected(
    physical_rows: u64,
    row_count: usize,
) -> Result<bool> {
    let bitmap_words = usize::try_from(physical_rows.div_ceil(64))
        .map_err(|_| resource_limit("identity-run offset state bytes"))?;
    let bitmap_bytes = bitmap_words
        .checked_mul(size_of::<u64>())
        .ok_or_else(|| resource_limit("identity-run offset state bytes"))?;
    if bitmap_words <= row_count && bitmap_bytes <= EXTERNAL_MAX_CUTOFF_BITMAP_BYTES {
        return Ok(true);
    }
    let offset_bytes = row_count
        .checked_mul(size_of::<u64>())
        .ok_or_else(|| resource_limit("identity-run offset state bytes"))?;
    if offset_bytes > EXTERNAL_MAX_CUTOFF_BITMAP_BYTES {
        return Err(resource_limit("identity-run offset state bytes"));
    }
    Ok(false)
}
const IDENTITY_SPILL_MAGIC: [u8; 8] = *b"V36IDR03";
const IDENTITY_SPILL_RECORD_BYTES: u64 = 18;

fn v36_prefix_external_io<T>(path: &Path, result: std::io::Result<T>) -> Result<T> {
    result.map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct V36PrefixScoredIdentity {
    score: [u8; 32],
    feature_row_id: u64,
    selected_object_ordinal: u16,
    row_offset: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct V36PrefixRawIdentity {
    feature_row_id: u64,
    selected_object_ordinal: u16,
    row_offset: u64,
}

struct V36PrefixRawIdentityReader {
    path: PathBuf,
    reader: BufReader<File>,
    remaining: u64,
    expected_blake3: [u8; 32],
    payload_hasher: blake3::Hasher,
}

impl V36PrefixRawIdentityReader {
    fn open(path: &Path, io_buffer_bytes: usize) -> Result<Self> {
        let file = File::open(path).map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
        let encoded_bytes = file
            .metadata()
            .map_err(|source| BorsukError::Io {
                path: path.to_owned(),
                source,
            })?
            .len();
        let mut reader = BufReader::with_capacity(io_buffer_bytes, file);
        let mut magic = [0_u8; 8];
        let mut count = [0_u8; 8];
        v36_prefix_external_io(path, reader.read_exact(&mut magic))?;
        v36_prefix_external_io(path, reader.read_exact(&mut count))?;
        let remaining = u64::from_le_bytes(count);
        let expected_bytes = EXTERNAL_SPILL_HEADER_BYTES
            .checked_add(
                remaining
                    .checked_mul(IDENTITY_SPILL_RECORD_BYTES)
                    .ok_or_else(|| invalid("V36 identity spill length overflows"))?,
            )
            .and_then(|bytes| bytes.checked_add(EXTERNAL_SPILL_DIGEST_BYTES))
            .ok_or_else(|| invalid("V36 identity spill length overflows"))?;
        if magic != IDENTITY_SPILL_MAGIC || encoded_bytes != expected_bytes {
            return Err(invalid("V36 identity spill header differs"));
        }
        v36_prefix_external_io(path, reader.seek(SeekFrom::End(-32)))?;
        let mut expected_blake3 = [0_u8; 32];
        v36_prefix_external_io(path, reader.read_exact(&mut expected_blake3))?;
        v36_prefix_external_io(path, reader.seek(SeekFrom::Start(16)))?;
        Ok(Self {
            path: path.to_owned(),
            reader,
            remaining,
            expected_blake3,
            payload_hasher: blake3::Hasher::new(),
        })
    }

    fn next_record(&mut self) -> Result<Option<V36PrefixRawIdentity>> {
        if self.remaining == 0 {
            return Ok(None);
        }
        let mut bytes = [0_u8; IDENTITY_SPILL_RECORD_BYTES as usize];
        v36_prefix_external_io(&self.path, self.reader.read_exact(&mut bytes))?;
        self.payload_hasher.update(&bytes);
        self.remaining -= 1;
        if self.remaining == 0 && self.payload_hasher.finalize().as_bytes() != &self.expected_blake3
        {
            return Err(invalid("V36 identity spill digest differs"));
        }
        Ok(Some(V36PrefixRawIdentity {
            feature_row_id: u64::from_le_bytes(bytes[..8].try_into().unwrap()),
            selected_object_ordinal: u16::from_le_bytes(bytes[8..10].try_into().unwrap()),
            row_offset: u64::from_le_bytes(bytes[10..18].try_into().unwrap()),
        }))
    }
}

fn write_v36_prefix_raw_identity(
    writer: &mut impl Write,
    hasher: &mut blake3::Hasher,
    record: V36PrefixRawIdentity,
) -> Result<()> {
    let mut bytes = [0_u8; IDENTITY_SPILL_RECORD_BYTES as usize];
    bytes[..8].copy_from_slice(&record.feature_row_id.to_le_bytes());
    bytes[8..10].copy_from_slice(&record.selected_object_ordinal.to_le_bytes());
    bytes[10..18].copy_from_slice(&record.row_offset.to_le_bytes());
    v36_prefix_external_io(Path::new("V36 identity spill"), writer.write_all(&bytes))?;
    hasher.update(&bytes);
    Ok(())
}

fn create_v36_prefix_identity_spill(
    attempt: &Path,
    ordinal: usize,
    records: &mut [V36PrefixRawIdentity],
    limits: &V36PrefixExternalSelectionLimits,
) -> Result<PathBuf> {
    records.sort_unstable();
    let path = attempt.join(format!("identity-{ordinal:08}.bin"));
    let count =
        u64::try_from(records.len()).map_err(|_| invalid("V36 identity spill count overflows"))?;
    let bytes = 16_u64
        .checked_add(
            count
                .checked_mul(IDENTITY_SPILL_RECORD_BYTES)
                .ok_or_else(|| invalid("V36 identity spill length overflows"))?,
        )
        .and_then(|value| value.checked_add(32))
        .ok_or_else(|| invalid("V36 identity spill length overflows"))?;
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let file = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(&path)
        .map_err(|source| BorsukError::Io {
            path: path.clone(),
            source,
        })?;
    let mut writer = BufWriter::with_capacity(limits.io_buffer_bytes, file);
    v36_prefix_external_io(&path, writer.write_all(&IDENTITY_SPILL_MAGIC))?;
    v36_prefix_external_io(&path, writer.write_all(&count.to_le_bytes()))?;
    let mut hasher = blake3::Hasher::new();
    for record in records.iter().copied() {
        write_v36_prefix_raw_identity(&mut writer, &mut hasher, record)?;
    }
    finish_v36_prefix_spill(&path, &mut writer, &hasher)?;
    Ok(path)
}

fn merge_v36_prefix_identity_spills(
    inputs: &[PathBuf],
    output: &Path,
    limits: &V36PrefixExternalSelectionLimits,
) -> Result<()> {
    let mut readers = inputs
        .iter()
        .map(|path| V36PrefixRawIdentityReader::open(path, limits.io_buffer_bytes))
        .collect::<Result<Vec<_>>>()?;
    let count = readers.iter().try_fold(0_u64, |total, reader| {
        total
            .checked_add(reader.remaining)
            .ok_or_else(|| invalid("V36 identity spill count overflows"))
    })?;
    let bytes = 16_u64
        .checked_add(
            count
                .checked_mul(IDENTITY_SPILL_RECORD_BYTES)
                .ok_or_else(|| invalid("V36 identity spill length overflows"))?,
        )
        .and_then(|value| value.checked_add(32))
        .ok_or_else(|| invalid("V36 identity spill length overflows"))?;
    let attempt = output
        .parent()
        .ok_or_else(|| invalid("V36 identity spill path differs"))?;
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let file = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(output)
        .map_err(|source| BorsukError::Io {
            path: output.to_owned(),
            source,
        })?;
    let mut writer = BufWriter::with_capacity(limits.io_buffer_bytes, file);
    v36_prefix_external_io(output, writer.write_all(&IDENTITY_SPILL_MAGIC))?;
    v36_prefix_external_io(output, writer.write_all(&count.to_le_bytes()))?;
    let mut hasher = blake3::Hasher::new();
    let mut heap = BinaryHeap::new();
    for (index, reader) in readers.iter_mut().enumerate() {
        if let Some(record) = reader.next_record()? {
            heap.push(Reverse((record, index)));
        }
    }
    while let Some(Reverse((record, index))) = heap.pop() {
        write_v36_prefix_raw_identity(&mut writer, &mut hasher, record)?;
        if let Some(next) = readers[index].next_record()? {
            heap.push(Reverse((next, index)));
        }
    }
    finish_v36_prefix_spill(output, &mut writer, &hasher)?;
    drop(writer);
    for reader in readers {
        fs::remove_file(&reader.path).map_err(|source| BorsukError::Io {
            path: reader.path,
            source,
        })?;
    }
    Ok(())
}

fn write_v36_prefix_spill_header(writer: &mut impl Write, records: u64) -> Result<()> {
    v36_prefix_external_io(
        Path::new("V36 external spill"),
        writer.write_all(&EXTERNAL_SPILL_MAGIC),
    )?;
    v36_prefix_external_io(
        Path::new("V36 external spill"),
        writer.write_all(&records.to_le_bytes()),
    )?;
    Ok(())
}

fn write_v36_prefix_scored_identity(
    writer: &mut impl Write,
    hasher: &mut blake3::Hasher,
    record: &V36PrefixScoredIdentity,
) -> Result<()> {
    let path = Path::new("V36 external spill");
    let mut bytes = [0_u8; EXTERNAL_SPILL_RECORD_BYTES as usize];
    bytes[..32].copy_from_slice(&record.score);
    bytes[32..40].copy_from_slice(&record.feature_row_id.to_le_bytes());
    bytes[40..42].copy_from_slice(&record.selected_object_ordinal.to_le_bytes());
    bytes[42..50].copy_from_slice(&record.row_offset.to_le_bytes());
    v36_prefix_external_io(path, writer.write_all(&bytes))?;
    hasher.update(&bytes);
    Ok(())
}

fn finish_v36_prefix_spill(
    path: &Path,
    writer: &mut BufWriter<File>,
    hasher: &blake3::Hasher,
) -> Result<()> {
    v36_prefix_external_io(path, writer.write_all(hasher.finalize().as_bytes()))?;
    v36_prefix_external_io(path, writer.flush())?;
    v36_prefix_external_io(path, writer.get_ref().sync_all())?;
    Ok(())
}

struct V36PrefixSpillReader {
    path: PathBuf,
    reader: BufReader<File>,
    remaining: u64,
    previous: Option<V36PrefixScoredIdentity>,
    expected_blake3: [u8; 32],
    payload_hasher: blake3::Hasher,
}

impl V36PrefixSpillReader {
    fn open(path: &Path, io_buffer_bytes: usize) -> Result<Self> {
        let file = File::open(path).map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
        let encoded_bytes = file
            .metadata()
            .map_err(|source| BorsukError::Io {
                path: path.to_owned(),
                source,
            })?
            .len();
        let mut file = file;
        v36_prefix_external_io(path, file.seek(SeekFrom::End(-32)))?;
        let mut expected_blake3 = [0_u8; 32];
        v36_prefix_external_io(path, file.read_exact(&mut expected_blake3))?;
        v36_prefix_external_io(path, file.seek(SeekFrom::Start(0)))?;
        let mut reader = BufReader::with_capacity(io_buffer_bytes, file);
        let mut magic = [0_u8; 8];
        v36_prefix_external_io(path, reader.read_exact(&mut magic))?;
        let mut count = [0_u8; 8];
        v36_prefix_external_io(path, reader.read_exact(&mut count))?;
        let remaining = u64::from_le_bytes(count);
        let expected_bytes = EXTERNAL_SPILL_HEADER_BYTES
            .checked_add(
                remaining
                    .checked_mul(EXTERNAL_SPILL_RECORD_BYTES)
                    .ok_or_else(|| invalid("V36 prefix spill length overflows"))?,
            )
            .and_then(|bytes| bytes.checked_add(EXTERNAL_SPILL_DIGEST_BYTES))
            .ok_or_else(|| invalid("V36 prefix spill length overflows"))?;
        if magic != EXTERNAL_SPILL_MAGIC || encoded_bytes != expected_bytes {
            return Err(invalid("V36 prefix spill header differs"));
        }
        Ok(Self {
            path: path.to_owned(),
            reader,
            remaining,
            previous: None,
            expected_blake3,
            payload_hasher: blake3::Hasher::new(),
        })
    }

    fn next_record(&mut self) -> Result<Option<V36PrefixScoredIdentity>> {
        if self.remaining == 0 {
            return Ok(None);
        }
        let mut bytes = [0_u8; EXTERNAL_SPILL_RECORD_BYTES as usize];
        v36_prefix_external_io(&self.path, self.reader.read_exact(&mut bytes))?;
        self.payload_hasher.update(&bytes);
        let score = bytes[..32].try_into().expect("fixed V36 spill score width");
        let record = V36PrefixScoredIdentity {
            score,
            feature_row_id: u64::from_le_bytes(bytes[32..40].try_into().unwrap()),
            selected_object_ordinal: u16::from_le_bytes(bytes[40..42].try_into().unwrap()),
            row_offset: u64::from_le_bytes(bytes[42..50].try_into().unwrap()),
        };
        if self.previous.is_some_and(|previous| previous > record) {
            return Err(invalid("V36 prefix spill order differs"));
        }
        self.previous = Some(record);
        self.remaining -= 1;
        if self.remaining == 0 && self.payload_hasher.finalize().as_bytes() != &self.expected_blake3
        {
            return Err(invalid("V36 prefix spill digest differs"));
        }
        Ok(Some(record))
    }
}

fn create_v36_prefix_spill(
    attempt: &Path,
    ordinal: usize,
    records: &mut [V36PrefixScoredIdentity],
    io_buffer_bytes: usize,
    max_scratch_bytes: u64,
) -> Result<PathBuf> {
    records.sort_unstable();
    let path = attempt.join(format!("spill-{ordinal:08}.bin"));
    let record_count = u64::try_from(records.len())
        .map_err(|_| invalid("V36 prefix spill row count overflows"))?;
    let output_bytes = EXTERNAL_SPILL_HEADER_BYTES
        .checked_add(
            record_count
                .checked_mul(EXTERNAL_SPILL_RECORD_BYTES)
                .ok_or_else(|| invalid("V36 prefix spill length overflows"))?,
        )
        .and_then(|bytes| bytes.checked_add(EXTERNAL_SPILL_DIGEST_BYTES))
        .ok_or_else(|| invalid("V36 prefix spill length overflows"))?;
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(output_bytes)
        .is_none_or(|peak| peak > max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let file = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(&path)
        .map_err(|source| BorsukError::Io {
            path: path.clone(),
            source,
        })?;
    let mut writer = BufWriter::with_capacity(io_buffer_bytes, file);
    write_v36_prefix_spill_header(&mut writer, record_count)?;
    let mut payload_hasher = blake3::Hasher::new();
    for record in records {
        write_v36_prefix_scored_identity(&mut writer, &mut payload_hasher, record)?;
    }
    finish_v36_prefix_spill(&path, &mut writer, &payload_hasher)?;
    Ok(path)
}

fn merge_v36_prefix_spills(
    inputs: &[PathBuf],
    output: &Path,
    io_buffer_bytes: usize,
    max_scratch_bytes: u64,
) -> Result<()> {
    let mut readers = inputs
        .iter()
        .map(|path| V36PrefixSpillReader::open(path, io_buffer_bytes))
        .collect::<Result<Vec<_>>>()?;
    let count = readers.iter().try_fold(0_u64, |count, reader| {
        count
            .checked_add(reader.remaining)
            .ok_or_else(|| invalid("V36 prefix spill row count overflows"))
    })?;
    let output_bytes = EXTERNAL_SPILL_HEADER_BYTES
        .checked_add(
            count
                .checked_mul(EXTERNAL_SPILL_RECORD_BYTES)
                .ok_or_else(|| invalid("V36 prefix spill length overflows"))?,
        )
        .and_then(|bytes| bytes.checked_add(EXTERNAL_SPILL_DIGEST_BYTES))
        .ok_or_else(|| invalid("V36 prefix spill length overflows"))?;
    let attempt = output
        .parent()
        .ok_or_else(|| invalid("V36 prefix spill path differs"))?;
    let current_bytes = v36_prefix_scratch_bytes(attempt)?;
    if current_bytes
        .checked_add(output_bytes)
        .is_none_or(|peak| peak > max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let file = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(output)
        .map_err(|source| BorsukError::Io {
            path: output.to_owned(),
            source,
        })?;
    let mut writer = BufWriter::with_capacity(io_buffer_bytes, file);
    write_v36_prefix_spill_header(&mut writer, count)?;
    let mut payload_hasher = blake3::Hasher::new();
    let mut heap = BinaryHeap::new();
    for (reader_index, reader) in readers.iter_mut().enumerate() {
        if let Some(record) = reader.next_record()? {
            heap.push(Reverse((record, reader_index)));
        }
    }
    while let Some(Reverse((record, reader_index))) = heap.pop() {
        write_v36_prefix_scored_identity(&mut writer, &mut payload_hasher, &record)?;
        if let Some(next) = readers[reader_index].next_record()? {
            heap.push(Reverse((next, reader_index)));
        }
    }
    finish_v36_prefix_spill(output, &mut writer, &payload_hasher)?;
    drop(writer);
    for reader in readers {
        fs::remove_file(&reader.path).map_err(|source| BorsukError::Io {
            path: reader.path,
            source,
        })?;
    }
    Ok(())
}

fn v36_prefix_scratch_bytes(attempt: &Path) -> Result<u64> {
    let mut bytes = 0_u64;
    for entry in fs::read_dir(attempt).map_err(|source| BorsukError::Io {
        path: attempt.to_owned(),
        source,
    })? {
        let entry = entry.map_err(|source| BorsukError::Io {
            path: attempt.to_owned(),
            source,
        })?;
        let path = entry.path();
        let metadata = entry.metadata().map_err(|source| BorsukError::Io {
            path: path.clone(),
            source,
        })?;
        if !metadata.is_file() {
            return Err(invalid("V36 prefix scratch entry differs"));
        }
        bytes = bytes
            .checked_add(metadata.len())
            .ok_or_else(|| invalid("V36 prefix scratch bytes overflow"))?;
    }
    Ok(bytes)
}

fn validate_v36_prefix_scratch_limit(attempt: &Path, limit: u64) -> Result<()> {
    if v36_prefix_scratch_bytes(attempt)? > limit {
        return Err(resource_limit("scratch bytes"));
    }
    Ok(())
}

fn v36_prefix_file_handle_digests(
    file: &mut File,
    path: &Path,
    io_buffer_bytes: usize,
) -> Result<(u64, String, String)> {
    v36_prefix_external_io(path, file.seek(SeekFrom::Start(0)))?;
    let encoded_bytes = file
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?
        .len();
    let mut sha256 = Sha256::new();
    let mut blake3 = blake3::Hasher::new();
    let mut buffer = vec![0_u8; io_buffer_bytes];
    loop {
        let read = v36_prefix_external_io(path, file.read(&mut buffer))?;
        if read == 0 {
            break;
        }
        sha256.update(&buffer[..read]);
        blake3.update(&buffer[..read]);
    }
    Ok((
        encoded_bytes,
        format!("{:x}", sha256.finalize()),
        blake3.finalize().to_hex().to_string(),
    ))
}

fn validate_v36_prefix_identity_batch_body(rows: u64, body_bytes: u64) -> Result<()> {
    const ALIGNMENT: u64 = 8;
    let validity_bytes = rows
        .checked_add(7)
        .map(|bits| bits / 8)
        .and_then(|bytes| bytes.checked_add(ALIGNMENT - 1))
        .map(|bytes| bytes / ALIGNMENT * ALIGNMENT)
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    let values_bytes = rows
        .checked_mul(u64::try_from(size_of::<u64>()).unwrap())
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    let expected = validity_bytes
        .checked_add(values_bytes)
        .and_then(|column| column.checked_mul(2))
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    if body_bytes != expected {
        return Err(invalid("V36 prefix Arrow batch body layout differs"));
    }
    Ok(())
}

fn align_v36_prefix_arrow_buffer(bytes: u64) -> Result<u64> {
    bytes
        .checked_add(7)
        .map(|value| value / 8 * 8)
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))
}

fn validate_v36_prefix_selected_batch_body(rows: u64, body_bytes: u64) -> Result<()> {
    let validity = align_v36_prefix_arrow_buffer(
        rows.checked_add(7)
            .map(|bits| bits / 8)
            .ok_or_else(|| resource_limit("Arrow batch body bytes"))?,
    )?;
    let values = rows
        .checked_mul(8 + 32 + 8)
        .and_then(|bytes| {
            rows.checked_mul(2)
                .and_then(|u16_bytes| align_v36_prefix_arrow_buffer(u16_bytes).ok())
                .and_then(|u16_bytes| bytes.checked_add(u16_bytes))
        })
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    let expected = validity
        .checked_mul(4)
        .and_then(|bytes| bytes.checked_add(values))
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    if body_bytes != expected {
        return Err(invalid("V36 prefix Arrow batch body layout differs"));
    }
    Ok(())
}

fn copy_v36_prefix_snapshot_exact(
    source: &mut impl Read,
    snapshot: &mut impl Write,
    paths: (&Path, &Path),
    expected_bytes: u64,
    io_buffer_bytes: usize,
) -> Result<(String, String)> {
    let (source_path, snapshot_path) = paths;
    let mut sha256 = Sha256::new();
    let mut blake3 = blake3::Hasher::new();
    let mut remaining = expected_bytes;
    let mut buffer = vec![0_u8; io_buffer_bytes];
    while remaining > 0 {
        let limit = usize::try_from(remaining.min(io_buffer_bytes as u64)).unwrap();
        let read = v36_prefix_external_io(source_path, source.read(&mut buffer[..limit]))?;
        if read == 0 {
            return Err(invalid("V36 prefix identity-run snapshot differs"));
        }
        sha256.update(&buffer[..read]);
        blake3.update(&buffer[..read]);
        v36_prefix_external_io(snapshot_path, snapshot.write_all(&buffer[..read]))?;
        remaining -= read as u64;
    }
    let mut excess = [0_u8; 1];
    if v36_prefix_external_io(source_path, source.read(&mut excess))? != 0 {
        return Err(resource_limit("identity-run input bytes"));
    }
    Ok((
        format!("{:x}", sha256.finalize()),
        blake3.finalize().to_hex().to_string(),
    ))
}

fn snapshot_v36_prefix_authenticated_file(
    source_path: &Path,
    snapshot_path: &Path,
    expected_bytes: u64,
    expected_sha256: &str,
    expected_blake3: Option<&str>,
    limits: &V36PrefixExternalSelectionLimits,
) -> Result<(File, String)> {
    let file_type = fs::symlink_metadata(source_path)
        .map_err(|source| BorsukError::Io {
            path: source_path.to_owned(),
            source,
        })?
        .file_type();
    if !file_type.is_file() || file_type.is_symlink() || expected_bytes == 0 {
        return Err(invalid("V36 prefix local artifact path differs"));
    }
    if expected_bytes > limits.max_input_bytes {
        return Err(resource_limit("identity-run input bytes"));
    }
    let attempt = snapshot_path
        .parent()
        .ok_or_else(|| invalid("V36 prefix snapshot path differs"))?;
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(expected_bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let mut source = File::open(source_path).map_err(|source| BorsukError::Io {
        path: source_path.to_owned(),
        source,
    })?;
    if source
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: source_path.to_owned(),
            source,
        })?
        .len()
        != expected_bytes
    {
        return Err(invalid("V36 prefix local input authority differs"));
    }
    let mut snapshot = OpenOptions::new()
        .create_new(true)
        .read(true)
        .write(true)
        .open(snapshot_path)
        .map_err(|source| BorsukError::Io {
            path: snapshot_path.to_owned(),
            source,
        })?;
    let (sha256, blake3) = copy_v36_prefix_snapshot_exact(
        &mut source,
        &mut snapshot,
        (source_path, snapshot_path),
        expected_bytes,
        limits.io_buffer_bytes,
    )?;
    v36_prefix_external_io(snapshot_path, snapshot.sync_all())?;
    if sha256 != expected_sha256 || expected_blake3.is_some_and(|expected| expected != blake3) {
        return Err(invalid("V36 prefix local input authority differs"));
    }
    v36_prefix_external_io(snapshot_path, snapshot.seek(SeekFrom::Start(0)))?;
    Ok((snapshot, blake3))
}

fn preflight_v36_prefix_arrow_file(
    file: &mut File,
    path: &Path,
    encoded_bytes: u64,
    max_batch_rows: usize,
    validate_body: fn(u64, u64) -> Result<()>,
) -> Result<u64> {
    const TRAILER_BYTES: u64 = 10;
    if encoded_bytes < TRAILER_BYTES {
        return Err(invalid("V36 prefix identity-run Arrow footer differs"));
    }
    v36_prefix_external_io(path, file.seek(SeekFrom::End(-10)))?;
    let mut trailer = [0_u8; 10];
    v36_prefix_external_io(path, file.read_exact(&mut trailer))?;
    let footer_len = read_footer_length(trailer)
        .map_err(|_| invalid("V36 prefix identity-run Arrow footer differs"))?;
    if footer_len > EXTERNAL_MAX_ARROW_FOOTER_BYTES {
        return Err(resource_limit("Arrow footer bytes"));
    }
    if footer_len == 0
        || u64::try_from(footer_len)
            .ok()
            .and_then(|length| length.checked_add(TRAILER_BYTES))
            .is_none_or(|required| required > encoded_bytes)
    {
        return Err(invalid("V36 prefix identity-run Arrow footer differs"));
    }
    let footer_start = encoded_bytes - TRAILER_BYTES - footer_len as u64;
    v36_prefix_external_io(path, file.seek(SeekFrom::Start(footer_start)))?;
    let mut footer_bytes = vec![0_u8; footer_len];
    v36_prefix_external_io(path, file.read_exact(&mut footer_bytes))?;
    let footer = root_as_footer(&footer_bytes)
        .map_err(|_| invalid("V36 prefix identity-run Arrow footer differs"))?;
    if footer
        .dictionaries()
        .is_some_and(|blocks| !blocks.is_empty())
    {
        return Err(invalid("V36 prefix identity-run Arrow dictionaries differ"));
    }
    let batches = footer
        .recordBatches()
        .ok_or_else(|| invalid("V36 prefix identity-run Arrow batches differ"))?;
    if batches.len() > EXTERNAL_MAX_ARROW_BATCHES {
        return Err(resource_limit("Arrow batch count"));
    }
    let mut total_rows = 0_u64;
    for block in batches {
        let offset = u64::try_from(block.offset())
            .map_err(|_| invalid("V36 prefix identity-run Arrow block differs"))?;
        let metadata = u64::try_from(block.metaDataLength())
            .map_err(|_| invalid("V36 prefix identity-run Arrow block differs"))?;
        let body = u64::try_from(block.bodyLength())
            .map_err(|_| invalid("V36 prefix identity-run Arrow block differs"))?;
        let end = offset
            .checked_add(metadata)
            .and_then(|value| value.checked_add(body))
            .ok_or_else(|| invalid("V36 prefix identity-run Arrow block differs"))?;
        if metadata < 4 || metadata > EXTERNAL_MAX_ARROW_FOOTER_BYTES as u64 || end > footer_start {
            return Err(invalid("V36 prefix identity-run Arrow block differs"));
        }
        v36_prefix_external_io(path, file.seek(SeekFrom::Start(offset)))?;
        let mut message_bytes = vec![0_u8; metadata as usize];
        v36_prefix_external_io(path, file.read_exact(&mut message_bytes))?;
        let (declared, message_start) = if message_bytes[..4] == [0xff; 4] {
            if message_bytes.len() < 8 {
                return Err(invalid("V36 prefix identity-run Arrow message differs"));
            }
            (
                u32::from_le_bytes(message_bytes[4..8].try_into().unwrap()) as usize,
                8_usize,
            )
        } else {
            (
                u32::from_le_bytes(message_bytes[..4].try_into().unwrap()) as usize,
                4_usize,
            )
        };
        let message_end = message_start
            .checked_add(declared)
            .filter(|end| *end <= message_bytes.len())
            .ok_or_else(|| invalid("V36 prefix identity-run Arrow message differs"))?;
        let message = root_as_message(&message_bytes[message_start..message_end])
            .map_err(|_| invalid("V36 prefix identity-run Arrow message differs"))?;
        let batch = message
            .header_as_record_batch()
            .ok_or_else(|| invalid("V36 prefix identity-run Arrow message differs"))?;
        if batch.length() <= 0
            || usize::try_from(batch.length())
                .ok()
                .is_none_or(|rows| rows > max_batch_rows)
            || batch.compression().is_some()
        {
            return Err(invalid("V36 prefix identity-run Arrow message differs"));
        }
        let rows = u64::try_from(batch.length())
            .map_err(|_| invalid("V36 prefix identity-run Arrow message differs"))?;
        total_rows = total_rows
            .checked_add(rows)
            .ok_or_else(|| invalid("V36 prefix identity-run Arrow row count overflows"))?;
        let message_body = u64::try_from(message.bodyLength())
            .map_err(|_| invalid("V36 prefix identity-run Arrow message differs"))?;
        if message_body != body {
            return Err(invalid("V36 prefix identity-run Arrow block differs"));
        }
        validate_body(rows, body)?;
    }
    v36_prefix_external_io(path, file.seek(SeekFrom::Start(0)))?;
    Ok(total_rows)
}

fn stream_v36_prefix_identity_run_file(
    input: &V36PrefixIdentityRunFile,
    limits: &V36PrefixExternalSelectionLimits,
    attempt: &Path,
    seed: &[u8; 32],
    manifest: &[u8; 32],
    consume: &mut impl FnMut(V36PrefixScoredIdentity) -> Result<()>,
) -> Result<(u64, u64)> {
    let file_type = fs::symlink_metadata(&input.path)
        .map_err(|source| BorsukError::Io {
            path: input.path.clone(),
            source,
        })?
        .file_type();
    if !file_type.is_file() || file_type.is_symlink() {
        return Err(invalid("V36 prefix local artifact path differs"));
    }
    let mut source_file = File::open(&input.path).map_err(|source| BorsukError::Io {
        path: input.path.clone(),
        source,
    })?;
    let encoded_bytes = source_file
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: input.path.clone(),
            source,
        })?
        .len();
    if encoded_bytes == 0 {
        return Err(invalid("V36 prefix identity-run artifact differs"));
    }
    if encoded_bytes > limits.max_input_bytes {
        return Err(resource_limit("identity-run input bytes"));
    }
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(encoded_bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let snapshot_path = attempt.join(format!("input-{:04}.arrow", input.selected_object_ordinal));
    let mut file = OpenOptions::new()
        .create_new(true)
        .read(true)
        .write(true)
        .open(&snapshot_path)
        .map_err(|source| BorsukError::Io {
            path: snapshot_path.clone(),
            source,
        })?;
    let (sha256, blake3) = copy_v36_prefix_snapshot_exact(
        &mut source_file,
        &mut file,
        (&input.path, &snapshot_path),
        encoded_bytes,
        limits.io_buffer_bytes,
    )?;
    v36_prefix_external_io(&snapshot_path, file.sync_all())?;
    if file
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: snapshot_path.clone(),
            source,
        })?
        .len()
        != encoded_bytes
    {
        return Err(invalid("V36 prefix identity-run snapshot differs"));
    }
    v36_prefix_external_io(&snapshot_path, file.seek(SeekFrom::Start(0)))?;
    let expected_role = format!(
        "population-identity-run-{:04}",
        input.selected_object_ordinal
    );
    let content_addressed = url::Url::parse(&input.identity.uri)
        .ok()
        .filter(|uri| uri.scheme() == "s3" && uri.host_str().is_some())
        .and_then(|uri| uri.path().rsplit('/').next().map(str::to_owned))
        .is_some_and(|name| name.starts_with(&format!("{sha256}-")));
    if input.identity.role != expected_role
        || input.identity.encoded_bytes != encoded_bytes
        || input.identity.sha256 != sha256
        || input.identity.blake3 != blake3
        || !content_addressed
    {
        return Err(invalid("V36 prefix identity-run artifact differs"));
    }
    preflight_v36_prefix_arrow_file(
        &mut file,
        &snapshot_path,
        encoded_bytes,
        IDENTITY_RUN_BATCH_ROWS,
        validate_v36_prefix_identity_batch_body,
    )?;
    let mut reader = ArrowFileReader::try_new(file, None)?;
    let schema = reader.schema();
    let row_count = schema
        .metadata()
        .get("rows")
        .and_then(|value| value.parse::<u64>().ok())
        .ok_or_else(|| invalid("V36 prefix identity-run schema differs"))?;
    let physical_rows = schema
        .metadata()
        .get("physical_rows")
        .and_then(|value| value.parse::<u64>().ok())
        .ok_or_else(|| invalid("V36 prefix identity-run schema differs"))?;
    if row_count > physical_rows {
        return Err(invalid("V36 prefix identity-run row count differs"));
    }
    let row_count_usize = usize::try_from(row_count)
        .map_err(|_| invalid("V36 prefix identity-run row count differs"))?;
    let expected_run = V36PrefixIdentityRun {
        physical_rows,
        rows: Vec::new(),
        selected_object_ordinal: input.selected_object_ordinal,
        source: input.source.clone(),
    };
    validate_v36_prefix_identity_run(&expected_run)?;
    let expected_batches = row_count_usize.div_ceil(IDENTITY_RUN_BATCH_ROWS);
    if schema.as_ref() != &v36_prefix_identity_run_schema(&expected_run, row_count_usize)
        || reader.num_batches() != expected_batches
    {
        return Err(invalid("V36 prefix identity-run schema differs"));
    }
    let mut previous_feature_id = None;
    let use_bitmap = v36_prefix_identity_offset_bitmap_selected(physical_rows, row_count_usize)?;
    let mut offset_bitmap = use_bitmap
        .then(|| allocate_v36_prefix_cutoff_bitmap(physical_rows))
        .transpose()?;
    let mut offset_rows = if use_bitmap {
        None
    } else {
        let mut offsets = Vec::new();
        offsets
            .try_reserve_exact(row_count_usize)
            .map_err(|_| resource_limit("identity-run offset state bytes"))?;
        Some(offsets)
    };
    let mut seen = 0_u64;
    for batch_index in 0..expected_batches {
        let batch = reader
            .next()
            .transpose()?
            .ok_or_else(|| invalid("V36 prefix identity-run batch is missing"))?;
        let expected_rows =
            (row_count_usize - batch_index * IDENTITY_RUN_BATCH_ROWS).min(IDENTITY_RUN_BATCH_ROWS);
        if batch.num_rows() != expected_rows {
            return Err(invalid("V36 prefix identity-run batches differ"));
        }
        let feature_ids = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix identity-run feature IDs differ"))?;
        let row_offsets = batch
            .column(1)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix identity-run row offsets differ"))?;
        for (&feature_row_id, &row_offset) in feature_ids.values().iter().zip(row_offsets.values())
        {
            if row_offset >= physical_rows
                || previous_feature_id.is_some_and(|prior| prior >= feature_row_id)
            {
                return Err(invalid("V36 prefix identity-run rows differ"));
            }
            let duplicate_offset = if let Some(bitmap) = &mut offset_bitmap {
                let word = usize::try_from(row_offset / 64)
                    .map_err(|_| invalid("V36 prefix identity-run row offset differs"))?;
                let mask = 1_u64 << (row_offset % 64);
                let duplicate = bitmap[word] & mask != 0;
                bitmap[word] |= mask;
                duplicate
            } else {
                offset_rows
                    .as_mut()
                    .ok_or_else(|| invalid("V36 prefix identity-run offset state differs"))?
                    .push(row_offset);
                false
            };
            if duplicate_offset {
                return Err(invalid("V36 prefix identity-run rows differ"));
            }
            previous_feature_id = Some(feature_row_id);
            consume(V36PrefixScoredIdentity {
                score: score(seed, manifest, feature_row_id),
                feature_row_id,
                selected_object_ordinal: input.selected_object_ordinal,
                row_offset,
            })?;
            seen += 1;
        }
    }
    if reader.next().is_some() || seen != row_count {
        return Err(invalid("V36 prefix identity-run batches differ"));
    }
    if let Some(offsets) = &mut offset_rows {
        offsets.sort_unstable();
        if offsets.windows(2).any(|pair| pair[0] == pair[1]) {
            return Err(invalid("V36 prefix identity-run rows differ"));
        }
    }
    drop(reader);
    fs::remove_file(&snapshot_path).map_err(|source| BorsukError::Io {
        path: snapshot_path,
        source,
    })?;
    Ok((row_count, physical_rows))
}

struct V36PrefixIdentityFeatureStream {
    reader: ArrowFileReader<File>,
    batch: Option<RecordBatch>,
    index: usize,
}

impl V36PrefixIdentityFeatureStream {
    fn from_file(mut file: File, path: &Path) -> Result<Self> {
        v36_prefix_external_io(path, file.seek(SeekFrom::Start(0)))?;
        Ok(Self {
            reader: ArrowFileReader::try_new(file, None)?,
            batch: None,
            index: 0,
        })
    }

    fn next_id(&mut self) -> Result<Option<u64>> {
        loop {
            if let Some(batch) = &self.batch
                && self.index < batch.num_rows()
            {
                let feature_ids = batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .ok_or_else(|| invalid("V36 prefix identity-run feature IDs differ"))?;
                let feature_row_id = feature_ids.value(self.index);
                self.index += 1;
                return Ok(Some(feature_row_id));
            }
            match self.reader.next().transpose()? {
                Some(batch) => {
                    self.batch = Some(batch);
                    self.index = 0;
                }
                None => return Ok(None),
            }
        }
    }
}

fn validate_v36_prefix_identity_run_handles_disjoint(
    left: &File,
    right: &File,
    paths: (&Path, &Path),
) -> Result<()> {
    let mut left = V36PrefixIdentityFeatureStream::from_file(
        left.try_clone().map_err(|source| BorsukError::Io {
            path: paths.0.to_owned(),
            source,
        })?,
        paths.0,
    )?;
    let mut right = V36PrefixIdentityFeatureStream::from_file(
        right.try_clone().map_err(|source| BorsukError::Io {
            path: paths.1.to_owned(),
            source,
        })?,
        paths.1,
    )?;
    let mut left_id = left.next_id()?;
    let mut right_id = right.next_id()?;
    while let (Some(existing), Some(candidate)) = (left_id, right_id) {
        match existing.cmp(&candidate) {
            Ordering::Less => left_id = left.next_id()?,
            Ordering::Greater => right_id = right.next_id()?,
            Ordering::Equal => {
                return Err(invalid("V36 prefix identity-run global ID repeats"));
            }
        }
    }
    Ok(())
}

fn validate_v36_prefix_identity_run_files_disjoint(left: &Path, right: &Path) -> Result<()> {
    let left_file = File::open(left).map_err(|source| BorsukError::Io {
        path: left.to_owned(),
        source,
    })?;
    let right_file = File::open(right).map_err(|source| BorsukError::Io {
        path: right.to_owned(),
        source,
    })?;
    validate_v36_prefix_identity_run_handles_disjoint(&left_file, &right_file, (left, right))
}

struct V36PrefixPriorFeatureMerge {
    streams: Vec<V36PrefixIdentityFeatureStream>,
    heap: BinaryHeap<Reverse<(u64, usize)>>,
}

impl V36PrefixPriorFeatureMerge {
    fn from_handles(handles: &[File], paths: &[PathBuf]) -> Result<Self> {
        if handles.len() != paths.len() {
            return Err(invalid("V36 identity-run predecessor handles differ"));
        }
        let mut streams = handles
            .iter()
            .zip(paths)
            .map(|(file, path)| {
                V36PrefixIdentityFeatureStream::from_file(
                    file.try_clone().map_err(|source| BorsukError::Io {
                        path: path.clone(),
                        source,
                    })?,
                    path,
                )
            })
            .collect::<Result<Vec<_>>>()?;
        let mut heap = BinaryHeap::new();
        for (index, stream) in streams.iter_mut().enumerate() {
            if let Some(id) = stream.next_id()? {
                heap.push(Reverse((id, index)));
            }
        }
        Ok(Self { streams, heap })
    }

    fn contains(&mut self, candidate: u64) -> Result<bool> {
        while self
            .heap
            .peek()
            .is_some_and(|Reverse((id, _))| *id < candidate)
        {
            let Reverse((_, index)) = self.heap.pop().unwrap();
            if let Some(id) = self.streams[index].next_id()? {
                self.heap.push(Reverse((id, index)));
            }
        }
        Ok(self
            .heap
            .peek()
            .is_some_and(|Reverse((id, _))| *id == candidate))
    }
}

fn collapse_v36_prefix_identity_spills(
    attempt: &Path,
    mut spills: Vec<PathBuf>,
    limits: &V36PrefixExternalSelectionLimits,
    next_spill: &mut usize,
) -> Result<PathBuf> {
    if spills.is_empty() {
        return Err(invalid("V36 identity spill set is empty"));
    }
    while spills.len() > 1 {
        let mut outputs = Vec::new();
        for group in spills.chunks(limits.merge_fan_in) {
            if outputs.len() >= limits.max_spills {
                return Err(resource_limit("spill count"));
            }
            let output = attempt.join(format!("identity-{:08}.bin", *next_spill));
            merge_v36_prefix_identity_spills(group, &output, limits)?;
            outputs.push(output);
            *next_spill = next_spill
                .checked_add(1)
                .ok_or_else(|| invalid("V36 identity spill ordinal overflows"))?;
        }
        spills = outputs;
    }
    Ok(spills.pop().unwrap())
}

struct V36PrefixSelectedStream {
    reader: ArrowFileReader<File>,
    batch: Option<RecordBatch>,
    batch_index: usize,
    contract: V36PrefixSelectedIdsContract,
    cutoff_feature_row_id: u64,
    cutoff_score_sha256: String,
    expected_rows: usize,
    finished: bool,
    manifest: [u8; 32],
    previous: Option<([u8; 32], u64)>,
    seed: [u8; 32],
    seen: usize,
}

#[derive(Clone, Copy)]
struct V36PrefixSelectedStreamRecord {
    feature_row_id: u64,
    row_offset: u64,
    score: [u8; 32],
    selected_object_ordinal: u16,
}

impl V36PrefixSelectedStream {
    fn next_record(&mut self) -> Result<Option<V36PrefixSelectedStreamRecord>> {
        loop {
            if let Some(batch) = &self.batch
                && self.batch_index < batch.num_rows()
            {
                let index = self.batch_index;
                self.batch_index += 1;
                let feature_ids = batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .ok_or_else(|| invalid("V36 prefix selected-ID feature IDs differ"))?;
                let encoded_scores = batch
                    .column(1)
                    .as_any()
                    .downcast_ref::<FixedSizeBinaryArray>()
                    .ok_or_else(|| invalid("V36 prefix selected-ID scores differ"))?;
                let object_ordinals = batch
                    .column(2)
                    .as_any()
                    .downcast_ref::<UInt16Array>()
                    .ok_or_else(|| invalid("V36 prefix selected-ID object ordinals differ"))?;
                let row_offsets = batch
                    .column(3)
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .ok_or_else(|| invalid("V36 prefix selected-ID row offsets differ"))?;
                let feature_row_id = feature_ids.value(index);
                let computed = score(&self.seed, &self.manifest, feature_row_id);
                let rank = (computed, feature_row_id);
                let window_end =
                    self.contract.selected_object_start + self.contract.selected_object_count;
                if encoded_scores.value(index) != computed
                    || object_ordinals.value(index) < self.contract.selected_object_start
                    || object_ordinals.value(index) >= window_end
                    || self.previous.is_some_and(|previous| previous >= rank)
                    || row_offsets.is_null(index)
                {
                    return Err(invalid("V36 prefix selected-ID rows differ"));
                }
                self.previous = Some(rank);
                self.seen += 1;
                return Ok(Some(V36PrefixSelectedStreamRecord {
                    feature_row_id,
                    row_offset: row_offsets.value(index),
                    score: computed,
                    selected_object_ordinal: object_ordinals.value(index),
                }));
            }
            if self.finished {
                return Ok(None);
            }
            match self.reader.next().transpose()? {
                Some(batch) => {
                    let remaining = self.expected_rows.saturating_sub(self.seen);
                    let expected = remaining.min(SELECTED_IDS_BATCH_ROWS);
                    if batch.num_rows() != expected
                        || batch.num_columns() != 4
                        || batch
                            .columns()
                            .iter()
                            .any(|column| column.null_count() != 0)
                    {
                        return Err(invalid("V36 prefix selected-ID batches differ"));
                    }
                    self.batch = Some(batch);
                    self.batch_index = 0;
                }
                None => {
                    self.finished = true;
                    let final_rank = self
                        .previous
                        .ok_or_else(|| invalid("V36 prefix selected-ID cutoff is missing"))?;
                    if self.seen != self.expected_rows
                        || final_rank.1 != self.cutoff_feature_row_id
                        || digest_hex(&final_rank.0) != self.cutoff_score_sha256
                    {
                        return Err(invalid("V36 prefix selected-ID cutoff differs"));
                    }
                    return Ok(None);
                }
            }
        }
    }
}

struct V36PrefixPhysicalUniqueness<'a> {
    attempt: &'a Path,
    buffer: Vec<V36PrefixScoredIdentity>,
    limits: &'a V36PrefixExternalSelectionLimits,
    next_spill: usize,
    spills: Vec<PathBuf>,
}

impl<'a> V36PrefixPhysicalUniqueness<'a> {
    fn new(
        attempt: &'a Path,
        limits: &'a V36PrefixExternalSelectionLimits,
        next_spill: usize,
    ) -> Self {
        Self {
            attempt,
            buffer: Vec::with_capacity(limits.sort_buffer_records),
            limits,
            next_spill,
            spills: Vec::new(),
        }
    }

    fn push(&mut self, selected: V36PrefixSelectedStreamRecord) -> Result<()> {
        let mut physical_key = [0_u8; 32];
        physical_key[..2].copy_from_slice(&selected.selected_object_ordinal.to_be_bytes());
        physical_key[2..10].copy_from_slice(&selected.row_offset.to_be_bytes());
        self.buffer.push(V36PrefixScoredIdentity {
            score: physical_key,
            feature_row_id: selected.feature_row_id,
            selected_object_ordinal: selected.selected_object_ordinal,
            row_offset: selected.row_offset,
        });
        if self.buffer.len() == self.limits.sort_buffer_records {
            self.flush()?;
        }
        Ok(())
    }

    fn flush(&mut self) -> Result<()> {
        if self.buffer.is_empty() {
            return Ok(());
        }
        if self.spills.len() >= self.limits.max_spills {
            return Err(resource_limit("spill count"));
        }
        let path = create_v36_prefix_spill(
            self.attempt,
            self.next_spill,
            &mut self.buffer,
            self.limits.io_buffer_bytes,
            self.limits.max_scratch_bytes,
        )?;
        self.spills.push(path);
        self.next_spill += 1;
        self.buffer.clear();
        Ok(())
    }

    fn finish(mut self) -> Result<()> {
        self.flush()?;
        while self.spills.len() > self.limits.merge_fan_in {
            let mut outputs = Vec::new();
            for group in self.spills.chunks(self.limits.merge_fan_in) {
                let output = self
                    .attempt
                    .join(format!("spill-{:08}.bin", self.next_spill));
                merge_v36_prefix_spills(
                    group,
                    &output,
                    self.limits.io_buffer_bytes,
                    self.limits.max_scratch_bytes,
                )?;
                outputs.push(output);
                self.next_spill += 1;
            }
            self.spills = outputs;
        }
        let physical = if self.spills.len() == 1 {
            self.spills.pop().unwrap()
        } else {
            let output = self
                .attempt
                .join(format!("spill-{:08}.bin", self.next_spill));
            merge_v36_prefix_spills(
                &self.spills,
                &output,
                self.limits.io_buffer_bytes,
                self.limits.max_scratch_bytes,
            )?;
            output
        };
        let mut reader = V36PrefixSpillReader::open(&physical, self.limits.io_buffer_bytes)?;
        let mut previous_key = None;
        while let Some(record) = reader.next_record()? {
            if previous_key == Some(record.score) {
                return Err(invalid("V36 prefix selected-ID rows differ"));
            }
            previous_key = Some(record.score);
        }
        drop(reader);
        fs::remove_file(&physical).map_err(|source| BorsukError::Io {
            path: physical,
            source,
        })?;
        Ok(())
    }
}

fn next_v36_prefix_excluded_rank(
    stream: &mut V36PrefixSelectedStream,
    physical: &mut V36PrefixPhysicalUniqueness<'_>,
) -> Result<Option<([u8; 32], u64)>> {
    let Some(record) = stream.next_record()? else {
        return Ok(None);
    };
    physical.push(record)?;
    Ok(Some((record.score, record.feature_row_id)))
}

fn open_v36_prefix_selected_stream(
    selected: &V36PrefixSelectedIdsFile,
    limits: &V36PrefixExternalSelectionLimits,
    attempt: &Path,
    snapshot_filename: &'static str,
) -> Result<V36PrefixSelectedStream> {
    if !matches!(
        snapshot_filename,
        "excluded-population.arrow" | "selected-population.arrow"
    ) {
        return Err(invalid("V36 prefix selected-ID snapshot role differs"));
    }
    let file_type = fs::symlink_metadata(&selected.path)
        .map_err(|source| BorsukError::Io {
            path: selected.path.clone(),
            source,
        })?
        .file_type();
    if !file_type.is_file() || file_type.is_symlink() {
        return Err(invalid("V36 prefix local artifact path differs"));
    }
    let mut source = File::open(&selected.path).map_err(|source| BorsukError::Io {
        path: selected.path.clone(),
        source,
    })?;
    let encoded_bytes = source
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: selected.path.clone(),
            source,
        })?
        .len();
    if encoded_bytes == 0 || encoded_bytes > limits.max_input_bytes {
        return Err(resource_limit("selected-ID input bytes"));
    }
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(encoded_bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let snapshot_path = attempt.join(snapshot_filename);
    let mut snapshot = OpenOptions::new()
        .create_new(true)
        .read(true)
        .write(true)
        .open(&snapshot_path)
        .map_err(|source| BorsukError::Io {
            path: snapshot_path.clone(),
            source,
        })?;
    let (sha256, blake3) = copy_v36_prefix_snapshot_exact(
        &mut source,
        &mut snapshot,
        (&selected.path, &snapshot_path),
        encoded_bytes,
        limits.io_buffer_bytes,
    )?;
    v36_prefix_external_io(&snapshot_path, snapshot.sync_all())?;
    let content_addressed = url::Url::parse(&selected.identity.uri)
        .ok()
        .filter(|uri| uri.scheme() == "s3" && uri.host_str().is_some())
        .and_then(|uri| uri.path().rsplit('/').next().map(str::to_owned))
        .is_some_and(|name| name.starts_with(&format!("{sha256}-")));
    if selected.identity.role != "population-selected-identities"
        || selected.identity.encoded_bytes != encoded_bytes
        || selected.identity.sha256 != sha256
        || selected.identity.blake3 != blake3
        || !content_addressed
    {
        return Err(invalid("V36 prefix selected-ID artifact differs"));
    }
    let declared_rows = preflight_v36_prefix_arrow_file(
        &mut snapshot,
        &snapshot_path,
        encoded_bytes,
        SELECTED_IDS_BATCH_ROWS,
        validate_v36_prefix_selected_batch_body,
    )?;
    let reader = ArrowFileReader::try_new(snapshot, None)?;
    let expected_rows = usize::try_from(selected.contract.selected_rows)
        .map_err(|_| invalid("V36 prefix selected-ID row count overflows"))?;
    let expected_batches = expected_rows.div_ceil(SELECTED_IDS_BATCH_ROWS);
    let schema = reader.schema();
    let cutoff_feature_row_id = schema
        .metadata()
        .get("cutoff_feature_row_id")
        .and_then(|value| value.parse::<u64>().ok())
        .ok_or_else(|| invalid("V36 prefix selected-ID schema differs"))?;
    let cutoff_score_sha256 = schema
        .metadata()
        .get("cutoff_score_sha256")
        .ok_or_else(|| invalid("V36 prefix selected-ID schema differs"))?
        .clone();
    if declared_rows != selected.contract.selected_rows
        || schema.as_ref()
            != &selected_ids_schema(
                &selected.contract,
                cutoff_feature_row_id,
                &cutoff_score_sha256,
            )
        || reader.num_batches() != expected_batches
    {
        return Err(invalid("V36 prefix selected-ID schema differs"));
    }
    let (seed, manifest) = validate_selected_ids_contract(&selected.contract)?;
    Ok(V36PrefixSelectedStream {
        reader,
        batch: None,
        batch_index: 0,
        contract: selected.contract.clone(),
        cutoff_feature_row_id,
        cutoff_score_sha256,
        expected_rows,
        finished: false,
        manifest,
        previous: None,
        seed,
        seen: 0,
    })
}

fn write_v36_prefix_selected_file(
    contract: &V36PrefixSelectedIdsContract,
    selected_spill: &Path,
    cutoff: V36PrefixScoredIdentity,
    limits: &V36PrefixExternalSelectionLimits,
    output: &Path,
) -> Result<(u64, String, String)> {
    let cutoff_sha256 = digest_hex(&cutoff.score);
    let seed = digest_bytes(&contract.population_seed_sha256)?;
    let manifest = digest_bytes(&contract.ordered_source_manifest_sha256)?;
    let schema = Arc::new(selected_ids_schema(
        contract,
        cutoff.feature_row_id,
        &cutoff_sha256,
    ));
    let options = IpcWriteOptions::try_new(8, false, MetadataVersion::V5)?;
    let mut reader = V36PrefixSpillReader::open(selected_spill, limits.io_buffer_bytes)?;
    let mut temporary = temporary_output(output)?;
    let mut writer = ArrowFileWriter::try_new_with_options(
        BufWriter::with_capacity(limits.io_buffer_bytes, temporary.as_file()),
        schema.as_ref(),
        options,
    )?;
    let mut rows = Vec::with_capacity(SELECTED_IDS_BATCH_ROWS);
    while let Some(record) = reader.next_record()? {
        if score(&seed, &manifest, record.feature_row_id) != record.score {
            return Err(invalid("V36 prefix selected-ID score differs"));
        }
        rows.push(record);
        if rows.len() == SELECTED_IDS_BATCH_ROWS {
            write_v36_prefix_selected_batch(&mut writer, schema.clone(), &rows)?;
            rows.clear();
        }
    }
    if !rows.is_empty() {
        write_v36_prefix_selected_batch(&mut writer, schema, &rows)?;
    }
    writer.finish()?;
    let mut buffered = writer.into_inner()?;
    v36_prefix_external_io(output, buffered.flush())?;
    drop(buffered);
    let identity =
        v36_prefix_file_handle_digests(temporary.as_file_mut(), output, limits.io_buffer_bytes)?;
    publish_output_noclobber(temporary, output)?;
    Ok(identity)
}

fn write_v36_prefix_selected_batch(
    writer: &mut ArrowFileWriter<BufWriter<&File>>,
    schema: Arc<Schema>,
    rows: &[V36PrefixScoredIdentity],
) -> Result<()> {
    let scores = rows
        .iter()
        .map(|row| row.score.as_slice())
        .collect::<Vec<_>>();
    writer.write(&RecordBatch::try_new(
        schema,
        vec![
            Arc::new(UInt64Array::from(
                rows.iter()
                    .map(|row| row.feature_row_id)
                    .collect::<Vec<_>>(),
            )),
            Arc::new(FixedSizeBinaryArray::try_from_iter(scores.into_iter())?),
            Arc::new(UInt16Array::from(
                rows.iter()
                    .map(|row| row.selected_object_ordinal)
                    .collect::<Vec<_>>(),
            )),
            Arc::new(UInt64Array::from(
                rows.iter().map(|row| row.row_offset).collect::<Vec<_>>(),
            )),
        ],
    )?)?;
    Ok(())
}

/// Build one feature-ID-ordered v3 identity run with bounded external memory.
pub fn externally_build_v36_prefix_identity_run(
    request: V36PrefixExternalIdentityRunRequest<'_>,
) -> Result<V36PrefixExternalIdentityRunReceipt> {
    let limits = request.limits;
    if limits.max_spills == 0
        || limits.max_spills > EXTERNAL_MAX_SPILLS
        || limits.merge_fan_in < 2
        || limits.merge_fan_in > EXTERNAL_MAX_FAN_IN
        || limits.sort_buffer_records == 0
        || limits.sort_buffer_records > EXTERNAL_MAX_SORT_BUFFER_RECORDS
        || limits.io_buffer_bytes == 0
        || limits.io_buffer_bytes > EXTERNAL_MAX_IO_BUFFER_BYTES
        || request.prior_runs.len() > 16
        || request.cutoff_local_rank == Some(0)
        || request.output.exists()
    {
        return Err(resource_limit("external identity-run configuration"));
    }
    let output_uri = url::Url::parse(request.output_uri_prefix)
        .map_err(|_| invalid("V36 identity-run output URI differs"))?;
    let scratch_type = fs::symlink_metadata(request.scratch_root)
        .map_err(|source| BorsukError::Io {
            path: request.scratch_root.to_owned(),
            source,
        })?
        .file_type();
    let output_parent = request
        .output
        .parent()
        .ok_or_else(|| invalid("V36 identity-run output path differs"))?;
    let output_parent_type = fs::symlink_metadata(output_parent)
        .map_err(|source| BorsukError::Io {
            path: output_parent.to_owned(),
            source,
        })?
        .file_type();
    if output_uri.scheme() != "s3"
        || output_uri.host_str().is_none()
        || output_uri.query().is_some()
        || output_uri.fragment().is_some()
        || !scratch_type.is_dir()
        || scratch_type.is_symlink()
        || !output_parent_type.is_dir()
        || output_parent_type.is_symlink()
    {
        return Err(invalid("V36 identity-run output authority differs"));
    }
    let prior_start = request
        .selected_object_ordinal
        .checked_sub(
            request
                .prior_runs
                .len()
                .try_into()
                .map_err(|_| invalid("V36 identity-run predecessor count overflows"))?,
        )
        .ok_or_else(|| invalid("V36 identity-run predecessor sequence differs"))?;
    for (index, prior) in request.prior_runs.iter().enumerate() {
        let expected = prior_start
            .checked_add(
                index
                    .try_into()
                    .map_err(|_| invalid("V36 identity-run predecessor count overflows"))?,
            )
            .ok_or_else(|| invalid("V36 identity-run predecessor sequence differs"))?;
        if prior.selected_object_ordinal != expected {
            return Err(invalid("V36 identity-run predecessor sequence differs"));
        }
    }
    let attempt = tempfile::tempdir_in(request.scratch_root).map_err(|source| BorsukError::Io {
        path: request.scratch_root.to_owned(),
        source,
    })?;
    if request.source.encoded_bytes == 0 || request.source.encoded_bytes > limits.max_input_bytes {
        return Err(resource_limit("identity-run input bytes"));
    }
    let mut prior_local_paths = BTreeSet::new();
    let mut source_paths = BTreeSet::new();
    let mut source_uris = BTreeSet::new();
    let mut source_digests = BTreeSet::new();
    let mut stable_prior_paths = Vec::with_capacity(request.prior_runs.len());
    let mut stable_prior_handles = Vec::with_capacity(request.prior_runs.len());
    for (index, prior) in request.prior_runs.iter().enumerate() {
        if !prior_local_paths.insert(prior.path.clone())
            || !source_paths.insert(prior.source.path.clone())
            || !source_uris.insert(prior.source.uri.clone())
            || !source_digests.insert(prior.source.sha256.clone())
        {
            return Err(invalid("V36 identity-run predecessor sources differ"));
        }
        let stable_path = attempt.path().join(format!("prior-{index:04}.arrow"));
        let (stable_handle, _) = snapshot_v36_prefix_authenticated_file(
            &prior.path,
            &stable_path,
            prior.identity.encoded_bytes,
            &prior.identity.sha256,
            Some(&prior.identity.blake3),
            limits,
        )?;
        let stable_prior = V36PrefixIdentityRunFile {
            identity: prior.identity.clone(),
            path: stable_path.clone(),
            selected_object_ordinal: prior.selected_object_ordinal,
            source: prior.source.clone(),
        };
        stream_v36_prefix_identity_run_file(
            &stable_prior,
            limits,
            attempt.path(),
            &[0_u8; 32],
            &[0_u8; 32],
            &mut |_| Ok(()),
        )?;
        stable_prior_paths.push(stable_path);
        stable_prior_handles.push(stable_handle);
    }
    if !source_paths.insert(request.source.path.clone())
        || !source_uris.insert(request.source.uri.clone())
        || !source_digests.insert(request.source.sha256.clone())
    {
        return Err(invalid("V36 identity-run predecessor sources differ"));
    }
    for left in 0..stable_prior_handles.len() {
        for right in left + 1..stable_prior_handles.len() {
            validate_v36_prefix_identity_run_handles_disjoint(
                &stable_prior_handles[left],
                &stable_prior_handles[right],
                (&stable_prior_paths[left], &stable_prior_paths[right]),
            )?;
        }
    }
    let source_snapshot_path = attempt.path().join("source.parquet");
    let (_source_snapshot, source_blake3) = snapshot_v36_prefix_authenticated_file(
        request.input,
        &source_snapshot_path,
        request.source.encoded_bytes,
        &request.source.sha256,
        None,
        limits,
    )?;
    let mut buffer = Vec::with_capacity(limits.sort_buffer_records);
    let mut spills = Vec::new();
    let mut next_spill = 0_usize;
    let physical_rows = scan_v36_prefix_registered_input_parquet(
        &source_snapshot_path,
        request.source,
        request.selected_object_ordinal,
        |row| {
            let identity = validate_v36_prefix_input_row(&row)?;
            buffer.push(V36PrefixRawIdentity {
                feature_row_id: identity.feature_row_id,
                selected_object_ordinal: identity.selected_object_ordinal,
                row_offset: identity.row_offset,
            });
            if buffer.len() == limits.sort_buffer_records {
                if spills.len() >= limits.max_spills {
                    return Err(resource_limit("spill count"));
                }
                spills.push(create_v36_prefix_identity_spill(
                    attempt.path(),
                    next_spill,
                    &mut buffer,
                    limits,
                )?);
                next_spill = next_spill
                    .checked_add(1)
                    .ok_or_else(|| invalid("V36 identity spill ordinal overflows"))?;
                buffer.clear();
            }
            Ok(())
        },
    )?;
    if !buffer.is_empty() {
        if spills.len() >= limits.max_spills {
            return Err(resource_limit("spill count"));
        }
        spills.push(create_v36_prefix_identity_spill(
            attempt.path(),
            next_spill,
            &mut buffer,
            limits,
        )?);
        next_spill = next_spill
            .checked_add(1)
            .ok_or_else(|| invalid("V36 identity spill ordinal overflows"))?;
    }
    let merged =
        collapse_v36_prefix_identity_spills(attempt.path(), spills, limits, &mut next_spill)?;
    let mut cutoff_bitmap = request
        .cutoff_local_rank
        .map(|_| allocate_v36_prefix_cutoff_bitmap(physical_rows))
        .transpose()?;
    let mut reader = V36PrefixRawIdentityReader::open(&merged, limits.io_buffer_bytes)?;
    let mut prior =
        V36PrefixPriorFeatureMerge::from_handles(&stable_prior_handles, &stable_prior_paths)?;
    let mut previous_id = None;
    let mut distinct_rows = 0_u64;
    while let Some(row) = reader.next_record()? {
        if previous_id == Some(row.feature_row_id) {
            continue;
        }
        previous_id = Some(row.feature_row_id);
        if !prior.contains(row.feature_row_id)? {
            distinct_rows += 1;
            if let Some(bitmap) = &mut cutoff_bitmap {
                let word = usize::try_from(row.row_offset / 64)
                    .map_err(|_| invalid("V36 identity-run cutoff offset differs"))?;
                bitmap[word] |= 1_u64 << (row.row_offset % 64);
            }
        }
    }
    let cutoff_row_offset = request
        .cutoff_local_rank
        .and_then(|rank| select_v36_prefix_cutoff_offset(cutoff_bitmap.as_deref()?, rank));
    let source = V36PrefixSourceObject {
        blake3: source_blake3,
        encoded_bytes: request.source.encoded_bytes,
        path: request.source.path.clone(),
        sample_sha256: request.source.sample_sha256.clone(),
        sha256: request.source.sha256.clone(),
        uri: request.source.uri.clone(),
    };
    let run = V36PrefixIdentityRun {
        physical_rows,
        rows: Vec::new(),
        selected_object_ordinal: request.selected_object_ordinal,
        source: source.clone(),
    };
    let row_count = usize::try_from(distinct_rows)
        .map_err(|_| invalid("V36 identity-run row count overflows"))?;
    let schema = Arc::new(v36_prefix_identity_run_schema(&run, row_count));
    let options = IpcWriteOptions::try_new(8, false, MetadataVersion::V5)?;
    let mut temporary = temporary_output(request.output)?;
    let mut writer = ArrowFileWriter::try_new_with_options(
        BufWriter::with_capacity(limits.io_buffer_bytes, temporary.as_file()),
        schema.as_ref(),
        options,
    )?;
    let mut reader = V36PrefixRawIdentityReader::open(&merged, limits.io_buffer_bytes)?;
    let mut prior =
        V36PrefixPriorFeatureMerge::from_handles(&stable_prior_handles, &stable_prior_paths)?;
    let mut previous_id = None;
    let mut batch = Vec::with_capacity(IDENTITY_RUN_BATCH_ROWS);
    while let Some(row) = reader.next_record()? {
        if previous_id == Some(row.feature_row_id) {
            continue;
        }
        previous_id = Some(row.feature_row_id);
        if prior.contains(row.feature_row_id)? {
            continue;
        }
        batch.push(V36PrefixRowIdentity {
            feature_row_id: row.feature_row_id,
            selected_object_ordinal: row.selected_object_ordinal,
            row_offset: row.row_offset,
            source_ordinal: None,
        });
        if batch.len() == IDENTITY_RUN_BATCH_ROWS {
            write_v36_prefix_identity_run_batch(&mut writer, schema.clone(), &batch)?;
            batch.clear();
        }
    }
    if !batch.is_empty() {
        write_v36_prefix_identity_run_batch(&mut writer, schema, &batch)?;
    }
    writer.finish()?;
    drop(writer);
    let (encoded_bytes, sha256, blake3) = v36_prefix_file_handle_digests(
        temporary.as_file_mut(),
        request.output,
        limits.io_buffer_bytes,
    )?;
    let identity = V36ArtifactIdentity {
        blake3,
        encoded_bytes,
        role: format!(
            "population-identity-run-{:04}",
            request.selected_object_ordinal
        ),
        sha256: sha256.clone(),
        uri: format!(
            "{}/{sha256}-population-identity-run-{:04}.arrow",
            request.output_uri_prefix.trim_end_matches('/'),
            request.selected_object_ordinal
        ),
    };
    let duplicate_rows = physical_rows
        .checked_sub(distinct_rows)
        .ok_or_else(|| invalid("V36 identity-run duplicate rows underflow"))?;
    fs::remove_file(&merged).map_err(|source| BorsukError::Io {
        path: merged,
        source,
    })?;
    publish_output_noclobber(temporary, request.output)?;
    Ok(V36PrefixExternalIdentityRunReceipt {
        cutoff_row_offset,
        duplicate_rows,
        distinct_rows,
        physical_rows,
        run: V36PrefixIdentityRunFile {
            identity,
            path: request.output.to_owned(),
            selected_object_ordinal: request.selected_object_ordinal,
            source,
        },
    })
}

/// Externally select one complete authenticated population without resident bulk state.
pub fn externally_select_v36_prefix_population_rows(
    request: V36PrefixExternalSelectionRequest<'_>,
) -> Result<V36PrefixSelectedFileReceipt> {
    let V36PrefixExternalSelectionRequest {
        authority,
        exclusion,
        limits,
        output,
        output_uri_prefix,
        runs,
        scratch_root,
    } = request;
    validate_external_selection_authority(authority)?;
    if limits.max_spills > EXTERNAL_MAX_SPILLS
        || limits.merge_fan_in > EXTERNAL_MAX_FAN_IN
        || limits.sort_buffer_records > EXTERNAL_MAX_SORT_BUFFER_RECORDS
        || limits.io_buffer_bytes > EXTERNAL_MAX_IO_BUFFER_BYTES
    {
        return Err(resource_limit("external selection configuration"));
    }
    let output_uri = url::Url::parse(output_uri_prefix)
        .map_err(|_| invalid("V36 prefix selected-ID output URI differs"))?;
    let output_parent = output
        .parent()
        .ok_or_else(|| invalid("V36 prefix selected-ID output path differs"))?;
    let scratch_type = fs::symlink_metadata(scratch_root)
        .map_err(|source| BorsukError::Io {
            path: scratch_root.to_owned(),
            source,
        })?
        .file_type();
    let output_parent_type = fs::symlink_metadata(output_parent)
        .map_err(|source| BorsukError::Io {
            path: output_parent.to_owned(),
            source,
        })?
        .file_type();
    if output_uri.scheme() != "s3"
        || output_uri.host_str().is_none()
        || output_uri.query().is_some()
        || output_uri.fragment().is_some()
        || output.exists()
        || !scratch_type.is_dir()
        || scratch_type.is_symlink()
        || !output_parent_type.is_dir()
        || output_parent_type.is_symlink()
    {
        return Err(invalid("V36 prefix external selection output differs"));
    }
    let exclusion_is_valid = match (authority.cohort_ordinal, exclusion) {
        (0, None) => authority.excluded_population_identity.is_none(),
        (0, Some(_)) | (_, None) => false,
        (_, Some(selected)) => {
            validate_selected_ids_contract(&selected.contract).is_ok()
                && authority.excluded_population_identity.as_ref() == Some(&selected.identity)
                && selected.contract.cohort_ordinal.checked_add(1) == Some(authority.cohort_ordinal)
                && selected.contract.population_seed_sha256 == authority.population_seed_sha256
                && selected.contract.ordered_source_manifest_sha256
                    == authority.ordered_source_manifest_sha256
                && selected
                    .contract
                    .selected_object_start
                    .checked_add(selected.contract.selected_object_count)
                    == Some(authority.selected_object_start)
        }
    };
    if !exclusion_is_valid
        || runs.len() != usize::from(authority.selected_object_count)
        || runs.is_empty()
        || limits.io_buffer_bytes == 0
        || limits.max_input_bytes == 0
        || limits.max_scratch_bytes == 0
        || limits.max_spills == 0
        || limits.merge_fan_in < 2
        || limits.sort_buffer_records == 0
        || runs.len() > 16
        || output_uri_prefix.trim_end_matches('/').is_empty()
    {
        return Err(invalid("V36 prefix external selection authority differs"));
    }
    let seed = digest_bytes(&authority.population_seed_sha256)?;
    let manifest = digest_bytes(&authority.ordered_source_manifest_sha256)?;
    let mut source_paths = BTreeSet::new();
    for (index, run) in runs.iter().enumerate() {
        let expected_ordinal = authority
            .selected_object_start
            .checked_add(
                u16::try_from(index)
                    .map_err(|_| invalid("V36 prefix identity-run ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix identity-run ordinal overflows"))?;
        if run.selected_object_ordinal != expected_ordinal
            || !source_paths.insert(run.source.path.as_str())
        {
            return Err(invalid("V36 prefix identity-run sequence differs"));
        }
    }
    let attempt = tempfile::tempdir_in(scratch_root).map_err(|source| BorsukError::Io {
        path: scratch_root.to_owned(),
        source,
    })?;
    let mut exclusion_stream = exclusion
        .map(|selected| {
            open_v36_prefix_selected_stream(
                selected,
                limits,
                attempt.path(),
                "excluded-population.arrow",
            )
        })
        .transpose()?;
    let mut spills = Vec::new();
    let mut buffer = Vec::with_capacity(limits.sort_buffer_records);
    let mut next_spill = 0_usize;
    let mut scratch_bytes = 0_u64;
    for run in runs {
        stream_v36_prefix_identity_run_file(
            run,
            limits,
            attempt.path(),
            &seed,
            &manifest,
            &mut |record| {
                buffer.push(record);
                if buffer.len() == limits.sort_buffer_records {
                    if spills.len() >= limits.max_spills {
                        return Err(resource_limit("spill count"));
                    }
                    let path = create_v36_prefix_spill(
                        attempt.path(),
                        next_spill,
                        &mut buffer,
                        limits.io_buffer_bytes,
                        limits.max_scratch_bytes,
                    )?;
                    let spill_bytes = v36_prefix_external_io(&path, fs::metadata(&path))?.len();
                    scratch_bytes = scratch_bytes
                        .checked_add(spill_bytes)
                        .ok_or_else(|| invalid("V36 prefix scratch bytes overflow"))?;
                    if scratch_bytes > limits.max_scratch_bytes {
                        return Err(resource_limit("scratch bytes"));
                    }
                    spills.push(path);
                    next_spill += 1;
                    buffer.clear();
                }
                Ok(())
            },
        )?;
    }
    if !buffer.is_empty() {
        if spills.len() >= limits.max_spills {
            return Err(resource_limit("spill count"));
        }
        let path = create_v36_prefix_spill(
            attempt.path(),
            next_spill,
            &mut buffer,
            limits.io_buffer_bytes,
            limits.max_scratch_bytes,
        )?;
        let spill_bytes = v36_prefix_external_io(&path, fs::metadata(&path))?.len();
        scratch_bytes = scratch_bytes
            .checked_add(spill_bytes)
            .ok_or_else(|| invalid("V36 prefix scratch bytes overflow"))?;
        if scratch_bytes > limits.max_scratch_bytes {
            return Err(resource_limit("scratch bytes"));
        }
        spills.push(path);
        next_spill += 1;
    }
    if spills.is_empty() {
        if let Some(stream) = exclusion_stream.as_mut() {
            let mut physical = V36PrefixPhysicalUniqueness::new(attempt.path(), limits, next_spill);
            while next_v36_prefix_excluded_rank(stream, &mut physical)?.is_some() {}
            physical.finish()?;
        }
        return Err(BorsukError::V36PrefixSourceInsufficient);
    }
    while spills.len() > limits.merge_fan_in {
        let mut outputs = Vec::new();
        for group in spills.chunks(limits.merge_fan_in) {
            let output = attempt.path().join(format!("spill-{next_spill:08}.bin"));
            merge_v36_prefix_spills(
                group,
                &output,
                limits.io_buffer_bytes,
                limits.max_scratch_bytes,
            )?;
            validate_v36_prefix_scratch_limit(attempt.path(), limits.max_scratch_bytes)?;
            outputs.push(output);
            next_spill += 1;
        }
        spills = outputs;
    }
    let merged = attempt.path().join(format!("spill-{next_spill:08}.bin"));
    merge_v36_prefix_spills(
        &spills,
        &merged,
        limits.io_buffer_bytes,
        limits.max_scratch_bytes,
    )?;
    validate_v36_prefix_scratch_limit(attempt.path(), limits.max_scratch_bytes)?;
    next_spill += 1;
    let selected_path = attempt.path().join(format!("spill-{next_spill:08}.bin"));
    let selected_bytes = EXTERNAL_SPILL_HEADER_BYTES
        .checked_add(
            authority
                .selected_rows
                .checked_mul(EXTERNAL_SPILL_RECORD_BYTES)
                .ok_or_else(|| invalid("V36 prefix spill length overflows"))?,
        )
        .and_then(|bytes| bytes.checked_add(EXTERNAL_SPILL_DIGEST_BYTES))
        .ok_or_else(|| invalid("V36 prefix spill length overflows"))?;
    if v36_prefix_scratch_bytes(attempt.path())?
        .checked_add(selected_bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let selected_file = OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(&selected_path)
        .map_err(|source| BorsukError::Io {
            path: selected_path.clone(),
            source,
        })?;
    let mut selected_writer = BufWriter::with_capacity(limits.io_buffer_bytes, selected_file);
    write_v36_prefix_spill_header(&mut selected_writer, authority.selected_rows)?;
    let mut selected_hasher = blake3::Hasher::new();
    let mut merged_reader = V36PrefixSpillReader::open(&merged, limits.io_buffer_bytes)?;
    let mut eligible_rows = 0_u64;
    let mut excluded_rows = 0_u64;
    let mut previous_id = None;
    let mut cutoff = None;
    let mut exclusion_physical =
        V36PrefixPhysicalUniqueness::new(attempt.path(), limits, next_spill + 1);
    let mut excluded_rank = exclusion_stream
        .as_mut()
        .map(|stream| next_v36_prefix_excluded_rank(stream, &mut exclusion_physical))
        .transpose()?
        .flatten();
    while let Some(record) = merged_reader.next_record()? {
        if previous_id == Some(record.feature_row_id) {
            return Err(invalid("V36 prefix identity-run global ID repeats"));
        }
        previous_id = Some(record.feature_row_id);
        let rank = (record.score, record.feature_row_id);
        while excluded_rank.is_some_and(|excluded| excluded < rank) {
            excluded_rank = next_v36_prefix_excluded_rank(
                exclusion_stream
                    .as_mut()
                    .expect("V36 exclusion stream exists with an exclusion rank"),
                &mut exclusion_physical,
            )?;
        }
        if excluded_rank == Some(rank) {
            excluded_rows += 1;
            excluded_rank = next_v36_prefix_excluded_rank(
                exclusion_stream
                    .as_mut()
                    .expect("V36 exclusion stream exists with an exclusion rank"),
                &mut exclusion_physical,
            )?;
            continue;
        }
        eligible_rows += 1;
        if eligible_rows <= authority.selected_rows {
            write_v36_prefix_scored_identity(&mut selected_writer, &mut selected_hasher, &record)?;
            cutoff = Some(record);
        }
    }
    if let Some(stream) = exclusion_stream.as_mut() {
        while next_v36_prefix_excluded_rank(stream, &mut exclusion_physical)?.is_some() {}
        exclusion_physical.finish()?;
    }
    if eligible_rows < authority.selected_rows {
        return Err(BorsukError::V36PrefixSourceInsufficient);
    }
    if eligible_rows
        .checked_add(excluded_rows)
        .is_none_or(|rows| rows != authority.distinct_rows)
    {
        return Err(invalid("V36 prefix selected-ID population count differs"));
    }
    finish_v36_prefix_spill(&selected_path, &mut selected_writer, &selected_hasher)?;
    drop(selected_writer);
    validate_v36_prefix_scratch_limit(attempt.path(), limits.max_scratch_bytes)?;
    let cutoff = cutoff.ok_or(BorsukError::V36PrefixSourceInsufficient)?;
    let cutoff_feature_row_id = cutoff.feature_row_id;
    let cutoff_score_sha256 = digest_hex(&cutoff.score);
    let contract = V36PrefixSelectedIdsContract {
        cohort_ordinal: authority.cohort_ordinal,
        eligible_rows,
        excluded_population_identity: authority.excluded_population_identity.clone(),
        excluded_rows,
        ordered_source_manifest_sha256: authority.ordered_source_manifest_sha256.clone(),
        population_seed_sha256: authority.population_seed_sha256.clone(),
        selected_object_count: authority.selected_object_count,
        selected_object_start: authority.selected_object_start,
        selected_rows: authority.selected_rows,
    };
    let (encoded_bytes, sha256, blake3) =
        write_v36_prefix_selected_file(&contract, &selected_path, cutoff, limits, output)?;
    let prefix = output_uri_prefix.trim_end_matches('/');
    Ok(V36PrefixSelectedFileReceipt {
        cutoff_feature_row_id,
        cutoff_score_sha256,
        contract,
        identity: V36ArtifactIdentity {
            blake3,
            encoded_bytes,
            role: "population-selected-identities".to_owned(),
            sha256: sha256.clone(),
            uri: format!("{prefix}/{sha256}-population-selected-identities.arrow"),
        },
    })
}

/// Select one complete file-backed population and publish its exact Selected checkpoint.
pub fn select_v36_prefix_checkpoint_population(
    request: V36PrefixCheckpointSelectionRequest<'_>,
) -> Result<V36PrefixCheckpointSelection> {
    let V36PrefixCheckpointSelectionRequest {
        authority,
        exclusion,
        limits,
        output,
        output_uri_prefix,
        population,
        scratch_root,
        writer,
    } = request;
    let installed_runs = writer.identity_run_files()?;
    if population.runs != installed_runs
        || population.distinct_rows != authority.distinct_rows
        || population
            .physical_rows
            .checked_sub(population.distinct_rows)
            != Some(population.duplicate_rows)
    {
        return Err(invalid("V36 checkpoint population selection state differs"));
    }
    let receipt =
        externally_select_v36_prefix_population_rows(V36PrefixExternalSelectionRequest {
            authority,
            exclusion,
            limits,
            output,
            output_uri_prefix,
            runs: &installed_runs,
            scratch_root,
        })?;
    let selection = V36PrefixPopulationSelection {
        cutoff_feature_row_id: receipt.cutoff_feature_row_id,
        cutoff_score_sha256: receipt.cutoff_score_sha256.clone(),
        eligible_rows: receipt.contract.eligible_rows,
        excluded_population_identity: receipt.contract.excluded_population_identity.clone(),
        excluded_rows: receipt.contract.excluded_rows,
        selected_ids: receipt.identity.clone(),
        selected_rows: receipt.contract.selected_rows,
    };
    let checkpoint_ready = writer.commit_selected(&selection, output)?;
    let selected = V36PrefixSelectedIdsFile {
        contract: receipt.contract.clone(),
        identity: receipt.identity.clone(),
        path: output.to_owned(),
    };
    Ok(V36PrefixCheckpointSelection {
        selected,
        receipt,
        selection,
        checkpoint_ready,
    })
}

fn validate_v36_prefix_role_assignment_contract(
    contract: &V36PrefixRoleAssignmentContract,
    selected: &V36PrefixSelectedIdsFile,
) -> Result<([u8; 32], [u8; 32])> {
    let authority = validate_v36_prefix_role_assignment_contract_shape(contract)?;
    if contract.selected_rows != selected.contract.selected_rows
        || contract.selected_population_identity != selected.identity
        || contract.ordered_source_manifest_sha256
            != selected.contract.ordered_source_manifest_sha256
        || contract.selected_object_start != selected.contract.selected_object_start
        || contract.selected_object_count != selected.contract.selected_object_count
    {
        return Err(invalid("V36 prefix role-assignment authority differs"));
    }
    Ok(authority)
}

fn validate_v36_prefix_role_assignment_contract_shape(
    contract: &V36PrefixRoleAssignmentContract,
) -> Result<([u8; 32], [u8; 32])> {
    let expected_names = ["development", "validation", "sealed-holdout", "performance"];
    let expected_labels = [
        "borsuk-v36-prefix-screen-development-query-v2",
        "borsuk-v36-prefix-screen-validation-query-v2",
        "borsuk-v36-prefix-screen-sealed-holdout-query-v2",
        "borsuk-v36-prefix-screen-performance-query-v2",
    ];
    let query_rows = contract.roles.iter().try_fold(0_u64, |sum, role| {
        sum.checked_add(role.rows)
            .ok_or_else(|| invalid("V36 prefix role row count overflows"))
    })?;
    if contract.roles.len() != 4
        || contract.corpus_rows == 0
        || contract.selected_object_count == 0
        || contract.selected_population_identity.role != "population-selected-identities"
        || contract.selected_population_identity.encoded_bytes == 0
        || digest_bytes(&contract.selected_population_identity.sha256).is_err()
        || digest_bytes(&contract.selected_population_identity.blake3).is_err()
        || contract.corpus_seed_label != "borsuk-v36-prefix-screen-corpus-v2"
        || contract.corpus_seed_sha256
            != format!(
                "{:x}",
                Sha256::digest(contract.corpus_seed_label.as_bytes())
            )
        || query_rows
            .checked_add(contract.corpus_rows)
            .is_none_or(|assigned| assigned > contract.selected_rows)
    {
        return Err(invalid("V36 prefix role-assignment authority differs"));
    }
    for ((role, expected_name), expected_label) in contract
        .roles
        .iter()
        .zip(expected_names)
        .zip(expected_labels)
    {
        if role.role != expected_name
            || role.seed_label != expected_label
            || role.rows == 0
            || role.seed_sha256 != format!("{:x}", Sha256::digest(role.seed_label.as_bytes()))
        {
            return Err(invalid("V36 prefix role-assignment authority differs"));
        }
    }
    Ok((
        digest_bytes(&contract.corpus_seed_sha256)?,
        digest_bytes(&contract.ordered_source_manifest_sha256)?,
    ))
}

fn project_v36_prefix_role_assignment_owned_bytes(
    contract: &V36PrefixRoleAssignmentContract,
    limits: &V36PrefixExternalSelectionLimits,
) -> Result<u64> {
    let record_bytes = u64::try_from(size_of::<V36PrefixScoredIdentity>()).unwrap();
    let mut cumulative = 0_u64;
    let mut heap_slots = 0_u64;
    for role in &contract.roles {
        cumulative = cumulative
            .checked_add(role.rows)
            .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
        let capacity = cumulative
            .checked_next_power_of_two()
            .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
        heap_slots = heap_slots
            .checked_add(capacity)
            .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    }
    let heap_bytes = heap_slots
        .checked_mul(record_bytes)
        .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    let assignment_bytes = cumulative
        .checked_mul(record_bytes)
        .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    let chosen_bytes = cumulative
        .checked_mul(64)
        .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    let sort_bytes = u64::try_from(limits.sort_buffer_records)
        .ok()
        .and_then(|records| records.checked_mul(record_bytes))
        .and_then(|bytes| bytes.checked_mul(2))
        .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    let io_bytes = u64::try_from(limits.merge_fan_in)
        .ok()
        .and_then(|readers| readers.checked_add(4))
        .and_then(|buffers| buffers.checked_mul(limits.io_buffer_bytes as u64))
        .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    let arrow_bytes = u64::try_from(SELECTED_IDS_BATCH_ROWS)
        .unwrap()
        .checked_mul(64)
        .and_then(|bytes| bytes.checked_add(EXTERNAL_MAX_ARROW_FOOTER_BYTES as u64))
        .ok_or_else(|| resource_limit("role-assignment owned memory"))?;
    heap_bytes
        .checked_add(assignment_bytes)
        .and_then(|bytes| bytes.checked_add(chosen_bytes))
        .and_then(|bytes| bytes.checked_add(sort_bytes))
        .and_then(|bytes| bytes.checked_add(io_bytes))
        .and_then(|bytes| bytes.checked_add(arrow_bytes))
        .ok_or_else(|| resource_limit("role-assignment owned memory"))
}

fn v36_prefix_role_assignment_score(
    selected_object_ordinal: u16,
    row_offset: u64,
    role: u8,
    role_ordinal: u64,
) -> [u8; 32] {
    let mut key = [0_u8; 32];
    key[..2].copy_from_slice(&selected_object_ordinal.to_be_bytes());
    key[2..10].copy_from_slice(&row_offset.to_be_bytes());
    key[10] = role;
    key[11..19].copy_from_slice(&role_ordinal.to_be_bytes());
    key
}

fn v36_prefix_role_assignment_record(
    row: V36PrefixScoredIdentity,
    role: u8,
    role_ordinal: u64,
) -> V36PrefixScoredIdentity {
    V36PrefixScoredIdentity {
        score: v36_prefix_role_assignment_score(
            row.selected_object_ordinal,
            row.row_offset,
            role,
            role_ordinal,
        ),
        feature_row_id: row.feature_row_id,
        selected_object_ordinal: row.selected_object_ordinal,
        row_offset: row.row_offset,
    }
}

fn push_v36_prefix_external_record(
    record: V36PrefixScoredIdentity,
    buffer: &mut Vec<V36PrefixScoredIdentity>,
    spills: &mut Vec<PathBuf>,
    next_spill: &mut usize,
    attempt: &Path,
    limits: &V36PrefixExternalSelectionLimits,
) -> Result<()> {
    buffer.push(record);
    if buffer.len() == limits.sort_buffer_records {
        if spills.len() >= limits.max_spills {
            return Err(resource_limit("spill count"));
        }
        spills.push(create_v36_prefix_spill(
            attempt,
            *next_spill,
            buffer,
            limits.io_buffer_bytes,
            limits.max_scratch_bytes,
        )?);
        *next_spill += 1;
        buffer.clear();
    }
    Ok(())
}

fn finish_v36_prefix_external_spills(
    buffer: &mut Vec<V36PrefixScoredIdentity>,
    mut spills: Vec<PathBuf>,
    next_spill: &mut usize,
    attempt: &Path,
    limits: &V36PrefixExternalSelectionLimits,
) -> Result<PathBuf> {
    if !buffer.is_empty() {
        if spills.len() >= limits.max_spills {
            return Err(resource_limit("spill count"));
        }
        spills.push(create_v36_prefix_spill(
            attempt,
            *next_spill,
            buffer,
            limits.io_buffer_bytes,
            limits.max_scratch_bytes,
        )?);
        *next_spill += 1;
        buffer.clear();
    }
    if spills.is_empty() {
        return Err(invalid("V36 prefix role-assignment rows are missing"));
    }
    while spills.len() > limits.merge_fan_in {
        let mut outputs = Vec::new();
        for group in spills.chunks(limits.merge_fan_in) {
            let output = attempt.join(format!("spill-{:08}.bin", *next_spill));
            merge_v36_prefix_spills(
                group,
                &output,
                limits.io_buffer_bytes,
                limits.max_scratch_bytes,
            )?;
            *next_spill += 1;
            outputs.push(output);
        }
        spills = outputs;
    }
    let output = attempt.join(format!("spill-{:08}.bin", *next_spill));
    merge_v36_prefix_spills(
        &spills,
        &output,
        limits.io_buffer_bytes,
        limits.max_scratch_bytes,
    )?;
    *next_spill += 1;
    Ok(output)
}

fn v36_prefix_role_assignment_schema(contract: &V36PrefixRoleAssignmentContract) -> Schema {
    let query_rows = contract.roles.iter().map(|role| role.rows).sum::<u64>();
    let assigned_rows = query_rows + contract.corpus_rows;
    let metadata = HashMap::from([
        ("assigned_rows".into(), assigned_rows.to_string()),
        ("corpus_rows".into(), contract.corpus_rows.to_string()),
        (
            "corpus_seed_label".into(),
            contract.corpus_seed_label.clone(),
        ),
        (
            "corpus_seed_sha256".into(),
            contract.corpus_seed_sha256.clone(),
        ),
        (
            "dropped_rows".into(),
            (contract.selected_rows - assigned_rows).to_string(),
        ),
        ("format".into(), ROLE_ASSIGNMENT_FORMAT.into()),
        (
            "ordered_source_manifest_sha256".into(),
            contract.ordered_source_manifest_sha256.clone(),
        ),
        (
            "role_rows".into(),
            contract
                .roles
                .iter()
                .map(|role| role.rows.to_string())
                .collect::<Vec<_>>()
                .join(","),
        ),
        (
            "role_mapping".into(),
            "0:corpus,1:development,2:validation,3:sealed-holdout,4:performance".into(),
        ),
        (
            "role_seed_sha256".into(),
            contract
                .roles
                .iter()
                .map(|role| role.seed_sha256.as_str())
                .collect::<Vec<_>>()
                .join(","),
        ),
        (
            "selected_identity_blake3".into(),
            contract.selected_population_identity.blake3.clone(),
        ),
        (
            "selected_identity_bytes".into(),
            contract
                .selected_population_identity
                .encoded_bytes
                .to_string(),
        ),
        (
            "selected_identity_sha256".into(),
            contract.selected_population_identity.sha256.clone(),
        ),
        (
            "selected_identity_uri".into(),
            contract.selected_population_identity.uri.clone(),
        ),
        (
            "selected_object_count".into(),
            contract.selected_object_count.to_string(),
        ),
        (
            "selected_object_start".into(),
            contract.selected_object_start.to_string(),
        ),
        ("selected_rows".into(), contract.selected_rows.to_string()),
        (
            "sort".into(),
            "selected-object-ordinal-row-offset-role-role-ordinal".into(),
        ),
    ]);
    Schema::new_with_metadata(
        vec![
            Field::new("selected_object_ordinal", DataType::UInt16, false),
            Field::new("row_offset", DataType::UInt64, false),
            Field::new("feature_row_id", DataType::UInt64, false),
            Field::new("role", DataType::UInt8, false),
            Field::new("role_ordinal", DataType::UInt64, false),
        ],
        metadata,
    )
}

fn validate_v36_prefix_role_assignment_batch_body(rows: u64, body_bytes: u64) -> Result<()> {
    let validity = align_v36_prefix_arrow_buffer(
        rows.checked_add(7)
            .map(|bits| bits / 8)
            .ok_or_else(|| resource_limit("Arrow batch body bytes"))?,
    )?;
    let values = rows
        .checked_mul(24)
        .and_then(|bytes| {
            rows.checked_mul(2)
                .and_then(|part| align_v36_prefix_arrow_buffer(part).ok())
                .and_then(|part| bytes.checked_add(part))
        })
        .and_then(|bytes| {
            align_v36_prefix_arrow_buffer(rows)
                .ok()
                .and_then(|part| bytes.checked_add(part))
        })
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    let expected = validity
        .checked_mul(5)
        .and_then(|bytes| bytes.checked_add(values))
        .ok_or_else(|| resource_limit("Arrow batch body bytes"))?;
    if body_bytes != expected {
        return Err(invalid("V36 prefix role-assignment Arrow layout differs"));
    }
    Ok(())
}

#[derive(Clone, Copy)]
struct V36PrefixRoleAssignmentRow {
    feature_row_id: u64,
    role: u8,
    role_ordinal: u64,
    row_offset: u64,
    selected_object_ordinal: u16,
}

struct V36PrefixRoleAssignmentStream {
    batch: Option<RecordBatch>,
    batch_index: usize,
    counts: [u64; 5],
    expected_rows: usize,
    finished: bool,
    previous_physical: Option<(u16, u64)>,
    reader: ArrowFileReader<File>,
    seen: usize,
    seen_ordinals: Vec<Vec<u64>>,
    snapshot_path: PathBuf,
    window_end: u16,
    window_start: u16,
}

impl V36PrefixRoleAssignmentStream {
    fn next_record(&mut self) -> Result<Option<V36PrefixRoleAssignmentRow>> {
        loop {
            if let Some(batch) = &self.batch
                && self.batch_index < batch.num_rows()
            {
                let index = self.batch_index;
                self.batch_index += 1;
                let objects = batch
                    .column(0)
                    .as_any()
                    .downcast_ref::<UInt16Array>()
                    .ok_or_else(|| invalid("V36 prefix role-assignment objects differ"))?;
                let offsets = batch
                    .column(1)
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .ok_or_else(|| invalid("V36 prefix role-assignment offsets differ"))?;
                let ids = batch
                    .column(2)
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .ok_or_else(|| invalid("V36 prefix role-assignment IDs differ"))?;
                let roles = batch
                    .column(3)
                    .as_any()
                    .downcast_ref::<UInt8Array>()
                    .ok_or_else(|| invalid("V36 prefix role-assignment roles differ"))?;
                let ordinals = batch
                    .column(4)
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .ok_or_else(|| invalid("V36 prefix role-assignment ordinals differ"))?;
                let object = objects.value(index);
                let offset = offsets.value(index);
                let role = usize::from(roles.value(index));
                let ordinal = ordinals.value(index);
                let physical = (object, offset);
                if object < self.window_start
                    || object >= self.window_end
                    || self
                        .previous_physical
                        .is_some_and(|previous| previous >= physical)
                    || role >= self.counts.len()
                    || ordinal >= self.counts[role]
                {
                    return Err(invalid("V36 prefix role-assignment rows differ"));
                }
                let word = usize::try_from(ordinal / 64)
                    .map_err(|_| invalid("V36 prefix role ordinal overflows"))?;
                let bit = 1_u64 << (ordinal % 64);
                if self.seen_ordinals[role][word] & bit != 0 {
                    return Err(invalid("V36 prefix role-assignment ordinal repeats"));
                }
                self.seen_ordinals[role][word] |= bit;
                self.previous_physical = Some(physical);
                self.seen += 1;
                return Ok(Some(V36PrefixRoleAssignmentRow {
                    feature_row_id: ids.value(index),
                    role: roles.value(index),
                    role_ordinal: ordinal,
                    row_offset: offset,
                    selected_object_ordinal: object,
                }));
            }
            if self.finished {
                return Ok(None);
            }
            match self.reader.next().transpose()? {
                Some(batch) => {
                    let remaining = self.expected_rows.saturating_sub(self.seen);
                    let expected = remaining.min(SELECTED_IDS_BATCH_ROWS);
                    if batch.num_rows() != expected
                        || batch.num_columns() != 5
                        || batch
                            .columns()
                            .iter()
                            .any(|column| column.null_count() != 0)
                    {
                        return Err(invalid("V36 prefix role-assignment batches differ"));
                    }
                    self.batch = Some(batch);
                    self.batch_index = 0;
                }
                None => {
                    self.finished = true;
                    if self.seen != self.expected_rows
                        || self
                            .seen_ordinals
                            .iter()
                            .zip(self.counts)
                            .any(|(words, count)| {
                                words
                                    .iter()
                                    .map(|word| word.count_ones() as u64)
                                    .sum::<u64>()
                                    != count
                            })
                    {
                        return Err(invalid("V36 prefix role-assignment row count differs"));
                    }
                    return Ok(None);
                }
            }
        }
    }
}

fn open_v36_prefix_role_assignment_stream(
    assignment: &V36PrefixRoleAssignmentFile,
    limits: &V36PrefixExternalSelectionLimits,
    attempt: &Path,
) -> Result<V36PrefixRoleAssignmentStream> {
    validate_v36_prefix_role_assignment_contract_shape(&assignment.contract)?;
    let file_type = fs::symlink_metadata(&assignment.path)
        .map_err(|source| BorsukError::Io {
            path: assignment.path.clone(),
            source,
        })?
        .file_type();
    if !file_type.is_file() || file_type.is_symlink() {
        return Err(invalid("V36 prefix local artifact path differs"));
    }
    let mut source = File::open(&assignment.path).map_err(|source| BorsukError::Io {
        path: assignment.path.clone(),
        source,
    })?;
    let encoded_bytes = source
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: assignment.path.clone(),
            source,
        })?
        .len();
    if encoded_bytes == 0 || encoded_bytes > limits.max_input_bytes {
        return Err(resource_limit("role-assignment input bytes"));
    }
    if v36_prefix_scratch_bytes(attempt)?
        .checked_add(encoded_bytes)
        .is_none_or(|peak| peak > limits.max_scratch_bytes)
    {
        return Err(resource_limit("scratch bytes"));
    }
    let snapshot_path = attempt.join("role-assignments.arrow");
    let mut snapshot = OpenOptions::new()
        .create_new(true)
        .read(true)
        .write(true)
        .open(&snapshot_path)
        .map_err(|source| BorsukError::Io {
            path: snapshot_path.clone(),
            source,
        })?;
    let (sha256, blake3) = copy_v36_prefix_snapshot_exact(
        &mut source,
        &mut snapshot,
        (&assignment.path, &snapshot_path),
        encoded_bytes,
        limits.io_buffer_bytes,
    )?;
    v36_prefix_external_io(&snapshot_path, snapshot.sync_all())?;
    let content_addressed = url::Url::parse(&assignment.identity.uri)
        .ok()
        .filter(|uri| uri.scheme() == "s3" && uri.host_str().is_some())
        .and_then(|uri| uri.path().rsplit('/').next().map(str::to_owned))
        .is_some_and(|name| name.starts_with(&format!("{sha256}-")));
    if assignment.identity.role != "population-role-assignments"
        || assignment.identity.encoded_bytes != encoded_bytes
        || assignment.identity.sha256 != sha256
        || assignment.identity.blake3 != blake3
        || !content_addressed
    {
        return Err(invalid("V36 prefix role-assignment artifact differs"));
    }
    preflight_v36_prefix_arrow_file(
        &mut snapshot,
        &snapshot_path,
        encoded_bytes,
        SELECTED_IDS_BATCH_ROWS,
        validate_v36_prefix_role_assignment_batch_body,
    )?;
    let reader = ArrowFileReader::try_new(snapshot, None)?;
    let query_counts: [u64; 4] = assignment
        .contract
        .roles
        .iter()
        .map(|role| role.rows)
        .collect::<Vec<_>>()
        .try_into()
        .map_err(|_| invalid("V36 prefix role-assignment authority differs"))?;
    let counts = [
        assignment.contract.corpus_rows,
        query_counts[0],
        query_counts[1],
        query_counts[2],
        query_counts[3],
    ];
    let expected_rows = counts.iter().try_fold(0_usize, |sum, &count| {
        usize::try_from(count)
            .ok()
            .and_then(|count| sum.checked_add(count))
            .ok_or_else(|| invalid("V36 prefix role-assignment row count overflows"))
    })?;
    if reader.schema().as_ref() != &v36_prefix_role_assignment_schema(&assignment.contract)
        || reader.num_batches() != expected_rows.div_ceil(SELECTED_IDS_BATCH_ROWS)
    {
        return Err(invalid("V36 prefix role-assignment schema differs"));
    }
    let window_end = assignment
        .contract
        .selected_object_start
        .checked_add(assignment.contract.selected_object_count)
        .ok_or_else(|| invalid("V36 prefix selected object window overflows"))?;
    let mut seen_ordinals = Vec::with_capacity(counts.len());
    for count in counts {
        let words = usize::try_from(count.div_ceil(64))
            .map_err(|_| resource_limit("role-assignment ordinal bitmap"))?;
        seen_ordinals.push(vec![0_u64; words]);
    }
    Ok(V36PrefixRoleAssignmentStream {
        batch: None,
        batch_index: 0,
        counts,
        expected_rows,
        finished: false,
        previous_physical: None,
        reader,
        seen: 0,
        seen_ordinals,
        snapshot_path,
        window_end,
        window_start: assignment.contract.selected_object_start,
    })
}

fn write_v36_prefix_role_assignment_file(
    contract: &V36PrefixRoleAssignmentContract,
    physical_spill: &Path,
    limits: &V36PrefixExternalSelectionLimits,
    output: &Path,
) -> Result<(u64, String, String)> {
    let schema = Arc::new(v36_prefix_role_assignment_schema(contract));
    let options = IpcWriteOptions::try_new(8, false, MetadataVersion::V5)?;
    let mut reader = V36PrefixSpillReader::open(physical_spill, limits.io_buffer_bytes)?;
    let mut temporary = temporary_output(output)?;
    let mut writer = ArrowFileWriter::try_new_with_options(
        BufWriter::with_capacity(limits.io_buffer_bytes, temporary.as_file()),
        schema.as_ref(),
        options,
    )?;
    let mut rows = Vec::with_capacity(SELECTED_IDS_BATCH_ROWS);
    let mut previous_physical = None;
    while let Some(record) = reader.next_record()? {
        let physical = (record.selected_object_ordinal, record.row_offset);
        if previous_physical.is_some_and(|previous| previous >= physical)
            || record.score[..10]
                != v36_prefix_role_assignment_score(physical.0, physical.1, 0, 0)[..10]
        {
            return Err(invalid("V36 prefix role-assignment physical order differs"));
        }
        previous_physical = Some(physical);
        rows.push(record);
        if rows.len() == SELECTED_IDS_BATCH_ROWS {
            write_v36_prefix_role_assignment_batch(&mut writer, schema.clone(), &rows)?;
            rows.clear();
        }
    }
    if !rows.is_empty() {
        write_v36_prefix_role_assignment_batch(&mut writer, schema, &rows)?;
    }
    writer.finish()?;
    let mut buffered = writer.into_inner()?;
    v36_prefix_external_io(output, buffered.flush())?;
    drop(buffered);
    let identity =
        v36_prefix_file_handle_digests(temporary.as_file_mut(), output, limits.io_buffer_bytes)?;
    publish_output_noclobber(temporary, output)?;
    Ok(identity)
}

fn write_v36_prefix_role_assignment_batch(
    writer: &mut ArrowFileWriter<BufWriter<&File>>,
    schema: Arc<Schema>,
    rows: &[V36PrefixScoredIdentity],
) -> Result<()> {
    writer.write(&RecordBatch::try_new(
        schema,
        vec![
            Arc::new(UInt16Array::from(
                rows.iter()
                    .map(|row| row.selected_object_ordinal)
                    .collect::<Vec<_>>(),
            )),
            Arc::new(UInt64Array::from(
                rows.iter().map(|row| row.row_offset).collect::<Vec<_>>(),
            )),
            Arc::new(UInt64Array::from(
                rows.iter()
                    .map(|row| row.feature_row_id)
                    .collect::<Vec<_>>(),
            )),
            Arc::new(UInt8Array::from(
                rows.iter().map(|row| row.score[10]).collect::<Vec<_>>(),
            )),
            Arc::new(UInt64Array::from(
                rows.iter()
                    .map(|row| u64::from_be_bytes(row.score[11..19].try_into().unwrap()))
                    .collect::<Vec<_>>(),
            )),
        ],
    )?)?;
    Ok(())
}

/// Assign an authenticated selected population to roles without resident bulk state.
pub fn assign_v36_prefix_roles_from_selected_file(
    request: V36PrefixRoleAssignmentRequest<'_>,
) -> Result<V36PrefixRoleAssignmentReceipt> {
    let V36PrefixRoleAssignmentRequest {
        contract,
        limits,
        output,
        output_uri_prefix,
        scratch_root,
        selected,
    } = request;
    let (corpus_seed, manifest) = validate_v36_prefix_role_assignment_contract(contract, selected)?;
    if limits.max_spills > EXTERNAL_MAX_SPILLS
        || limits.merge_fan_in > EXTERNAL_MAX_FAN_IN
        || limits.sort_buffer_records > EXTERNAL_MAX_SORT_BUFFER_RECORDS
        || limits.io_buffer_bytes > EXTERNAL_MAX_IO_BUFFER_BYTES
        || limits.io_buffer_bytes == 0
        || limits.max_input_bytes == 0
        || limits.max_scratch_bytes == 0
        || limits.max_spills == 0
        || limits.merge_fan_in < 2
        || limits.sort_buffer_records == 0
    {
        return Err(resource_limit("external role-assignment configuration"));
    }
    if project_v36_prefix_role_assignment_owned_bytes(contract, limits)?
        > ROLE_ASSIGNMENT_MAX_OWNED_BYTES
    {
        return Err(resource_limit("role-assignment owned memory"));
    }
    let output_uri = url::Url::parse(output_uri_prefix)
        .map_err(|_| invalid("V36 prefix role-assignment output URI differs"))?;
    let output_parent = output
        .parent()
        .ok_or_else(|| invalid("V36 prefix role-assignment output path differs"))?;
    let scratch_type = fs::symlink_metadata(scratch_root)
        .map_err(|source| BorsukError::Io {
            path: scratch_root.to_owned(),
            source,
        })?
        .file_type();
    let output_parent_type = fs::symlink_metadata(output_parent)
        .map_err(|source| BorsukError::Io {
            path: output_parent.to_owned(),
            source,
        })?
        .file_type();
    if output_uri.scheme() != "s3"
        || output_uri.host_str().is_none()
        || output_uri.query().is_some()
        || output_uri.fragment().is_some()
        || output.exists()
        || !scratch_type.is_dir()
        || scratch_type.is_symlink()
        || !output_parent_type.is_dir()
        || output_parent_type.is_symlink()
    {
        return Err(invalid(
            "V36 prefix external role-assignment output differs",
        ));
    }
    let attempt = tempfile::tempdir_in(scratch_root).map_err(|source| BorsukError::Io {
        path: scratch_root.to_owned(),
        source,
    })?;
    let mut stream = open_v36_prefix_selected_stream(
        selected,
        limits,
        attempt.path(),
        "selected-population.arrow",
    )?;
    let mut cumulative = 0_usize;
    let mut heaps = Vec::with_capacity(contract.roles.len());
    for role in &contract.roles {
        cumulative = cumulative
            .checked_add(
                usize::try_from(role.rows)
                    .map_err(|_| invalid("V36 prefix role row count overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix role row count overflows"))?;
        heaps.push((
            digest_bytes(&role.seed_sha256)?,
            cumulative,
            BinaryHeap::new(),
        ));
    }
    let mut physical = V36PrefixPhysicalUniqueness::new(attempt.path(), limits, 0);
    while let Some(row) = stream.next_record()? {
        physical.push(row)?;
        for (seed, capacity, heap) in &mut heaps {
            let ranked = V36PrefixScoredIdentity {
                score: score(seed, &manifest, row.feature_row_id),
                feature_row_id: row.feature_row_id,
                selected_object_ordinal: row.selected_object_ordinal,
                row_offset: row.row_offset,
            };
            if heap.len() < *capacity {
                heap.push(ranked);
            } else if heap.peek().is_some_and(|worst| ranked < *worst) {
                heap.pop();
                heap.push(ranked);
            }
        }
    }
    physical.finish()?;
    drop(stream);
    let selected_snapshot = attempt.path().join("selected-population.arrow");
    fs::remove_file(&selected_snapshot).map_err(|source| BorsukError::Io {
        path: selected_snapshot,
        source,
    })?;

    let mut chosen = HashSet::with_capacity(cumulative);
    let mut query_assignments = Vec::with_capacity(cumulative);
    for (role_index, ((_, _, heap), role)) in heaps.into_iter().zip(&contract.roles).enumerate() {
        let mut ordinal = 0_u64;
        for row in heap.into_sorted_vec() {
            if chosen.insert(row.feature_row_id) {
                query_assignments.push(v36_prefix_role_assignment_record(
                    row,
                    u8::try_from(role_index + 1)
                        .map_err(|_| invalid("V36 prefix role ordinal overflows"))?,
                    ordinal,
                ));
                ordinal += 1;
                if ordinal == role.rows {
                    break;
                }
            }
        }
        if ordinal != role.rows {
            return Err(invalid("V36 prefix query population is insufficient"));
        }
    }

    let mut corpus_stream = open_v36_prefix_selected_stream(
        selected,
        limits,
        attempt.path(),
        "selected-population.arrow",
    )?;
    let mut next_spill = 0_usize;
    let mut corpus_buffer = Vec::with_capacity(limits.sort_buffer_records);
    let mut corpus_spills = Vec::new();
    let mut remaining_rows = 0_u64;
    while let Some(row) = corpus_stream.next_record()? {
        if chosen.contains(&row.feature_row_id) {
            continue;
        }
        remaining_rows += 1;
        push_v36_prefix_external_record(
            V36PrefixScoredIdentity {
                score: score(&corpus_seed, &manifest, row.feature_row_id),
                feature_row_id: row.feature_row_id,
                selected_object_ordinal: row.selected_object_ordinal,
                row_offset: row.row_offset,
            },
            &mut corpus_buffer,
            &mut corpus_spills,
            &mut next_spill,
            attempt.path(),
            limits,
        )?;
    }
    drop(corpus_stream);
    let selected_snapshot = attempt.path().join("selected-population.arrow");
    fs::remove_file(&selected_snapshot).map_err(|source| BorsukError::Io {
        path: selected_snapshot,
        source,
    })?;
    if remaining_rows != contract.selected_rows - u64::try_from(chosen.len()).unwrap_or(u64::MAX)
        || remaining_rows < contract.corpus_rows
    {
        return Err(invalid("V36 prefix corpus population is insufficient"));
    }
    let corpus = finish_v36_prefix_external_spills(
        &mut corpus_buffer,
        corpus_spills,
        &mut next_spill,
        attempt.path(),
        limits,
    )?;

    let mut physical_buffer = Vec::with_capacity(limits.sort_buffer_records);
    let mut physical_spills = Vec::new();
    for assignment in query_assignments {
        push_v36_prefix_external_record(
            assignment,
            &mut physical_buffer,
            &mut physical_spills,
            &mut next_spill,
            attempt.path(),
            limits,
        )?;
    }
    let mut corpus_reader = V36PrefixSpillReader::open(&corpus, limits.io_buffer_bytes)?;
    let mut corpus_ordinal = 0_u64;
    while let Some(row) = corpus_reader.next_record()? {
        if corpus_ordinal < contract.corpus_rows {
            push_v36_prefix_external_record(
                v36_prefix_role_assignment_record(row, 0, corpus_ordinal),
                &mut physical_buffer,
                &mut physical_spills,
                &mut next_spill,
                attempt.path(),
                limits,
            )?;
            corpus_ordinal += 1;
        }
    }
    if corpus_ordinal != contract.corpus_rows {
        return Err(invalid("V36 prefix corpus population is insufficient"));
    }
    drop(corpus_reader);
    fs::remove_file(&corpus).map_err(|source| BorsukError::Io {
        path: corpus,
        source,
    })?;
    let physical = finish_v36_prefix_external_spills(
        &mut physical_buffer,
        physical_spills,
        &mut next_spill,
        attempt.path(),
        limits,
    )?;
    let (encoded_bytes, sha256, blake3) =
        write_v36_prefix_role_assignment_file(contract, &physical, limits, output)?;
    let prefix = output_uri_prefix.trim_end_matches('/');
    Ok(V36PrefixRoleAssignmentReceipt {
        identity: V36ArtifactIdentity {
            blake3,
            encoded_bytes,
            role: "population-role-assignments".into(),
            sha256: sha256.clone(),
            uri: format!("{prefix}/{sha256}-population-role-assignments.arrow"),
        },
    })
}

/// Validate membership against independently authenticated complete-object evidence.
pub fn validate_v36_prefix_cutoff_membership(
    rows: &[V36PrefixRowIdentity],
    consumed_objects: usize,
    distinct_candidates: usize,
) -> Result<()> {
    validate_v36_prefix_cutoff_membership_from_start(rows, 0, consumed_objects, distinct_candidates)
}

fn validate_v36_prefix_cutoff_membership_from_start(
    rows: &[V36PrefixRowIdentity],
    selected_object_start: u16,
    consumed_objects: usize,
    distinct_candidates: usize,
) -> Result<()> {
    let selected_object_end = selected_object_start
        .checked_add(
            u16::try_from(consumed_objects)
                .map_err(|_| invalid("V36 prefix consumed-object count overflows"))?,
        )
        .ok_or_else(|| invalid("V36 prefix consumed-object window overflows"))?;
    if consumed_objects == 0
        || rows.len() < distinct_candidates
        || distinct_candidates == 0
        || rows.iter().any(|row| {
            row.selected_object_ordinal < selected_object_start
                || row.selected_object_ordinal >= selected_object_end
        })
    {
        return Err(invalid("V36 prefix consumed-object membership differs"));
    }
    Ok(())
}

fn score(seed: &[u8; 32], source_identity: &[u8; 32], feature_row_id: u64) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(seed);
    hasher.update(source_identity);
    hasher.update(feature_row_id.to_le_bytes());
    hasher.finalize().into()
}

/// Compute one frozen prefix-population query score for audit and mutation tests.
pub fn v36_prefix_query_score_sha256(
    seed_label: &str,
    source_identity_sha256: &str,
    feature_row_id: u64,
) -> Result<String> {
    let seed: [u8; 32] = Sha256::digest(seed_label.as_bytes()).into();
    let source_identity = digest_bytes(source_identity_sha256)?;
    Ok(score(&seed, &source_identity, feature_row_id)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect())
}

/// Compute one frozen prefix-population corpus score for audit and mutation tests.
pub fn v36_prefix_source_score_sha256(
    source_identity_sha256: &str,
    feature_row_id: u64,
) -> Result<String> {
    let seed: [u8; 32] = Sha256::digest(b"borsuk-v36-prefix-screen-corpus-v2").into();
    let source_identity = digest_bytes(source_identity_sha256)?;
    Ok(score(&seed, &source_identity, feature_row_id)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect())
}

/// Validate the exact population-specific query-role authority.
pub fn validate_v36_prefix_role_authority(roles: &[V36PrefixRoleAuthority]) -> Result<()> {
    let expected_names = ["development", "validation", "sealed-holdout", "performance"];
    let expected_labels = [
        "borsuk-v36-prefix-screen-development-query-v2",
        "borsuk-v36-prefix-screen-validation-query-v2",
        "borsuk-v36-prefix-screen-sealed-holdout-query-v2",
        "borsuk-v36-prefix-screen-performance-query-v2",
    ];
    let expected_rows = [1_000_u64, 1_000, 1_000, 10_000];
    if roles.len() != expected_names.len() {
        return Err(invalid("V36 prefix query role authority differs"));
    }
    let mut seeds = BTreeSet::new();
    for (((role, expected_name), expected_label), expected_rows) in roles
        .iter()
        .zip(expected_names)
        .zip(expected_labels)
        .zip(expected_rows)
    {
        if role.role != expected_name
            || role.seed_label != expected_label
            || role.rows != expected_rows
            || role.seed_sha256 != format!("{:x}", Sha256::digest(role.seed_label.as_bytes()))
            || !seeds.insert(role.seed_sha256.as_str())
        {
            return Err(invalid("V36 prefix query role authority differs"));
        }
    }
    Ok(())
}

/// Select disjoint query roles in priority order, then order the corpus.
pub fn select_v36_prefix_roles(
    rows: Vec<V36PrefixRowIdentity>,
    population: &V36PrefixPopulationAuthority,
    source_registry: &[V36PrefixRegisteredSourceObject],
) -> Result<V36PrefixRoleSplit> {
    validate_v36_prefix_population_authority(population, source_registry)?;
    validate_v36_prefix_role_authority(&population.roles)?;
    let source_identity = digest_bytes(&population.ordered_source_manifest_sha256)?;
    let window_start = population.selected_object_start;
    let window_end = window_start
        .checked_add(population.selected_object_count)
        .ok_or_else(|| invalid("V36 prefix selected object window overflows"))?;
    if rows.iter().any(|row| {
        row.selected_object_ordinal < window_start || row.selected_object_ordinal >= window_end
    }) {
        return Err(invalid("V36 prefix population row object differs"));
    }
    let mut remaining = select_v36_prefix_population_rows(
        rows,
        &population.ordered_source_manifest_sha256,
        DISTINCT_CANDIDATES,
    )?;
    let mut selected = Vec::with_capacity(4);
    for role in &population.roles {
        let seed = digest_bytes(&role.seed_sha256)?;
        let mut ranked = remaining
            .into_iter()
            .map(|row| (score(&seed, &source_identity, row.feature_row_id), row))
            .collect::<Vec<_>>();
        ranked.sort_by(|left, right| {
            (&left.0, left.1.feature_row_id).cmp(&(&right.0, right.1.feature_row_id))
        });
        let count =
            usize::try_from(role.rows).map_err(|_| invalid("V36 prefix query count overflows"))?;
        if ranked.len() < count {
            return Err(invalid("V36 prefix query population is insufficient"));
        }
        let rest = ranked.split_off(count);
        selected.push(ranked.into_iter().map(|(_, row)| row).collect::<Vec<_>>());
        remaining = rest.into_iter().map(|(_, row)| row).collect();
    }
    let corpus_seed = digest_bytes(&population.corpus_seed_sha256)?;
    let mut corpus = remaining
        .into_iter()
        .map(|row| {
            (
                score(&corpus_seed, &source_identity, row.feature_row_id),
                row,
            )
        })
        .collect::<Vec<_>>();
    corpus.sort_by(|left, right| {
        (&left.0, left.1.feature_row_id).cmp(&(&right.0, right.1.feature_row_id))
    });
    if corpus.len() < CORPUS_ROWS {
        return Err(invalid("V36 prefix corpus size differs"));
    }
    corpus.truncate(CORPUS_ROWS);
    let corpus = corpus
        .into_iter()
        .enumerate()
        .map(|(ordinal, (_, mut row))| {
            row.source_ordinal = Some(u64::try_from(ordinal).unwrap());
            row
        })
        .collect();
    let [development, validation, sealed_holdout, performance] = selected
        .try_into()
        .map_err(|_| invalid("V36 prefix query roles differ"))?;
    Ok(V36PrefixRoleSplit {
        development,
        validation,
        sealed_holdout,
        performance,
        corpus,
    })
}

fn vector_field() -> Field {
    Field::new(
        "embedding",
        DataType::FixedSizeList(
            Arc::new(Field::new("item", DataType::Float32, false)),
            DIMENSIONS as i32,
        ),
        false,
    )
}

fn registered_input_schema() -> Schema {
    Schema::new(vec![
        Field::new("url", DataType::Utf8, true),
        Field::new("natural_score", DataType::Float32, true),
        Field::new("feature_row_id", DataType::Int64, true),
        Field::new(
            "embedding",
            DataType::FixedSizeList(
                Arc::new(Field::new("item", DataType::Float32, true)),
                DIMENSIONS as i32,
            ),
            true,
        ),
    ])
}

fn sha256_file(path: &Path) -> Result<(u64, String)> {
    let mut file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    sha256_file_handle(&mut file, path)
}

fn sha256_file_handle(file: &mut File, path: &Path) -> Result<(u64, String)> {
    v36_prefix_external_io(path, file.seek(SeekFrom::Start(0)))?;
    let mut reader = BufReader::with_capacity(1024 * 1024, file);
    let mut buffer = vec![0_u8; 1024 * 1024];
    let mut bytes = 0_u64;
    let mut hasher = Sha256::new();
    loop {
        let read = reader.read(&mut buffer).map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
        if read == 0 {
            break;
        }
        bytes = bytes
            .checked_add(u64::try_from(read).unwrap())
            .ok_or_else(|| invalid("V36 prefix registered object length overflows"))?;
        hasher.update(&buffer[..read]);
    }
    let digest = format!("{:x}", hasher.finalize());
    v36_prefix_external_io(path, reader.seek(SeekFrom::Start(0)))?;
    Ok((bytes, digest))
}

fn authenticate_file(path: &Path, expected: &V36ArtifactIdentity) -> Result<()> {
    let mut file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    let (bytes, sha256, blake3) = digest_file_handle(&mut file, path)?;
    if bytes != expected.encoded_bytes || sha256 != expected.sha256 || blake3 != expected.blake3 {
        return Err(invalid("V36 prefix local input authority differs"));
    }
    Ok(())
}

fn digest_file_handle(file: &mut File, path: &Path) -> Result<(u64, String, String)> {
    v36_prefix_external_io(path, file.seek(SeekFrom::Start(0)))?;
    let mut reader = BufReader::with_capacity(1024 * 1024, file);
    let mut buffer = vec![0_u8; 1024 * 1024];
    let mut bytes = 0_u64;
    let mut sha256 = Sha256::new();
    let mut blake3 = blake3::Hasher::new();
    loop {
        let read = reader.read(&mut buffer).map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
        if read == 0 {
            break;
        }
        bytes = bytes
            .checked_add(u64::try_from(read).unwrap())
            .ok_or_else(|| invalid("V36 prefix local input length overflows"))?;
        sha256.update(&buffer[..read]);
        blake3.update(&buffer[..read]);
    }
    let sha256 = format!("{:x}", sha256.finalize());
    let blake3 = blake3.finalize().to_hex().to_string();
    v36_prefix_external_io(path, reader.seek(SeekFrom::Start(0)))?;
    Ok((bytes, sha256, blake3))
}

fn read_file(path: &Path) -> Result<Vec<u8>> {
    fs::read(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })
}

fn write_atomic_bytes(path: &Path, bytes: &[u8]) -> Result<()> {
    let mut temporary = temporary_output(path)?;
    temporary
        .write_all(bytes)
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
    publish_output(temporary, path)
}

fn acquire_v36_prefix_object(
    runtime: &tokio::runtime::Runtime,
    object: &V36PrefixRankedSourceObject,
    scratch: &Path,
    ordinal: u16,
) -> Result<PathBuf> {
    if !scratch.is_dir() || object.encoded_bytes == 0 {
        return Err(invalid("V36 prefix object acquisition request differs"));
    }
    digest_bytes(&object.sha256)?;
    let uri = url::Url::parse(&object.uri)
        .map_err(|_| invalid("V36 prefix registered object URI differs"))?;
    let (scheme, location) = ObjectStoreScheme::parse(&uri)
        .map_err(|_| invalid("V36 prefix registered object URI differs"))?;
    let store: Box<dyn ObjectStore> = match scheme {
        ObjectStoreScheme::Http => {
            let origin = uri.origin().ascii_serialization();
            Box::new(
                object_store::http::HttpBuilder::new()
                    .with_url(origin)
                    .with_retry(object_store::RetryConfig {
                        max_retries: 0,
                        ..Default::default()
                    })
                    .with_client_options(
                        object_store::ClientOptions::new()
                            .with_allow_http(uri.scheme() == "http")
                            .with_timeout_disabled()
                            .with_read_timeout(std::time::Duration::from_secs(120)),
                    )
                    .build()?,
            )
        }
        ObjectStoreScheme::Local => object_store::parse_url(&uri)?.0,
        _ => return Err(invalid("V36 prefix registered object scheme differs")),
    };
    let output = scratch.join(format!("source-{ordinal:04}.parquet"));
    if output.exists() {
        return Err(invalid("V36 prefix acquired object path already exists"));
    }
    let mut temporary =
        tempfile::NamedTempFile::new_in(scratch).map_err(|source| BorsukError::Io {
            path: scratch.to_owned(),
            source,
        })?;
    let (encoded_bytes, sha256) = runtime.block_on(async {
        let result = store.get(&location).await?;
        if result.meta.size != object.encoded_bytes {
            return Err(invalid("V36 prefix registered object length differs"));
        }
        let mut stream = result.into_stream();
        let mut encoded_bytes = 0_u64;
        let mut sha256 = Sha256::new();
        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;
            encoded_bytes = encoded_bytes
                .checked_add(u64::try_from(chunk.len()).unwrap())
                .ok_or_else(|| invalid("V36 prefix acquired object length overflows"))?;
            if encoded_bytes > object.encoded_bytes {
                return Err(invalid("V36 prefix registered object length differs"));
            }
            temporary
                .write_all(&chunk)
                .map_err(|source| BorsukError::Io {
                    path: output.clone(),
                    source,
                })?;
            sha256.update(&chunk);
        }
        Ok((encoded_bytes, format!("{:x}", sha256.finalize())))
    })?;
    if encoded_bytes != object.encoded_bytes || sha256 != object.sha256 {
        return Err(invalid("V36 prefix registered object authority differs"));
    }
    temporary
        .as_file()
        .sync_all()
        .map_err(|source| BorsukError::Io {
            path: output.clone(),
            source,
        })?;
    temporary
        .persist_noclobber(&output)
        .map_err(|error| BorsukError::Io {
            path: output.clone(),
            source: error.error,
        })?;
    Ok(output)
}

struct V36PrefixAcquiredObjects {
    paths: Vec<PathBuf>,
}

impl V36PrefixAcquiredObjects {
    fn cleanup(mut self) -> Result<()> {
        while let Some(path) = self.paths.pop() {
            if let Err(source) = fs::remove_file(&path) {
                self.paths.push(path.clone());
                return Err(BorsukError::Io { path, source });
            }
        }
        Ok(())
    }
}

impl Drop for V36PrefixAcquiredObjects {
    fn drop(&mut self) {
        for path in &self.paths {
            let _ = fs::remove_file(path);
        }
    }
}

fn output_identity(
    role: &str,
    filename: &str,
    output_prefix: &str,
    path: &Path,
) -> Result<V36ArtifactIdentity> {
    let (encoded_bytes, sha256) = sha256_file(path)?;
    Ok(V36ArtifactIdentity {
        blake3: blake3_file(path)?,
        encoded_bytes,
        role: role.to_owned(),
        sha256,
        uri: format!("{output_prefix}{filename}"),
    })
}

fn v36_prefix_production_external_limits(
    authority: &V36PrefixFreezeAuthority,
) -> Result<V36PrefixExternalSelectionLimits> {
    let raw_population_bytes = authority
        .distinct_candidates
        .checked_mul(DIMENSIONS as u64)
        .and_then(|bytes| bytes.checked_mul(4))
        .ok_or_else(|| resource_limit("production scratch bytes"))?;
    let materialization_bytes = raw_population_bytes
        .checked_mul(9)
        .map(|bytes| bytes / 4)
        .ok_or_else(|| resource_limit("production scratch bytes"))?;
    let max_scratch_bytes = authority
        .source_byte_cap
        .checked_add(materialization_bytes)
        .ok_or_else(|| resource_limit("production scratch bytes"))?;
    Ok(V36PrefixExternalSelectionLimits {
        io_buffer_bytes: EXTERNAL_MAX_IO_BUFFER_BYTES,
        max_input_bytes: authority.source_byte_cap,
        max_scratch_bytes,
        max_spills: EXTERNAL_MAX_SPILLS,
        merge_fan_in: EXTERNAL_MAX_FAN_IN,
        sort_buffer_records: EXTERNAL_MAX_SORT_BUFFER_RECORDS,
    })
}

fn v36_prefix_phase_selection(
    phase: &V36PrefixCheckpointPhase,
) -> Option<&V36PrefixPopulationSelection> {
    match phase {
        V36PrefixCheckpointPhase::Population => None,
        V36PrefixCheckpointPhase::Selected { selection }
        | V36PrefixCheckpointPhase::Materialized { selection, .. }
        | V36PrefixCheckpointPhase::GroundTruth { selection, .. }
        | V36PrefixCheckpointPhase::Complete { selection, .. } => Some(selection),
    }
}

fn acquire_v36_prefix_object_cached(
    runtime: &tokio::runtime::Runtime,
    object: &V36PrefixRankedSourceObject,
    scratch: &Path,
    ordinal: u16,
    acquired: &mut V36PrefixAcquiredObjects,
    acquired_by_ordinal: &mut BTreeMap<u16, PathBuf>,
) -> Result<PathBuf> {
    if let Some(path) = acquired_by_ordinal.get(&ordinal) {
        return Ok(path.clone());
    }
    let path = acquire_v36_prefix_object(runtime, object, scratch, ordinal)?;
    acquired.paths.push(path.clone());
    acquired_by_ordinal.insert(ordinal, path.clone());
    Ok(path)
}

fn v36_prefix_selected_cutoff(
    selected: &V36PrefixSelectedIdsFile,
    limits: &V36PrefixExternalSelectionLimits,
    scratch: &Path,
) -> Result<V36PrefixSelectedStreamRecord> {
    let attempt = tempfile::tempdir_in(scratch).map_err(|source| BorsukError::Io {
        path: scratch.to_owned(),
        source,
    })?;
    let mut stream = open_v36_prefix_selected_stream(
        selected,
        limits,
        attempt.path(),
        "selected-population.arrow",
    )?;
    let mut cutoff = None;
    while let Some(row) = stream.next_record()? {
        cutoff = Some(row);
    }
    cutoff.ok_or_else(|| invalid("V36 prefix selected-ID cutoff is missing"))
}

fn ensure_v36_prefix_final_artifact(
    destination: &Path,
    source: &V36PrefixCheckpointDependencyFile,
) -> Result<()> {
    install_content_addressed_file(destination, &source.path, &source.identity)
}

/// Execute one complete bounded V36 diagnostic population freeze locally.
pub fn run_v36_prefix_freeze(request: V36PrefixFreezeRequest) -> Result<()> {
    run_v36_prefix_freeze_file_backed(request)
}

fn run_v36_prefix_freeze_file_backed(request: V36PrefixFreezeRequest) -> Result<()> {
    let mut preflight = load_v36_prefix_freeze_preflight(&request)?;
    crate::validate_v36_prefix_registered_screen_authority(
        &preflight.authority,
        &preflight.registry,
    )?;
    let limits = v36_prefix_production_external_limits(&preflight.authority)?;
    let execution_authority_bytes =
        canonical_v36_prefix_freeze_execution_authority_bytes(&preflight.execution_authority)?;
    let execution_authority_sha256 = format!("{:x}", Sha256::digest(&execution_authority_bytes));
    let selected_contract = preflight
        .resume_head
        .as_ref()
        .and_then(|head| v36_prefix_phase_selection(&head.manifest.phase))
        .map(|selection| bind_v36_prefix_selected_ids_contract(&preflight.authority, selection))
        .transpose()?;
    let (mut checkpoint_writer, mut state) = match preflight.resume_head.take() {
        Some(head) => {
            let (writer, state) =
                V36PrefixPopulationCheckpointWriter::resume_phase(V36PrefixPhaseResumeRequest {
                    execution_authority_sha256: execution_authority_sha256.clone(),
                    head,
                    context: preflight.checkpoint_context.clone(),
                    limits: &limits,
                    producer_attempt_id: preflight.execution_authority.attempt_id.clone(),
                    producer_attempt_ordinal: preflight.producer_attempt_ordinal,
                    producer_instance_id: request.producer_instance_id.clone(),
                    root: &request.checkpoint_outbox,
                    scratch_root: &request.scratch,
                    selected_contract: selected_contract.as_ref(),
                })?;
            (writer, Some(state))
        }
        None => (
            V36PrefixPopulationCheckpointWriter::create(
                &request.checkpoint_outbox,
                preflight.checkpoint_context.clone(),
                execution_authority_sha256.clone(),
                preflight.execution_authority.attempt_id.clone(),
                preflight.producer_attempt_ordinal,
                request.producer_instance_id.clone(),
            )?,
            None,
        ),
    };
    let selected_object_start = preflight.authority.selected_object_start;
    let selected_object_count = usize::from(preflight.authority.selected_object_count);
    let selected_object_end = usize::from(selected_object_start)
        .checked_add(selected_object_count)
        .ok_or_else(|| invalid("V36 prefix selected object window overflows"))?;
    let ranked_window = preflight
        .ranked_objects
        .get(usize::from(selected_object_start)..selected_object_end)
        .ok_or_else(|| invalid("V36 prefix selected object window differs"))?;
    let runtime =
        tokio::runtime::Runtime::new().map_err(|_| invalid("V36 prefix object runtime differs"))?;
    let mut acquired = V36PrefixAcquiredObjects { paths: Vec::new() };
    let mut acquired_by_ordinal = BTreeMap::new();

    loop {
        match next_v36_prefix_checkpoint_action(
            checkpoint_writer.previous_manifest.as_ref(),
            preflight.checkpoint_context.corpus_rows,
            preflight.authority.distinct_candidates,
        )? {
            V36PrefixCheckpointAction::Populate => {
                let runs =
                    tempfile::tempdir_in(&request.scratch).map_err(|source| BorsukError::Io {
                        path: request.scratch.clone(),
                        source,
                    })?;
                let prior = match state.as_ref() {
                    Some(V36PrefixCheckpointResumeState::Population { population }) => {
                        Some(population)
                    }
                    None => None,
                    _ => return Err(invalid("V36 prefix population phase differs")),
                };
                let mut population = scan_v36_prefix_object_prefix_file_backed(
                    V36PrefixFileBackedScanRequest {
                        byte_cap: preflight.authority.source_byte_cap,
                        distinct_candidates: preflight.authority.distinct_candidates,
                        limits: &limits,
                        output_uri_prefix: &preflight.checkpoint_context.object_prefix,
                        prior,
                        ranked_objects: ranked_window,
                        run_output_root: runs.path(),
                        scratch_root: &request.scratch,
                        selected_object_start,
                    },
                    |ordinal, object| {
                        acquire_v36_prefix_object_cached(
                            &runtime,
                            object,
                            &request.scratch,
                            ordinal,
                            &mut acquired,
                            &mut acquired_by_ordinal,
                        )
                    },
                    |boundary| {
                        checkpoint_writer.commit_file(boundary)?;
                        Ok(())
                    },
                )?;
                population.runs = checkpoint_writer.identity_run_files()?;
                state = Some(V36PrefixCheckpointResumeState::Population { population });
            }
            V36PrefixCheckpointAction::Select => {
                let Some(V36PrefixCheckpointResumeState::Population { population }) = state.take()
                else {
                    return Err(invalid("V36 prefix selection phase differs"));
                };
                if preflight.authority.cohort_ordinal != 0 {
                    return Err(invalid(
                        "V36 prefix prior-cohort selected input is unavailable",
                    ));
                }
                let selection_authority = bind_v36_prefix_external_selection_authority(
                    &preflight.authority,
                    population.distinct_rows,
                )?;
                let selected_attempt =
                    tempfile::tempdir_in(&request.scratch).map_err(|source| BorsukError::Io {
                        path: request.scratch.clone(),
                        source,
                    })?;
                let selected_path = selected_attempt.path().join("population-selected.arrow");
                let mut selected =
                    select_v36_prefix_checkpoint_population(V36PrefixCheckpointSelectionRequest {
                        authority: &selection_authority,
                        exclusion: None,
                        limits: &limits,
                        output: &selected_path,
                        output_uri_prefix: &preflight.checkpoint_context.object_prefix,
                        population: &population,
                        scratch_root: &request.scratch,
                        writer: &mut checkpoint_writer,
                    })?
                    .selected;
                selected.path = request
                    .checkpoint_outbox
                    .join("objects")
                    .join(format!("{}.blob", selected.identity.sha256));
                authenticate_file(&selected.path, &selected.identity)?;
                state = Some(V36PrefixCheckpointResumeState::Selected {
                    population,
                    selected,
                });
            }
            V36PrefixCheckpointAction::Materialize => {
                let Some(V36PrefixCheckpointResumeState::Selected {
                    population,
                    selected,
                }) = state.take()
                else {
                    return Err(invalid("V36 prefix materialization phase differs"));
                };
                let mut source_paths = Vec::with_capacity(ranked_window.len());
                for (local_ordinal, object) in ranked_window.iter().enumerate() {
                    let ordinal = selected_object_start
                        .checked_add(
                            u16::try_from(local_ordinal).map_err(|_| {
                                invalid("V36 prefix acquired object ordinal overflows")
                            })?,
                        )
                        .ok_or_else(|| invalid("V36 prefix acquired object ordinal overflows"))?;
                    source_paths.push(acquire_v36_prefix_object_cached(
                        &runtime,
                        object,
                        &request.scratch,
                        ordinal,
                        &mut acquired,
                        &mut acquired_by_ordinal,
                    )?);
                }
                let population_authority = bind_v36_prefix_population_authority(
                    &preflight.authority,
                    population.consumed_objects.clone(),
                    &preflight.registry,
                )?;
                let selection = checkpoint_writer
                    .previous_manifest
                    .as_ref()
                    .and_then(|manifest| v36_prefix_phase_selection(&manifest.phase))
                    .ok_or_else(|| invalid("V36 prefix selected checkpoint differs"))?;
                let contract = bind_v36_prefix_role_assignment_contract(
                    &preflight.authority,
                    selection,
                    &selected,
                )?;
                let stage = materialize_v36_prefix_checkpoint_selection(
                    V36PrefixCheckpointMaterializationRequest {
                        contract: &contract,
                        limits: &limits,
                        output: &request.output,
                        output_uri_prefix: &preflight.checkpoint_context.object_prefix,
                        population: &population_authority,
                        ranked_objects: &preflight.ranked_objects,
                        scratch_root: &request.scratch,
                        selected: &selected,
                        source_paths: &source_paths,
                        source_registry: &preflight.registry,
                        writer: &mut checkpoint_writer,
                    },
                )?;
                let dependencies = [
                    (
                        stage.artifacts.population_authority.clone(),
                        request.output.join("population-authority.json"),
                    ),
                    (stage.artifacts.source.clone(), stage.paths.source),
                    (
                        stage.artifacts.development_query.clone(),
                        stage.paths.development,
                    ),
                    (
                        stage.artifacts.validation_query.clone(),
                        stage.paths.validation,
                    ),
                    (
                        stage.artifacts.sealed_holdout_query.clone(),
                        stage.paths.sealed_holdout,
                    ),
                    (
                        stage.artifacts.performance_query.clone(),
                        stage.paths.performance,
                    ),
                ]
                .map(|(identity, path)| V36PrefixCheckpointDependencyFile { identity, path });
                state = Some(V36PrefixCheckpointResumeState::Materialized {
                    artifacts: Box::new(V36PrefixMaterializedCheckpointFiles {
                        authenticated_dependencies: dependencies.to_vec(),
                        authenticated_ground_truth: None,
                        expected_source_rows: population_authority.corpus_rows,
                        population_authority: dependencies[0].clone(),
                        source: dependencies[1].clone(),
                        development_query: dependencies[2].clone(),
                        validation_query: dependencies[3].clone(),
                        sealed_holdout_query: dependencies[4].clone(),
                        performance_query: dependencies[5].clone(),
                    }),
                    population,
                    selected,
                });
            }
            V36PrefixCheckpointAction::GroundTruth => {
                preflight_v36_prefix_checkpoint_gt100(
                    state
                        .as_ref()
                        .ok_or_else(|| invalid("V36 ground-truth state is missing"))?,
                    usize::from(preflight.authority.workspace_count),
                    preflight.execution_authority.active_wall_seconds,
                )?;
                let ground_truth = run_v36_prefix_checkpoint_ground_truth(
                    V36PrefixCheckpointGroundTruthRequest {
                        block_rows: usize::try_from(preflight.checkpoint_context.gt_block_rows)
                            .map_err(|_| invalid("V36 prefix GT block rows overflow"))?,
                        output_root: &request.output,
                        output_uri_prefix: &preflight.checkpoint_context.object_prefix,
                        state: state
                            .as_ref()
                            .ok_or_else(|| invalid("V36 ground-truth state is missing"))?,
                        worker_threads: usize::from(preflight.authority.workspace_count),
                        writer: &mut checkpoint_writer,
                    },
                )?;
                let (mut artifacts, population, selected) = match state.take() {
                    Some(V36PrefixCheckpointResumeState::Materialized {
                        artifacts,
                        population,
                        selected,
                    })
                    | Some(V36PrefixCheckpointResumeState::GroundTruth {
                        artifacts,
                        population,
                        selected,
                        ..
                    }) => (artifacts, population, selected),
                    _ => return Err(invalid("V36 ground-truth phase differs")),
                };
                artifacts.authenticated_ground_truth = Some((
                    ground_truth.heaps.clone(),
                    preflight.checkpoint_context.corpus_rows,
                ));
                state = Some(V36PrefixCheckpointResumeState::GroundTruth {
                    artifacts,
                    heaps: ground_truth.heaps,
                    next_source_ordinal: preflight.checkpoint_context.corpus_rows,
                    population,
                    selected,
                });
            }
            V36PrefixCheckpointAction::Complete => {
                let completion = complete_v36_prefix_checkpoint_ground_truth(
                    V36PrefixCheckpointCompletionRequest {
                        output_root: &request.output,
                        output_uri_prefix: &preflight.checkpoint_context.object_prefix,
                        state: state
                            .as_ref()
                            .ok_or_else(|| invalid("V36 completion state is missing"))?,
                        writer: &mut checkpoint_writer,
                    },
                )?;
                let Some(V36PrefixCheckpointResumeState::GroundTruth {
                    artifacts,
                    heaps,
                    population,
                    selected,
                    ..
                }) = state.take()
                else {
                    return Err(invalid("V36 completion phase differs"));
                };
                let ground_truth = [
                    heaps,
                    V36PrefixCheckpointDependencyFile {
                        identity: completion.ground_truth.development.clone(),
                        path: request.output.join("development-gt100.parquet"),
                    },
                    V36PrefixCheckpointDependencyFile {
                        identity: completion.ground_truth.validation.clone(),
                        path: request.output.join("validation-gt100.parquet"),
                    },
                    V36PrefixCheckpointDependencyFile {
                        identity: completion.ground_truth.sealed_holdout.clone(),
                        path: request.output.join("sealed-holdout-gt100.parquet"),
                    },
                ];
                state = Some(V36PrefixCheckpointResumeState::Complete {
                    artifacts,
                    ground_truth: Box::new(ground_truth),
                    population,
                    selected,
                });
            }
            V36PrefixCheckpointAction::Finished => break,
        }
    }

    acquired.cleanup()?;
    let Some(V36PrefixCheckpointResumeState::Complete {
        artifacts,
        ground_truth,
        population: scanned_population,
        selected,
    }) = state
    else {
        return Err(invalid("V36 prefix terminal checkpoint differs"));
    };
    let final_artifacts = [
        (&artifacts.population_authority, "population-authority.json"),
        (&artifacts.source, "source.parquet"),
        (&artifacts.development_query, "development-query.parquet"),
        (&ground_truth[1], "development-gt100.parquet"),
        (&artifacts.validation_query, "validation-query.parquet"),
        (&ground_truth[2], "validation-gt100.parquet"),
        (
            &artifacts.sealed_holdout_query,
            "sealed-holdout-query.parquet",
        ),
        (&ground_truth[3], "sealed-holdout-gt100.parquet"),
        (&artifacts.performance_query, "performance-query.parquet"),
    ];
    for (artifact, filename) in final_artifacts {
        ensure_v36_prefix_final_artifact(&request.output.join(filename), artifact)?;
    }
    let population = bind_v36_prefix_population_authority(
        &preflight.authority,
        scanned_population.consumed_objects,
        &preflight.registry,
    )?;
    let cutoff = v36_prefix_selected_cutoff(&selected, &limits, &request.scratch)?;
    let terminal_selection = checkpoint_writer
        .previous_manifest
        .as_ref()
        .and_then(|manifest| v36_prefix_phase_selection(&manifest.phase))
        .ok_or_else(|| invalid("V36 prefix terminal selection differs"))?;
    if cutoff.feature_row_id != terminal_selection.cutoff_feature_row_id
        || digest_hex(&cutoff.score) != terminal_selection.cutoff_score_sha256
        || selected.identity != terminal_selection.selected_ids
    {
        return Err(invalid("V36 prefix terminal selection differs"));
    }
    let artifact_paths = [
        ("population-authority", "population-authority.json"),
        ("source", "source.parquet"),
        ("development-query", "development-query.parquet"),
        ("development-gt100", "development-gt100.parquet"),
        ("validation-query", "validation-query.parquet"),
        ("validation-gt100", "validation-gt100.parquet"),
        ("sealed-holdout-query", "sealed-holdout-query.parquet"),
        ("sealed-holdout-gt100", "sealed-holdout-gt100.parquet"),
        ("performance-query", "performance-query.parquet"),
    ];
    let outputs = artifact_paths
        .into_iter()
        .map(|(role, filename)| {
            output_identity(
                role,
                filename,
                &preflight.execution_authority.output_prefix,
                &request.output.join(filename),
            )
        })
        .collect::<Result<Vec<_>>>()?;
    let receipt = V36PrefixFreezeReceipt {
        claim_eligible: false,
        cutoff_object_ordinal: cutoff.selected_object_ordinal,
        cutoff_row_offset: cutoff.row_offset,
        distinct_rows_observed: scanned_population.distinct_rows,
        duplicate_rows: scanned_population.duplicate_rows,
        execution_authority_sha256,
        freeze_authority_sha256: preflight.checkpoint_context.freeze_authority_sha256.clone(),
        outputs,
        physical_rows: scanned_population.physical_rows,
        population,
        selection: terminal_selection.clone(),
        schema: "borsuk-v36-prefix-freeze-receipt-v2".to_owned(),
        source_archive_sha256: preflight.checkpoint_context.source_archive_sha256.clone(),
        source_registry_sha256: preflight.checkpoint_context.source_registry_sha256.clone(),
    };
    write_atomic_bytes(
        &request.output.join("freeze-receipt.json"),
        &canonical_v36_prefix_freeze_receipt_bytes(
            &receipt,
            &preflight.authority,
            &preflight.execution_authority,
            &preflight.registry,
        )?,
    )?;
    Ok(())
}

/// Authenticate every local attempt input before any source-object network access.
pub fn load_v36_prefix_freeze_preflight(
    request: &V36PrefixFreezeRequest,
) -> Result<V36PrefixFreezePreflight> {
    if request.output == request.scratch
        || request.output == request.checkpoint_outbox
        || request.scratch == request.checkpoint_outbox
        || request.resume_checkpoint.as_ref().is_some_and(|resume| {
            resume == &request.output
                || resume == &request.scratch
                || resume == &request.checkpoint_outbox
                || !resume.is_dir()
                || resume.is_symlink()
        })
        || !request.output.is_dir()
        || !request.scratch.is_dir()
        || !request.checkpoint_outbox.is_dir()
        || !request.producer_instance_id.starts_with("i-")
        || request.producer_instance_id.len() <= 2
        || !request
            .producer_instance_id
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
        || request
            .output
            .read_dir()
            .map_err(|source| BorsukError::Io {
                path: request.output.clone(),
                source,
            })?
            .next()
            .is_some()
        || request
            .checkpoint_outbox
            .read_dir()
            .map_err(|source| BorsukError::Io {
                path: request.checkpoint_outbox.clone(),
                source,
            })?
            .next()
            .is_some()
        || request
            .scratch
            .read_dir()
            .map_err(|source| BorsukError::Io {
                path: request.scratch.clone(),
                source,
            })?
            .next()
            .is_some()
    {
        return Err(invalid("V36 prefix attempt directories differ"));
    }
    let execution_bytes = read_file(&request.execution_authority)?;
    let execution_authority: V36PrefixFreezeExecutionAuthority =
        serde_json::from_slice(&execution_bytes)
            .map_err(|_| invalid("V36 prefix execution authority JSON differs"))?;
    validate_v36_prefix_freeze_execution_authority(&execution_authority)?;
    if canonical_v36_prefix_freeze_execution_authority_bytes(&execution_authority)?
        != execution_bytes
    {
        return Err(invalid("V36 prefix execution authority bytes differ"));
    }
    let input = |role: &str| {
        execution_authority
            .inputs
            .iter()
            .find(|input| input.role == role)
            .ok_or_else(|| invalid("V36 prefix execution input role differs"))
    };
    authenticate_file(&request.executable, input("binary")?)?;
    authenticate_file(&request.authority, input("freeze-authority")?)?;
    authenticate_file(&request.source_archive, input("source-archive")?)?;
    authenticate_file(&request.source_registry, input("source-registry")?)?;

    let authority_bytes = read_file(&request.authority)?;
    let authority: V36PrefixFreezeAuthority = serde_json::from_slice(&authority_bytes)
        .map_err(|_| invalid("V36 prefix freeze authority JSON differs"))?;
    let registry_bytes = read_file(&request.source_registry)?;
    let registry: Vec<V36PrefixRegisteredSourceObject> = serde_json::from_slice(&registry_bytes)
        .map_err(|_| invalid("V36 prefix source registry JSON differs"))?;
    validate_v36_prefix_freeze_authority(&authority, &registry)?;
    if canonical_v36_prefix_freeze_authority_bytes(&authority, &registry)? != authority_bytes
        || crate::canonical_v36_prefix_source_registry_bytes(&authority, &registry)?
            != registry_bytes
    {
        return Err(invalid("V36 prefix local authority bytes differ"));
    }
    let ranked_objects = rank_v36_prefix_source_objects(&authority, &registry)?;
    let (run_id, attempt_text) = execution_authority
        .attempt_id
        .rsplit_once("-attempt-")
        .ok_or_else(|| invalid("V36 prefix attempt identity differs"))?;
    let producer_attempt_ordinal = attempt_text
        .parse::<u8>()
        .map_err(|_| invalid("V36 prefix attempt ordinal differs"))?;
    if attempt_text.len() != 4
        || execution_authority.attempt_id
            != format!("{run_id}-attempt-{producer_attempt_ordinal:04}")
    {
        return Err(invalid("V36 prefix attempt identity differs"));
    }
    let attempt_suffix = format!("attempt-{producer_attempt_ordinal:04}/");
    let campaign_prefix = execution_authority
        .output_prefix
        .strip_suffix(&attempt_suffix)
        .ok_or_else(|| invalid("V36 prefix checkpoint campaign prefix differs"))?;
    let source_archive_sha256 = input("source-archive")?.sha256.clone();
    let checkpoint_context = V36PrefixCheckpointContext {
        cohort_ordinal: authority.cohort_ordinal,
        corpus_rows: authority.corpus_rows,
        distinct_candidates: authority.distinct_candidates,
        excluded_population_identity: authority.excluded_population_identity.clone(),
        freeze_authority_sha256: format!("{:x}", Sha256::digest(&authority_bytes)),
        gt_block_rows: PARQUET_ROW_GROUP_ROWS as u64,
        object_prefix: format!("{campaign_prefix}checkpoints/objects/"),
        pointer_uri: format!("{campaign_prefix}checkpoints/runs/{run_id}/latest.json"),
        ranked_objects: ranked_objects
            .iter()
            .skip(usize::from(authority.selected_object_start))
            .take(usize::from(authority.selected_object_count))
            .map(|object| V36PrefixRegisteredSourceObject {
                encoded_bytes: object.encoded_bytes,
                path: object.path.clone(),
                sha256: object.sha256.clone(),
                uri: object.uri.clone(),
            })
            .collect(),
        run_id: run_id.to_owned(),
        selected_object_count: authority.selected_object_count,
        selected_object_start: authority.selected_object_start,
        source_archive_sha256,
        source_byte_cap: authority.source_byte_cap,
        source_commit: execution_authority.source_commit.clone(),
        source_registry_sha256: format!("{:x}", Sha256::digest(&registry_bytes)),
    };
    let resume_head = match (&request.resume_checkpoint, &execution_authority.resume) {
        (None, None) => None,
        (Some(root), Some(binding)) => {
            let head = load_v36_prefix_checkpoint_head(root, &checkpoint_context)?;
            let pointer: V36PrefixCheckpointPointer =
                serde_json::from_slice(&head.pointer_bytes)
                    .map_err(|_| invalid("V36 prefix resume pointer JSON differs"))?;
            if binding.generation != pointer.generation
                || binding.manifest != pointer.manifest
                || binding.pointer_encoded_bytes != head.pointer_bytes.len() as u64
                || binding.pointer_sha256 != format!("{:x}", Sha256::digest(&head.pointer_bytes))
                || binding.pointer_uri != checkpoint_context.pointer_uri
                || head.manifest.producer_attempt_ordinal >= producer_attempt_ordinal
            {
                return Err(invalid("V36 prefix resume binding differs"));
            }
            Some(head)
        }
        _ => return Err(invalid("V36 prefix resume presence differs")),
    };
    Ok(V36PrefixFreezePreflight {
        authority,
        checkpoint_context,
        execution_authority,
        producer_attempt_ordinal,
        registry,
        ranked_objects,
        resume_head,
    })
}

/// Authenticate and stream one complete registered raw source object.
pub fn scan_v36_prefix_registered_input_parquet<F>(
    path: &Path,
    object: &V36PrefixRankedSourceObject,
    selected_object_ordinal: u16,
    mut consume: F,
) -> Result<u64>
where
    F: FnMut(V36PrefixInputRow) -> Result<()>,
{
    digest_bytes(&object.sha256)?;
    digest_bytes(&object.sample_sha256)?;
    if object.path.is_empty()
        || object.uri.is_empty()
        || object.sample_sha256
            != v36_prefix_object_sample_sha256(&object.path, object.encoded_bytes)
    {
        return Err(invalid("V36 prefix registered object identity differs"));
    }
    let file_type = fs::symlink_metadata(path)
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?
        .file_type();
    if !file_type.is_file() || file_type.is_symlink() {
        return Err(invalid("V36 prefix registered object path differs"));
    }
    let mut file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    let (encoded_bytes, sha256) = sha256_file_handle(&mut file, path)?;
    if encoded_bytes != object.encoded_bytes || sha256 != object.sha256 {
        return Err(invalid("V36 prefix registered object authority differs"));
    }
    let builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    let expected_schema = registered_input_schema();
    validate_parquet_descriptor(builder.parquet_schema(), &expected_schema)?;
    if builder.schema().fields() != expected_schema.fields() {
        return Err(invalid("V36 prefix registered object schema differs"));
    }
    let mut row_offset = 0_u64;
    for batch in builder.build()? {
        let batch = batch?;
        if batch.schema().fields() != expected_schema.fields()
            || batch.num_columns() != 4
            || batch.num_rows() == 0
        {
            return Err(invalid("V36 prefix registered object batch differs"));
        }
        let ids = batch
            .column(2)
            .as_any()
            .downcast_ref::<Int64Array>()
            .ok_or_else(|| invalid("V36 prefix registered object ID column differs"))?;
        let embeddings = batch
            .column(3)
            .as_any()
            .downcast_ref::<FixedSizeListArray>()
            .ok_or_else(|| invalid("V36 prefix registered object embedding column differs"))?;
        let values = embeddings
            .values()
            .as_any()
            .downcast_ref::<Float32Array>()
            .ok_or_else(|| invalid("V36 prefix registered object embedding child differs"))?;
        if ids.null_count() != 0
            || embeddings.null_count() != 0
            || values.null_count() != 0
            || values.len() != batch.num_rows() * DIMENSIONS
        {
            return Err(invalid("V36 prefix registered object gated null differs"));
        }
        for row in 0..batch.num_rows() {
            let start = row * DIMENSIONS;
            let input = V36PrefixInputRow {
                feature_row_id: ids.value(row),
                selected_object_ordinal,
                row_offset,
                embedding: values.values()[start..start + DIMENSIONS].to_vec(),
            };
            validate_v36_prefix_input_row(&input)?;
            consume(input)?;
            row_offset = row_offset
                .checked_add(1)
                .ok_or_else(|| invalid("V36 prefix registered object row count overflows"))?;
        }
    }
    if row_offset == 0 {
        return Err(invalid("V36 prefix registered object is empty"));
    }
    Ok(row_offset)
}

fn blake3_file(path: &Path) -> Result<String> {
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    let mut reader = BufReader::with_capacity(1024 * 1024, file);
    let mut buffer = vec![0_u8; 1024 * 1024];
    let mut hasher = blake3::Hasher::new();
    loop {
        let read = reader.read(&mut buffer).map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?;
        if read == 0 {
            break;
        }
        hasher.update(&buffer[..read]);
    }
    Ok(hasher.finalize().to_hex().to_string())
}

fn authenticate_v36_prefix_file_backed_population_scan(
    state: &V36PrefixFileBackedPopulationScan,
    limits: &V36PrefixExternalSelectionLimits,
    scratch_root: &Path,
) -> Result<V36PrefixFileBackedPopulationScan> {
    let attempt = tempfile::tempdir_in(scratch_root).map_err(|source| BorsukError::Io {
        path: scratch_root.to_owned(),
        source,
    })?;
    let mut run_paths = BTreeSet::new();
    let mut source_paths = BTreeSet::new();
    let mut source_uris = BTreeSet::new();
    let mut source_digests = BTreeSet::new();
    let mut stable_paths = Vec::with_capacity(state.runs.len());
    let mut stable_handles = Vec::with_capacity(state.runs.len());
    let mut physical_rows = 0_u64;
    let mut distinct_rows = 0_u64;
    for (index, run) in state.runs.iter().enumerate() {
        if !run_paths.insert(run.path.clone())
            || !source_paths.insert(run.source.path.clone())
            || !source_uris.insert(run.source.uri.clone())
            || !source_digests.insert(run.source.sha256.clone())
        {
            return Err(invalid("V36 file-backed restored population differs"));
        }
        let stable_path = attempt.path().join(format!("prior-{index:04}.arrow"));
        let (stable_handle, _) = snapshot_v36_prefix_authenticated_file(
            &run.path,
            &stable_path,
            run.identity.encoded_bytes,
            &run.identity.sha256,
            Some(&run.identity.blake3),
            limits,
        )?;
        let stable_run = V36PrefixIdentityRunFile {
            identity: run.identity.clone(),
            path: stable_path.clone(),
            selected_object_ordinal: run.selected_object_ordinal,
            source: run.source.clone(),
        };
        let (rows, physical) = stream_v36_prefix_identity_run_file(
            &stable_run,
            limits,
            attempt.path(),
            &[0_u8; 32],
            &[0_u8; 32],
            &mut |_| Ok(()),
        )?;
        distinct_rows = distinct_rows
            .checked_add(rows)
            .ok_or_else(|| invalid("V36 prefix distinct rows overflow"))?;
        physical_rows = physical_rows
            .checked_add(physical)
            .ok_or_else(|| invalid("V36 prefix physical rows overflow"))?;
        stable_paths.push(stable_path);
        stable_handles.push(stable_handle);
    }
    for left in 0..stable_handles.len() {
        for right in left + 1..stable_handles.len() {
            validate_v36_prefix_identity_run_handles_disjoint(
                &stable_handles[left],
                &stable_handles[right],
                (&stable_paths[left], &stable_paths[right]),
            )?;
        }
    }
    let duplicate_rows = physical_rows
        .checked_sub(distinct_rows)
        .ok_or_else(|| invalid("V36 prefix duplicate rows underflow"))?;
    Ok(V36PrefixFileBackedPopulationScan {
        consumed_objects: state.consumed_objects.clone(),
        distinct_rows,
        duplicate_rows,
        physical_rows,
        runs: state.runs.clone(),
    })
}

/// Reconstruct bounded file-backed population state from one authenticated checkpoint head.
pub fn restore_v36_prefix_file_backed_population_scan(
    head: &V36PrefixCheckpointHead,
    limits: &V36PrefixExternalSelectionLimits,
    scratch_root: &Path,
) -> Result<V36PrefixFileBackedPopulationScan> {
    head.validate_authenticated_seal()?;
    let population_dependencies = head.manifest.population.identity_runs.len();
    if usize::from(head.manifest.population.completed_objects) != population_dependencies
        || head.dependencies.len() < population_dependencies
        || population_dependencies != head.manifest.population.consumed_objects.len()
    {
        return Err(invalid("V36 file-backed checkpoint population differs"));
    }
    let pointer: V36PrefixCheckpointPointer = serde_json::from_slice(&head.pointer_bytes)
        .map_err(|_| invalid("V36 population checkpoint pointer JSON differs"))?;
    let manifest_bytes = canonical_v36_prefix_checkpoint_manifest_bytes(&head.manifest)?;
    if pointer.generation != head.manifest.generation
        || pointer.run_id != head.manifest.run_id
        || pointer.producer_attempt_id != head.manifest.producer_attempt_id
        || pointer.producer_attempt_ordinal != head.manifest.producer_attempt_ordinal
        || pointer.manifest.encoded_bytes != manifest_bytes.len() as u64
        || pointer.manifest.sha256 != format!("{:x}", Sha256::digest(&manifest_bytes))
        || pointer.manifest.blake3 != blake3::hash(&manifest_bytes).to_hex().as_str()
    {
        return Err(invalid("V36 file-backed checkpoint authority differs"));
    }
    let runs = head
        .dependencies
        .iter()
        .take(population_dependencies)
        .zip(&head.manifest.population.identity_runs)
        .zip(&head.manifest.population.consumed_objects)
        .enumerate()
        .map(|(index, ((dependency, registered), source))| {
            let selected_object_ordinal = head
                .manifest
                .population
                .selected_object_start
                .checked_add(
                    u16::try_from(index)
                        .map_err(|_| invalid("V36 population checkpoint ordinal overflows"))?,
                )
                .ok_or_else(|| invalid("V36 population checkpoint ordinal overflows"))?;
            if &dependency.identity != registered {
                return Err(invalid("V36 file-backed checkpoint dependencies differ"));
            }
            Ok(V36PrefixIdentityRunFile {
                identity: dependency.identity.clone(),
                path: dependency.path.clone(),
                selected_object_ordinal,
                source: source.clone(),
            })
        })
        .collect::<Result<Vec<_>>>()?;
    let claimed = V36PrefixFileBackedPopulationScan {
        consumed_objects: head.manifest.population.consumed_objects.clone(),
        distinct_rows: head.manifest.population.distinct_rows,
        duplicate_rows: head.manifest.population.duplicate_rows,
        physical_rows: head.manifest.population.physical_rows,
        runs,
    };
    let authenticated =
        authenticate_v36_prefix_file_backed_population_scan(&claimed, limits, scratch_root)?;
    if authenticated.consumed_objects != claimed.consumed_objects
        || authenticated.distinct_rows != claimed.distinct_rows
        || authenticated.duplicate_rows != claimed.duplicate_rows
        || authenticated.physical_rows != claimed.physical_rows
        || authenticated.runs != claimed.runs
    {
        return Err(invalid("V36 file-backed checkpoint population differs"));
    }
    Ok(authenticated)
}

fn validate_v36_prefix_checkpoint_selected_file(
    selected: &V36PrefixSelectedIdsFile,
    selection: &V36PrefixPopulationSelection,
) -> Result<()> {
    let metadata = fs::symlink_metadata(&selected.path).map_err(|source| BorsukError::Io {
        path: selected.path.clone(),
        source,
    })?;
    if !metadata.file_type().is_file()
        || metadata.len() != selected.identity.encoded_bytes
        || selected.identity != selection.selected_ids
    {
        return Err(invalid("V36 checkpoint resume selected file differs"));
    }
    let mut file = File::open(&selected.path).map_err(|source| BorsukError::Io {
        path: selected.path.clone(),
        source,
    })?;
    let declared_rows = preflight_v36_prefix_arrow_file(
        &mut file,
        &selected.path,
        metadata.len(),
        SELECTED_IDS_BATCH_ROWS,
        validate_v36_prefix_selected_batch_body,
    )?;
    let reader = ArrowFileReader::try_new(file, None)?;
    let expected_rows = usize::try_from(selected.contract.selected_rows)
        .map_err(|_| invalid("V36 prefix selected-ID row count overflows"))?;
    let expected_batches = expected_rows.div_ceil(SELECTED_IDS_BATCH_ROWS);
    if declared_rows != selected.contract.selected_rows
        || reader.num_batches() != expected_batches
        || reader.schema().as_ref()
            != &selected_ids_schema(
                &selected.contract,
                selection.cutoff_feature_row_id,
                &selection.cutoff_score_sha256,
            )
    {
        return Err(invalid("V36 checkpoint resume selected schema differs"));
    }
    Ok(())
}

fn validate_v36_prefix_checkpoint_dependency_file(
    dependency: &V36PrefixCheckpointDependencyFile,
) -> Result<()> {
    let metadata = fs::symlink_metadata(&dependency.path).map_err(|source| BorsukError::Io {
        path: dependency.path.clone(),
        source,
    })?;
    if !metadata.file_type().is_file() || metadata.len() != dependency.identity.encoded_bytes {
        return Err(invalid("V36 checkpoint resume dependency file differs"));
    }
    Ok(())
}

fn validate_v36_prefix_checkpoint_query_metadata_rows(
    declared_rows: i64,
    row_group_rows: &[i64],
    maximum_rows: u32,
) -> Result<()> {
    let mut total = 0_i64;
    for rows in row_group_rows {
        if *rows <= 0 {
            return Err(invalid("V36 prefix query Parquet row count differs"));
        }
        total = total
            .checked_add(*rows)
            .ok_or_else(|| invalid("V36 prefix query Parquet row count overflows"))?;
    }
    if maximum_rows == 0
        || row_group_rows.is_empty()
        || declared_rows != total
        || total > i64::from(maximum_rows)
    {
        return Err(invalid("V36 prefix query Parquet row count differs"));
    }
    Ok(())
}

fn validate_v36_prefix_checkpoint_query_file(path: &Path, maximum_rows: u32) -> Result<u32> {
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    let builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    validate_parquet_descriptor(builder.parquet_schema(), &v36_prefix_query_schema())?;
    validate_v36_prefix_checkpoint_query_metadata_rows(
        builder.metadata().file_metadata().num_rows(),
        &builder
            .metadata()
            .row_groups()
            .iter()
            .map(|group| group.num_rows())
            .collect::<Vec<_>>(),
        maximum_rows,
    )?;
    if builder.schema().as_ref() != &v36_prefix_query_schema() {
        return Err(invalid("V36 prefix query Parquet physical schema differs"));
    }
    let mut feature_ids = BTreeSet::new();
    let mut next_ordinal = 0_u64;
    for batch in builder.build()? {
        validate_query_batch(&batch?, &mut next_ordinal, &mut feature_ids)?;
        if next_ordinal > u64::from(maximum_rows) {
            return Err(invalid("V36 prefix query Parquet row count differs"));
        }
    }
    u32::try_from(next_ordinal)
        .ok()
        .filter(|count| *count != 0)
        .ok_or_else(|| invalid("V36 prefix query Parquet row count differs"))
}

/// Reconstruct the exact phase-specific file-backed continuation from one authenticated head.
pub fn restore_v36_prefix_checkpoint_phase(
    head: &V36PrefixCheckpointHead,
    selected_contract: Option<&V36PrefixSelectedIdsContract>,
    limits: &V36PrefixExternalSelectionLimits,
    scratch_root: &Path,
) -> Result<V36PrefixCheckpointResumeState> {
    let expected = plan_v36_prefix_checkpoint_dependency_closure(&head.manifest)?;
    if head.dependencies.len() != expected.len()
        || head
            .dependencies
            .iter()
            .zip(&expected)
            .any(|(dependency, identity)| &dependency.identity != identity)
    {
        return Err(invalid("V36 checkpoint resume dependency closure differs"));
    }
    let population = restore_v36_prefix_file_backed_population_scan(head, limits, scratch_root)?;
    if matches!(&head.manifest.phase, V36PrefixCheckpointPhase::Population) {
        if selected_contract.is_some() {
            return Err(invalid("V36 checkpoint resume selected authority differs"));
        }
        return Ok(V36PrefixCheckpointResumeState::Population { population });
    }

    let selection = match &head.manifest.phase {
        V36PrefixCheckpointPhase::Selected { selection }
        | V36PrefixCheckpointPhase::Materialized { selection, .. }
        | V36PrefixCheckpointPhase::GroundTruth { selection, .. }
        | V36PrefixCheckpointPhase::Complete { selection, .. } => selection,
        V36PrefixCheckpointPhase::Population => unreachable!(),
    };
    let contract = selected_contract
        .ok_or_else(|| invalid("V36 checkpoint resume selected authority is missing"))?;
    validate_selected_ids_contract(contract)?;
    if contract.eligible_rows != selection.eligible_rows
        || contract.excluded_population_identity != selection.excluded_population_identity
        || contract.excluded_rows != selection.excluded_rows
        || contract.selected_object_count != head.manifest.population.selected_object_count
        || contract.selected_object_start != head.manifest.population.selected_object_start
        || contract.selected_rows != selection.selected_rows
    {
        return Err(invalid("V36 checkpoint resume selected authority differs"));
    }
    let selected_index = head.manifest.population.identity_runs.len();
    let selected_dependency = head
        .dependencies
        .get(selected_index)
        .ok_or_else(|| invalid("V36 checkpoint resume selected file is missing"))?;
    if selected_dependency.identity != selection.selected_ids {
        return Err(invalid("V36 checkpoint resume selected file differs"));
    }
    let selected = V36PrefixSelectedIdsFile {
        contract: contract.clone(),
        identity: selected_dependency.identity.clone(),
        path: selected_dependency.path.clone(),
    };
    validate_v36_prefix_checkpoint_selected_file(&selected, selection)?;
    if matches!(
        &head.manifest.phase,
        V36PrefixCheckpointPhase::Selected { .. }
    ) {
        return Ok(V36PrefixCheckpointResumeState::Selected {
            population,
            selected,
        });
    }

    let dependency = |offset: usize| -> Result<V36PrefixCheckpointDependencyFile> {
        let dependency = head
            .dependencies
            .get(selected_index + 1 + offset)
            .cloned()
            .ok_or_else(|| invalid("V36 checkpoint resume materialized file is missing"))?;
        validate_v36_prefix_checkpoint_dependency_file(&dependency)?;
        Ok(dependency)
    };
    let materialized_dependencies = (0..6).map(dependency).collect::<Result<Vec<_>>>()?;
    let mut artifacts = V36PrefixMaterializedCheckpointFiles {
        authenticated_dependencies: materialized_dependencies.clone(),
        authenticated_ground_truth: None,
        expected_source_rows: head.authenticated_corpus_rows,
        population_authority: materialized_dependencies[0].clone(),
        source: materialized_dependencies[1].clone(),
        development_query: materialized_dependencies[2].clone(),
        validation_query: materialized_dependencies[3].clone(),
        sealed_holdout_query: materialized_dependencies[4].clone(),
        performance_query: materialized_dependencies[5].clone(),
    };
    match &head.manifest.phase {
        V36PrefixCheckpointPhase::Materialized { .. } => {
            Ok(V36PrefixCheckpointResumeState::Materialized {
                artifacts: Box::new(artifacts),
                population,
                selected,
            })
        }
        V36PrefixCheckpointPhase::GroundTruth {
            next_source_ordinal,
            ..
        } => {
            let mut remaining_queries = u32::try_from(GT_HEAP_CHECKPOINT_MAX_QUERIES).unwrap();
            let mut query_counts = [0_u32; 3];
            for (count, artifact) in query_counts.iter_mut().zip([
                &artifacts.development_query,
                &artifacts.validation_query,
                &artifacts.sealed_holdout_query,
            ]) {
                *count =
                    validate_v36_prefix_checkpoint_query_file(&artifact.path, remaining_queries)?;
                remaining_queries = remaining_queries
                    .checked_sub(*count)
                    .ok_or_else(|| invalid("V36 prefix GT heap query count differs"))?;
            }
            let heaps = dependency(6)?;
            artifacts.authenticated_ground_truth = Some((heaps.clone(), *next_source_ordinal));
            let heap_bytes = read_file(&heaps.path)?;
            decode_v36_prefix_gt_heap_checkpoint(
                &heap_bytes,
                &heaps.identity,
                *next_source_ordinal,
                query_counts,
            )?;
            Ok(V36PrefixCheckpointResumeState::GroundTruth {
                artifacts: Box::new(artifacts),
                heaps,
                next_source_ordinal: *next_source_ordinal,
                population,
                selected,
            })
        }
        V36PrefixCheckpointPhase::Complete { .. } => {
            let mut remaining_queries = u32::try_from(GT_HEAP_CHECKPOINT_MAX_QUERIES).unwrap();
            let mut query_counts = [0_u32; 3];
            for (count, artifact) in query_counts.iter_mut().zip([
                &artifacts.development_query,
                &artifacts.validation_query,
                &artifacts.sealed_holdout_query,
            ]) {
                *count =
                    validate_v36_prefix_checkpoint_query_file(&artifact.path, remaining_queries)?;
                remaining_queries = remaining_queries
                    .checked_sub(*count)
                    .ok_or_else(|| invalid("V36 prefix complete query count differs"))?;
            }
            let ground_truth = [
                dependency(6)?,
                dependency(7)?,
                dependency(8)?,
                dependency(9)?,
            ];
            artifacts.authenticated_ground_truth =
                Some((ground_truth[0].clone(), head.authenticated_corpus_rows));
            let checkpoint = decode_v36_prefix_gt_heap_checkpoint(
                &read_file(&ground_truth[0].path)?,
                &ground_truth[0].identity,
                head.authenticated_corpus_rows,
                query_counts,
            )?;
            let mut expected_truth = [Vec::new(), Vec::new(), Vec::new()];
            for entry in checkpoint
                .entries
                .into_iter()
                .filter(|entry| usize::from(entry.rank) < GT_NEIGHBORS)
            {
                expected_truth[usize::from(v36_prefix_gt_role_ordinal(entry.role))].push(
                    V36PrefixGtNeighbor {
                        query_ordinal: entry.query_ordinal,
                        rank: entry.rank,
                        feature_row_id: entry.feature_row_id,
                        squared_distance: entry.squared_distance,
                    },
                );
            }
            for ((artifact, expected_queries), expected) in ground_truth[1..]
                .iter()
                .zip(query_counts)
                .zip(&expected_truth)
            {
                validate_v36_prefix_gt100_matches_heap(&artifact.path, expected, expected_queries)?;
            }
            Ok(V36PrefixCheckpointResumeState::Complete {
                artifacts: Box::new(artifacts),
                ground_truth: Box::new(ground_truth),
                population,
                selected,
            })
        }
        V36PrefixCheckpointPhase::Population | V36PrefixCheckpointPhase::Selected { .. } => {
            unreachable!()
        }
    }
}

/// Scan and checkpoint a complete ranked source prefix without resident identity state.
pub fn scan_v36_prefix_object_prefix_file_backed<F, C>(
    request: V36PrefixFileBackedScanRequest<'_>,
    mut acquire: F,
    mut commit: C,
) -> Result<V36PrefixFileBackedPopulationScan>
where
    F: FnMut(u16, &V36PrefixRankedSourceObject) -> Result<PathBuf>,
    C: FnMut(&V36PrefixPopulationFileCommit) -> Result<()>,
{
    let output_type = fs::symlink_metadata(request.run_output_root)
        .map_err(|source| BorsukError::Io {
            path: request.run_output_root.to_owned(),
            source,
        })?
        .file_type();
    if request.ranked_objects.is_empty()
        || request.ranked_objects.len() > 16
        || request.byte_cap == 0
        || request.distinct_candidates == 0
        || request
            .selected_object_start
            .checked_add(
                u16::try_from(request.ranked_objects.len())
                    .map_err(|_| invalid("V36 prefix source window count overflows"))?,
            )
            .is_none()
        || !output_type.is_dir()
        || output_type.is_symlink()
        || request.run_output_root == request.scratch_root
        || request
            .run_output_root
            .read_dir()
            .map_err(|source| BorsukError::Io {
                path: request.run_output_root.to_owned(),
                source,
            })?
            .next()
            .is_some()
    {
        return Err(invalid("V36 file-backed population scan limits differ"));
    }
    let mut state = request
        .prior
        .cloned()
        .unwrap_or(V36PrefixFileBackedPopulationScan {
            consumed_objects: Vec::new(),
            distinct_rows: 0,
            duplicate_rows: 0,
            physical_rows: 0,
            runs: Vec::new(),
        });
    if state.runs.len() != state.consumed_objects.len()
        || state.runs.len() > request.ranked_objects.len()
        || state
            .physical_rows
            .checked_sub(state.distinct_rows)
            .is_none_or(|duplicates| duplicates != state.duplicate_rows)
    {
        return Err(invalid("V36 file-backed restored population differs"));
    }
    for (local_ordinal, ((source, run), ranked)) in state
        .consumed_objects
        .iter()
        .zip(&state.runs)
        .zip(request.ranked_objects)
        .enumerate()
    {
        let ordinal = request
            .selected_object_start
            .checked_add(
                u16::try_from(local_ordinal)
                    .map_err(|_| invalid("V36 prefix source object ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix source object ordinal overflows"))?;
        if run.selected_object_ordinal != ordinal
            || &run.source != source
            || source.encoded_bytes != ranked.encoded_bytes
            || source.path != ranked.path
            || source.sample_sha256 != ranked.sample_sha256
            || source.sha256 != ranked.sha256
            || source.uri != ranked.uri
        {
            return Err(invalid("V36 file-backed restored population differs"));
        }
    }
    let mut encoded_bytes = state
        .consumed_objects
        .iter()
        .try_fold(0_u64, |total, source| {
            total
                .checked_add(source.encoded_bytes)
                .ok_or_else(|| invalid("V36 prefix source scan bytes overflow"))
        })?;
    if encoded_bytes > request.byte_cap {
        return Err(invalid(
            "V36 prefix complete source window exceeds byte cap",
        ));
    }
    if request.prior.is_some() {
        let authenticated = authenticate_v36_prefix_file_backed_population_scan(
            &state,
            request.limits,
            request.scratch_root,
        )?;
        if authenticated != state {
            return Err(invalid("V36 file-backed restored population differs"));
        }
        state = authenticated;
    }
    if state.runs.len() == request.ranked_objects.len() {
        if state.distinct_rows < request.distinct_candidates {
            return Err(BorsukError::V36PrefixSourceInsufficient);
        }
        return Ok(state);
    }

    for (local_ordinal, object) in request
        .ranked_objects
        .iter()
        .enumerate()
        .skip(state.runs.len())
    {
        encoded_bytes = encoded_bytes
            .checked_add(object.encoded_bytes)
            .ok_or_else(|| invalid("V36 prefix source scan bytes overflow"))?;
        if encoded_bytes > request.byte_cap {
            return Err(invalid(
                "V36 prefix complete source window exceeds byte cap",
            ));
        }
        let ordinal = request
            .selected_object_start
            .checked_add(
                u16::try_from(local_ordinal)
                    .map_err(|_| invalid("V36 prefix source object ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix source object ordinal overflows"))?;
        let input = acquire(ordinal, object)?;
        let output = request
            .run_output_root
            .join(format!("identity-run-{ordinal:04}.arrow"));
        let receipt =
            externally_build_v36_prefix_identity_run(V36PrefixExternalIdentityRunRequest {
                cutoff_local_rank: None,
                input: &input,
                limits: request.limits,
                output: &output,
                output_uri_prefix: request.output_uri_prefix,
                prior_runs: &state.runs,
                scratch_root: request.scratch_root,
                selected_object_ordinal: ordinal,
                source: object,
            })?;
        state.distinct_rows = state
            .distinct_rows
            .checked_add(receipt.distinct_rows)
            .ok_or_else(|| invalid("V36 prefix distinct rows overflow"))?;
        state.physical_rows = state
            .physical_rows
            .checked_add(receipt.physical_rows)
            .ok_or_else(|| invalid("V36 prefix physical rows overflow"))?;
        state.duplicate_rows = state
            .physical_rows
            .checked_sub(state.distinct_rows)
            .ok_or_else(|| invalid("V36 prefix duplicate rows underflow"))?;
        if receipt.cutoff_row_offset.is_some() {
            return Err(invalid("V36 prefix file-backed cutoff differs"));
        }
        let boundary = V36PrefixPopulationFileCommit {
            distinct_rows: state.distinct_rows,
            duplicate_rows: state.duplicate_rows,
            physical_rows: state.physical_rows,
            run: receipt.run.clone(),
        };
        commit(&boundary)?;
        state.consumed_objects.push(receipt.run.source.clone());
        state.runs.push(receipt.run);
    }
    if state.distinct_rows < request.distinct_candidates {
        return Err(BorsukError::V36PrefixSourceInsufficient);
    }
    Ok(state)
}

fn scan_v36_prefix_object_prefix_from_state<F, C>(
    ranked_objects: &[V36PrefixRankedSourceObject],
    selected_object_start: u16,
    byte_cap: u64,
    distinct_candidates: usize,
    restored: Option<V36PrefixRestoredPopulation>,
    mut acquire: F,
    mut commit: C,
) -> Result<V36PrefixObjectPrefixScan>
where
    F: FnMut(u16, &V36PrefixRankedSourceObject) -> Result<PathBuf>,
    C: FnMut(&V36PrefixPopulationCommit) -> Result<()>,
{
    if ranked_objects.is_empty()
        || ranked_objects.len() > 16
        || byte_cap == 0
        || distinct_candidates == 0
        || selected_object_start
            .checked_add(
                u16::try_from(ranked_objects.len())
                    .map_err(|_| invalid("V36 prefix source window count overflows"))?,
            )
            .is_none()
    {
        return Err(invalid("V36 prefix source scan limits differ"));
    }
    let restored = restored.unwrap_or(V36PrefixRestoredPopulation {
        consumed_objects: Vec::new(),
        cutoff: None,
        distinct_rows_observed: 0,
        duplicate_rows: 0,
        next_object_ordinal: selected_object_start,
        physical_rows: 0,
        unique_rows: Vec::new(),
    });
    let start = restored
        .next_object_ordinal
        .checked_sub(selected_object_start)
        .map(usize::from)
        .ok_or_else(|| invalid("V36 prefix restored source authority differs"))?;
    if start > ranked_objects.len()
        || restored.consumed_objects.len() != start
        || restored
            .consumed_objects
            .iter()
            .zip(ranked_objects)
            .any(|(source, ranked)| {
                source.encoded_bytes != ranked.encoded_bytes
                    || source.path != ranked.path
                    || source.sample_sha256 != ranked.sample_sha256
                    || source.sha256 != ranked.sha256
                    || source.uri != ranked.uri
            })
    {
        return Err(invalid("V36 prefix restored source authority differs"));
    }
    let mut consumed_objects = restored.consumed_objects;
    let mut seen = restored
        .unique_rows
        .iter()
        .map(|row| row.feature_row_id)
        .collect::<HashSet<_>>();
    if seen.len() != restored.unique_rows.len()
        || u64::try_from(seen.len()).unwrap_or(u64::MAX) != restored.distinct_rows_observed
    {
        return Err(invalid("V36 prefix restored identity authority differs"));
    }
    let mut unique_rows = restored.unique_rows;
    let mut physical_rows = restored.physical_rows;
    let mut encoded_bytes = consumed_objects.iter().try_fold(0_u64, |total, object| {
        total
            .checked_add(object.encoded_bytes)
            .ok_or_else(|| invalid("V36 prefix source scan bytes overflow"))
    })?;
    if encoded_bytes > byte_cap {
        return Err(invalid(
            "V36 prefix complete source window exceeds byte cap",
        ));
    }
    let mut cutoff = restored.cutoff;
    for (ordinal, object) in ranked_objects.iter().enumerate().skip(start) {
        encoded_bytes = encoded_bytes
            .checked_add(object.encoded_bytes)
            .ok_or_else(|| invalid("V36 prefix source scan bytes overflow"))?;
        if encoded_bytes > byte_cap {
            return Err(invalid(
                "V36 prefix complete source window exceeds byte cap",
            ));
        }
        let selected_object_ordinal = selected_object_start
            .checked_add(
                u16::try_from(ordinal)
                    .map_err(|_| invalid("V36 prefix source object ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix source object ordinal overflows"))?;
        let path = acquire(selected_object_ordinal, object)?;
        let mut object_seen = HashSet::new();
        let mut object_identities = Vec::new();
        let object_rows = scan_v36_prefix_registered_input_parquet(
            &path,
            object,
            selected_object_ordinal,
            |row| {
                let identity = validate_v36_prefix_input_row(&row)?;
                if !seen.contains(&identity.feature_row_id)
                    && object_seen.insert(identity.feature_row_id)
                {
                    object_identities.push(identity);
                }
                Ok(())
            },
        )?;
        if object_rows == 0 {
            return Err(invalid("V36 prefix source object is empty"));
        }
        let source = crate::V36PrefixSourceObject {
            blake3: blake3_file(&path)?,
            encoded_bytes: object.encoded_bytes,
            path: object.path.clone(),
            sample_sha256: object.sample_sha256.clone(),
            sha256: object.sha256.clone(),
            uri: object.uri.clone(),
        };
        physical_rows = physical_rows
            .checked_add(object_rows)
            .ok_or_else(|| invalid("V36 prefix physical rows overflow"))?;
        let previous_distinct = seen.len();
        for identity in &object_identities {
            if !seen.insert(identity.feature_row_id) {
                return Err(invalid("V36 prefix provisional identity commit differs"));
            }
            unique_rows.push(identity.clone());
            if unique_rows.len() == distinct_candidates {
                cutoff = Some((selected_object_ordinal, identity.row_offset));
            }
        }
        consumed_objects.push(source.clone());
        let distinct_rows = u64::try_from(seen.len()).unwrap_or(u64::MAX);
        let duplicate_rows = physical_rows
            .checked_sub(distinct_rows)
            .ok_or_else(|| invalid("V36 prefix duplicate rows underflow"))?;
        let boundary_cutoff =
            if previous_distinct < distinct_candidates && seen.len() >= distinct_candidates {
                cutoff
            } else {
                None
            };
        let mut durable_identities = object_identities;
        durable_identities.sort_unstable_by_key(|identity| identity.feature_row_id);
        let boundary = V36PrefixPopulationCommit {
            cutoff: boundary_cutoff,
            distinct_rows,
            duplicate_rows,
            physical_rows,
            run: V36PrefixIdentityRun {
                physical_rows: object_rows,
                rows: durable_identities,
                selected_object_ordinal,
                source,
            },
        };
        validate_v36_prefix_identity_run(&boundary.run)?;
        commit(&boundary)?;
    }
    let (cutoff_object_ordinal, cutoff_row_offset) =
        cutoff.ok_or(BorsukError::V36PrefixSourceInsufficient)?;
    validate_v36_prefix_cutoff_membership_from_start(
        &unique_rows,
        selected_object_start,
        consumed_objects.len(),
        distinct_candidates,
    )?;
    let distinct_rows_observed = u64::try_from(seen.len()).unwrap_or(u64::MAX);
    Ok(V36PrefixObjectPrefixScan {
        consumed_objects,
        cutoff_object_ordinal,
        cutoff_row_offset,
        distinct_rows_observed,
        duplicate_rows: physical_rows
            .checked_sub(distinct_rows_observed)
            .ok_or_else(|| invalid("V36 prefix duplicate rows underflow"))?,
        physical_rows,
        unique_rows,
    })
}

/// Scan authenticated objects and emit a durable boundary only after each completes.
pub fn scan_v36_prefix_object_prefix_checkpointed<F, C>(
    ranked_objects: &[V36PrefixRankedSourceObject],
    selected_object_start: u16,
    byte_cap: u64,
    distinct_candidates: usize,
    acquire: F,
    commit: C,
) -> Result<V36PrefixObjectPrefixScan>
where
    F: FnMut(u16, &V36PrefixRankedSourceObject) -> Result<PathBuf>,
    C: FnMut(&V36PrefixPopulationCommit) -> Result<()>,
{
    scan_v36_prefix_object_prefix_from_state(
        ranked_objects,
        selected_object_start,
        byte_cap,
        distinct_candidates,
        None,
        acquire,
        commit,
    )
}

/// Resume a source scan strictly after an authenticated complete-object prefix.
pub fn scan_v36_prefix_object_prefix_resumed<F, C>(
    ranked_objects: &[V36PrefixRankedSourceObject],
    selected_object_start: u16,
    byte_cap: u64,
    distinct_candidates: usize,
    prior_runs: &[V36PrefixIdentityRun],
    acquire: F,
    commit: C,
) -> Result<V36PrefixObjectPrefixScan>
where
    F: FnMut(u16, &V36PrefixRankedSourceObject) -> Result<PathBuf>,
    C: FnMut(&V36PrefixPopulationCommit) -> Result<()>,
{
    let restored = restore_v36_prefix_population_state(prior_runs, distinct_candidates)?;
    scan_v36_prefix_object_prefix_from_state(
        ranked_objects,
        selected_object_start,
        byte_cap,
        distinct_candidates,
        Some(restored),
        acquire,
        commit,
    )
}

/// Scan every authenticated object in one complete registered window.
pub fn scan_v36_prefix_object_prefix<F>(
    ranked_objects: &[V36PrefixRankedSourceObject],
    selected_object_start: u16,
    byte_cap: u64,
    distinct_candidates: usize,
    acquire: F,
) -> Result<V36PrefixObjectPrefixScan>
where
    F: FnMut(u16, &V36PrefixRankedSourceObject) -> Result<PathBuf>,
{
    scan_v36_prefix_object_prefix_checkpointed(
        ranked_objects,
        selected_object_start,
        byte_cap,
        distinct_candidates,
        acquire,
        |_| Ok(()),
    )
}

/// Exact physical schema of a V36 prefix source table.
pub fn v36_prefix_source_schema() -> Schema {
    Schema::new(vec![
        Field::new("feature_row_id", DataType::UInt64, false),
        vector_field(),
    ])
}

/// Exact physical schema of a V36 prefix query table.
pub fn v36_prefix_query_schema() -> Schema {
    Schema::new(vec![
        Field::new("query_ordinal", DataType::UInt32, false),
        Field::new("feature_row_id", DataType::UInt64, false),
        vector_field(),
    ])
}

/// Exact physical schema of a V36 prefix exact-GT table.
pub fn v36_prefix_gt100_schema() -> Schema {
    Schema::new(vec![
        Field::new("query_ordinal", DataType::UInt32, false),
        Field::new("rank", DataType::UInt16, false),
        Field::new("feature_row_id", DataType::UInt64, false),
        Field::new("squared_distance", DataType::Float64, false),
    ])
}

fn validate_expected_feature_ids(expected: &[u64]) -> Result<()> {
    if expected.is_empty() {
        return Err(invalid("V36 prefix source membership is empty"));
    }
    let mut sorted = expected.to_vec();
    sorted.sort_unstable();
    if sorted.windows(2).any(|pair| pair[0] == pair[1]) {
        return Err(invalid("V36 prefix source membership overlaps"));
    }
    Ok(())
}

fn validate_source_batch(
    batch: &RecordBatch,
    expected_feature_ids: &[u64],
    next_ordinal: &mut usize,
) -> Result<()> {
    if batch.schema().as_ref() != &v36_prefix_source_schema()
        || batch.num_rows() == 0
        || batch.num_columns() != 2
        || batch
            .columns()
            .iter()
            .any(|column| column.null_count() != 0)
    {
        return Err(invalid("V36 prefix source Parquet batch differs"));
    }
    let ids = batch
        .column(0)
        .as_any()
        .downcast_ref::<UInt64Array>()
        .ok_or_else(|| invalid("V36 prefix source Parquet ID column differs"))?;
    let embeddings = batch
        .column(1)
        .as_any()
        .downcast_ref::<FixedSizeListArray>()
        .ok_or_else(|| invalid("V36 prefix source Parquet embedding column differs"))?;
    let values = embeddings
        .values()
        .as_any()
        .downcast_ref::<Float32Array>()
        .ok_or_else(|| invalid("V36 prefix source Parquet embedding child differs"))?;
    if values.null_count() != 0 || values.len() != batch.num_rows() * DIMENSIONS {
        return Err(invalid("V36 prefix source Parquet embedding shape differs"));
    }
    for row in 0..batch.num_rows() {
        if expected_feature_ids.get(*next_ordinal).copied() != Some(ids.value(row)) {
            return Err(invalid("V36 prefix source Parquet membership differs"));
        }
        let start = row * DIMENSIONS;
        validate_embedding(&values.values()[start..start + DIMENSIONS])?;
        *next_ordinal = next_ordinal
            .checked_add(1)
            .ok_or_else(|| invalid("V36 prefix source Parquet row count overflows"))?;
    }
    Ok(())
}

const MATERIALIZATION_BUCKET_ROWS: usize = 2_048;
const MATERIALIZATION_RECORD_BYTES: usize = 16 + DIMENSIONS * 4;

fn write_materialization_record<W: Write>(
    writer: &mut W,
    path: &Path,
    ordinal: usize,
    row: &V36PrefixMaterializedRow,
) -> Result<()> {
    validate_embedding(&row.embedding)?;
    let mut record = [0_u8; MATERIALIZATION_RECORD_BYTES];
    record[..8].copy_from_slice(
        &u64::try_from(ordinal)
            .map_err(|_| invalid("V36 prefix materialization ordinal overflows"))?
            .to_le_bytes(),
    );
    record[8..16].copy_from_slice(&row.feature_row_id.to_le_bytes());
    for (encoded, value) in record[16..]
        .as_chunks_mut::<4>()
        .0
        .iter_mut()
        .zip(&row.embedding)
    {
        *encoded = value.to_bits().to_le_bytes();
    }
    writer.write_all(&record).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })
}

fn materialization_rows(split: &V36PrefixRoleSplit) -> [&[V36PrefixRowIdentity]; 5] {
    [
        &split.corpus,
        &split.development,
        &split.validation,
        &split.sealed_holdout,
        &split.performance,
    ]
}

fn read_materialization_bucket(path: &Path) -> Result<Vec<(u64, V36PrefixMaterializedRow)>> {
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    let encoded_bytes = file
        .metadata()
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?
        .len();
    if encoded_bytes == 0
        || encoded_bytes % u64::try_from(MATERIALIZATION_RECORD_BYTES).unwrap() != 0
        || encoded_bytes
            > u64::try_from(MATERIALIZATION_BUCKET_ROWS * MATERIALIZATION_RECORD_BYTES).unwrap()
    {
        return Err(invalid("V36 prefix materialization spool differs"));
    }
    let row_count =
        usize::try_from(encoded_bytes / u64::try_from(MATERIALIZATION_RECORD_BYTES).unwrap())
            .map_err(|_| invalid("V36 prefix materialization spool differs"))?;
    let mut reader = BufReader::with_capacity(65_536, file);
    let mut rows = Vec::with_capacity(row_count);
    for _ in 0..row_count {
        let mut record = [0_u8; MATERIALIZATION_RECORD_BYTES];
        reader
            .read_exact(&mut record)
            .map_err(|source| BorsukError::Io {
                path: path.to_owned(),
                source,
            })?;
        let ordinal = u64::from_le_bytes(record[..8].try_into().unwrap());
        let feature_row_id = u64::from_le_bytes(record[8..16].try_into().unwrap());
        let mut embedding = Vec::with_capacity(DIMENSIONS);
        for component in record[16..].as_chunks::<4>().0 {
            embedding.push(f32::from_bits(u32::from_le_bytes(*component)));
        }
        validate_embedding(&embedding)?;
        rows.push((
            ordinal,
            V36PrefixMaterializedRow {
                feature_row_id,
                source_ordinal: Some(ordinal),
                embedding,
            },
        ));
    }
    let mut trailing = [0_u8; 1];
    if reader
        .read(&mut trailing)
        .map_err(|source| BorsukError::Io {
            path: path.to_owned(),
            source,
        })?
        != 0
    {
        return Err(invalid("V36 prefix materialization spool differs"));
    }
    rows.sort_by_key(|(ordinal, _)| *ordinal);
    Ok(rows)
}

fn materialized_batch(
    rows: &[(u64, V36PrefixMaterializedRow)],
    query: bool,
) -> Result<RecordBatch> {
    let ordinals = rows
        .iter()
        .map(|(ordinal, _)| u32::try_from(*ordinal))
        .collect::<std::result::Result<Vec<_>, _>>()
        .map_err(|_| invalid("V36 prefix materialization ordinal overflows"))?;
    let ids = rows
        .iter()
        .map(|(_, row)| row.feature_row_id)
        .collect::<Vec<_>>();
    let values = rows
        .iter()
        .flat_map(|(_, row)| row.embedding.iter().copied())
        .collect::<Vec<_>>();
    let embeddings = FixedSizeListArray::try_new(
        Arc::new(Field::new("item", DataType::Float32, false)),
        DIMENSIONS as i32,
        Arc::new(Float32Array::from(values)),
        None,
    )?;
    let mut columns = Vec::<ArrayRef>::new();
    let schema = if query {
        columns.push(Arc::new(UInt32Array::from(ordinals)));
        columns.push(Arc::new(UInt64Array::from(ids)));
        v36_prefix_query_schema()
    } else {
        columns.push(Arc::new(UInt64Array::from(ids)));
        v36_prefix_source_schema()
    };
    columns.push(Arc::new(embeddings));
    Ok(RecordBatch::try_new(Arc::new(schema), columns)?)
}

fn write_spooled_output(
    path: &Path,
    rows: &[V36PrefixRowIdentity],
    buckets: &[PathBuf],
    query: bool,
) -> Result<()> {
    let schema = if query {
        v36_prefix_query_schema()
    } else {
        v36_prefix_source_schema()
    };
    let mut temporary = temporary_output(path)?;
    let mut writer = ArrowWriter::try_new(
        temporary.as_file_mut(),
        Arc::new(schema),
        Some(parquet_writer_properties()),
    )?;
    let expected = rows
        .iter()
        .map(|row| row.feature_row_id)
        .collect::<Vec<_>>();
    let mut source_ordinal = 0_usize;
    let mut query_ordinal = 0_u64;
    let mut query_ids = BTreeSet::new();
    for bucket in buckets {
        let decoded = read_materialization_bucket(bucket)?;
        let batch = materialized_batch(&decoded, query)?;
        if query {
            validate_query_batch(&batch, &mut query_ordinal, &mut query_ids)?;
        } else {
            validate_source_batch(&batch, &expected, &mut source_ordinal)?;
        }
        writer.write(&batch)?;
    }
    if (query && query_ordinal != rows.len() as u64) || (!query && source_ordinal != rows.len()) {
        return Err(invalid("V36 prefix materialization row count differs"));
    }
    writer.close()?;
    publish_output(temporary, path)
}

fn write_spooled_output_counted(
    path: &Path,
    expected_rows: u64,
    buckets: &[PathBuf],
    query: bool,
) -> Result<()> {
    let schema = if query {
        v36_prefix_query_schema()
    } else {
        v36_prefix_source_schema()
    };
    let mut temporary = temporary_output(path)?;
    let mut writer = ArrowWriter::try_new(
        temporary.as_file_mut(),
        Arc::new(schema),
        Some(parquet_writer_properties()),
    )?;
    let mut next_ordinal = 0_u64;
    let mut query_ordinal = 0_u64;
    let mut query_ids = BTreeSet::new();
    for bucket in buckets {
        let decoded = read_materialization_bucket(bucket)?;
        for (ordinal, _) in &decoded {
            if *ordinal != next_ordinal {
                return Err(invalid("V36 prefix materialization ordinal differs"));
            }
            next_ordinal += 1;
        }
        let batch = materialized_batch(&decoded, query)?;
        if query {
            validate_query_batch(&batch, &mut query_ordinal, &mut query_ids)?;
        }
        writer.write(&batch)?;
    }
    if next_ordinal != expected_rows || (query && query_ordinal != expected_rows) {
        return Err(invalid("V36 prefix materialization row count differs"));
    }
    writer.close()?;
    publish_output(temporary, path)
}

fn v36_prefix_ranked_source_manifest_sha256(
    ranked_objects: &[V36PrefixRankedSourceObject],
) -> Result<String> {
    let mut objects = ranked_objects.iter().collect::<Vec<_>>();
    objects.sort_by(|left, right| left.path.as_bytes().cmp(right.path.as_bytes()));
    let mut paths = BTreeSet::new();
    let mut manifest = Sha256::new();
    for object in objects {
        if !paths.insert(object.path.as_str()) {
            return Err(invalid("V36 prefix source manifest paths differ"));
        }
        digest_bytes(&object.sha256)?;
        manifest.update(object.path.as_bytes());
        manifest.update(b"\t");
        manifest.update(object.sha256.as_bytes());
        manifest.update(b"\t");
        manifest.update(object.encoded_bytes.to_string().as_bytes());
        manifest.update(b"\n");
    }
    Ok(format!("{:x}", manifest.finalize()))
}

/// Materialize role Parquets by merge-joining physical assignments with source rows.
pub fn materialize_v36_prefix_assigned_roles(
    request: V36PrefixExternalMaterializationRequest<'_>,
) -> Result<V36PrefixRoleParquetPaths> {
    let V36PrefixExternalMaterializationRequest {
        assignment,
        limits,
        output,
        ranked_objects,
        scratch_root,
        source_paths,
    } = request;
    validate_v36_prefix_role_assignment_contract_shape(&assignment.contract)?;
    if limits.io_buffer_bytes > EXTERNAL_MAX_IO_BUFFER_BYTES {
        return Err(resource_limit("external materialization configuration"));
    }
    let object_count = usize::from(assignment.contract.selected_object_count);
    let object_start = usize::from(assignment.contract.selected_object_start);
    let object_end = object_start
        .checked_add(object_count)
        .ok_or_else(|| invalid("V36 prefix selected object window overflows"))?;
    if source_paths.len() != object_count
        || object_count == 0
        || object_count > 16
        || ranked_objects.get(object_start..object_end).is_none()
        || ranked_objects.windows(2).any(|pair| {
            (&pair[0].sample_sha256, &pair[0].path) >= (&pair[1].sample_sha256, &pair[1].path)
        })
        || ranked_objects.iter().any(|object| {
            object.sample_sha256
                != v36_prefix_object_sample_sha256(&object.path, object.encoded_bytes)
        })
        || v36_prefix_ranked_source_manifest_sha256(ranked_objects)?
            != assignment.contract.ordered_source_manifest_sha256
        || limits.io_buffer_bytes == 0
        || limits.max_input_bytes == 0
        || limits.max_scratch_bytes == 0
    {
        return Err(invalid(
            "V36 prefix external materialization authority differs",
        ));
    }
    let required_scratch_bytes = assignment
        .contract
        .selected_rows
        .checked_mul(
            u64::try_from(MATERIALIZATION_RECORD_BYTES)
                .map_err(|_| resource_limit("materialization scratch bytes"))?,
        )
        .and_then(|bytes| bytes.checked_add(assignment.identity.encoded_bytes))
        .ok_or_else(|| resource_limit("materialization scratch bytes"))?;
    if required_scratch_bytes > limits.max_scratch_bytes {
        return Err(resource_limit("materialization scratch bytes"));
    }
    let selected_objects = &ranked_objects[object_start..object_end];
    if selected_objects
        .iter()
        .any(|object| object.encoded_bytes > limits.max_input_bytes)
    {
        return Err(resource_limit("materialization source input bytes"));
    }
    let scratch_type = fs::symlink_metadata(scratch_root)
        .map_err(|source| BorsukError::Io {
            path: scratch_root.to_owned(),
            source,
        })?
        .file_type();
    let output_parent = output
        .parent()
        .ok_or_else(|| invalid("V36 prefix materialization output path differs"))?;
    let output_parent_type = fs::symlink_metadata(output_parent)
        .map_err(|source| BorsukError::Io {
            path: output_parent.to_owned(),
            source,
        })?
        .file_type();
    let names = [
        "source.parquet",
        "development-query.parquet",
        "validation-query.parquet",
        "sealed-holdout-query.parquet",
        "performance-query.parquet",
    ];
    let output_type = fs::symlink_metadata(output)
        .map_err(|source| BorsukError::Io {
            path: output.to_owned(),
            source,
        })?
        .file_type();
    if !scratch_type.is_dir()
        || scratch_type.is_symlink()
        || !output_parent_type.is_dir()
        || output_parent_type.is_symlink()
        || !output_type.is_dir()
        || output_type.is_symlink()
        || output
            .read_dir()
            .map_err(|source| BorsukError::Io {
                path: output.to_owned(),
                source,
            })?
            .next()
            .is_some()
    {
        return Err(invalid(
            "V36 prefix external materialization output differs",
        ));
    }
    let attempt = tempfile::tempdir_in(scratch_root).map_err(|source| BorsukError::Io {
        path: scratch_root.to_owned(),
        source,
    })?;
    let staging = tempfile::tempdir_in(output_parent).map_err(|source| BorsukError::Io {
        path: output_parent.to_owned(),
        source,
    })?;
    let mut assignments =
        open_v36_prefix_role_assignment_stream(assignment, limits, attempt.path())?;
    let counts = assignments.counts;
    let mut spool_paths = Vec::new();
    let mut spools = Vec::new();
    for (role, count) in counts.into_iter().enumerate() {
        let count = usize::try_from(count)
            .map_err(|_| invalid("V36 prefix materialization row count overflows"))?;
        let mut paths = Vec::new();
        let mut files = Vec::new();
        for bucket in 0..count.div_ceil(MATERIALIZATION_BUCKET_ROWS) {
            let path = attempt
                .path()
                .join(format!("role-{role}-bucket-{bucket:06}.bin"));
            let file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&path)
                .map_err(|source| BorsukError::Io {
                    path: path.clone(),
                    source,
                })?;
            paths.push(path);
            files.push(BufWriter::new(file));
        }
        spool_paths.push(paths);
        spools.push(files);
    }
    let mut next_assignment = assignments.next_record()?;
    for (local_ordinal, (path, object)) in source_paths.iter().zip(selected_objects).enumerate() {
        let object_ordinal = assignment
            .contract
            .selected_object_start
            .checked_add(
                u16::try_from(local_ordinal)
                    .map_err(|_| invalid("V36 prefix materialization ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix materialization ordinal overflows"))?;
        scan_v36_prefix_registered_input_parquet(path, object, object_ordinal, |row| {
            let physical = (row.selected_object_ordinal, row.row_offset);
            if next_assignment.is_some_and(|assignment| {
                (assignment.selected_object_ordinal, assignment.row_offset) < physical
            }) {
                return Err(invalid("V36 prefix materialization row is missing"));
            }
            if let Some(assignment_row) = next_assignment
                && (
                    assignment_row.selected_object_ordinal,
                    assignment_row.row_offset,
                ) == physical
            {
                if assignment_row.feature_row_id
                    != u64::try_from(row.feature_row_id).unwrap_or(u64::MAX)
                {
                    return Err(invalid("V36 prefix materialization feature ID differs"));
                }
                let role = usize::from(assignment_row.role);
                let ordinal = usize::try_from(assignment_row.role_ordinal)
                    .map_err(|_| invalid("V36 prefix materialization ordinal overflows"))?;
                let bucket = ordinal / MATERIALIZATION_BUCKET_ROWS;
                write_materialization_record(
                    &mut spools[role][bucket],
                    &spool_paths[role][bucket],
                    ordinal,
                    &V36PrefixMaterializedRow {
                        feature_row_id: assignment_row.feature_row_id,
                        source_ordinal: (role == 0).then_some(assignment_row.role_ordinal),
                        embedding: row.embedding,
                    },
                )?;
                next_assignment = assignments.next_record()?;
            }
            Ok(())
        })?;
    }
    if next_assignment.is_some() || assignments.next_record()?.is_some() {
        return Err(invalid("V36 prefix materialization row is missing"));
    }
    let snapshot_path = assignments.snapshot_path.clone();
    drop(assignments);
    fs::remove_file(&snapshot_path).map_err(|source| BorsukError::Io {
        path: snapshot_path,
        source,
    })?;
    for (role, role_spools) in spools.iter_mut().enumerate() {
        for (bucket, spool) in role_spools.iter_mut().enumerate() {
            spool.flush().map_err(|source| BorsukError::Io {
                path: spool_paths[role][bucket].clone(),
                source,
            })?;
        }
    }
    drop(spools);
    let staged_outputs = names.map(|name| staging.path().join(name));
    for (role, ((path, count), buckets)) in staged_outputs
        .iter()
        .zip(counts)
        .zip(&spool_paths)
        .enumerate()
    {
        write_spooled_output_counted(path, count, buckets, role != 0)?;
    }
    for role in spool_paths {
        for path in role {
            fs::remove_file(&path).map_err(|source| BorsukError::Io { path, source })?;
        }
    }
    sync_directory(staging.path())?;
    for (staged, name) in staged_outputs.iter().zip(names) {
        let destination = output.join(name);
        rustix::fs::renameat_with(
            rustix::fs::CWD,
            staged,
            rustix::fs::CWD,
            &destination,
            rustix::fs::RenameFlags::NOREPLACE,
        )
        .map_err(|source| BorsukError::Io {
            path: destination,
            source: source.into(),
        })?;
    }
    sync_directory(output)?;
    let outputs = names.map(|name| output.join(name));
    let [source, development, validation, sealed_holdout, performance] = outputs;
    Ok(V36PrefixRoleParquetPaths {
        development,
        performance,
        sealed_holdout,
        source,
        validation,
    })
}

fn v36_prefix_checkpoint_output_identity(
    role: &str,
    filename: &str,
    output_uri_prefix: &str,
    path: &Path,
) -> Result<V36ArtifactIdentity> {
    let (encoded_bytes, sha256) = sha256_file(path)?;
    let prefix = output_uri_prefix.trim_end_matches('/');
    Ok(V36ArtifactIdentity {
        blake3: blake3_file(path)?,
        encoded_bytes,
        role: role.to_owned(),
        sha256: sha256.clone(),
        uri: format!("{prefix}/{sha256}-{filename}"),
    })
}

/// Materialize one authenticated selection and publish its exact Materialized checkpoint.
pub fn materialize_v36_prefix_checkpoint_selection(
    request: V36PrefixCheckpointMaterializationRequest<'_>,
) -> Result<V36PrefixCheckpointMaterialization> {
    let V36PrefixCheckpointMaterializationRequest {
        contract,
        limits,
        output,
        output_uri_prefix,
        population,
        ranked_objects,
        scratch_root,
        selected,
        source_registry,
        source_paths,
        writer,
    } = request;
    let (selection, checkpoint_population) = match writer
        .previous_manifest
        .as_ref()
        .map(|manifest| (&manifest.phase, &manifest.population))
    {
        Some((V36PrefixCheckpointPhase::Selected { selection }, population)) => {
            (selection, population)
        }
        _ => {
            return Err(invalid(
                "V36 materialization checkpoint predecessor differs",
            ));
        }
    };
    validate_v36_prefix_checkpoint_selected_file(selected, selection)?;
    validate_v36_prefix_role_assignment_contract(contract, selected)?;
    let object_start = usize::from(population.selected_object_start);
    let object_end = object_start
        .checked_add(usize::from(population.selected_object_count))
        .ok_or_else(|| invalid("V36 prefix selected object window overflows"))?;
    let selected_ranked_objects = ranked_objects
        .get(object_start..object_end)
        .ok_or_else(|| invalid("V36 materialization source window differs"))?;
    let consumed_matches_ranked = population.consumed_objects.len()
        == selected_ranked_objects.len()
        && population
            .consumed_objects
            .iter()
            .zip(selected_ranked_objects)
            .all(|(consumed, ranked)| {
                consumed.encoded_bytes == ranked.encoded_bytes
                    && consumed.path == ranked.path
                    && consumed.sample_sha256 == ranked.sample_sha256
                    && consumed.sha256 == ranked.sha256
                    && consumed.uri == ranked.uri
            });
    if population.cohort_ordinal != selected.contract.cohort_ordinal
        || population.corpus_rows != contract.corpus_rows
        || population.corpus_rows != writer.context.corpus_rows
        || population.distinct_candidates != selected.contract.selected_rows
        || population.excluded_population_identity != selected.contract.excluded_population_identity
        || population.ordered_source_manifest_sha256
            != selected.contract.ordered_source_manifest_sha256
        || population.population_seed_sha256 != selected.contract.population_seed_sha256
        || population.selected_object_count != selected.contract.selected_object_count
        || population.selected_object_start != selected.contract.selected_object_start
        || population.source_byte_cap != writer.context.source_byte_cap
        || population.corpus_seed_label != contract.corpus_seed_label
        || population.corpus_seed_sha256 != contract.corpus_seed_sha256
        || population.roles != contract.roles
        || population.consumed_objects != checkpoint_population.consumed_objects
        || !consumed_matches_ranked
    {
        return Err(invalid("V36 materialization population authority differs"));
    }
    let source_registry_bytes =
        canonical_v36_prefix_checkpoint_source_registry_bytes(population, source_registry)?;
    if format!("{:x}", Sha256::digest(&source_registry_bytes))
        != writer.context.source_registry_sha256
    {
        return Err(invalid("V36 materialization source registry differs"));
    }
    let population_authority_bytes =
        canonical_v36_prefix_checkpoint_population_authority_bytes(population, source_registry)?;

    let assignment_attempt =
        tempfile::tempdir_in(scratch_root).map_err(|source| BorsukError::Io {
            path: scratch_root.to_owned(),
            source,
        })?;
    let assignment_path = assignment_attempt.path().join("role-assignments.arrow");
    let assignment_receipt =
        assign_v36_prefix_roles_from_selected_file(V36PrefixRoleAssignmentRequest {
            contract,
            limits,
            output: &assignment_path,
            output_uri_prefix,
            scratch_root: assignment_attempt.path(),
            selected,
        })?;
    let assignment = V36PrefixRoleAssignmentFile {
        contract: contract.clone(),
        identity: assignment_receipt.identity,
        path: assignment_path,
    };
    let paths = materialize_v36_prefix_assigned_roles(V36PrefixExternalMaterializationRequest {
        assignment: &assignment,
        limits,
        output,
        ranked_objects,
        scratch_root,
        source_paths,
    })?;
    let population_authority_path = output.join("population-authority.json");
    write_atomic_bytes(&population_authority_path, &population_authority_bytes)?;
    let specifications = [
        (
            "population-authority",
            "population-authority.json",
            population_authority_path,
        ),
        ("source", "source.parquet", paths.source.clone()),
        (
            "development-query",
            "development-query.parquet",
            paths.development.clone(),
        ),
        (
            "validation-query",
            "validation-query.parquet",
            paths.validation.clone(),
        ),
        (
            "sealed-holdout-query",
            "sealed-holdout-query.parquet",
            paths.sealed_holdout.clone(),
        ),
        (
            "performance-query",
            "performance-query.parquet",
            paths.performance.clone(),
        ),
    ];
    let dependencies = specifications
        .iter()
        .map(|(role, filename, path)| {
            Ok(V36PrefixCheckpointDependencyFile {
                identity: v36_prefix_checkpoint_output_identity(
                    role,
                    filename,
                    output_uri_prefix,
                    path,
                )?,
                path: path.clone(),
            })
        })
        .collect::<Result<Vec<_>>>()?;
    let artifacts = V36PrefixMaterializedArtifacts {
        population_authority: dependencies[0].identity.clone(),
        source: dependencies[1].identity.clone(),
        development_query: dependencies[2].identity.clone(),
        validation_query: dependencies[3].identity.clone(),
        sealed_holdout_query: dependencies[4].identity.clone(),
        performance_query: dependencies[5].identity.clone(),
    };
    let checkpoint_ready = writer.commit_materialized(&artifacts, &dependencies)?;
    Ok(V36PrefixCheckpointMaterialization {
        artifacts,
        checkpoint_ready,
        paths,
    })
}

/// Materialize canonical source and query Parquet using bounded ordinal buckets.
pub fn materialize_v36_prefix_role_parquets(
    source_paths: &[PathBuf],
    ranked_objects: &[V36PrefixRankedSourceObject],
    selected_object_start: u16,
    split: &V36PrefixRoleSplit,
    scratch: &Path,
    output: &Path,
) -> Result<V36PrefixRoleParquetPaths> {
    if source_paths.len() != ranked_objects.len()
        || source_paths.is_empty()
        || !scratch.is_dir()
        || !output.is_dir()
    {
        return Err(invalid("V36 prefix materialization inputs differ"));
    }
    let role_rows = materialization_rows(split);
    if role_rows.iter().any(|rows| rows.is_empty()) {
        return Err(invalid("V36 prefix materialization role is empty"));
    }
    let mut destinations = HashMap::new();
    for (role, rows) in role_rows.iter().enumerate() {
        for (ordinal, row) in rows.iter().enumerate() {
            if (role == 0 && row.source_ordinal != Some(ordinal as u64))
                || (role != 0 && row.source_ordinal.is_some())
                || destinations
                    .insert(
                        (row.selected_object_ordinal, row.row_offset),
                        (role, ordinal, row.feature_row_id),
                    )
                    .is_some()
            {
                return Err(invalid("V36 prefix materialization membership differs"));
            }
        }
    }
    let mut spool_paths = Vec::new();
    let mut spools = Vec::new();
    for (role, rows) in role_rows.iter().enumerate() {
        let mut role_paths = Vec::new();
        let mut role_files = Vec::new();
        for bucket in 0..rows.len().div_ceil(MATERIALIZATION_BUCKET_ROWS) {
            let path = scratch.join(format!("role-{role}-bucket-{bucket:06}.bin"));
            let file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&path)
                .map_err(|source| BorsukError::Io {
                    path: path.clone(),
                    source,
                })?;
            role_paths.push(path);
            role_files.push(BufWriter::new(file));
        }
        spool_paths.push(role_paths);
        spools.push(role_files);
    }
    for (local_ordinal, (path, object)) in source_paths.iter().zip(ranked_objects).enumerate() {
        let object_ordinal = selected_object_start
            .checked_add(
                u16::try_from(local_ordinal)
                    .map_err(|_| invalid("V36 prefix materialization object ordinal overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix materialization object ordinal overflows"))?;
        scan_v36_prefix_registered_input_parquet(path, object, object_ordinal, |row| {
            if let Some((role, ordinal, feature_row_id)) =
                destinations.remove(&(row.selected_object_ordinal, row.row_offset))
            {
                if feature_row_id != u64::try_from(row.feature_row_id).unwrap_or(u64::MAX) {
                    return Err(invalid("V36 prefix materialization feature ID differs"));
                }
                let file = &mut spools[role][ordinal / MATERIALIZATION_BUCKET_ROWS];
                write_materialization_record(
                    file,
                    &spool_paths[role][ordinal / MATERIALIZATION_BUCKET_ROWS],
                    ordinal,
                    &V36PrefixMaterializedRow {
                        feature_row_id,
                        source_ordinal: Some(ordinal as u64),
                        embedding: row.embedding,
                    },
                )?;
            }
            Ok(())
        })?;
    }
    if !destinations.is_empty() {
        return Err(invalid("V36 prefix materialization row is missing"));
    }
    for (role, role_spools) in spools.iter_mut().enumerate() {
        for (bucket, spool) in role_spools.iter_mut().enumerate() {
            spool.flush().map_err(|source| BorsukError::Io {
                path: spool_paths[role][bucket].clone(),
                source,
            })?;
        }
    }
    drop(spools);
    let names = [
        "source.parquet",
        "development-query.parquet",
        "validation-query.parquet",
        "sealed-holdout-query.parquet",
        "performance-query.parquet",
    ];
    let mut outputs = Vec::new();
    for (role, (rows, name)) in role_rows.iter().zip(names).enumerate() {
        let path = output.join(name);
        write_spooled_output(&path, rows, &spool_paths[role], role != 0)?;
        outputs.push(path);
    }
    for role in spool_paths {
        for path in role {
            fs::remove_file(&path).map_err(|source| BorsukError::Io { path, source })?;
        }
    }
    let [source, development, validation, sealed_holdout, performance] = outputs
        .try_into()
        .map_err(|_| invalid("V36 prefix materialization outputs differ"))?;
    Ok(V36PrefixRoleParquetPaths {
        development,
        performance,
        sealed_holdout,
        source,
        validation,
    })
}

/// Write validated source batches without retaining the complete corpus in RAM.
pub fn write_v36_prefix_source_parquet<I>(
    path: &Path,
    expected_feature_ids: &[u64],
    batches: I,
) -> Result<()>
where
    I: IntoIterator<Item = RecordBatch>,
{
    validate_expected_feature_ids(expected_feature_ids)?;
    let mut temporary = temporary_output(path)?;
    let mut writer = ArrowWriter::try_new(
        temporary.as_file_mut(),
        Arc::new(v36_prefix_source_schema()),
        Some(parquet_writer_properties()),
    )?;
    let mut next_ordinal = 0_usize;
    for batch in batches {
        validate_source_batch(&batch, expected_feature_ids, &mut next_ordinal)?;
        writer.write(&batch)?;
    }
    if next_ordinal != expected_feature_ids.len() {
        return Err(invalid("V36 prefix source Parquet row count differs"));
    }
    writer.close()?;
    publish_output(temporary, path)?;
    Ok(())
}

/// Stream and validate a complete source Parquet artifact one batch at a time.
pub fn scan_v36_prefix_source_parquet<F>(
    path: &Path,
    expected_feature_ids: &[u64],
    consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    scan_v36_prefix_source_parquet_with_batch_size(path, expected_feature_ids, None, consume)
}

fn scan_v36_prefix_source_parquet_with_batch_size<F>(
    path: &Path,
    expected_feature_ids: &[u64],
    batch_size: Option<usize>,
    consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    scan_v36_prefix_source_parquet_file_with_batch_size(
        file,
        path,
        expected_feature_ids,
        batch_size,
        consume,
    )
}

fn scan_v36_prefix_source_parquet_file_with_batch_size<F>(
    mut file: File,
    display_path: &Path,
    expected_feature_ids: &[u64],
    batch_size: Option<usize>,
    mut consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    validate_expected_feature_ids(expected_feature_ids)?;
    v36_prefix_external_io(display_path, file.seek(SeekFrom::Start(0)))?;
    let page_file = file.try_clone().map_err(|source| BorsukError::Io {
        path: display_path.to_owned(),
        source,
    })?;
    validate_v36_prefix_parquet_footer(&page_file)?;
    let mut builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    validate_parquet_descriptor(builder.parquet_schema(), &v36_prefix_source_schema())?;
    if builder.schema().as_ref() != &v36_prefix_source_schema() {
        return Err(invalid("V36 prefix source Parquet physical schema differs"));
    }
    if let Some(batch_size) = batch_size {
        if batch_size == 0 {
            return Err(invalid("V36 prefix source batch size differs"));
        }
        let row_groups = builder
            .metadata()
            .row_groups()
            .iter()
            .map(|group| {
                let compressed = group.columns().iter().try_fold(0_i64, |total, column| {
                    total.checked_add(column.compressed_size())
                });
                let uncompressed = group.columns().iter().try_fold(0_i64, |total, column| {
                    total.checked_add(column.uncompressed_size())
                });
                compressed
                    .zip(uncompressed)
                    .map(|(compressed, uncompressed)| (group.num_rows(), compressed, uncompressed))
                    .ok_or_else(|| invalid("V36 prefix source decoder size overflows"))
            })
            .collect::<Result<Vec<_>>>()?;
        validate_v36_prefix_source_decoder_bounds(
            &row_groups,
            batch_size,
            SOURCE_DECODER_COMPRESSED_CAP_BYTES,
            SOURCE_DECODER_UNCOMPRESSED_CAP_BYTES,
        )?;
        validate_v36_parquet_pages(
            &page_file,
            builder.metadata(),
            &[(1, 8), (DIMENSIONS as u64, 4)],
        )?;
        builder = builder.with_batch_size(batch_size);
    }
    let mut next_ordinal = 0_usize;
    for batch in builder.build()? {
        let batch = batch?;
        validate_source_batch(&batch, expected_feature_ids, &mut next_ordinal)?;
        consume(batch)?;
    }
    if next_ordinal != expected_feature_ids.len() {
        return Err(invalid("V36 prefix source Parquet row count differs"));
    }
    Ok(())
}

pub(crate) fn validate_v36_prefix_source_decoder_bounds(
    row_groups: &[(i64, i64, i64)],
    maximum_rows: usize,
    maximum_compressed_bytes: u64,
    maximum_uncompressed_bytes: u64,
) -> Result<()> {
    if row_groups.is_empty()
        || maximum_rows == 0
        || maximum_compressed_bytes == 0
        || maximum_uncompressed_bytes == 0
    {
        return Err(invalid("V36 prefix source decoder bounds differ"));
    }
    let maximum_rows = i64::try_from(maximum_rows)
        .map_err(|_| invalid("V36 prefix source decoder row bound overflows"))?;
    let maximum_compressed_bytes = i64::try_from(maximum_compressed_bytes)
        .map_err(|_| invalid("V36 prefix source decoder byte bound overflows"))?;
    let maximum_uncompressed_bytes = i64::try_from(maximum_uncompressed_bytes)
        .map_err(|_| invalid("V36 prefix source decoder byte bound overflows"))?;
    if row_groups.iter().any(|(rows, compressed, uncompressed)| {
        *rows <= 0
            || *rows > maximum_rows
            || *compressed < 0
            || *compressed > maximum_compressed_bytes
            || *uncompressed < 0
            || *uncompressed > maximum_uncompressed_bytes
    }) {
        return Err(invalid("V36 prefix source decoder working set differs"));
    }
    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum V36PrefixSourcePageKind {
    Data,
    DataV2,
    Dictionary,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct V36PrefixSourcePageClaim {
    compressed_bytes: i32,
    kind: V36PrefixSourcePageKind,
    rows: Option<i32>,
    uncompressed_bytes: i32,
    values: i32,
}

struct V36CompactCursor<'a> {
    bytes: &'a [u8],
    position: usize,
}

impl<'a> V36CompactCursor<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self { bytes, position: 0 }
    }

    fn byte(&mut self) -> Result<u8> {
        let byte = self
            .bytes
            .get(self.position)
            .copied()
            .ok_or_else(|| invalid("V36 prefix source page header is truncated"))?;
        self.position += 1;
        Ok(byte)
    }

    fn varint(&mut self) -> Result<u64> {
        let mut value = 0_u64;
        for byte_index in 0..10 {
            let byte = self.byte()?;
            if byte_index == 9 && byte > 1 {
                return Err(invalid("V36 prefix compact varint overflows"));
            }
            value |= u64::from(byte & 0x7f) << (byte_index * 7);
            if byte & 0x80 == 0 {
                return Ok(value);
            }
        }
        Err(invalid("V36 prefix source page header varint differs"))
    }

    fn zigzag_i32(&mut self) -> Result<i32> {
        let value = u32::try_from(self.varint()?)
            .map_err(|_| invalid("V36 prefix source page header integer differs"))?;
        Ok(((value >> 1) as i32) ^ -((value & 1) as i32))
    }

    fn field(&mut self, prior: &mut i16) -> Result<Option<(i16, u8)>> {
        let header = self.byte()?;
        let kind = header & 0x0f;
        if kind == 0 {
            return Ok(None);
        }
        if !(1..=12).contains(&kind) {
            return Err(invalid("V36 prefix source page header type differs"));
        }
        let delta = i16::from(header >> 4);
        let id = if delta == 0 {
            i16::try_from(self.zigzag_i32()?)
                .map_err(|_| invalid("V36 prefix source page header field differs"))?
        } else {
            prior
                .checked_add(delta)
                .ok_or_else(|| invalid("V36 prefix source page header field overflows"))?
        };
        if id <= 0 {
            return Err(invalid("V36 prefix compact field ID differs"));
        }
        *prior = id;
        Ok(Some((id, kind)))
    }

    fn skip(&mut self, kind: u8, depth: u8) -> Result<()> {
        if depth == 0 {
            return Err(invalid("V36 prefix source page header nesting differs"));
        }
        match kind {
            1 | 2 => Ok(()),
            3 => {
                self.byte()?;
                Ok(())
            }
            4..=6 => self.varint().map(|_| ()),
            7 => self.advance(8),
            8 => {
                let length = usize::try_from(self.varint()?)
                    .map_err(|_| invalid("V36 prefix source page header length overflows"))?;
                if length > 1_048_576 {
                    return Err(invalid("V36 prefix compact binary length differs"));
                }
                self.advance(length)
            }
            9 | 10 => {
                let header = self.byte()?;
                let mut count = usize::from(header >> 4);
                if count == 15 {
                    count = usize::try_from(self.varint()?).map_err(|_| {
                        invalid("V36 prefix source page header collection overflows")
                    })?;
                }
                if count > 65_536 || count > self.bytes.len() {
                    return Err(invalid("V36 prefix source page header collection differs"));
                }
                let child = header & 0x0f;
                for _ in 0..count {
                    if child == 1 || child == 2 {
                        self.byte()?;
                    } else {
                        self.skip(child, depth - 1)?;
                    }
                }
                Ok(())
            }
            11 => {
                let count = usize::try_from(self.varint()?)
                    .map_err(|_| invalid("V36 prefix source page header map overflows"))?;
                if count == 0 {
                    return Ok(());
                }
                if count > 65_536 || count > self.bytes.len() {
                    return Err(invalid("V36 prefix source page header map differs"));
                }
                let kinds = self.byte()?;
                for _ in 0..count {
                    self.skip(kinds >> 4, depth - 1)?;
                    self.skip(kinds & 0x0f, depth - 1)?;
                }
                Ok(())
            }
            12 => {
                let mut prior = 0;
                while let Some((_, child)) = self.field(&mut prior)? {
                    self.skip(child, depth - 1)?;
                }
                Ok(())
            }
            _ => Err(invalid("V36 prefix source page header type differs")),
        }
    }

    fn advance(&mut self, length: usize) -> Result<()> {
        self.position = self
            .position
            .checked_add(length)
            .filter(|end| *end <= self.bytes.len())
            .ok_or_else(|| invalid("V36 prefix source page header is truncated"))?;
        Ok(())
    }
}

fn parse_v36_prefix_source_nested_page_header(
    cursor: &mut V36CompactCursor<'_>,
    kind: V36PrefixSourcePageKind,
) -> Result<(i32, Option<i32>)> {
    let mut prior = 0;
    let mut values = None;
    let mut rows = None;
    while let Some((id, field_kind)) = cursor.field(&mut prior)? {
        if id == 1 {
            if field_kind != 5 || values.replace(cursor.zigzag_i32()?).is_some() {
                return Err(invalid("V36 prefix source page value count differs"));
            }
        } else if kind == V36PrefixSourcePageKind::DataV2 && id == 3 {
            if field_kind != 5 || rows.replace(cursor.zigzag_i32()?).is_some() {
                return Err(invalid("V36 prefix source page row count differs"));
            }
        } else {
            cursor.skip(field_kind, 8)?;
        }
    }
    Ok((
        values.ok_or_else(|| invalid("V36 prefix source page value count is absent"))?,
        rows,
    ))
}

fn parse_v36_prefix_source_page_header(bytes: &[u8]) -> Result<(usize, V36PrefixSourcePageClaim)> {
    let mut cursor = V36CompactCursor::new(bytes);
    let mut prior = 0;
    let mut page_type = None;
    let mut compressed_bytes = None;
    let mut uncompressed_bytes = None;
    let mut nested = None;
    while let Some((id, kind)) = cursor.field(&mut prior)? {
        match id {
            1 if kind == 5 && page_type.is_none() => page_type = Some(cursor.zigzag_i32()?),
            2 if kind == 5 && uncompressed_bytes.is_none() => {
                uncompressed_bytes = Some(cursor.zigzag_i32()?)
            }
            3 if kind == 5 && compressed_bytes.is_none() => {
                compressed_bytes = Some(cursor.zigzag_i32()?)
            }
            5 if kind == 12 => {
                let value = (
                    V36PrefixSourcePageKind::Data,
                    parse_v36_prefix_source_nested_page_header(
                        &mut cursor,
                        V36PrefixSourcePageKind::Data,
                    )?,
                );
                if nested.replace(value).is_some() {
                    return Err(invalid("V36 prefix source page-specific header overlaps"));
                }
            }
            7 if kind == 12 => {
                let value = (
                    V36PrefixSourcePageKind::Dictionary,
                    parse_v36_prefix_source_nested_page_header(
                        &mut cursor,
                        V36PrefixSourcePageKind::Dictionary,
                    )?,
                );
                if nested.replace(value).is_some() {
                    return Err(invalid("V36 prefix source page-specific header overlaps"));
                }
            }
            8 if kind == 12 => {
                let value = (
                    V36PrefixSourcePageKind::DataV2,
                    parse_v36_prefix_source_nested_page_header(
                        &mut cursor,
                        V36PrefixSourcePageKind::DataV2,
                    )?,
                );
                if nested.replace(value).is_some() {
                    return Err(invalid("V36 prefix source page-specific header overlaps"));
                }
            }
            1..=3 => return Err(invalid("V36 prefix source page header overlaps")),
            _ => cursor.skip(kind, 8)?,
        }
    }
    let (kind, (values, rows)) =
        nested.ok_or_else(|| invalid("V36 prefix source page-specific header is absent"))?;
    let expected_type = match kind {
        V36PrefixSourcePageKind::Data => 0,
        V36PrefixSourcePageKind::Dictionary => 2,
        V36PrefixSourcePageKind::DataV2 => 3,
    };
    if page_type != Some(expected_type) {
        return Err(invalid("V36 prefix source page type differs"));
    }
    Ok((
        cursor.position,
        V36PrefixSourcePageClaim {
            compressed_bytes: compressed_bytes
                .ok_or_else(|| invalid("V36 prefix source compressed page size is absent"))?,
            kind,
            rows,
            uncompressed_bytes: uncompressed_bytes
                .ok_or_else(|| invalid("V36 prefix source page size is absent"))?,
            values,
        },
    ))
}

fn validate_v36_prefix_source_page_header(
    claim: &V36PrefixSourcePageClaim,
    row_group_rows: i64,
    maximum_values_per_row: u64,
    physical_value_bytes: u64,
) -> Result<()> {
    const MAXIMUM_PAGE_BYTES: i32 = 16 * 1_048_576;
    let maximum_values = u64::try_from(row_group_rows)
        .ok()
        .and_then(|rows| rows.checked_mul(maximum_values_per_row))
        .ok_or_else(|| invalid("V36 prefix source page value bound overflows"))?;
    let values = u64::try_from(claim.values)
        .map_err(|_| invalid("V36 prefix source page value count differs"))?;
    if claim.compressed_bytes <= 0
        || claim.compressed_bytes > MAXIMUM_PAGE_BYTES
        || claim.uncompressed_bytes <= 0
        || claim.uncompressed_bytes > MAXIMUM_PAGE_BYTES
        || values == 0
        || values > maximum_values
        || claim.rows.is_some_and(|rows| {
            rows <= 0 || i64::from(rows) > row_group_rows || values < rows as u64
        })
        || (claim.kind == V36PrefixSourcePageKind::Dictionary
            && values
                .checked_mul(physical_value_bytes)
                .is_none_or(|bytes| bytes > claim.uncompressed_bytes as u64))
    {
        return Err(invalid("V36 prefix source page allocation claim differs"));
    }
    Ok(())
}

pub(crate) fn validate_v36_prefix_parquet_footer<R: ChunkReader>(file: &R) -> Result<()> {
    const MAXIMUM_FOOTER_BYTES: usize = 16 * 1_048_576;
    let length = file.len();
    if length < 12 {
        return Err(invalid("V36 prefix Parquet length differs"));
    }
    let head = file.get_bytes(0, 4)?;
    let tail = file.get_bytes(length - 8, 8)?;
    if head.as_ref() != b"PAR1" || &tail[4..] != b"PAR1" {
        return Err(invalid("V36 prefix Parquet magic differs"));
    }
    let footer_length = usize::try_from(u32::from_le_bytes(
        tail[..4]
            .try_into()
            .map_err(|_| invalid("V36 prefix Parquet footer length differs"))?,
    ))
    .map_err(|_| invalid("V36 prefix Parquet footer length overflows"))?;
    if footer_length == 0 || footer_length > MAXIMUM_FOOTER_BYTES {
        return Err(invalid("V36 prefix Parquet footer length differs"));
    }
    let footer_start = length
        .checked_sub(8)
        .and_then(|value| value.checked_sub(footer_length as u64))
        .filter(|value| *value >= 4)
        .ok_or_else(|| invalid("V36 prefix Parquet footer range differs"))?;
    let footer = file.get_bytes(footer_start, footer_length)?;
    let mut cursor = V36CompactCursor::new(&footer);
    let mut prior = 0;
    while let Some((_, kind)) = cursor.field(&mut prior)? {
        cursor.skip(kind, 32)?;
    }
    if cursor.position != footer.len() {
        return Err(invalid("V36 prefix Parquet footer bytes differ"));
    }
    Ok(())
}

pub(crate) fn validate_v36_parquet_pages<R: ChunkReader>(
    file: &R,
    row_groups: &parquet::file::metadata::ParquetMetaData,
    column_bounds: &[(u64, u64)],
) -> Result<()> {
    const MAXIMUM_HEADER_BYTES: usize = 64 * 1_024;
    for group in row_groups.row_groups() {
        if group.columns().len() != column_bounds.len() {
            return Err(invalid("V36 prefix Parquet column count differs"));
        }
        for (column_index, column) in group.columns().iter().enumerate() {
            let start = column
                .dictionary_page_offset()
                .unwrap_or_else(|| column.data_page_offset());
            let mut position = u64::try_from(start)
                .map_err(|_| invalid("V36 prefix source column offset differs"))?;
            let length = u64::try_from(column.compressed_size())
                .map_err(|_| invalid("V36 prefix source column length differs"))?;
            let end = position
                .checked_add(length)
                .ok_or_else(|| invalid("V36 prefix source column range overflows"))?;
            while position < end {
                let available = usize::try_from((end - position).min(MAXIMUM_HEADER_BYTES as u64))
                    .map_err(|_| invalid("V36 prefix source page header length overflows"))?;
                let header_bytes = file.get_bytes(position, available)?;
                let (header_length, claim) = parse_v36_prefix_source_page_header(&header_bytes)?;
                let (values_per_row, physical_bytes) = column_bounds[column_index];
                validate_v36_prefix_source_page_header(
                    &claim,
                    group.num_rows(),
                    values_per_row,
                    physical_bytes,
                )?;
                position = position
                    .checked_add(header_length as u64)
                    .and_then(|value| value.checked_add(claim.compressed_bytes as u64))
                    .filter(|value| *value <= end)
                    .ok_or_else(|| invalid("V36 prefix source page range differs"))?;
            }
            if position != end {
                return Err(invalid("V36 prefix source column range differs"));
            }
        }
    }
    Ok(())
}

fn scan_v36_prefix_source_parquet_suffix<F>(
    path: &Path,
    expected_feature_ids: &[u64],
    first_unscored_row: u64,
    mut consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch, u64) -> Result<()>,
{
    validate_expected_feature_ids(expected_feature_ids)?;
    let first_unscored_row = usize::try_from(first_unscored_row)
        .ok()
        .filter(|row| *row <= expected_feature_ids.len())
        .ok_or_else(|| invalid("V36 prefix exact truth checkpoint boundary differs"))?;
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    let mut builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    validate_parquet_descriptor(builder.parquet_schema(), &v36_prefix_source_schema())?;
    if builder.schema().as_ref() != &v36_prefix_source_schema() {
        return Err(invalid("V36 prefix source Parquet physical schema differs"));
    }
    let row_group_rows = builder
        .metadata()
        .row_groups()
        .iter()
        .map(|group| group.num_rows())
        .collect::<Vec<_>>();
    validate_v36_prefix_checkpoint_source_metadata_rows(
        builder.metadata().file_metadata().num_rows(),
        &row_group_rows,
        u64::try_from(expected_feature_ids.len())
            .map_err(|_| invalid("V36 prefix source Parquet row count overflows"))?,
    )?;
    let mut row_start = 0_usize;
    let mut selected_start = expected_feature_ids.len();
    let mut selected_row_groups = Vec::new();
    for (index, rows) in row_group_rows.into_iter().enumerate() {
        let rows = usize::try_from(rows)
            .map_err(|_| invalid("V36 prefix source Parquet row count differs"))?;
        let row_end = row_start
            .checked_add(rows)
            .ok_or_else(|| invalid("V36 prefix source Parquet row count overflows"))?;
        if row_end > first_unscored_row {
            if selected_row_groups.is_empty() {
                selected_start = row_start;
            }
            selected_row_groups.push(index);
        }
        row_start = row_end;
    }
    if selected_row_groups.is_empty() {
        return Ok(());
    }
    builder = builder.with_row_groups(selected_row_groups);
    let expected_suffix = &expected_feature_ids[selected_start..];
    let mut next_ordinal = 0_usize;
    for batch in builder.build()? {
        let batch = batch?;
        let batch_start = selected_start
            .checked_add(next_ordinal)
            .ok_or_else(|| invalid("V36 prefix source Parquet row count overflows"))?;
        validate_source_batch(&batch, expected_suffix, &mut next_ordinal)?;
        consume(
            batch,
            u64::try_from(batch_start)
                .map_err(|_| invalid("V36 prefix source Parquet row count overflows"))?,
        )?;
    }
    if next_ordinal != expected_suffix.len() {
        return Err(invalid("V36 prefix source Parquet row count differs"));
    }
    Ok(())
}

fn validate_query_batch(
    batch: &RecordBatch,
    next_ordinal: &mut u64,
    feature_ids: &mut BTreeSet<u64>,
) -> Result<()> {
    if batch.schema().as_ref() != &v36_prefix_query_schema()
        || batch.num_rows() == 0
        || batch.num_columns() != 3
        || batch
            .columns()
            .iter()
            .any(|column| column.null_count() != 0)
    {
        return Err(invalid("V36 prefix query Parquet batch differs"));
    }
    let ordinals = batch
        .column(0)
        .as_any()
        .downcast_ref::<arrow_array::UInt32Array>()
        .ok_or_else(|| invalid("V36 prefix query Parquet ordinal column differs"))?;
    let ids = batch
        .column(1)
        .as_any()
        .downcast_ref::<UInt64Array>()
        .ok_or_else(|| invalid("V36 prefix query Parquet ID column differs"))?;
    let embeddings = batch
        .column(2)
        .as_any()
        .downcast_ref::<FixedSizeListArray>()
        .ok_or_else(|| invalid("V36 prefix query Parquet embedding column differs"))?;
    let values = embeddings
        .values()
        .as_any()
        .downcast_ref::<Float32Array>()
        .ok_or_else(|| invalid("V36 prefix query Parquet embedding child differs"))?;
    if values.null_count() != 0 || values.len() != batch.num_rows() * DIMENSIONS {
        return Err(invalid("V36 prefix query Parquet embedding shape differs"));
    }
    for row in 0..batch.num_rows() {
        if u64::from(ordinals.value(row)) != *next_ordinal || !feature_ids.insert(ids.value(row)) {
            return Err(invalid("V36 prefix query Parquet ordering differs"));
        }
        let start = row * DIMENSIONS;
        validate_embedding(&values.values()[start..start + DIMENSIONS])?;
        *next_ordinal = next_ordinal
            .checked_add(1)
            .ok_or_else(|| invalid("V36 prefix query Parquet row count overflows"))?;
    }
    Ok(())
}

/// Write validated query batches without retaining all query vectors in RAM.
pub fn write_v36_prefix_query_parquet<I>(path: &Path, batches: I) -> Result<()>
where
    I: IntoIterator<Item = RecordBatch>,
{
    let mut temporary = temporary_output(path)?;
    let mut writer = ArrowWriter::try_new(
        temporary.as_file_mut(),
        Arc::new(v36_prefix_query_schema()),
        Some(parquet_writer_properties()),
    )?;
    let mut feature_ids = BTreeSet::new();
    let mut next_ordinal = 0_u64;
    for batch in batches {
        validate_query_batch(&batch, &mut next_ordinal, &mut feature_ids)?;
        writer.write(&batch)?;
    }
    if next_ordinal == 0 {
        return Err(invalid("V36 prefix query Parquet is empty"));
    }
    writer.close()?;
    publish_output(temporary, path)?;
    Ok(())
}

/// Stream and validate a complete query Parquet artifact.
pub fn scan_v36_prefix_query_parquet<F>(path: &Path, expected_rows: u64, consume: F) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    scan_v36_prefix_query_parquet_file(file, path, expected_rows, consume)
}

pub(crate) fn scan_v36_prefix_query_parquet_file<F>(
    file: File,
    _display_path: &Path,
    expected_rows: u64,
    mut consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    if expected_rows == 0 {
        return Err(invalid("V36 prefix query Parquet row count differs"));
    }
    let builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    validate_parquet_descriptor(builder.parquet_schema(), &v36_prefix_query_schema())?;
    if builder.schema().as_ref() != &v36_prefix_query_schema() {
        return Err(invalid("V36 prefix query Parquet physical schema differs"));
    }
    let mut feature_ids = BTreeSet::new();
    let mut next_ordinal = 0_u64;
    for batch in builder.build()? {
        let batch = batch?;
        validate_query_batch(&batch, &mut next_ordinal, &mut feature_ids)?;
        consume(batch)?;
    }
    if next_ordinal != expected_rows {
        return Err(invalid("V36 prefix query Parquet row count differs"));
    }
    Ok(())
}

#[derive(Default)]
struct GtValidationState {
    next_query: u32,
    next_rank: u16,
    prior: Option<(f64, u64)>,
    feature_ids: BTreeSet<u64>,
    rows: u64,
}

fn validate_gt_batch(batch: &RecordBatch, state: &mut GtValidationState) -> Result<()> {
    if batch.schema().as_ref() != &v36_prefix_gt100_schema()
        || batch.num_rows() == 0
        || batch.num_columns() != 4
        || batch
            .columns()
            .iter()
            .any(|column| column.null_count() != 0)
    {
        return Err(invalid("V36 prefix GT Parquet batch differs"));
    }
    let queries = batch
        .column(0)
        .as_any()
        .downcast_ref::<arrow_array::UInt32Array>()
        .ok_or_else(|| invalid("V36 prefix GT query column differs"))?;
    let ranks = batch
        .column(1)
        .as_any()
        .downcast_ref::<arrow_array::UInt16Array>()
        .ok_or_else(|| invalid("V36 prefix GT rank column differs"))?;
    let ids = batch
        .column(2)
        .as_any()
        .downcast_ref::<UInt64Array>()
        .ok_or_else(|| invalid("V36 prefix GT ID column differs"))?;
    let distances = batch
        .column(3)
        .as_any()
        .downcast_ref::<arrow_array::Float64Array>()
        .ok_or_else(|| invalid("V36 prefix GT distance column differs"))?;
    for row in 0..batch.num_rows() {
        let distance = distances.value(row);
        let id = ids.value(row);
        if queries.value(row) != state.next_query
            || ranks.value(row) != state.next_rank
            || !distance.is_finite()
            || distance < 0.0
            || !state.feature_ids.insert(id)
            || state
                .prior
                .is_some_and(|prior| prior.0.total_cmp(&distance).then(prior.1.cmp(&id)).is_gt())
        {
            return Err(invalid("V36 prefix GT ordering differs"));
        }
        state.rows = state
            .rows
            .checked_add(1)
            .ok_or_else(|| invalid("V36 prefix GT row count overflows"))?;
        if usize::from(state.next_rank) + 1 == GT_NEIGHBORS {
            state.next_query = state
                .next_query
                .checked_add(1)
                .ok_or_else(|| invalid("V36 prefix GT query count overflows"))?;
            state.next_rank = 0;
            state.prior = None;
            state.feature_ids.clear();
        } else {
            state.next_rank += 1;
            state.prior = Some((distance, id));
        }
    }
    Ok(())
}

/// Write validated exact-GT batches.
pub fn write_v36_prefix_gt100_parquet<I>(path: &Path, batches: I) -> Result<()>
where
    I: IntoIterator<Item = RecordBatch>,
{
    let mut temporary = temporary_output(path)?;
    let mut writer = ArrowWriter::try_new(
        temporary.as_file_mut(),
        Arc::new(v36_prefix_gt100_schema()),
        Some(parquet_writer_properties()),
    )?;
    let mut state = GtValidationState::default();
    for batch in batches {
        validate_gt_batch(&batch, &mut state)?;
        writer.write(&batch)?;
    }
    if state.rows == 0 || state.next_rank != 0 {
        return Err(invalid("V36 prefix GT row count differs"));
    }
    writer.close()?;
    publish_output(temporary, path)?;
    Ok(())
}

/// Stream and validate exact GT@100 for an exact query count.
pub fn scan_v36_prefix_gt100_parquet<F>(
    path: &Path,
    expected_queries: u32,
    consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    scan_v36_prefix_gt100_parquet_file(file, path, expected_queries, consume)
}

pub(crate) fn scan_v36_prefix_gt100_parquet_file<F>(
    mut file: File,
    display_path: &Path,
    expected_queries: u32,
    mut consume: F,
) -> Result<()>
where
    F: FnMut(RecordBatch) -> Result<()>,
{
    if expected_queries == 0 {
        return Err(invalid("V36 prefix GT query count differs"));
    }
    v36_prefix_external_io(display_path, file.seek(SeekFrom::Start(0)))?;
    let page_file = file.try_clone().map_err(|source| BorsukError::Io {
        path: display_path.to_owned(),
        source,
    })?;
    validate_v36_prefix_parquet_footer(&page_file)?;
    let mut builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    validate_parquet_descriptor(builder.parquet_schema(), &v36_prefix_gt100_schema())?;
    if builder.schema().as_ref() != &v36_prefix_gt100_schema() {
        return Err(invalid("V36 prefix GT physical schema differs"));
    }
    let maximum_rows = usize::try_from(expected_queries)
        .ok()
        .and_then(|queries| queries.checked_mul(GT_NEIGHBORS))
        .ok_or_else(|| invalid("V36 prefix GT row count overflows"))?;
    let row_groups = builder
        .metadata()
        .row_groups()
        .iter()
        .map(|group| {
            let compressed = group.columns().iter().try_fold(0_i64, |total, column| {
                total.checked_add(column.compressed_size())
            });
            let uncompressed = group.columns().iter().try_fold(0_i64, |total, column| {
                total.checked_add(column.uncompressed_size())
            });
            compressed
                .zip(uncompressed)
                .map(|(compressed, uncompressed)| (group.num_rows(), compressed, uncompressed))
                .ok_or_else(|| invalid("V36 prefix GT decoder size overflows"))
        })
        .collect::<Result<Vec<_>>>()?;
    validate_v36_prefix_source_decoder_bounds(
        &row_groups,
        maximum_rows,
        SOURCE_DECODER_COMPRESSED_CAP_BYTES,
        SOURCE_DECODER_UNCOMPRESSED_CAP_BYTES,
    )?;
    validate_v36_parquet_pages(
        &page_file,
        builder.metadata(),
        &[(1, 4), (1, 2), (1, 8), (1, 8)],
    )?;
    builder = builder.with_batch_size(PARQUET_ROW_GROUP_ROWS);
    let mut state = GtValidationState::default();
    for batch in builder.build()? {
        let batch = batch?;
        validate_gt_batch(&batch, &mut state)?;
        consume(batch)?;
    }
    if state.next_query != expected_queries || state.next_rank != 0 {
        return Err(invalid("V36 prefix GT query count differs"));
    }
    Ok(())
}

fn validate_v36_prefix_gt100_matches_heap(
    path: &Path,
    expected: &[V36PrefixGtNeighbor],
    expected_queries: u32,
) -> Result<()> {
    let mut next = 0_usize;
    scan_v36_prefix_gt100_parquet(path, expected_queries, |batch| {
        let queries = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt32Array>()
            .ok_or_else(|| invalid("V36 prefix GT query column differs"))?;
        let ranks = batch
            .column(1)
            .as_any()
            .downcast_ref::<UInt16Array>()
            .ok_or_else(|| invalid("V36 prefix GT rank column differs"))?;
        let ids = batch
            .column(2)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix GT ID column differs"))?;
        let distances = batch
            .column(3)
            .as_any()
            .downcast_ref::<Float64Array>()
            .ok_or_else(|| invalid("V36 prefix GT distance column differs"))?;
        for row in 0..batch.num_rows() {
            let expected = expected
                .get(next)
                .ok_or_else(|| invalid("V36 prefix GT heap binding differs"))?;
            if queries.value(row) != expected.query_ordinal
                || ranks.value(row) != expected.rank
                || ids.value(row) != expected.feature_row_id
                || distances.value(row).to_bits() != expected.squared_distance.to_bits()
            {
                return Err(invalid("V36 prefix GT heap binding differs"));
            }
            next += 1;
        }
        Ok(())
    })?;
    if next != expected.len() {
        return Err(invalid("V36 prefix GT heap binding differs"));
    }
    Ok(())
}

#[derive(Debug, Clone, Copy)]
struct RankedNeighbor {
    distance: f64,
    feature_row_id: u64,
}

impl PartialEq for RankedNeighbor {
    fn eq(&self, other: &Self) -> bool {
        self.distance.to_bits() == other.distance.to_bits()
            && self.feature_row_id == other.feature_row_id
    }
}

impl Eq for RankedNeighbor {}

impl PartialOrd for RankedNeighbor {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for RankedNeighbor {
    fn cmp(&self, other: &Self) -> Ordering {
        self.distance
            .total_cmp(&other.distance)
            .then(self.feature_row_id.cmp(&other.feature_row_id))
    }
}

fn squared_l2(left: &[f32], right: &[f32]) -> f64 {
    left.iter().zip(right).fold(0.0_f64, |sum, (left, right)| {
        let delta = f64::from(*left) - f64::from(*right);
        let squared = delta * delta;
        sum + squared
    })
}

/// Bounded exact-GT state that consumes the corpus in source-ordinal batches.
pub struct V36PrefixGtAccumulator {
    queries: Vec<V36PrefixQueryRow>,
    query_ids: BTreeSet<u64>,
    corpus_ids: BTreeSet<u64>,
    heaps: Vec<BinaryHeap<RankedNeighbor>>,
    next_source_ordinal: u64,
    role: V36PrefixQualityRole,
}

impl V36PrefixGtAccumulator {
    fn record_corpus(&mut self, corpus: &[V36PrefixMaterializedRow]) -> Result<()> {
        for row in corpus {
            if row.source_ordinal != Some(self.next_source_ordinal)
                || validate_embedding(&row.embedding).is_err()
                || self.query_ids.contains(&row.feature_row_id)
                || !self.corpus_ids.insert(row.feature_row_id)
            {
                return Err(invalid("V36 prefix exact truth corpus input differs"));
            }
            self.next_source_ordinal = self
                .next_source_ordinal
                .checked_add(1)
                .ok_or_else(|| invalid("V36 prefix exact truth corpus size overflows"))?;
        }
        Ok(())
    }

    fn absorb_with_pool(
        &mut self,
        corpus: &[V36PrefixMaterializedRow],
        pool: &rayon::ThreadPool,
    ) -> Result<()> {
        self.record_corpus(corpus)?;
        let queries = &self.queries;
        pool.install(|| {
            self.heaps
                .par_iter_mut()
                .zip(queries.par_iter())
                .for_each(|(heap, query)| {
                    for row in corpus {
                        update_v36_prefix_gt_heap(heap, query, row);
                    }
                });
        });
        Ok(())
    }

    /// Create a GT tile accumulator for one quality-query role.
    pub fn new(role: V36PrefixQualityRole, queries: Vec<V36PrefixQueryRow>) -> Result<Self> {
        let first_ordinal = queries.first().map(|row| row.query_ordinal);
        if queries.is_empty()
            || queries.iter().enumerate().any(|(ordinal, row)| {
                first_ordinal
                    .and_then(|first| first.checked_add(u32::try_from(ordinal).unwrap_or(u32::MAX)))
                    != Some(row.query_ordinal)
                    || validate_embedding(&row.embedding).is_err()
            })
        {
            return Err(invalid("V36 prefix exact truth query input differs"));
        }
        let query_ids = queries
            .iter()
            .map(|query| query.feature_row_id)
            .collect::<BTreeSet<_>>();
        if query_ids.len() != queries.len() {
            return Err(invalid("V36 prefix exact truth query membership differs"));
        }
        let heaps = (0..queries.len())
            .map(|_| BinaryHeap::with_capacity(GT_HEAP_CHECKPOINT_NEIGHBORS))
            .collect();
        Ok(Self {
            queries,
            query_ids,
            corpus_ids: BTreeSet::new(),
            heaps,
            next_source_ordinal: 0,
            role,
        })
    }

    /// Restore one role from a validated top-101 source-block boundary.
    pub fn restore(
        role: V36PrefixQualityRole,
        queries: Vec<V36PrefixQueryRow>,
        next_source_ordinal: u64,
        prefix_feature_ids: &[u64],
        entries: Vec<V36PrefixGtHeapEntry>,
    ) -> Result<Self> {
        let mut accumulator = Self::new(role, queries)?;
        let expected_entries = accumulator
            .queries
            .len()
            .checked_mul(GT_HEAP_CHECKPOINT_NEIGHBORS)
            .ok_or_else(|| invalid("V36 prefix GT heap row count overflows"))?;
        if next_source_ordinal < GT_HEAP_CHECKPOINT_NEIGHBORS as u64
            || usize::try_from(next_source_ordinal).ok() != Some(prefix_feature_ids.len())
            || entries.len() != expected_entries
        {
            return Err(invalid("V36 prefix GT heap checkpoint differs"));
        }
        for &feature_row_id in prefix_feature_ids {
            if accumulator.query_ids.contains(&feature_row_id)
                || !accumulator.corpus_ids.insert(feature_row_id)
            {
                return Err(invalid("V36 prefix exact truth corpus input differs"));
            }
        }
        let (entry_chunks, remainder) = entries.as_chunks::<GT_HEAP_CHECKPOINT_NEIGHBORS>();
        if !remainder.is_empty() {
            return Err(invalid("V36 prefix GT heap checkpoint differs"));
        }
        for (query_index, (query, entries)) in
            accumulator.queries.iter().zip(entry_chunks).enumerate()
        {
            let mut feature_ids = BTreeSet::new();
            let mut previous: Option<(f64, u64)> = None;
            for (rank, entry) in entries.iter().enumerate() {
                let ordered = previous.is_none_or(|(distance, feature_row_id)| {
                    distance
                        .total_cmp(&entry.squared_distance)
                        .then(feature_row_id.cmp(&entry.feature_row_id))
                        .is_le()
                });
                if entry.role != role
                    || entry.query_ordinal != query.query_ordinal
                    || usize::from(entry.rank) != rank
                    || !entry.squared_distance.is_finite()
                    || entry.squared_distance.is_sign_negative()
                    || !accumulator.corpus_ids.contains(&entry.feature_row_id)
                    || !feature_ids.insert(entry.feature_row_id)
                    || !ordered
                {
                    return Err(invalid("V36 prefix GT heap entry differs"));
                }
                accumulator.heaps[query_index].push(RankedNeighbor {
                    distance: entry.squared_distance,
                    feature_row_id: entry.feature_row_id,
                });
                previous = Some((entry.squared_distance, entry.feature_row_id));
            }
        }
        accumulator.next_source_ordinal = next_source_ordinal;
        Ok(accumulator)
    }

    /// Snapshot this role's canonical top-101 heaps for durable publication.
    pub fn checkpoint_entries(&self) -> Result<Vec<V36PrefixGtHeapEntry>> {
        if self.next_source_ordinal < GT_HEAP_CHECKPOINT_NEIGHBORS as u64
            || self
                .heaps
                .iter()
                .any(|heap| heap.len() != GT_HEAP_CHECKPOINT_NEIGHBORS)
        {
            return Err(invalid("V36 prefix exact truth corpus is insufficient"));
        }
        let mut entries = Vec::with_capacity(
            self.queries
                .len()
                .checked_mul(GT_HEAP_CHECKPOINT_NEIGHBORS)
                .ok_or_else(|| invalid("V36 prefix GT heap row count overflows"))?,
        );
        for (query, heap) in self.queries.iter().zip(&self.heaps) {
            let mut neighbors = heap.clone().into_vec();
            neighbors.sort();
            entries.extend(neighbors.into_iter().enumerate().map(|(rank, neighbor)| {
                V36PrefixGtHeapEntry {
                    feature_row_id: neighbor.feature_row_id,
                    query_ordinal: query.query_ordinal,
                    rank: u16::try_from(rank).unwrap(),
                    role: self.role,
                    squared_distance: neighbor.distance,
                }
            }));
        }
        Ok(entries)
    }

    /// Absorb one validated, source-ordered corpus batch.
    pub fn absorb(&mut self, corpus: &[V36PrefixMaterializedRow]) -> Result<()> {
        self.record_corpus(corpus)?;
        for row in corpus {
            for (query, heap) in self.queries.iter().zip(&mut self.heaps) {
                update_v36_prefix_gt_heap(heap, query, row);
            }
        }
        Ok(())
    }

    /// Finish one complete GT tile in `(query_ordinal,rank)` order.
    pub fn finish(self) -> Result<Vec<V36PrefixGtNeighbor>> {
        if self.next_source_ordinal < GT_HEAP_CHECKPOINT_NEIGHBORS as u64
            || self
                .heaps
                .iter()
                .any(|heap| heap.len() != GT_HEAP_CHECKPOINT_NEIGHBORS)
        {
            return Err(invalid("V36 prefix exact truth corpus is insufficient"));
        }
        let mut truth = Vec::with_capacity(self.queries.len() * GT_NEIGHBORS);
        for (query, heap) in self.queries.iter().zip(self.heaps) {
            let mut neighbors = heap.into_vec();
            neighbors.sort();
            truth.extend(neighbors.into_iter().take(GT_NEIGHBORS).enumerate().map(
                |(rank, neighbor)| V36PrefixGtNeighbor {
                    query_ordinal: query.query_ordinal,
                    rank: u16::try_from(rank).unwrap(),
                    feature_row_id: neighbor.feature_row_id,
                    squared_distance: neighbor.distance,
                },
            ));
        }
        Ok(truth)
    }
}

fn update_v36_prefix_gt_heap(
    heap: &mut BinaryHeap<RankedNeighbor>,
    query: &V36PrefixQueryRow,
    row: &V36PrefixMaterializedRow,
) {
    let candidate = RankedNeighbor {
        distance: squared_l2(&row.embedding, &query.embedding),
        feature_row_id: row.feature_row_id,
    };
    if heap.len() < GT_HEAP_CHECKPOINT_NEIGHBORS {
        heap.push(candidate);
    } else if heap.peek().is_some_and(|worst| candidate < *worst) {
        heap.pop();
        heap.push(candidate);
    }
}

/// All quality roles advanced at one common exact-GT source boundary.
pub struct V36PrefixAllQueryGtAccumulator {
    accumulators: [V36PrefixGtAccumulator; 3],
    query_ids: BTreeSet<u64>,
}

impl V36PrefixAllQueryGtAccumulator {
    fn absorb_with_pool(
        &mut self,
        corpus: &[V36PrefixMaterializedRow],
        pool: &rayon::ThreadPool,
    ) -> Result<()> {
        self.prevalidate_corpus(corpus)?;
        for accumulator in &mut self.accumulators {
            accumulator.absorb_with_pool(corpus, pool)?;
        }
        Ok(())
    }

    fn prevalidate_corpus(&self, corpus: &[V36PrefixMaterializedRow]) -> Result<()> {
        let mut ordinal = self.accumulators[0].next_source_ordinal;
        let mut batch_ids = BTreeSet::new();
        for row in corpus {
            if row.source_ordinal != Some(ordinal)
                || validate_embedding(&row.embedding).is_err()
                || self.query_ids.contains(&row.feature_row_id)
                || self.accumulators[0]
                    .corpus_ids
                    .contains(&row.feature_row_id)
                || !batch_ids.insert(row.feature_row_id)
            {
                return Err(invalid("V36 prefix exact truth corpus input differs"));
            }
            ordinal = ordinal
                .checked_add(1)
                .ok_or_else(|| invalid("V36 prefix exact truth corpus size overflows"))?;
        }
        Ok(())
    }

    /// Create synchronized development, validation, and sealed-holdout heaps.
    pub fn new(queries: [Vec<V36PrefixQueryRow>; 3]) -> Result<Self> {
        let mut query_ids = BTreeSet::new();
        if queries
            .iter()
            .flatten()
            .any(|query| !query_ids.insert(query.feature_row_id))
        {
            return Err(invalid("V36 prefix exact truth query membership differs"));
        }
        let [development, validation, holdout] = queries;
        Ok(Self {
            accumulators: [
                V36PrefixGtAccumulator::new(V36PrefixQualityRole::Development, development)?,
                V36PrefixGtAccumulator::new(V36PrefixQualityRole::Validation, validation)?,
                V36PrefixGtAccumulator::new(V36PrefixQualityRole::SealedHoldout, holdout)?,
            ],
            query_ids,
        })
    }

    /// Restore all roles from one authenticated all-query heap checkpoint.
    pub fn restore(
        queries: [Vec<V36PrefixQueryRow>; 3],
        prefix_feature_ids: &[u64],
        checkpoint: V36PrefixGtHeapCheckpoint,
    ) -> Result<Self> {
        let expected_counts = queries
            .each_ref()
            .map(|rows| u32::try_from(rows.len()).ok());
        if expected_counts.map(|count| count.unwrap_or(u32::MAX)) != checkpoint.query_counts {
            return Err(invalid("V36 prefix GT heap query count differs"));
        }
        let mut query_ids = BTreeSet::new();
        if queries
            .iter()
            .flatten()
            .any(|query| !query_ids.insert(query.feature_row_id))
        {
            return Err(invalid("V36 prefix exact truth query membership differs"));
        }
        let [development, validation, holdout] = queries;
        let first = usize::try_from(checkpoint.query_counts[0])
            .ok()
            .and_then(|count| count.checked_mul(GT_HEAP_CHECKPOINT_NEIGHBORS))
            .ok_or_else(|| invalid("V36 prefix GT heap row count overflows"))?;
        let second = usize::try_from(checkpoint.query_counts[1])
            .ok()
            .and_then(|count| count.checked_mul(GT_HEAP_CHECKPOINT_NEIGHBORS))
            .and_then(|count| first.checked_add(count))
            .ok_or_else(|| invalid("V36 prefix GT heap row count overflows"))?;
        let holdout_entries = checkpoint
            .entries
            .get(second..)
            .unwrap_or_default()
            .to_vec();
        let validation_entries = checkpoint
            .entries
            .get(first..second)
            .unwrap_or_default()
            .to_vec();
        let development_entries = checkpoint.entries.get(..first).unwrap_or_default().to_vec();
        Ok(Self {
            accumulators: [
                V36PrefixGtAccumulator::restore(
                    V36PrefixQualityRole::Development,
                    development,
                    checkpoint.next_source_ordinal,
                    prefix_feature_ids,
                    development_entries,
                )?,
                V36PrefixGtAccumulator::restore(
                    V36PrefixQualityRole::Validation,
                    validation,
                    checkpoint.next_source_ordinal,
                    prefix_feature_ids,
                    validation_entries,
                )?,
                V36PrefixGtAccumulator::restore(
                    V36PrefixQualityRole::SealedHoldout,
                    holdout,
                    checkpoint.next_source_ordinal,
                    prefix_feature_ids,
                    holdout_entries,
                )?,
            ],
            query_ids,
        })
    }

    /// Absorb one complete canonical source block into every quality role.
    pub fn absorb(&mut self, corpus: &[V36PrefixMaterializedRow]) -> Result<()> {
        self.prevalidate_corpus(corpus)?;
        for accumulator in &mut self.accumulators {
            accumulator.absorb(corpus)?;
        }
        Ok(())
    }

    /// Snapshot every role at their shared next source ordinal.
    pub fn checkpoint(&self) -> Result<V36PrefixGtHeapCheckpoint> {
        let next_source_ordinal = self.accumulators[0].next_source_ordinal;
        if self
            .accumulators
            .iter()
            .any(|accumulator| accumulator.next_source_ordinal != next_source_ordinal)
        {
            return Err(invalid("V36 prefix GT heap checkpoint differs"));
        }
        let mut entries = Vec::new();
        for accumulator in &self.accumulators {
            entries.extend(accumulator.checkpoint_entries()?);
        }
        let query_counts = self.accumulators.each_ref().map(|accumulator| {
            u32::try_from(accumulator.queries.len()).expect("validated query count fits u32")
        });
        let checkpoint = V36PrefixGtHeapCheckpoint {
            entries,
            next_source_ordinal,
            query_counts,
        };
        validate_v36_prefix_gt_heap_checkpoint(&checkpoint)?;
        Ok(checkpoint)
    }

    /// Finish every role as canonical GT@100 after retaining rank 101 evidence.
    pub fn finish(self) -> Result<[Vec<V36PrefixGtNeighbor>; 3]> {
        let [development, validation, holdout] = self.accumulators;
        Ok([
            development.finish()?,
            validation.finish()?,
            holdout.finish()?,
        ])
    }
}

/// Exact binary64 no-explicit-FMA GT@100 for quality queries.
pub fn exact_v36_prefix_gt100(
    role: V36PrefixQualityRole,
    corpus: &[V36PrefixMaterializedRow],
    queries: &[V36PrefixQueryRow],
) -> Result<Vec<V36PrefixGtNeighbor>> {
    let mut accumulator = V36PrefixGtAccumulator::new(role, queries.to_vec())?;
    accumulator.absorb(corpus)?;
    accumulator.finish()
}

/// Compute every quality role from one schema-validated source scan, exposing only
/// complete source-block checkpoints that can be resumed without rescoring the prefix.
///
/// The caller owns artifact authentication and must bind each consumed checkpoint
/// through the authenticated ground-truth checkpoint manifest before publication.
pub fn run_v36_prefix_gt100_checkpointed<F>(
    source_path: &Path,
    expected_source_feature_ids: &[u64],
    queries: [Vec<V36PrefixQueryRow>; 3],
    prior: Option<V36PrefixGtHeapCheckpoint>,
    block_rows: usize,
    worker_threads: usize,
    mut consume_checkpoint: F,
) -> Result<([Vec<V36PrefixGtNeighbor>; 3], V36PrefixGtRunStats)>
where
    F: FnMut(&V36PrefixGtHeapCheckpoint) -> Result<()>,
{
    if !(GT_HEAP_CHECKPOINT_NEIGHBORS..=PARQUET_ROW_GROUP_ROWS).contains(&block_rows)
        || !(1..=16).contains(&worker_threads)
    {
        return Err(invalid("V36 prefix exact truth checkpoint run differs"));
    }
    let query_counts = [
        u32::try_from(queries[0].len())
            .map_err(|_| invalid("V36 prefix exact truth query count overflows"))?,
        u32::try_from(queries[1].len())
            .map_err(|_| invalid("V36 prefix exact truth query count overflows"))?,
        u32::try_from(queries[2].len())
            .map_err(|_| invalid("V36 prefix exact truth query count overflows"))?,
    ];
    v36_prefix_gt_heap_expected_rows(query_counts)?;
    let quality_queries = query_counts.into_iter().sum();
    let prior_next = prior
        .as_ref()
        .map_or(0, |checkpoint| checkpoint.next_source_ordinal);
    let prior_rows = usize::try_from(prior_next)
        .ok()
        .filter(|rows| *rows <= expected_source_feature_ids.len())
        .ok_or_else(|| invalid("V36 prefix exact truth checkpoint boundary differs"))?;
    if prior_rows % block_rows != 0 && prior_rows != expected_source_feature_ids.len() {
        return Err(invalid(
            "V36 prefix exact truth checkpoint boundary differs",
        ));
    }
    let mut accumulator = match prior {
        Some(checkpoint) => V36PrefixAllQueryGtAccumulator::restore(
            queries,
            &expected_source_feature_ids[..prior_rows],
            checkpoint,
        )?,
        None => V36PrefixAllQueryGtAccumulator::new(queries)?,
    };
    let pool = ThreadPoolBuilder::new()
        .num_threads(worker_threads)
        .build()
        .map_err(|_| invalid("V36 prefix exact truth worker pool differs"))?;
    let mut pending = Vec::with_capacity(block_rows);
    scan_v36_prefix_source_parquet_suffix(
        source_path,
        expected_source_feature_ids,
        prior_next,
        |source_batch, batch_start| {
            let mut decoded_source_rows = batch_start;
            let rows = v36_prefix_source_rows_from_batch(&source_batch, &mut decoded_source_rows)?;
            pending.extend(rows.into_iter().filter(|row| {
                row.source_ordinal
                    .is_some_and(|ordinal| ordinal >= prior_next)
            }));
            while pending.len() >= block_rows {
                let remaining = pending.split_off(block_rows);
                accumulator.absorb_with_pool(&pending, &pool)?;
                consume_checkpoint(&accumulator.checkpoint()?)?;
                pending = remaining;
            }
            Ok(())
        },
    )?;
    if !pending.is_empty() {
        accumulator.absorb_with_pool(&pending, &pool)?;
        consume_checkpoint(&accumulator.checkpoint()?)?;
    }
    let truth = accumulator.finish()?;
    let source_rows = u64::try_from(expected_source_feature_ids.len())
        .map_err(|_| invalid("V36 prefix exact truth corpus size overflows"))?;
    Ok((
        truth,
        V36PrefixGtRunStats {
            quality_queries,
            source_scans: 1,
            source_rows,
        },
    ))
}

pub(crate) fn v36_prefix_query_rows_from_batch(
    batch: &RecordBatch,
    offset: usize,
    rows: usize,
) -> Result<Vec<V36PrefixQueryRow>> {
    let ordinals = batch
        .column(0)
        .as_any()
        .downcast_ref::<UInt32Array>()
        .ok_or_else(|| invalid("V36 prefix query Parquet ordinal column differs"))?;
    let ids = batch
        .column(1)
        .as_any()
        .downcast_ref::<UInt64Array>()
        .ok_or_else(|| invalid("V36 prefix query Parquet ID column differs"))?;
    let embeddings = batch
        .column(2)
        .as_any()
        .downcast_ref::<FixedSizeListArray>()
        .ok_or_else(|| invalid("V36 prefix query Parquet embedding column differs"))?;
    let values = embeddings
        .values()
        .as_any()
        .downcast_ref::<Float32Array>()
        .ok_or_else(|| invalid("V36 prefix query Parquet embedding child differs"))?;
    (offset..offset + rows)
        .map(|row| {
            let start = row * DIMENSIONS;
            let embedding = values.values()[start..start + DIMENSIONS].to_vec();
            validate_embedding(&embedding)?;
            Ok(V36PrefixQueryRow {
                query_ordinal: ordinals.value(row),
                feature_row_id: ids.value(row),
                embedding,
            })
        })
        .collect()
}

fn validate_v36_prefix_checkpoint_source_metadata_rows(
    declared_rows: i64,
    row_group_rows: &[i64],
    expected_rows: u64,
) -> Result<usize> {
    let expected = i64::try_from(expected_rows)
        .ok()
        .filter(|rows| *rows >= i64::try_from(GT_HEAP_CHECKPOINT_NEIGHBORS).unwrap())
        .ok_or_else(|| invalid("V36 prefix source Parquet row count differs"))?;
    let mut total = 0_i64;
    for rows in row_group_rows {
        if *rows <= 0 {
            return Err(invalid("V36 prefix source Parquet row count differs"));
        }
        total = total
            .checked_add(*rows)
            .ok_or_else(|| invalid("V36 prefix source Parquet row count overflows"))?;
    }
    if row_group_rows.is_empty() || declared_rows != total || total != expected {
        return Err(invalid("V36 prefix source Parquet row count differs"));
    }
    usize::try_from(expected).map_err(|_| invalid("V36 prefix source Parquet row count overflows"))
}

fn load_v36_prefix_checkpoint_source_ids(path: &Path, expected_rows: u64) -> Result<Vec<u64>> {
    let file = File::open(path).map_err(|source| BorsukError::Io {
        path: path.to_owned(),
        source,
    })?;
    load_v36_prefix_checkpoint_source_ids_file(file, path, expected_rows)
}

pub(crate) fn load_v36_prefix_source_feature_ids_file(
    file: File,
    display_path: &Path,
    expected_rows: u64,
) -> Result<Vec<u64>> {
    load_v36_prefix_checkpoint_source_ids_file(file, display_path, expected_rows)
}

fn load_v36_prefix_checkpoint_source_ids_file(
    mut file: File,
    display_path: &Path,
    expected_rows: u64,
) -> Result<Vec<u64>> {
    v36_prefix_external_io(display_path, file.seek(SeekFrom::Start(0)))?;
    let page_file = file.try_clone().map_err(|source| BorsukError::Io {
        path: display_path.to_owned(),
        source,
    })?;
    validate_v36_prefix_parquet_footer(&page_file)?;
    let mut builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
    validate_parquet_descriptor(builder.parquet_schema(), &v36_prefix_source_schema())?;
    if builder.schema().as_ref() != &v36_prefix_source_schema() {
        return Err(invalid("V36 prefix source Parquet physical schema differs"));
    }
    let row_groups = builder
        .metadata()
        .row_groups()
        .iter()
        .map(|group| {
            let compressed = group.columns().iter().try_fold(0_i64, |total, column| {
                total.checked_add(column.compressed_size())
            });
            let uncompressed = group.columns().iter().try_fold(0_i64, |total, column| {
                total.checked_add(column.uncompressed_size())
            });
            compressed
                .zip(uncompressed)
                .map(|(compressed, uncompressed)| (group.num_rows(), compressed, uncompressed))
                .ok_or_else(|| invalid("V36 prefix source decoder size overflows"))
        })
        .collect::<Result<Vec<_>>>()?;
    validate_v36_prefix_source_decoder_bounds(
        &row_groups,
        PARQUET_ROW_GROUP_ROWS,
        SOURCE_DECODER_COMPRESSED_CAP_BYTES,
        SOURCE_DECODER_UNCOMPRESSED_CAP_BYTES,
    )?;
    validate_v36_parquet_pages(
        &page_file,
        builder.metadata(),
        &[(1, 8), (DIMENSIONS as u64, 4)],
    )?;
    let declared_rows = validate_v36_prefix_checkpoint_source_metadata_rows(
        builder.metadata().file_metadata().num_rows(),
        &builder
            .metadata()
            .row_groups()
            .iter()
            .map(|group| group.num_rows())
            .collect::<Vec<_>>(),
        expected_rows,
    )?;
    let projection = ProjectionMask::roots(builder.parquet_schema(), [0]);
    builder = builder
        .with_projection(projection)
        .with_batch_size(PARQUET_ROW_GROUP_ROWS);
    let mut ids = Vec::with_capacity(declared_rows);
    let mut unique = BTreeSet::new();
    for batch in builder.build()? {
        let batch = batch?;
        let values = batch
            .column(0)
            .as_any()
            .downcast_ref::<UInt64Array>()
            .ok_or_else(|| invalid("V36 prefix source Parquet ID column differs"))?;
        if batch.num_columns() != 1
            || batch.num_rows() == 0
            || values.null_count() != 0
            || values.iter().flatten().any(|id| !unique.insert(id))
        {
            return Err(invalid("V36 prefix source Parquet membership differs"));
        }
        ids.extend(values.values());
        if ids.len() > declared_rows {
            return Err(invalid("V36 prefix source Parquet row count differs"));
        }
    }
    if ids.len() != declared_rows {
        return Err(invalid("V36 prefix source Parquet row count differs"));
    }
    Ok(ids)
}

/// Load the exact ordered feature IDs from an already authenticated V36 source
/// Parquet without decoding its embedding column.
///
/// The offline geometry oracle uses this bounded identity-only pass to reuse
/// the prefix-freeze schema and membership validation. Complete-object byte
/// authentication remains the caller's mandatory preceding boundary.
pub fn load_v36_prefix_source_feature_ids(path: &Path, expected_rows: u64) -> Result<Vec<u64>> {
    load_v36_prefix_checkpoint_source_ids(path, expected_rows)
}

fn load_v36_prefix_checkpoint_queries(
    artifacts: &V36PrefixMaterializedCheckpointFiles,
) -> Result<[Vec<V36PrefixQueryRow>; 3]> {
    let mut remaining = u32::try_from(GT_HEAP_CHECKPOINT_MAX_QUERIES).unwrap();
    let mut output = [Vec::new(), Vec::new(), Vec::new()];
    for (queries, artifact) in output.iter_mut().zip([
        &artifacts.development_query,
        &artifacts.validation_query,
        &artifacts.sealed_holdout_query,
    ]) {
        let count = validate_v36_prefix_checkpoint_query_file(&artifact.path, remaining)?;
        scan_v36_prefix_query_parquet(&artifact.path, u64::from(count), |batch| {
            queries.extend(v36_prefix_query_rows_from_batch(
                &batch,
                0,
                batch.num_rows(),
            )?);
            Ok(())
        })?;
        remaining = remaining
            .checked_sub(count)
            .ok_or_else(|| invalid("V36 prefix exact truth query count differs"))?;
    }
    Ok(output)
}

fn preflight_v36_prefix_checkpoint_gt100(
    state: &V36PrefixCheckpointResumeState,
    worker_threads: usize,
    active_wall_seconds: u64,
) -> Result<u128> {
    let artifacts = match state {
        V36PrefixCheckpointResumeState::Materialized { artifacts, .. }
        | V36PrefixCheckpointResumeState::GroundTruth { artifacts, .. } => artifacts,
        V36PrefixCheckpointResumeState::Population { .. }
        | V36PrefixCheckpointResumeState::Selected { .. }
        | V36PrefixCheckpointResumeState::Complete { .. } => {
            return Err(invalid("V36 prefix GT preflight phase differs"));
        }
    };
    artifacts.validate_authenticated_seal()?;
    if !(1..=16).contains(&worker_threads) {
        return Err(invalid("V36 prefix exact truth worker pool differs"));
    }
    let queries = load_v36_prefix_checkpoint_queries(artifacts)?;
    let quality_queries = queries.iter().try_fold(0_u64, |total, role| {
        total
            .checked_add(
                u64::try_from(role.len())
                    .map_err(|_| invalid("V36 prefix exact truth query count overflows"))?,
            )
            .ok_or_else(|| invalid("V36 prefix exact truth query count overflows"))
    })?;
    let query_ids = queries
        .iter()
        .flatten()
        .map(|query| query.feature_row_id)
        .collect::<BTreeSet<_>>();
    let templates = queries.iter().flatten().collect::<Vec<_>>();
    let mut candidate_id = u64::MAX;
    let mut rows = Vec::with_capacity(GT_PREFLIGHT_ROWS);
    for ordinal in 0..GT_PREFLIGHT_ROWS {
        while query_ids.contains(&candidate_id) {
            candidate_id = candidate_id
                .checked_sub(1)
                .ok_or_else(|| invalid("V36 prefix GT preflight IDs overflow"))?;
        }
        rows.push(V36PrefixMaterializedRow {
            feature_row_id: candidate_id,
            source_ordinal: Some(
                u64::try_from(ordinal)
                    .map_err(|_| invalid("V36 prefix GT preflight ordinal overflows"))?,
            ),
            embedding: templates[ordinal % templates.len()].embedding.clone(),
        });
        candidate_id = candidate_id
            .checked_sub(1)
            .ok_or_else(|| invalid("V36 prefix GT preflight IDs overflow"))?;
    }
    let mut accumulator = V36PrefixAllQueryGtAccumulator::new(queries)?;
    let pool = ThreadPoolBuilder::new()
        .num_threads(worker_threads)
        .build()
        .map_err(|_| invalid("V36 prefix exact truth worker pool differs"))?;
    let started = Instant::now();
    accumulator.absorb_with_pool(&rows, &pool)?;
    validate_v36_prefix_gt_preflight_projection(
        started.elapsed().as_nanos(),
        u64::try_from(rows.len())
            .map_err(|_| invalid("V36 prefix GT preflight row count overflows"))?,
        quality_queries,
        artifacts.expected_source_rows,
        quality_queries,
        active_wall_seconds,
    )
}

/// Continue exact GT from authenticated Materialized or GroundTruth checkpoint files.
pub fn run_v36_prefix_checkpoint_gt100<C>(
    state: &V36PrefixCheckpointResumeState,
    block_rows: usize,
    worker_threads: usize,
    consume_checkpoint: C,
) -> Result<([Vec<V36PrefixGtNeighbor>; 3], V36PrefixGtRunStats)>
where
    C: FnMut(&V36PrefixGtHeapCheckpoint) -> Result<()>,
{
    let (artifacts, prior) = match state {
        V36PrefixCheckpointResumeState::Materialized { artifacts, .. } => (artifacts, None),
        V36PrefixCheckpointResumeState::GroundTruth {
            artifacts,
            heaps,
            next_source_ordinal,
            ..
        } => {
            artifacts.validate_ground_truth_seal(heaps, *next_source_ordinal)?;
            authenticate_file(&heaps.path, &heaps.identity)?;
            let queries = load_v36_prefix_checkpoint_queries(artifacts)?;
            let query_counts = queries.each_ref().map(|role| role.len() as u32);
            let bytes = read_file(&heaps.path)?;
            let checkpoint = decode_v36_prefix_gt_heap_checkpoint(
                &bytes,
                &heaps.identity,
                *next_source_ordinal,
                query_counts,
            )?;
            let source_ids = load_v36_prefix_checkpoint_source_ids(
                &artifacts.source.path,
                artifacts.expected_source_rows,
            )?;
            return run_v36_prefix_gt100_checkpointed(
                &artifacts.source.path,
                &source_ids,
                queries,
                Some(checkpoint),
                block_rows,
                worker_threads,
                consume_checkpoint,
            );
        }
        V36PrefixCheckpointResumeState::Population { .. }
        | V36PrefixCheckpointResumeState::Selected { .. }
        | V36PrefixCheckpointResumeState::Complete { .. } => {
            return Err(invalid("V36 prefix exact truth continuation phase differs"));
        }
    };
    artifacts.validate_authenticated_seal()?;
    let queries = load_v36_prefix_checkpoint_queries(artifacts)?;
    let source_ids = load_v36_prefix_checkpoint_source_ids(
        &artifacts.source.path,
        artifacts.expected_source_rows,
    )?;
    run_v36_prefix_gt100_checkpointed(
        &artifacts.source.path,
        &source_ids,
        queries,
        prior,
        block_rows,
        worker_threads,
        consume_checkpoint,
    )
}

/// Run exact GT from one authenticated Materialized head and publish every heap boundary.
pub fn run_v36_prefix_checkpoint_ground_truth(
    request: V36PrefixCheckpointGroundTruthRequest<'_>,
) -> Result<V36PrefixCheckpointGroundTruth> {
    let V36PrefixCheckpointGroundTruthRequest {
        block_rows,
        output_root,
        output_uri_prefix,
        state,
        worker_threads,
        writer,
    } = request;
    let (state_artifacts, state_population, state_selected, state_ground_truth) = match state {
        V36PrefixCheckpointResumeState::Materialized {
            artifacts,
            population,
            selected,
        } => (artifacts, population, selected, None),
        V36PrefixCheckpointResumeState::GroundTruth {
            artifacts,
            heaps,
            next_source_ordinal,
            population,
            selected,
        } => (
            artifacts,
            population,
            selected,
            Some((heaps, *next_source_ordinal)),
        ),
        V36PrefixCheckpointResumeState::Population { .. }
        | V36PrefixCheckpointResumeState::Selected { .. }
        | V36PrefixCheckpointResumeState::Complete { .. } => {
            return Err(invalid("V36 ground-truth driver phase differs"));
        }
    };
    state_artifacts.validate_authenticated_seal()?;
    let (writer_selection, writer_artifacts, writer_population, writer_ground_truth) = match writer
        .previous_manifest
        .as_ref()
        .map(|manifest| (&manifest.phase, &manifest.population))
    {
        Some((
            V36PrefixCheckpointPhase::Materialized {
                selection,
                artifacts,
            },
            population,
        )) => (selection, artifacts, population, None),
        Some((
            V36PrefixCheckpointPhase::GroundTruth {
                selection,
                materialized,
                heaps,
                next_source_ordinal,
            },
            population,
        )) => (
            selection,
            materialized,
            population,
            Some((heaps, *next_source_ordinal)),
        ),
        _ => return Err(invalid("V36 ground-truth driver predecessor differs")),
    };
    let artifact_files = [
        &state_artifacts.population_authority,
        &state_artifacts.source,
        &state_artifacts.development_query,
        &state_artifacts.validation_query,
        &state_artifacts.sealed_holdout_query,
        &state_artifacts.performance_query,
    ];
    let artifact_identities = [
        &writer_artifacts.population_authority,
        &writer_artifacts.source,
        &writer_artifacts.development_query,
        &writer_artifacts.validation_query,
        &writer_artifacts.sealed_holdout_query,
        &writer_artifacts.performance_query,
    ];
    let state_run_identities = state_population
        .runs
        .iter()
        .map(|run| &run.identity)
        .collect::<Vec<_>>();
    if !output_root.is_dir()
        || state_selected.identity != writer_selection.selected_ids
        || state_population.consumed_objects != writer_population.consumed_objects
        || state_population.distinct_rows != writer_population.distinct_rows
        || state_population.duplicate_rows != writer_population.duplicate_rows
        || state_population.physical_rows != writer_population.physical_rows
        || state_run_identities != writer_population.identity_runs.iter().collect::<Vec<_>>()
        || state_ground_truth.map(|(heaps, ordinal)| (&heaps.identity, ordinal))
            != writer_ground_truth.map(|(heaps, ordinal)| (heaps.as_ref(), ordinal))
        || artifact_files
            .iter()
            .zip(artifact_identities)
            .any(|(file, identity)| &file.identity != identity)
    {
        return Err(invalid("V36 ground-truth driver authority differs"));
    }

    let mut newest_heaps = state_ground_truth.map(|(heaps, _)| heaps.clone());
    let mut newest_ready = None;
    let (truth, stats) =
        run_v36_prefix_checkpoint_gt100(state, block_rows, worker_threads, |checkpoint| {
            let filename = format!("gt-heaps-{:08}.arrow", checkpoint.next_source_ordinal);
            let path = output_root.join(&filename);
            let bytes = encode_v36_prefix_gt_heap_checkpoint(checkpoint)?;
            install_content_addressed(&path, &bytes)?;
            let heaps = V36PrefixCheckpointDependencyFile {
                identity: v36_prefix_checkpoint_output_identity(
                    "gt-heaps",
                    &filename,
                    output_uri_prefix,
                    &path,
                )?,
                path,
            };
            let ready = writer.commit_ground_truth(&heaps, checkpoint.next_source_ordinal)?;
            newest_heaps = Some(heaps);
            newest_ready = Some(ready);
            Ok(())
        })?;
    Ok(V36PrefixCheckpointGroundTruth {
        checkpoint_ready: newest_ready,
        heaps: newest_heaps
            .ok_or_else(|| invalid("V36 ground-truth driver emitted no checkpoint"))?,
        stats,
        truth,
    })
}

/// Materialize exact GT@100 Parquets from an authenticated EOF heap and publish Complete.
pub fn complete_v36_prefix_checkpoint_ground_truth(
    request: V36PrefixCheckpointCompletionRequest<'_>,
) -> Result<V36PrefixCheckpointCompletion> {
    let V36PrefixCheckpointCompletionRequest {
        output_root,
        output_uri_prefix,
        state,
        writer,
    } = request;
    let (artifacts, heaps, next_source_ordinal, state_population, state_selected) = match state {
        V36PrefixCheckpointResumeState::GroundTruth {
            artifacts,
            heaps,
            next_source_ordinal,
            population,
            selected,
        } => (artifacts, heaps, *next_source_ordinal, population, selected),
        _ => return Err(invalid("V36 completion phase differs")),
    };
    if !output_root.is_dir()
        || output_uri_prefix.trim_end_matches('/')
            != writer.context.object_prefix.trim_end_matches('/')
        || next_source_ordinal != writer.context.corpus_rows
    {
        return Err(invalid("V36 completion boundary differs"));
    }
    artifacts.validate_ground_truth_seal(heaps, next_source_ordinal)?;
    authenticate_file(&heaps.path, &heaps.identity)?;
    let (writer_selection, writer_materialized, writer_population, writer_heaps, writer_ordinal) =
        match writer
            .previous_manifest
            .as_ref()
            .map(|manifest| (&manifest.phase, &manifest.population))
        {
            Some((
                V36PrefixCheckpointPhase::GroundTruth {
                    heaps,
                    materialized,
                    next_source_ordinal,
                    selection,
                },
                population,
            )) => (
                selection,
                materialized,
                population,
                heaps,
                *next_source_ordinal,
            ),
            _ => return Err(invalid("V36 completion predecessor differs")),
        };
    let artifact_files = [
        &artifacts.population_authority,
        &artifacts.source,
        &artifacts.development_query,
        &artifacts.validation_query,
        &artifacts.sealed_holdout_query,
        &artifacts.performance_query,
    ];
    let artifact_identities = [
        &writer_materialized.population_authority,
        &writer_materialized.source,
        &writer_materialized.development_query,
        &writer_materialized.validation_query,
        &writer_materialized.sealed_holdout_query,
        &writer_materialized.performance_query,
    ];
    let state_run_identities = state_population
        .runs
        .iter()
        .map(|run| &run.identity)
        .collect::<Vec<_>>();
    if writer_heaps.as_ref() != &heaps.identity
        || writer_ordinal != next_source_ordinal
        || state_selected.identity != writer_selection.selected_ids
        || state_population.consumed_objects != writer_population.consumed_objects
        || state_population.distinct_rows != writer_population.distinct_rows
        || state_population.duplicate_rows != writer_population.duplicate_rows
        || state_population.physical_rows != writer_population.physical_rows
        || state_run_identities != writer_population.identity_runs.iter().collect::<Vec<_>>()
        || artifact_files
            .iter()
            .zip(artifact_identities)
            .any(|(file, identity)| &file.identity != identity)
    {
        return Err(invalid("V36 completion authority differs"));
    }
    let mut remaining_queries = u32::try_from(GT_HEAP_CHECKPOINT_MAX_QUERIES).unwrap();
    let mut query_counts = [0_u32; 3];
    for (count, artifact) in query_counts.iter_mut().zip([
        &artifacts.development_query,
        &artifacts.validation_query,
        &artifacts.sealed_holdout_query,
    ]) {
        *count = validate_v36_prefix_checkpoint_query_file(&artifact.path, remaining_queries)?;
        remaining_queries = remaining_queries
            .checked_sub(*count)
            .ok_or_else(|| invalid("V36 completion query count differs"))?;
    }
    let checkpoint = decode_v36_prefix_gt_heap_checkpoint(
        &read_file(&heaps.path)?,
        &heaps.identity,
        next_source_ordinal,
        query_counts,
    )?;
    let mut truth = [Vec::new(), Vec::new(), Vec::new()];
    for entry in checkpoint
        .entries
        .into_iter()
        .filter(|entry| usize::from(entry.rank) < GT_NEIGHBORS)
    {
        truth[usize::from(v36_prefix_gt_role_ordinal(entry.role))].push(V36PrefixGtNeighbor {
            query_ordinal: entry.query_ordinal,
            rank: entry.rank,
            feature_row_id: entry.feature_row_id,
            squared_distance: entry.squared_distance,
        });
    }
    let attempt = tempfile::tempdir_in(output_root).map_err(|source| BorsukError::Io {
        path: output_root.to_owned(),
        source,
    })?;
    let specifications = [
        ("development-gt100", "development-gt100.parquet"),
        ("validation-gt100", "validation-gt100.parquet"),
        ("sealed-holdout-gt100", "sealed-holdout-gt100.parquet"),
    ];
    let mut dependencies = Vec::with_capacity(3);
    for ((role, filename), rows) in specifications.into_iter().zip(&truth) {
        let temporary = attempt.path().join(filename);
        write_v36_prefix_gt100_parquet(&temporary, [v36_prefix_gt_batch(rows)?])?;
        let identity =
            v36_prefix_checkpoint_output_identity(role, filename, output_uri_prefix, &temporary)?;
        let path = output_root.join(filename);
        install_content_addressed_file(&path, &temporary, &identity)?;
        dependencies.push(V36PrefixCheckpointDependencyFile { identity, path });
    }
    let ground_truth = crate::V36PrefixGroundTruthArtifacts {
        heaps: heaps.identity.clone(),
        development: dependencies[0].identity.clone(),
        validation: dependencies[1].identity.clone(),
        sealed_holdout: dependencies[2].identity.clone(),
    };
    let checkpoint_ready = writer.commit_complete(&ground_truth, &dependencies)?;
    Ok(V36PrefixCheckpointCompletion {
        checkpoint_ready,
        ground_truth,
    })
}

fn v36_prefix_source_rows_from_batch(
    batch: &RecordBatch,
    next_source_ordinal: &mut u64,
) -> Result<Vec<V36PrefixMaterializedRow>> {
    let ids = batch
        .column(0)
        .as_any()
        .downcast_ref::<UInt64Array>()
        .ok_or_else(|| invalid("V36 prefix source Parquet ID column differs"))?;
    let embeddings = batch
        .column(1)
        .as_any()
        .downcast_ref::<FixedSizeListArray>()
        .ok_or_else(|| invalid("V36 prefix source Parquet embedding column differs"))?;
    let values = embeddings
        .values()
        .as_any()
        .downcast_ref::<Float32Array>()
        .ok_or_else(|| invalid("V36 prefix source Parquet embedding child differs"))?;
    let mut rows = Vec::with_capacity(batch.num_rows());
    for row in 0..batch.num_rows() {
        let start = row * DIMENSIONS;
        let embedding = values.values()[start..start + DIMENSIONS].to_vec();
        validate_embedding(&embedding)?;
        rows.push(V36PrefixMaterializedRow {
            feature_row_id: ids.value(row),
            source_ordinal: Some(*next_source_ordinal),
            embedding,
        });
        *next_source_ordinal = next_source_ordinal
            .checked_add(1)
            .ok_or_else(|| invalid("V36 prefix source Parquet row count overflows"))?;
    }
    Ok(rows)
}

fn v36_prefix_gt_batch(rows: &[V36PrefixGtNeighbor]) -> Result<RecordBatch> {
    Ok(RecordBatch::try_new(
        Arc::new(v36_prefix_gt100_schema()),
        vec![
            Arc::new(UInt32Array::from(
                rows.iter().map(|row| row.query_ordinal).collect::<Vec<_>>(),
            )) as ArrayRef,
            Arc::new(UInt16Array::from(
                rows.iter().map(|row| row.rank).collect::<Vec<_>>(),
            )),
            Arc::new(UInt64Array::from(
                rows.iter()
                    .map(|row| row.feature_row_id)
                    .collect::<Vec<_>>(),
            )),
            Arc::new(Float64Array::from(
                rows.iter()
                    .map(|row| row.squared_distance)
                    .collect::<Vec<_>>(),
            )),
        ],
    )?)
}

struct V36PrefixGtQueryState {
    heap: BinaryHeap<RankedNeighbor>,
    query: V36PrefixQueryRow,
    role: usize,
}

/// Compute all quality-role GT@100 with one corpus scan and bounded state.
pub fn write_v36_prefix_gt100_roles_from_parquets(
    source_path: &Path,
    expected_source_feature_ids: &[u64],
    jobs: &[V36PrefixGtParquetJob],
    worker_threads: usize,
) -> Result<V36PrefixGtRunStats> {
    if jobs.len() != 3
        || worker_threads == 0
        || worker_threads > 16
        || jobs[0].role != V36PrefixQualityRole::Development
        || jobs[1].role != V36PrefixQualityRole::Validation
        || jobs[2].role != V36PrefixQualityRole::SealedHoldout
        || jobs.iter().any(|job| job.expected_queries == 0)
    {
        return Err(invalid("V36 prefix exact truth job set differs"));
    }
    let mut paths = BTreeSet::from([source_path]);
    if jobs
        .iter()
        .flat_map(|job| [&job.query, &job.output])
        .any(|path| !paths.insert(path))
    {
        return Err(invalid("V36 prefix exact truth paths overlap"));
    }
    let mut states = Vec::new();
    let mut query_ids = BTreeSet::new();
    for (role, job) in jobs.iter().enumerate() {
        scan_v36_prefix_query_parquet(&job.query, u64::from(job.expected_queries), |batch| {
            let rows = v36_prefix_query_rows_from_batch(&batch, 0, batch.num_rows())?;
            for query in rows {
                if !query_ids.insert(query.feature_row_id) {
                    return Err(invalid("V36 prefix exact truth query membership differs"));
                }
                states.push(V36PrefixGtQueryState {
                    heap: BinaryHeap::with_capacity(GT_NEIGHBORS),
                    query,
                    role,
                });
            }
            Ok(())
        })?;
    }
    let quality_queries = u32::try_from(states.len())
        .map_err(|_| invalid("V36 prefix exact truth query count overflows"))?;
    let expected_quality_queries = jobs.iter().try_fold(0_u32, |total, job| {
        total
            .checked_add(job.expected_queries)
            .ok_or_else(|| invalid("V36 prefix exact truth query count overflows"))
    })?;
    if quality_queries != expected_quality_queries {
        return Err(invalid("V36 prefix exact truth query count differs"));
    }
    let pool = ThreadPoolBuilder::new()
        .num_threads(worker_threads)
        .build()
        .map_err(|_| invalid("V36 prefix exact truth worker pool differs"))?;
    let mut source_rows = 0_u64;
    scan_v36_prefix_source_parquet(source_path, expected_source_feature_ids, |source_batch| {
        let rows = v36_prefix_source_rows_from_batch(&source_batch, &mut source_rows)?;
        if rows
            .iter()
            .any(|row| query_ids.contains(&row.feature_row_id))
        {
            return Err(invalid("V36 prefix exact truth corpus contains a query"));
        }
        pool.install(|| {
            states.par_iter_mut().for_each(|state| {
                for row in &rows {
                    let candidate = RankedNeighbor {
                        distance: squared_l2(&row.embedding, &state.query.embedding),
                        feature_row_id: row.feature_row_id,
                    };
                    if state.heap.len() < GT_NEIGHBORS {
                        state.heap.push(candidate);
                    } else if state.heap.peek().is_some_and(|worst| candidate < *worst) {
                        state.heap.pop();
                        state.heap.push(candidate);
                    }
                }
            });
        });
        Ok(())
    })?;
    if source_rows < GT_NEIGHBORS as u64
        || states.iter().any(|state| state.heap.len() != GT_NEIGHBORS)
    {
        return Err(invalid("V36 prefix exact truth corpus is insufficient"));
    }
    let mut truth_by_role = [Vec::new(), Vec::new(), Vec::new()];
    for state in states {
        let mut neighbors = state.heap.into_vec();
        neighbors.sort();
        truth_by_role[state.role].extend(neighbors.into_iter().enumerate().map(
            |(rank, neighbor)| V36PrefixGtNeighbor {
                query_ordinal: state.query.query_ordinal,
                rank: u16::try_from(rank).unwrap(),
                feature_row_id: neighbor.feature_row_id,
                squared_distance: neighbor.distance,
            },
        ));
    }
    for (job, truth) in jobs.iter().zip(truth_by_role) {
        write_v36_prefix_gt100_parquet(&job.output, [v36_prefix_gt_batch(&truth)?])?;
    }
    Ok(V36PrefixGtRunStats {
        quality_queries,
        source_scans: 1,
        source_rows,
    })
}

#[cfg(test)]
mod tests {
    use std::{
        cell::Cell,
        io::{BufWriter, Cursor, Write},
        rc::Rc,
        sync::{
            Arc as StdArc,
            atomic::{AtomicUsize, Ordering as AtomicOrdering},
        },
    };

    use axum::{Router, body::Body, http::Response, routing::get};

    use super::*;

    #[test]
    fn v36_prefix_source_scanner_honors_the_bounded_decoder_window() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("source.parquet");
        let mut coordinates = vec![0.0_f32; 2 * DIMENSIONS];
        coordinates[0] = 1.0;
        coordinates[DIMENSIONS + 1] = 1.0;
        let vectors = FixedSizeListArray::try_new(
            Arc::new(Field::new("item", DataType::Float32, false)),
            DIMENSIONS as i32,
            Arc::new(Float32Array::from(coordinates)),
            None,
        )
        .unwrap();
        let batch = RecordBatch::try_new(
            Arc::new(v36_prefix_source_schema()),
            vec![Arc::new(UInt64Array::from(vec![7, 9])), Arc::new(vectors)],
        )
        .unwrap();
        let mut writer = ArrowWriter::try_new(
            File::create(&path).unwrap(),
            Arc::new(v36_prefix_source_schema()),
            Some(
                WriterProperties::builder()
                    .set_max_row_group_row_count(Some(1))
                    .build(),
            ),
        )
        .unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        let mut maximum_rows = 0;
        scan_v36_prefix_source_parquet_with_batch_size(&path, &[7, 9], Some(1), |batch| {
            maximum_rows = maximum_rows.max(batch.num_rows());
            Ok(())
        })
        .unwrap();
        assert_eq!(maximum_rows, 1);
    }

    #[test]
    fn v36_prefix_source_scanner_rejects_oversized_row_group_decoder_working_set() {
        assert!(
            validate_v36_prefix_source_decoder_bounds(
                &[(65_536, 200 * 1_048_576, 240 * 1_048_576)],
                65_536,
                256 * 1_048_576,
                256 * 1_048_576,
            )
            .is_ok()
        );
        for invalid in [
            vec![(65_537, 1, 1)],
            vec![(65_536, 256 * 1_048_576 + 1, 1)],
            vec![(65_536, 1, 256 * 1_048_576 + 1)],
            vec![(65_536, -1, 1)],
        ] {
            assert!(
                validate_v36_prefix_source_decoder_bounds(
                    &invalid,
                    65_536,
                    256 * 1_048_576,
                    256 * 1_048_576,
                )
                .is_err()
            );
        }
    }

    #[test]
    fn v36_prefix_source_scanner_rejects_page_header_allocation_claims() {
        let valid = V36PrefixSourcePageClaim {
            compressed_bytes: 2_048,
            kind: V36PrefixSourcePageKind::Data,
            rows: None,
            uncompressed_bytes: 4_096,
            values: 1_024,
        };
        assert!(validate_v36_prefix_source_page_header(&valid, 65_536, 768, 4).is_ok());

        let oversized_dictionary = V36PrefixSourcePageClaim {
            compressed_bytes: 4,
            kind: V36PrefixSourcePageKind::Dictionary,
            rows: None,
            uncompressed_bytes: 4,
            values: i32::MAX,
        };
        assert!(
            validate_v36_prefix_source_page_header(&oversized_dictionary, 65_536, 768, 4,).is_err()
        );

        let oversized_page = V36PrefixSourcePageClaim {
            uncompressed_bytes: 16 * 1_048_576 + 1,
            ..valid
        };
        assert!(validate_v36_prefix_source_page_header(&oversized_page, 65_536, 768, 4).is_err());
    }

    #[test]
    fn v36_prefix_source_page_parser_accepts_explicit_reordering_and_rejects_duplicates() {
        // Compact Thrift permits an explicit field ID to move backwards. This
        // is the same DataPageHeader as the canonical order, with fields 3, 1,
        // 2, then 5.
        let reordered = [
            0x35, 0x28, // compressed_page_size = 20
            0x05, 0x02, 0x00, // type = DATA_PAGE
            0x05, 0x04, 0x50, // uncompressed_page_size = 40
            0x3c, 0x15, 0x14, 0x00, // data_page_header.num_values = 10
            0x00,
        ];
        let (length, claim) = parse_v36_prefix_source_page_header(&reordered).unwrap();
        assert_eq!(length, reordered.len());
        assert_eq!(claim.compressed_bytes, 20);
        assert_eq!(claim.uncompressed_bytes, 40);
        assert_eq!(claim.values, 10);

        let duplicate_type = [
            0x15, 0x00, // type = DATA_PAGE
            0x05, 0x02, 0x00, // explicit duplicate type
            0x15, 0x50, // uncompressed_page_size = 40
            0x15, 0x28, // compressed_page_size = 20
            0x2c, 0x15, 0x14, 0x00, // data_page_header.num_values = 10
            0x00,
        ];
        assert!(parse_v36_prefix_source_page_header(&duplicate_type).is_err());
    }

    #[test]
    fn v36_prefix_parquet_footer_rejects_collection_allocation_claims_before_decode() {
        let mut oversized_footer = vec![0x19, 0xf5];
        let mut count = 65_537_u64;
        while count >= 0x80 {
            oversized_footer.push((count as u8) | 0x80);
            count >>= 7;
        }
        oversized_footer.push(count as u8);
        oversized_footer.push(0x00);
        let mut parquet = b"PAR1".to_vec();
        parquet.extend_from_slice(&oversized_footer);
        parquet.extend_from_slice(&(oversized_footer.len() as u32).to_le_bytes());
        parquet.extend_from_slice(b"PAR1");
        assert!(validate_v36_prefix_parquet_footer(&bytes::Bytes::from(parquet)).is_err());

        let overflowing_varint = [
            b'P', b'A', b'R', b'1', 0x19, 0xf5, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80,
            0x80, 0x02, 0x00, 0x0d, 0x00, 0x00, 0x00, b'P', b'A', b'R', b'1',
        ];
        assert!(
            validate_v36_prefix_parquet_footer(&bytes::Bytes::copy_from_slice(&overflowing_varint))
                .is_err()
        );
    }

    #[test]
    fn v36_prefix_checkpoint_query_file_rejects_total_limit_during_scan() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("too-many-queries.parquet");
        let rows = (0_u64..=GT_HEAP_CHECKPOINT_MAX_QUERIES)
            .map(|ordinal| {
                let mut embedding = vec![0.0_f32; DIMENSIONS];
                embedding[usize::try_from(ordinal).unwrap() % DIMENSIONS] = 1.0;
                (
                    ordinal,
                    V36PrefixMaterializedRow {
                        embedding,
                        feature_row_id: ordinal + 1,
                        source_ordinal: Some(ordinal),
                    },
                )
            })
            .collect::<Vec<_>>();
        write_v36_prefix_query_parquet(&path, [materialized_batch(&rows, true).unwrap()]).unwrap();

        assert!(validate_v36_prefix_checkpoint_query_file(&path, 3_000).is_err());
    }

    #[test]
    fn v36_prefix_checkpoint_query_metadata_binds_every_row_group_to_limit() {
        assert!(
            validate_v36_prefix_checkpoint_query_metadata_rows(3_000, &[1_024, 1_976], 3_000)
                .is_ok()
        );
        assert!(
            validate_v36_prefix_checkpoint_query_metadata_rows(2_999, &[3_000], 3_000).is_err()
        );
        assert!(
            validate_v36_prefix_checkpoint_query_metadata_rows(3_000, &[3_001], 3_000).is_err()
        );
    }

    #[test]
    fn v36_prefix_checkpoint_source_metadata_binds_rows_before_allocation() {
        assert!(validate_v36_prefix_checkpoint_source_metadata_rows(128, &[64, 64], 128).is_ok());
        assert!(validate_v36_prefix_checkpoint_source_metadata_rows(129, &[64, 65], 128).is_err());
        assert!(validate_v36_prefix_checkpoint_source_metadata_rows(128, &[127], 128).is_err());
        assert!(validate_v36_prefix_checkpoint_source_metadata_rows(128, &[128, 0], 128).is_err());
        assert!(
            validate_v36_prefix_checkpoint_source_metadata_rows(i64::MAX, &[i64::MAX, 1], 128)
                .is_err()
        );
    }

    #[test]
    fn v36_prefix_identity_run_offset_uniqueness_allocation_is_bounded() {
        assert!(v36_prefix_identity_offset_bitmap_selected(64, 64).unwrap());
        assert!(!v36_prefix_identity_offset_bitmap_selected(u64::MAX, 8).unwrap());
        assert!(
            v36_prefix_identity_offset_bitmap_selected(
                u64::MAX,
                EXTERNAL_MAX_CUTOFF_BITMAP_BYTES / size_of::<u64>() + 1,
            )
            .is_err()
        );
    }

    struct CountingWriter {
        calls: Rc<Cell<usize>>,
    }

    impl Write for CountingWriter {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            self.calls.set(self.calls.get() + 1);
            Ok(bytes.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    #[test]
    fn v36_prefix_dataset_external_arrow_batch_body_is_canonically_bounded() {
        assert!(validate_v36_prefix_identity_batch_body(4, 80).is_ok());
        let error = validate_v36_prefix_identity_batch_body(4, 1 << 20).unwrap_err();
        assert_ne!(error.code(), "v36_prefix_resource_limit");
        assert!(validate_v36_prefix_selected_batch_body(4, 232).is_ok());
        let error = validate_v36_prefix_selected_batch_body(4, 1 << 20).unwrap_err();
        assert_ne!(error.code(), "v36_prefix_resource_limit");
    }

    #[test]
    fn v36_prefix_dataset_arrow_preflight_returns_exact_declared_rows() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("rows.arrow");
        let schema = Arc::new(Schema::new(vec![Field::new(
            "row",
            DataType::UInt64,
            false,
        )]));
        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(UInt64Array::from(vec![1, 2, 3]))],
        )
        .unwrap();
        let mut file = File::create(&path).unwrap();
        let mut writer = ArrowFileWriter::try_new(&mut file, &schema).unwrap();
        writer.write(&batch).unwrap();
        writer.finish().unwrap();
        drop(writer);
        file.sync_all().unwrap();
        drop(file);

        let encoded_bytes = fs::metadata(&path).unwrap().len();
        let mut file = File::open(&path).unwrap();
        let rows =
            preflight_v36_prefix_arrow_file(&mut file, &path, encoded_bytes, 4, |_, _| Ok(()))
                .unwrap();
        assert_eq!(rows, 3);
    }

    #[test]
    fn v36_prefix_dataset_external_snapshot_rejects_source_growth_before_writing_it() {
        let mut source = Cursor::new(b"registered-plus-growth".to_vec());
        let mut snapshot = Vec::new();
        let error = copy_v36_prefix_snapshot_exact(
            &mut source,
            &mut snapshot,
            (Path::new("source.arrow"), Path::new("snapshot.arrow")),
            10,
            4,
        )
        .unwrap_err();

        assert_eq!(error.code(), "v36_prefix_resource_limit");
        assert_eq!(snapshot, b"registered");
    }

    #[test]
    fn v36_prefix_dataset_selected_stream_snapshots_have_distinct_roles() {
        let directory = tempfile::tempdir().unwrap();
        let contract = V36PrefixSelectedIdsContract {
            cohort_ordinal: 0,
            eligible_rows: 1,
            excluded_population_identity: None,
            excluded_rows: 0,
            ordered_source_manifest_sha256: "1".repeat(64),
            population_seed_sha256:
                "bcb490ff7944bfa3a0a6d5abe6d35ba34ecaba60b615e214edb057a1a5b63b8e".into(),
            selected_object_count: 1,
            selected_object_start: 0,
            selected_rows: 1,
        };
        let rows = select_v36_prefix_population_rows(
            vec![V36PrefixRowIdentity {
                feature_row_id: 7,
                row_offset: 3,
                selected_object_ordinal: 0,
                source_ordinal: None,
            }],
            &contract.ordered_source_manifest_sha256,
            1,
        )
        .unwrap();
        let bytes = encode_v36_prefix_selected_ids(&contract, &rows).unwrap();
        let sha256 = format!("{:x}", Sha256::digest(&bytes));
        let path = directory.path().join("selected.arrow");
        fs::write(&path, &bytes).unwrap();
        let selected = V36PrefixSelectedIdsFile {
            contract,
            identity: V36ArtifactIdentity {
                blake3: blake3::hash(&bytes).to_hex().to_string(),
                encoded_bytes: bytes.len().try_into().unwrap(),
                role: "population-selected-identities".into(),
                sha256: sha256.clone(),
                uri: format!("s3://fixture/v36/{sha256}-selected.arrow"),
            },
            path,
        };
        let limits = V36PrefixExternalSelectionLimits {
            io_buffer_bytes: 64,
            max_input_bytes: 1 << 20,
            max_scratch_bytes: 1 << 20,
            max_spills: 16,
            merge_fan_in: 2,
            sort_buffer_records: 2,
        };

        let mut primary = open_v36_prefix_selected_stream(
            &selected,
            &limits,
            directory.path(),
            "selected-population.arrow",
        )
        .unwrap();
        let mut exclusion = open_v36_prefix_selected_stream(
            &selected,
            &limits,
            directory.path(),
            "excluded-population.arrow",
        )
        .unwrap();
        assert_eq!(primary.next_record().unwrap().unwrap().feature_row_id, 7);
        assert_eq!(exclusion.next_record().unwrap().unwrap().feature_row_id, 7);
    }

    #[test]
    fn v36_prefix_dataset_spool_writer_coalesces_record_writes() {
        let calls = Rc::new(Cell::new(0));
        let mut writer = BufWriter::with_capacity(
            8 * 1024,
            CountingWriter {
                calls: Rc::clone(&calls),
            },
        );
        let row = V36PrefixMaterializedRow {
            feature_row_id: 7,
            source_ordinal: Some(0),
            embedding: vec![1.0; DIMENSIONS],
        };
        for ordinal in 0..32 {
            write_materialization_record(
                &mut writer,
                Path::new("counting-spool.bin"),
                ordinal,
                &row,
            )
            .unwrap();
        }
        writer.flush().unwrap();
        assert!(calls.get() <= 16, "underlying writes={}", calls.get());
    }

    #[test]
    fn v36_prefix_dataset_acquires_one_complete_authenticated_object() {
        let directory = tempfile::tempdir().unwrap();
        let source = directory.path().join("registered.bin");
        fs::write(&source, b"registered object bytes").unwrap();
        let bytes = fs::read(&source).unwrap();
        let object = V36PrefixRankedSourceObject {
            encoded_bytes: bytes.len().try_into().unwrap(),
            path: "data/registered.parquet".into(),
            sample_sha256: "1".repeat(64),
            sha256: format!("{:x}", Sha256::digest(&bytes)),
            uri: url::Url::from_file_path(&source).unwrap().to_string(),
        };
        let scratch = directory.path().join("scratch");
        fs::create_dir(&scratch).unwrap();
        let runtime = tokio::runtime::Runtime::new().unwrap();
        let acquired = acquire_v36_prefix_object(&runtime, &object, &scratch, 0).unwrap();
        assert_eq!(fs::read(acquired).unwrap(), bytes);

        let bad_scratch = directory.path().join("bad-scratch");
        fs::create_dir(&bad_scratch).unwrap();
        let mut drifted = object;
        drifted.sha256 = "f".repeat(64);
        assert!(acquire_v36_prefix_object(&runtime, &drifted, &bad_scratch, 0).is_err());
        assert!(bad_scratch.read_dir().unwrap().next().is_none());
    }

    #[test]
    fn v36_prefix_dataset_http_failure_never_resumes_a_partial_object() {
        let runtime = tokio::runtime::Runtime::new().unwrap();
        let calls = StdArc::new(AtomicUsize::new(0));
        let handler_calls = StdArc::clone(&calls);
        let app = Router::new().route(
            "/object",
            get(move || {
                handler_calls.fetch_add(1, AtomicOrdering::SeqCst);
                async {
                    Response::builder()
                        .header("content-length", "64")
                        .header("etag", "\"registered-etag\"")
                        .header("last-modified", "Sun, 06 Sep 2026 00:00:00 GMT")
                        .body(Body::from("partial"))
                        .unwrap()
                }
            }),
        );
        let listener = runtime
            .block_on(tokio::net::TcpListener::bind("127.0.0.1:0"))
            .unwrap();
        let address = listener.local_addr().unwrap();
        let server = runtime.spawn(async move { axum::serve(listener, app).await.unwrap() });
        let directory = tempfile::tempdir().unwrap();
        let object = V36PrefixRankedSourceObject {
            encoded_bytes: 64,
            path: "data/registered.parquet".into(),
            sample_sha256: "1".repeat(64),
            sha256: "2".repeat(64),
            uri: format!("http://{address}/object"),
        };
        assert!(acquire_v36_prefix_object(&runtime, &object, directory.path(), 0).is_err());
        assert_eq!(calls.load(AtomicOrdering::SeqCst), 1);
        assert!(directory.path().read_dir().unwrap().next().is_none());
        server.abort();
    }

    #[test]
    fn v36_prefix_dataset_checked_cleanup_cannot_report_false_success() {
        let directory = tempfile::tempdir().unwrap();
        let acquired = directory.path().join("source-0000.parquet");
        fs::write(&acquired, b"complete").unwrap();
        V36PrefixAcquiredObjects {
            paths: vec![acquired],
        }
        .cleanup()
        .unwrap();
        assert!(directory.path().read_dir().unwrap().next().is_none());

        let not_a_file = directory.path().join("source-0001.parquet");
        fs::create_dir(&not_a_file).unwrap();
        assert!(
            V36PrefixAcquiredObjects {
                paths: vec![not_a_file],
            }
            .cleanup()
            .is_err()
        );
    }
}
