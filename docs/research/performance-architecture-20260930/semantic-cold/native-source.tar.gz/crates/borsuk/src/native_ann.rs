use std::collections::BTreeSet;

use serde::{Deserialize, Serialize};

use crate::{
    error::{BorsukError, Result},
    metric::VectorMetric,
};

const NATIVE_ANN_FORMAT_VERSION: u16 = 2;
const NATIVE_ANN_PAGE_ROWS: u32 = 256;
const NATIVE_ANN_PQ_WIDTH: u8 = 16;
const NATIVE_ANN_SUMMARY_CODES_PER_PAGE: u8 = 2;
const NATIVE_BOUNDED_FORMAT_VERSION: u16 = 3;
const NATIVE_BOUNDED_PQ_WIDTH: u8 = 64;
const SHA256_HEX_LEN: usize = 64;
const MUTATION_KEY_HEX_LEN: usize = 48;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeArtifactRef {
    pub(crate) role: String,
    pub(crate) uri: String,
    pub(crate) sha256: String,
    pub(crate) encoded_bytes: u64,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeRouterRef {
    pub(crate) pq_width: u8,
    pub(crate) summary_codes_per_page: u8,
    pub(crate) physical_rows: u64,
    pub(crate) page_count: u32,
    pub(crate) codebooks: NativeArtifactRef,
    pub(crate) row_codes: NativeArtifactRef,
    pub(crate) summary_codes: NativeArtifactRef,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeBoundedRouteLimits {
    pub(crate) cpu_permits: u16,
    pub(crate) cpu_waiters: u16,
    pub(crate) max_summary_pages: u32,
    pub(crate) max_candidate_rows: u32,
    pub(crate) max_output_pages: u32,
    pub(crate) coalesce_gap_pages: u32,
    pub(crate) range_concurrency: u16,
    pub(crate) response_bytes_each: u64,
    pub(crate) decoded_cache_bytes: u64,
    pub(crate) workspace_bytes: u64,
    pub(crate) runtime_reserve_bytes: u64,
    pub(crate) resident_budget_bytes: u64,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeBoundedRouterRef {
    pub(crate) pq_width: u8,
    pub(crate) summary_blocks_per_page: u8,
    pub(crate) physical_rows: u64,
    pub(crate) page_count: u32,
    pub(crate) summaries: NativeArtifactRef,
    pub(crate) codebooks: NativeArtifactRef,
    pub(crate) row_codes: NativeArtifactRef,
    pub(crate) limits: NativeBoundedRouteLimits,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeSq8Authority {
    pub(crate) low: Vec<f32>,
    pub(crate) step: Vec<f32>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeRunRef {
    pub(crate) ordinal: u32,
    pub(crate) rows: u64,
    pub(crate) version_start: String,
    pub(crate) version_end: String,
    pub(crate) artifact: NativeArtifactRef,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeBoundedDeltaRunRef {
    pub(crate) ordinal: u32,
    pub(crate) rows: u64,
    pub(crate) version_start: String,
    pub(crate) version_end: String,
    pub(crate) artifact: NativeArtifactRef,
    pub(crate) sq8: NativeSq8Authority,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeAnnRef {
    pub(crate) format_version: u16,
    pub(crate) generation: u64,
    pub(crate) previous_generation_sha256: Option<String>,
    pub(crate) source_identity: String,
    pub(crate) dimensions: u32,
    pub(crate) metric: VectorMetric,
    pub(crate) page_rows: u32,
    pub(crate) router: NativeRouterRef,
    pub(crate) page_directory: NativeArtifactRef,
    pub(crate) mutation_directory: NativeArtifactRef,
    pub(crate) base_runs: Vec<NativeRunRef>,
    pub(crate) delta_runs: Vec<NativeRunRef>,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct NativeBoundedAnnRef {
    pub(crate) format_version: u16,
    pub(crate) generation: u64,
    pub(crate) previous_generation_sha256: Option<String>,
    pub(crate) source_identity: String,
    pub(crate) dimensions: u32,
    pub(crate) metric: VectorMetric,
    pub(crate) page_rows: u32,
    pub(crate) router: NativeBoundedRouterRef,
    pub(crate) sq8: NativeSq8Authority,
    pub(crate) page_directory: NativeArtifactRef,
    pub(crate) mutation_directory: NativeArtifactRef,
    pub(crate) base_runs: Vec<NativeRunRef>,
    pub(crate) delta_runs: Vec<NativeBoundedDeltaRunRef>,
}

fn invalid(message: impl Into<String>) -> BorsukError {
    BorsukError::InvalidStorage(message.into())
}

fn validate_hex(value: &str, len: usize, name: &str) -> Result<()> {
    if value.len() != len
        || !value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(invalid(format!(
            "native ANN {name} must contain exactly {len} lower-case hex characters"
        )));
    }
    Ok(())
}

impl NativeArtifactRef {
    pub(crate) fn validate(&self, expected_role: &str) -> Result<()> {
        if self.role != expected_role {
            return Err(invalid(format!(
                "native ANN artifact role differs: expected {expected_role}, got {}",
                self.role
            )));
        }
        let uri = url::Url::parse(&self.uri)
            .map_err(|error| invalid(format!("native ANN artifact URI is invalid: {error}")))?;
        if uri.cannot_be_a_base()
            || uri.scheme().is_empty()
            || uri.path().is_empty()
            || uri.query().is_some()
            || uri.fragment().is_some()
        {
            return Err(invalid(
                "native ANN artifact URI is not an absolute object URI",
            ));
        }
        validate_hex(&self.sha256, SHA256_HEX_LEN, "artifact SHA-256")?;
        if self.encoded_bytes == 0 {
            return Err(invalid("native ANN artifact must not be empty"));
        }
        Ok(())
    }
}

impl NativeRunRef {
    fn validate(&self, expected_role: &str, expected_ordinal: usize) -> Result<()> {
        if usize::try_from(self.ordinal).ok() != Some(expected_ordinal) {
            return Err(invalid("native ANN run ordinals are not contiguous"));
        }
        if self.rows == 0 {
            return Err(invalid("native ANN run must contain rows"));
        }
        validate_hex(
            &self.version_start,
            MUTATION_KEY_HEX_LEN,
            "run start mutation key",
        )?;
        validate_hex(
            &self.version_end,
            MUTATION_KEY_HEX_LEN,
            "run end mutation key",
        )?;
        if self.version_start > self.version_end {
            return Err(invalid("native ANN run mutation range is reversed"));
        }
        self.artifact.validate(expected_role)
    }
}

impl NativeBoundedDeltaRunRef {
    fn validate(&self, dimensions: usize, expected_ordinal: usize) -> Result<()> {
        if usize::try_from(self.ordinal).ok() != Some(expected_ordinal)
            || self.rows == 0
            || self.version_start > self.version_end
        {
            return Err(invalid("native bounded ANN delta run shape differs"));
        }
        validate_hex(
            &self.version_start,
            MUTATION_KEY_HEX_LEN,
            "bounded delta start mutation key",
        )?;
        validate_hex(
            &self.version_end,
            MUTATION_KEY_HEX_LEN,
            "bounded delta end mutation key",
        )?;
        self.artifact.validate("delta-run")?;
        if self.sq8.low.len() != dimensions
            || self.sq8.step.len() != dimensions
            || self.sq8.low.iter().any(|value| !value.is_finite())
            || self
                .sq8
                .step
                .iter()
                .any(|value| !value.is_finite() || *value <= 0.0)
        {
            return Err(invalid("native bounded ANN delta SQ8 authority differs"));
        }
        Ok(())
    }
}

impl NativeBoundedRouteLimits {
    fn validate(&self, physical_rows: u64, page_count: u32) -> Result<()> {
        if self.cpu_permits == 0
            || self.cpu_permits > 256
            || self.cpu_waiters > 4096
            || self.max_summary_pages == 0
            || self.max_summary_pages > page_count
            || self.max_candidate_rows == 0
            || u64::from(self.max_candidate_rows) > physical_rows
            || self.max_output_pages == 0
            || self.max_output_pages > self.max_summary_pages
            || self.range_concurrency == 0
            || self.range_concurrency > 64
            || u32::from(self.range_concurrency) != self.max_output_pages
            || self.response_bytes_each == 0
            || self.decoded_cache_bytes == 0
            || self.workspace_bytes == 0
            || self.runtime_reserve_bytes == 0
            || self.resident_budget_bytes == 0
        {
            return Err(invalid("native bounded ANN route limits differ"));
        }
        let response_bytes = u64::from(self.range_concurrency)
            .checked_mul(self.response_bytes_each)
            .ok_or_else(|| invalid("native bounded ANN response budget overflows"))?;
        let fixed_runtime = response_bytes
            .checked_add(self.decoded_cache_bytes)
            .and_then(|bytes| bytes.checked_add(self.workspace_bytes))
            .and_then(|bytes| bytes.checked_add(self.runtime_reserve_bytes))
            .ok_or_else(|| invalid("native bounded ANN fixed runtime budget overflows"))?;
        if fixed_runtime > self.resident_budget_bytes {
            return Err(invalid(
                "native bounded ANN fixed runtime exceeds resident budget",
            ));
        }
        Ok(())
    }
}

impl NativeBoundedAnnRef {
    pub(crate) fn validate(&self) -> Result<()> {
        if self.format_version != NATIVE_BOUNDED_FORMAT_VERSION
            || self.generation == 0
            || self.source_identity.is_empty()
            || self.dimensions == 0
            || self.metric != VectorMetric::SquaredEuclidean
            || self.page_rows != NATIVE_ANN_PAGE_ROWS
            || self.router.pq_width != NATIVE_BOUNDED_PQ_WIDTH
            || self.router.summary_blocks_per_page == 0
            || self.router.physical_rows == 0
            || self.router.page_count == 0
        {
            return Err(invalid("native bounded ANN scalar authority differs"));
        }
        match (self.generation, self.previous_generation_sha256.as_deref()) {
            (1, None) => {}
            (1, Some(_)) => {
                return Err(invalid(
                    "native bounded ANN first generation names a predecessor",
                ));
            }
            (_, Some(digest)) => validate_hex(
                digest,
                SHA256_HEX_LEN,
                "bounded previous generation SHA-256",
            )?,
            (_, None) => {
                return Err(invalid(
                    "native bounded ANN generation is missing its predecessor",
                ));
            }
        }
        if self
            .router
            .physical_rows
            .div_ceil(u64::from(self.page_rows))
            != u64::from(self.router.page_count)
        {
            return Err(invalid(
                "native bounded ANN page count differs from physical rows",
            ));
        }
        self.router
            .limits
            .validate(self.router.physical_rows, self.router.page_count)?;
        let dimensions = usize::try_from(self.dimensions)
            .map_err(|_| invalid("native bounded ANN dimensions exceed usize"))?;
        if self.sq8.low.len() != dimensions
            || self.sq8.step.len() != dimensions
            || self.sq8.low.iter().any(|value| !value.is_finite())
            || self
                .sq8
                .step
                .iter()
                .any(|value| !value.is_finite() || *value <= 0.0)
        {
            return Err(invalid("native bounded ANN SQ8 authority differs"));
        }
        self.router.summaries.validate("route-summaries")?;
        self.router.codebooks.validate("route-codebooks")?;
        self.router.row_codes.validate("route-row-codes")?;
        self.page_directory.validate("page-directory")?;
        self.mutation_directory.validate("mutation-directory")?;
        validate_runs(&self.base_runs, "base-run")?;
        for (ordinal, run) in self.delta_runs.iter().enumerate() {
            run.validate(dimensions, ordinal)?;
            if ordinal > 0 && self.delta_runs[ordinal - 1].version_end >= run.version_start {
                return Err(invalid(
                    "native bounded ANN delta mutation ranges overlap or are unordered",
                ));
            }
        }
        let base_rows = self.base_runs.iter().try_fold(0_u64, |total, run| {
            total
                .checked_add(run.rows)
                .ok_or_else(|| invalid("native bounded ANN base row count overflows"))
        })?;
        if base_rows != self.router.physical_rows {
            return Err(invalid(
                "native bounded ANN physical rows differ from base runs",
            ));
        }
        if let (Some(base), Some(delta)) = (self.base_runs.last(), self.delta_runs.first())
            && base.version_end >= delta.version_start
        {
            return Err(invalid(
                "native bounded ANN base and delta mutation ranges overlap",
            ));
        }
        let mut uris = BTreeSet::new();
        for artifact in [
            &self.router.summaries,
            &self.router.codebooks,
            &self.router.row_codes,
            &self.page_directory,
            &self.mutation_directory,
        ]
        .into_iter()
        .chain(self.base_runs.iter().map(|run| &run.artifact))
        {
            if !uris.insert(artifact.uri.as_str()) {
                return Err(invalid("native bounded ANN artifact URIs must be unique"));
            }
        }
        for run in &self.delta_runs {
            if !uris.insert(run.artifact.uri.as_str()) {
                return Err(invalid("native bounded ANN artifact URIs must be unique"));
            }
        }
        Ok(())
    }
}

impl NativeAnnRef {
    pub(crate) fn validate(&self) -> Result<()> {
        if self.format_version != NATIVE_ANN_FORMAT_VERSION {
            return Err(invalid("native ANN format version differs"));
        }
        if self.generation == 0 {
            return Err(invalid("native ANN generation must be nonzero"));
        }
        match (self.generation, self.previous_generation_sha256.as_deref()) {
            (1, None) => {}
            (1, Some(_)) => {
                return Err(invalid(
                    "native ANN first generation must not name a predecessor",
                ));
            }
            (_, Some(digest)) => {
                validate_hex(digest, SHA256_HEX_LEN, "previous generation SHA-256")?;
            }
            (_, None) => {
                return Err(invalid(
                    "native ANN generation after one must name its predecessor",
                ));
            }
        }
        if self.source_identity.is_empty() {
            return Err(invalid("native ANN source identity must not be empty"));
        }
        if self.dimensions == 0 {
            return Err(invalid("native ANN dimensions must be nonzero"));
        }
        if let VectorMetric::Minkowski { p } = &self.metric
            && (!p.is_finite() || *p < 1.0)
        {
            return Err(invalid(
                "native ANN Minkowski power must be finite and >= 1",
            ));
        }
        if self.page_rows != NATIVE_ANN_PAGE_ROWS {
            return Err(invalid("native ANN page row count differs"));
        }
        if self.router.pq_width != NATIVE_ANN_PQ_WIDTH {
            return Err(invalid("native ANN PQ width differs"));
        }
        if self.router.summary_codes_per_page != NATIVE_ANN_SUMMARY_CODES_PER_PAGE {
            return Err(invalid("native ANN summary-code count differs"));
        }
        if self.router.physical_rows == 0 || self.router.page_count == 0 {
            return Err(invalid("native ANN router counts must be nonzero"));
        }
        let expected_pages = self
            .router
            .physical_rows
            .div_ceil(u64::from(self.page_rows));
        if expected_pages != u64::from(self.router.page_count) {
            return Err(invalid(
                "native ANN router page count differs from row count",
            ));
        }
        self.router.codebooks.validate("router-codebooks")?;
        self.router.row_codes.validate("router-row-codes")?;
        self.router.summary_codes.validate("router-summary-codes")?;
        self.page_directory.validate("page-directory")?;
        self.mutation_directory.validate("mutation-directory")?;
        validate_runs(&self.base_runs, "base-run")?;
        validate_runs(&self.delta_runs, "delta-run")?;
        let base_rows = self.base_runs.iter().try_fold(0_u64, |total, run| {
            total
                .checked_add(run.rows)
                .ok_or_else(|| invalid("native ANN base row count overflows"))
        })?;
        if base_rows != self.router.physical_rows {
            return Err(invalid("native ANN router rows differ from base runs"));
        }
        if let (Some(base), Some(delta)) = (self.base_runs.last(), self.delta_runs.first())
            && base.version_end >= delta.version_start
        {
            return Err(invalid("native ANN base and delta mutation ranges overlap"));
        }

        let artifacts = [
            &self.router.codebooks,
            &self.router.row_codes,
            &self.router.summary_codes,
            &self.page_directory,
            &self.mutation_directory,
        ];
        let mut uris = BTreeSet::new();
        for artifact in artifacts.into_iter().chain(
            self.base_runs
                .iter()
                .chain(self.delta_runs.iter())
                .map(|run| &run.artifact),
        ) {
            if !uris.insert(artifact.uri.as_str()) {
                return Err(invalid("native ANN artifact URIs must be unique"));
            }
        }
        Ok(())
    }
}

fn validate_runs(runs: &[NativeRunRef], role: &str) -> Result<()> {
    let mut previous_end: Option<&str> = None;
    for (ordinal, run) in runs.iter().enumerate() {
        run.validate(role, ordinal)?;
        if previous_end.is_some_and(|end| end >= run.version_start.as_str()) {
            return Err(invalid(
                "native ANN run mutation ranges overlap or are unordered",
            ));
        }
        previous_end = Some(&run.version_end);
    }
    Ok(())
}

fn canonical_json_value(value: serde_json::Value) -> serde_json::Value {
    match value {
        serde_json::Value::Array(values) => {
            serde_json::Value::Array(values.into_iter().map(canonical_json_value).collect())
        }
        serde_json::Value::Object(values) => serde_json::Value::Object(
            values
                .into_iter()
                .map(|(key, value)| (key, canonical_json_value(value)))
                .collect(),
        ),
        scalar => scalar,
    }
}

pub(crate) fn native_ann_root_bytes(reference: &NativeAnnRef) -> Result<Vec<u8>> {
    reference.validate()?;
    let value = serde_json::to_value(reference)
        .map_err(|error| invalid(format!("native ANN root serialization failed: {error}")))?;
    let mut bytes = serde_json::to_vec(&canonical_json_value(value))
        .map_err(|error| invalid(format!("native ANN root serialization failed: {error}")))?;
    bytes.push(b'\n');
    Ok(bytes)
}

pub(crate) fn native_ann_root_from_bytes(bytes: &[u8]) -> Result<NativeAnnRef> {
    let reference: NativeAnnRef = serde_json::from_slice(bytes)
        .map_err(|error| invalid(format!("native ANN root JSON is invalid: {error}")))?;
    let canonical = native_ann_root_bytes(&reference)?;
    if canonical != bytes {
        return Err(invalid("native ANN root JSON is not canonical"));
    }
    Ok(reference)
}

pub(crate) fn native_bounded_ann_root_bytes(reference: &NativeBoundedAnnRef) -> Result<Vec<u8>> {
    reference.validate()?;
    let value = serde_json::to_value(reference).map_err(|error| {
        invalid(format!(
            "native bounded ANN root serialization failed: {error}"
        ))
    })?;
    let mut bytes = serde_json::to_vec(&canonical_json_value(value)).map_err(|error| {
        invalid(format!(
            "native bounded ANN root serialization failed: {error}"
        ))
    })?;
    bytes.push(b'\n');
    Ok(bytes)
}

pub(crate) fn native_bounded_ann_root_from_bytes(bytes: &[u8]) -> Result<NativeBoundedAnnRef> {
    let reference: NativeBoundedAnnRef = serde_json::from_slice(bytes)
        .map_err(|error| invalid(format!("native bounded ANN root JSON is invalid: {error}")))?;
    if native_bounded_ann_root_bytes(&reference)? != bytes {
        return Err(invalid("native bounded ANN root JSON is not canonical"));
    }
    Ok(reference)
}

#[cfg(test)]
mod tests {
    use serde_json::Value;

    use super::*;
    use crate::metric::VectorMetric;

    const DIGEST_A: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const DIGEST_B: &str = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    const DIGEST_C: &str = "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc";
    const DIGEST_D: &str = "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd";
    const VERSION_1: &str = "000000000000000101010101010101010101010101010101";
    const VERSION_2: &str = "000000000000000202020202020202020202020202020202";
    const VERSION_3: &str = "000000000000000303030303030303030303030303030303";

    fn artifact(role: &str, suffix: &str, sha256: &str, encoded_bytes: u64) -> NativeArtifactRef {
        NativeArtifactRef {
            role: role.to_owned(),
            uri: format!("s3://borsuk-fixture/native/{suffix}"),
            sha256: sha256.to_owned(),
            encoded_bytes,
        }
    }

    fn run(
        role: &str,
        ordinal: u32,
        version_start: &str,
        version_end: &str,
        digest: &str,
    ) -> NativeRunRef {
        NativeRunRef {
            ordinal,
            rows: 256,
            version_start: version_start.to_owned(),
            version_end: version_end.to_owned(),
            artifact: artifact(role, &format!("{role}-{ordinal}.arrow"), digest, 4_096),
        }
    }

    fn bounded_delta_run(
        ordinal: u32,
        version_start: &str,
        version_end: &str,
        digest: &str,
    ) -> NativeBoundedDeltaRunRef {
        NativeBoundedDeltaRunRef {
            ordinal,
            rows: 256,
            version_start: version_start.to_owned(),
            version_end: version_end.to_owned(),
            artifact: artifact(
                "delta-run",
                &format!("delta-run-{ordinal}.arrow"),
                digest,
                4_096,
            ),
            sq8: NativeSq8Authority {
                low: vec![-2.0; 96],
                step: vec![0.02; 96],
            },
        }
    }

    fn valid_authority() -> NativeAnnRef {
        NativeAnnRef {
            format_version: 2,
            generation: 7,
            previous_generation_sha256: Some(DIGEST_A.to_owned()),
            source_identity: "deep-image/validation/v1".to_owned(),
            dimensions: 96,
            metric: VectorMetric::SquaredEuclidean,
            page_rows: 256,
            router: NativeRouterRef {
                pq_width: 16,
                summary_codes_per_page: 2,
                physical_rows: 512,
                page_count: 2,
                codebooks: artifact(
                    "router-codebooks",
                    "router-codebooks.parquet",
                    DIGEST_B,
                    65_536,
                ),
                row_codes: artifact(
                    "router-row-codes",
                    "router-row-codes.parquet",
                    DIGEST_C,
                    8_192,
                ),
                summary_codes: artifact(
                    "router-summary-codes",
                    "router-summary-codes.parquet",
                    DIGEST_D,
                    64,
                ),
            },
            page_directory: artifact("page-directory", "page-directory.parquet", DIGEST_C, 1_024),
            mutation_directory: artifact(
                "mutation-directory",
                "mutation-directory.arrow",
                DIGEST_A,
                2_048,
            ),
            base_runs: vec![NativeRunRef {
                rows: 512,
                ..run("base-run", 0, VERSION_1, VERSION_1, DIGEST_B)
            }],
            delta_runs: vec![
                run("delta-run", 0, VERSION_2, VERSION_2, DIGEST_C),
                run("delta-run", 1, VERSION_3, VERSION_3, DIGEST_D),
            ],
        }
    }

    fn canonical_test_json(value: Value) -> Value {
        match value {
            Value::Array(values) => {
                Value::Array(values.into_iter().map(canonical_test_json).collect())
            }
            Value::Object(values) => Value::Object(
                values
                    .into_iter()
                    .map(|(key, value)| (key, canonical_test_json(value)))
                    .collect(),
            ),
            scalar => scalar,
        }
    }

    fn canonical_test_bytes(value: Value) -> Vec<u8> {
        let mut bytes = serde_json::to_vec(&canonical_test_json(value)).unwrap();
        bytes.push(b'\n');
        bytes
    }

    #[test]
    fn native_ann_authority_round_trips_canonical_cross_language_root() {
        let authority = valid_authority();

        let bytes = native_ann_root_bytes(&authority).unwrap();

        assert_eq!(bytes.last(), Some(&b'\n'));
        assert_eq!(bytes.iter().filter(|byte| **byte == b'\n').count(), 1);
        assert!(!bytes.windows(2).any(|window| window == b": "));
        assert_eq!(native_ann_root_from_bytes(&bytes).unwrap(), authority);
        assert_eq!(native_ann_root_bytes(&authority).unwrap(), bytes);
    }

    #[test]
    fn native_ann_authority_rejects_every_identity_schema_and_generation_drift() {
        let valid = valid_authority();
        let valid_bytes = native_ann_root_bytes(&valid).unwrap();
        let valid_json: Value = serde_json::from_slice(&valid_bytes).unwrap();

        let mut malformed = Vec::new();
        let mut missing = valid_json.clone();
        missing.as_object_mut().unwrap().remove("source_identity");
        malformed.push(canonical_test_bytes(missing));
        let mut extra = valid_json;
        extra
            .as_object_mut()
            .unwrap()
            .insert("legacy_alias".to_owned(), Value::Bool(true));
        malformed.push(canonical_test_bytes(extra));
        let mut noncanonical = valid_bytes.clone();
        noncanonical.pop();
        malformed.push(noncanonical);
        for bytes in malformed {
            assert!(native_ann_root_from_bytes(&bytes).is_err());
        }

        let mut invalid = Vec::new();
        let mut changed = valid.clone();
        changed.format_version = 1;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.generation = 0;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.previous_generation_sha256 = Some("A".repeat(64));
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.source_identity.clear();
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.dimensions = 0;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.metric = VectorMetric::Minkowski { p: f32::NAN };
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.page_rows = 255;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.pq_width = 8;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.summary_codes_per_page = 1;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.row_codes.uri = "router-row-codes.parquet".to_owned();
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.row_codes.sha256 = "0".repeat(63);
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.row_codes.encoded_bytes = 0;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.row_codes.role = "router-summary-codes".to_owned();
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.router.summary_codes.uri = changed.router.row_codes.uri.clone();
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.delta_runs[1].ordinal = 0;
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.delta_runs.swap(0, 1);
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.delta_runs[1].version_start = VERSION_2.to_owned();
        invalid.push(changed);
        let mut changed = valid.clone();
        changed.base_runs[0].artifact.role = "delta-run".to_owned();
        invalid.push(changed);
        for authority in invalid {
            assert!(native_ann_root_bytes(&authority).is_err());
        }
    }

    fn valid_bounded_authority() -> NativeBoundedAnnRef {
        NativeBoundedAnnRef {
            format_version: 3,
            generation: 7,
            previous_generation_sha256: Some(DIGEST_A.to_owned()),
            source_identity: "re-laion-1m/development/v1".to_owned(),
            dimensions: 96,
            metric: VectorMetric::SquaredEuclidean,
            page_rows: 256,
            router: NativeBoundedRouterRef {
                pq_width: 64,
                summary_blocks_per_page: 2,
                physical_rows: 512,
                page_count: 2,
                summaries: artifact(
                    "route-summaries",
                    "route-summaries.parquet",
                    DIGEST_D,
                    24_576,
                ),
                codebooks: artifact(
                    "route-codebooks",
                    "route-codebooks.parquet",
                    DIGEST_B,
                    393_216,
                ),
                row_codes: artifact(
                    "route-row-codes",
                    "route-row-codes.parquet",
                    DIGEST_C,
                    32_768,
                ),
                limits: NativeBoundedRouteLimits {
                    cpu_permits: 2,
                    cpu_waiters: 8,
                    max_summary_pages: 2,
                    max_candidate_rows: 128,
                    max_output_pages: 2,
                    coalesce_gap_pages: 1,
                    range_concurrency: 2,
                    response_bytes_each: 1_048_576,
                    decoded_cache_bytes: 2_097_152,
                    workspace_bytes: 4_194_304,
                    runtime_reserve_bytes: 8_388_608,
                    resident_budget_bytes: 67_108_864,
                },
            },
            sq8: NativeSq8Authority {
                low: vec![-1.0; 96],
                step: vec![0.01; 96],
            },
            page_directory: artifact("page-directory", "page-directory.parquet", DIGEST_C, 1_024),
            mutation_directory: artifact(
                "mutation-directory",
                "mutation-directory.arrow",
                DIGEST_D,
                2_048,
            ),
            base_runs: vec![
                run("base-run", 0, VERSION_1, VERSION_1, DIGEST_B),
                run("base-run", 1, VERSION_2, VERSION_2, DIGEST_C),
            ],
            delta_runs: vec![bounded_delta_run(0, VERSION_3, VERSION_3, DIGEST_D)],
        }
    }

    #[test]
    fn native_bounded_authority_round_trips_canonical_format_v3() {
        let canonical = valid_bounded_authority();
        let bytes = native_bounded_ann_root_bytes(&canonical).unwrap();
        assert_eq!(bytes.last(), Some(&b'\n'));
        assert_eq!(
            native_bounded_ann_root_from_bytes(&bytes).unwrap(),
            canonical
        );
    }

    #[test]
    fn native_bounded_authority_rejects_every_identity_shape_and_budget_drift() {
        let canonical = valid_bounded_authority();
        let mut invalid = Vec::new();

        let mut changed = canonical.clone();
        changed.format_version = 2;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.previous_generation_sha256 = None;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.metric = VectorMetric::InnerProduct;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.page_rows = 128;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.pq_width = 16;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.summary_blocks_per_page = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.physical_rows = 513;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.summaries.role = "route-row-codes".to_owned();
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.summaries.uri = "route-summaries.parquet".to_owned();
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.summaries.sha256 = "A".repeat(64);
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.summaries.encoded_bytes = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.row_codes.uri = changed.router.codebooks.uri.clone();
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.cpu_permits = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.max_summary_pages = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.max_candidate_rows = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.max_output_pages = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.range_concurrency = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.response_bytes_each = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.router.limits.resident_budget_bytes = 0;
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.sq8.low.pop();
        invalid.push(changed);
        let mut changed = canonical.clone();
        changed.sq8.step[0] = 0.0;
        invalid.push(changed);

        for authority in invalid {
            assert!(native_bounded_ann_root_bytes(&authority).is_err());
        }
    }
}
