//! Narrow architecture-specific fused-dot kernel for BORSUK diagnostics.
//!
//! The public boundary is fixed-size and safe. Architecture intrinsics remain
//! encapsulated here so the main `borsuk` crate can continue to forbid unsafe
//! code.

/// Verified fused backend used by [`fused_dot_8x12`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FmaBackend {
    /// AArch64 Advanced SIMD fused multiply-add.
    Aarch64NeonFma,
    /// x86/x86_64 AVX fused multiply-add.
    X86AvxFma,
}

impl FmaBackend {
    /// Stable receipt spelling for this fused backend.
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Aarch64NeonFma => "aarch64-neon-fma",
            Self::X86AvxFma => "x86-avx-fma",
        }
    }
}

/// Error returned when no verified fused SIMD backend is available.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FmaUnavailable;

impl std::fmt::Display for FmaUnavailable {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("no verified fused SIMD backend is available")
    }
}

impl std::error::Error for FmaUnavailable {}

/// A fused-dot kernel whose architecture capability is detected once.
///
/// Reusing this value avoids feature detection and `Result` construction in
/// corpus-scale inner loops while preserving the registered arithmetic.
#[derive(Debug, Clone, Copy)]
pub struct FusedDot8x12 {
    backend: FmaBackend,
}

impl FusedDot8x12 {
    /// Detect and freeze the available fused backend.
    pub fn detect() -> Result<Self, FmaUnavailable> {
        #[cfg(target_arch = "aarch64")]
        if std::arch::is_aarch64_feature_detected!("neon") {
            return Ok(Self {
                backend: FmaBackend::Aarch64NeonFma,
            });
        }

        #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
        if std::arch::is_x86_feature_detected!("avx") && std::arch::is_x86_feature_detected!("fma")
        {
            return Ok(Self {
                backend: FmaBackend::X86AvxFma,
            });
        }

        Err(FmaUnavailable)
    }

    /// The exact backend frozen by [`Self::detect`].
    pub fn backend(self) -> FmaBackend {
        self.backend
    }

    /// Compute one registered dot product without repeating feature detection.
    #[inline(always)]
    pub fn dot(self, left: &[f32; 96], right: &[f32; 96]) -> f32 {
        match self.backend {
            #[cfg(target_arch = "aarch64")]
            FmaBackend::Aarch64NeonFma => {
                // SAFETY: `detect` established NEON availability and the
                // private field prevents construction with another backend.
                unsafe { aarch64_dot(left, right) }
            }
            #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
            FmaBackend::X86AvxFma => {
                // SAFETY: `detect` established AVX+FMA availability and the
                // private field prevents construction with another backend.
                unsafe { x86_dot(left, right) }
            }
            #[allow(unreachable_patterns)]
            _ => unreachable!("a fused kernel cannot contain a foreign backend"),
        }
    }
}

/// Detected eight-lane fused dot product for exactly 64 elements.
#[derive(Debug, Clone, Copy)]
pub struct FusedDot64 {
    backend: FmaBackend,
}

impl FusedDot64 {
    /// Detect and freeze the available fused backend.
    pub fn detect() -> Result<Self, FmaUnavailable> {
        FusedDot8x12::detect().map(|kernel| Self {
            backend: kernel.backend(),
        })
    }

    /// The exact backend frozen by [`Self::detect`].
    pub fn backend(self) -> FmaBackend {
        self.backend
    }

    /// Compute the registered eight-lane by eight-step fused dot product.
    #[inline(always)]
    pub fn dot(self, left: &[f32; 64], right: &[f32; 64]) -> f32 {
        fused_dot_fixed(self.backend, left, right)
    }
}

/// Detected row-major 64-by-64 fused matrix-vector kernel.
#[derive(Debug, Clone, Copy)]
pub struct FusedMatVec64 {
    dot: FusedDot64,
}

impl FusedMatVec64 {
    /// Detect and freeze the available fused backend.
    pub fn detect() -> Result<Self, FmaUnavailable> {
        FusedDot64::detect().map(|dot| Self { dot })
    }

    /// Multiply one row-major 64-by-64 matrix by one 64-element vector.
    pub fn matrix_vector_64x64(self, matrix: &[f32; 4_096], vector: &[f32; 64]) -> [f32; 64] {
        std::array::from_fn(|row| {
            let coefficients = matrix[row * 64..(row + 1) * 64]
                .try_into()
                .expect("a fixed matrix row has exactly 64 elements");
            self.dot.dot(coefficients, vector)
        })
    }
}

/// Detected row-major 64-by-768 fused matrix-vector kernel.
#[derive(Debug, Clone, Copy)]
pub struct FusedMatVec768 {
    backend: FmaBackend,
}

impl FusedMatVec768 {
    /// Detect and freeze the available fused backend.
    pub fn detect() -> Result<Self, FmaUnavailable> {
        FusedDot8x12::detect().map(|kernel| Self {
            backend: kernel.backend(),
        })
    }

    /// Multiply one row-major 64-by-768 matrix by one 768-element vector.
    pub fn matrix_vector_64x768(self, matrix: &[f32; 49_152], vector: &[f32; 768]) -> [f32; 64] {
        std::array::from_fn(|row| {
            let coefficients = matrix[row * 768..(row + 1) * 768]
                .try_into()
                .expect("a fixed matrix row has exactly 768 elements");
            fused_dot_fixed(self.backend, coefficients, vector)
        })
    }
}

#[inline(always)]
fn fused_dot_fixed<const N: usize>(backend: FmaBackend, left: &[f32; N], right: &[f32; N]) -> f32 {
    debug_assert!(N > 0 && N.is_multiple_of(8));
    match backend {
        #[cfg(target_arch = "aarch64")]
        FmaBackend::Aarch64NeonFma => {
            // SAFETY: detection established NEON availability and fixed-size
            // inputs make every generated lane access valid.
            unsafe { aarch64_dot_fixed(left, right) }
        }
        #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
        FmaBackend::X86AvxFma => {
            // SAFETY: detection established AVX+FMA availability and fixed-size
            // inputs make every generated lane access valid.
            unsafe { x86_dot_fixed(left, right) }
        }
        #[allow(unreachable_patterns)]
        _ => unreachable!("a fused kernel cannot contain a foreign backend"),
    }
}

/// Detected four-output f64 fused projection kernel.
#[derive(Debug, Clone, Copy)]
pub struct FusedProjection4 {
    backend: FmaBackend,
}

impl FusedProjection4 {
    /// Detect and freeze the available fused projection backend.
    pub fn detect() -> Result<Self, FmaUnavailable> {
        FusedDot8x12::detect().map(|kernel| Self {
            backend: kernel.backend(),
        })
    }

    /// The exact backend frozen by [`Self::detect`].
    pub fn backend(self) -> FmaBackend {
        self.backend
    }

    /// Project four adjacent outputs from source-major f32 coefficients.
    ///
    /// Every f64 lane consumes source dimensions in increasing order. Invalid
    /// shapes return `None` before entering the architecture-specific kernel.
    #[inline]
    pub fn project_source_major(
        self,
        basis: &[f32],
        query: &[f32],
        routing: usize,
        output: usize,
    ) -> Option<[f64; 4]> {
        if routing == 0
            || !routing.is_multiple_of(4)
            || output.checked_add(4)? > routing
            || basis.len() != query.len().checked_mul(routing)?
        {
            return None;
        }
        match self.backend {
            #[cfg(target_arch = "aarch64")]
            FmaBackend::Aarch64NeonFma => {
                // SAFETY: detection proved NEON availability; shape checks
                // prove all source-major coefficient accesses are in bounds.
                Some(unsafe { aarch64_project4(basis, query, routing, output) })
            }
            #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
            FmaBackend::X86AvxFma => {
                // SAFETY: detection proved AVX+FMA availability; shape checks
                // prove all source-major coefficient accesses are in bounds.
                Some(unsafe { x86_project4(basis, query, routing, output) })
            }
            #[allow(unreachable_patterns)]
            _ => unreachable!("a fused projection kernel cannot contain a foreign backend"),
        }
    }
}

/// Compute the registered eight-lane by twelve-step fused dot product.
///
/// Each lane starts at positive zero, consumes dimensions `lane * 12 + step`
/// for increasing `step`, and the eight extracted lanes are summed in order.
pub fn fused_dot_8x12(
    left: &[f32; 96],
    right: &[f32; 96],
) -> Result<(f32, FmaBackend), FmaUnavailable> {
    let kernel = FusedDot8x12::detect()?;
    Ok((kernel.dot(left, right), kernel.backend()))
}

/// Error returned when the qualified PQ4 table-lookup backend is unavailable.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Pq4Unavailable;

impl std::fmt::Display for Pq4Unavailable {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("no qualified PQ4 SIMD backend is available")
    }
}

impl std::error::Error for Pq4Unavailable {}

/// SIMD table-lookup backend frozen by [`Pq4BlockScorer::detect`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Pq4Backend {
    /// AArch64 Advanced SIMD byte-table lookup.
    Aarch64Neon,
    /// x86/x86_64 SSSE3 byte-table lookup.
    X86Ssse3,
}

/// A detected, safe PQ4 scorer for one 32-row transposed block.
///
/// Construction detects AArch64 NEON or x86 SSSE3 support once. Keeping
/// construction private prevents callers from invoking the target-feature
/// function on an unsupported processor.
#[derive(Debug, Clone, Copy)]
pub struct Pq4BlockScorer {
    backend: Pq4Backend,
}

impl Pq4BlockScorer {
    /// Detect the qualified table-lookup backend once before entering a scan.
    pub fn detect() -> Result<Self, Pq4Unavailable> {
        #[cfg(target_arch = "aarch64")]
        if std::arch::is_aarch64_feature_detected!("neon") {
            return Ok(Self {
                backend: Pq4Backend::Aarch64Neon,
            });
        }

        #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
        if std::arch::is_x86_feature_detected!("ssse3") {
            return Ok(Self {
                backend: Pq4Backend::X86Ssse3,
            });
        }

        Err(Pq4Unavailable)
    }

    /// The exact table-lookup backend frozen by [`Self::detect`].
    pub fn backend(self) -> Pq4Backend {
        self.backend
    }

    /// Score exactly 32 rows against 32 sixteen-entry lookup tables.
    #[inline(always)]
    pub fn score(self, block: &[u8; 512], tables: &[[u8; 16]; 32]) -> [u16; 32] {
        match self.backend {
            #[cfg(target_arch = "aarch64")]
            Pq4Backend::Aarch64Neon => {
                // SAFETY: `detect` established NEON availability and fixed-size
                // arguments make every 16-byte access valid.
                unsafe { aarch64_pq4_block_scores(block, tables) }
            }
            #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
            Pq4Backend::X86Ssse3 => {
                // SAFETY: `detect` established SSSE3 availability and fixed-size
                // arguments make every 16-byte access valid.
                unsafe { x86_pq4_block_scores(block, tables) }
            }
            #[allow(unreachable_patterns)]
            _ => unreachable!("a PQ4 scorer cannot contain a foreign backend"),
        }
    }
}

#[cfg(test)]
fn pq4_scalar_block_scores(block: &[u8; 512], tables: &[[u8; 16]; 32]) -> [u16; 32] {
    std::array::from_fn(|row| {
        (0..32)
            .map(|subspace| {
                let packed = block[subspace * 16 + row / 2];
                let code = if row.is_multiple_of(2) {
                    packed & 0x0f
                } else {
                    packed >> 4
                };
                u16::from(tables[subspace][usize::from(code)])
            })
            .sum()
    })
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn aarch64_pq4_block_scores(block: &[u8; 512], tables: &[[u8; 16]; 32]) -> [u16; 32] {
    use std::arch::aarch64::{
        vaddq_u16, vandq_u8, vdupq_n_u8, vdupq_n_u16, vget_high_u8, vget_low_u8, vld1q_u8,
        vmovl_u8, vqtbl1q_u8, vshrq_n_u8, vst1q_u16,
    };

    // SAFETY: every pointer is derived from a fixed-size array at a proven
    // 16-byte offset, and the function itself requires NEON.
    unsafe {
        let mask = vdupq_n_u8(0x0f);
        let mut even_low = vdupq_n_u16(0);
        let mut even_high = vdupq_n_u16(0);
        let mut odd_low = vdupq_n_u16(0);
        let mut odd_high = vdupq_n_u16(0);
        for (subspace, table_bytes) in tables.iter().enumerate() {
            let packed = vld1q_u8(block.as_ptr().add(subspace * 16));
            let table = vld1q_u8(table_bytes.as_ptr());
            let even = vqtbl1q_u8(table, vandq_u8(packed, mask));
            let odd = vqtbl1q_u8(table, vshrq_n_u8::<4>(packed));
            even_low = vaddq_u16(even_low, vmovl_u8(vget_low_u8(even)));
            even_high = vaddq_u16(even_high, vmovl_u8(vget_high_u8(even)));
            odd_low = vaddq_u16(odd_low, vmovl_u8(vget_low_u8(odd)));
            odd_high = vaddq_u16(odd_high, vmovl_u8(vget_high_u8(odd)));
        }
        let mut even = [0_u16; 16];
        let mut odd = [0_u16; 16];
        vst1q_u16(even.as_mut_ptr(), even_low);
        vst1q_u16(even.as_mut_ptr().add(8), even_high);
        vst1q_u16(odd.as_mut_ptr(), odd_low);
        vst1q_u16(odd.as_mut_ptr().add(8), odd_high);
        std::array::from_fn(|row| {
            if row.is_multiple_of(2) {
                even[row / 2]
            } else {
                odd[row / 2]
            }
        })
    }
}

#[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
#[target_feature(enable = "ssse3")]
unsafe fn x86_pq4_block_scores(block: &[u8; 512], tables: &[[u8; 16]; 32]) -> [u16; 32] {
    #[cfg(target_arch = "x86")]
    use std::arch::x86::{
        __m128i, _mm_add_epi16, _mm_and_si128, _mm_loadu_si128, _mm_set1_epi8, _mm_setzero_si128,
        _mm_shuffle_epi8, _mm_srli_epi16, _mm_storeu_si128, _mm_unpackhi_epi8, _mm_unpacklo_epi8,
    };
    #[cfg(target_arch = "x86_64")]
    use std::arch::x86_64::{
        __m128i, _mm_add_epi16, _mm_and_si128, _mm_loadu_si128, _mm_set1_epi8, _mm_setzero_si128,
        _mm_shuffle_epi8, _mm_srli_epi16, _mm_storeu_si128, _mm_unpackhi_epi8, _mm_unpacklo_epi8,
    };

    // SAFETY: each load/store addresses a fixed 16-byte region, SSSE3 was
    // detected before construction, and four u16 accumulators cannot exceed
    // the registered maximum score of 8,160.
    unsafe {
        let mask = _mm_set1_epi8(0x0f);
        let zero = _mm_setzero_si128();
        let mut even_low = zero;
        let mut even_high = zero;
        let mut odd_low = zero;
        let mut odd_high = zero;
        for (subspace, table_bytes) in tables.iter().enumerate() {
            let packed = _mm_loadu_si128(block.as_ptr().add(subspace * 16).cast::<__m128i>());
            let table = _mm_loadu_si128(table_bytes.as_ptr().cast::<__m128i>());
            let even = _mm_shuffle_epi8(table, _mm_and_si128(packed, mask));
            let odd_indices = _mm_and_si128(_mm_srli_epi16::<4>(packed), mask);
            let odd = _mm_shuffle_epi8(table, odd_indices);
            even_low = _mm_add_epi16(even_low, _mm_unpacklo_epi8(even, zero));
            even_high = _mm_add_epi16(even_high, _mm_unpackhi_epi8(even, zero));
            odd_low = _mm_add_epi16(odd_low, _mm_unpacklo_epi8(odd, zero));
            odd_high = _mm_add_epi16(odd_high, _mm_unpackhi_epi8(odd, zero));
        }
        let mut even = [0_u16; 16];
        let mut odd = [0_u16; 16];
        _mm_storeu_si128(even.as_mut_ptr().cast::<__m128i>(), even_low);
        _mm_storeu_si128(even.as_mut_ptr().add(8).cast::<__m128i>(), even_high);
        _mm_storeu_si128(odd.as_mut_ptr().cast::<__m128i>(), odd_low);
        _mm_storeu_si128(odd.as_mut_ptr().add(8).cast::<__m128i>(), odd_high);
        std::array::from_fn(|row| {
            if row.is_multiple_of(2) {
                even[row / 2]
            } else {
                odd[row / 2]
            }
        })
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn aarch64_dot_fixed<const N: usize>(left: &[f32; N], right: &[f32; N]) -> f32 {
    use std::arch::aarch64::{vfmaq_f32, vld1q_f32, vst1q_f32};

    // SAFETY: the caller established NEON support. N is a nonzero multiple of
    // eight for every public construction, so generated indices are in bounds.
    unsafe {
        let steps = N / 8;
        let mut low = vld1q_f32([0.0_f32; 4].as_ptr());
        let mut high = vld1q_f32([0.0_f32; 4].as_ptr());
        for step in 0..steps {
            let left_low = std::array::from_fn::<_, 4, _>(|lane| left[lane * steps + step]);
            let right_low = std::array::from_fn::<_, 4, _>(|lane| right[lane * steps + step]);
            let left_high = std::array::from_fn::<_, 4, _>(|lane| left[(lane + 4) * steps + step]);
            let right_high =
                std::array::from_fn::<_, 4, _>(|lane| right[(lane + 4) * steps + step]);
            low = vfmaq_f32(
                low,
                vld1q_f32(left_low.as_ptr()),
                vld1q_f32(right_low.as_ptr()),
            );
            high = vfmaq_f32(
                high,
                vld1q_f32(left_high.as_ptr()),
                vld1q_f32(right_high.as_ptr()),
            );
        }
        let mut lanes = [0.0_f32; 8];
        vst1q_f32(lanes.as_mut_ptr(), low);
        vst1q_f32(lanes.as_mut_ptr().add(4), high);
        lanes.into_iter().fold(0.0_f32, |sum, value| sum + value)
    }
}

#[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
#[target_feature(enable = "avx,fma")]
unsafe fn x86_dot_fixed<const N: usize>(left: &[f32; N], right: &[f32; N]) -> f32 {
    #[cfg(target_arch = "x86")]
    use std::arch::x86::{_mm256_fmadd_ps, _mm256_loadu_ps, _mm256_setzero_ps, _mm256_storeu_ps};
    #[cfg(target_arch = "x86_64")]
    use std::arch::x86_64::{
        _mm256_fmadd_ps, _mm256_loadu_ps, _mm256_setzero_ps, _mm256_storeu_ps,
    };

    // SAFETY: the caller established AVX+FMA support. N is a nonzero multiple
    // of eight for every public construction, so generated indices are valid.
    unsafe {
        let steps = N / 8;
        let mut accumulator = _mm256_setzero_ps();
        for step in 0..steps {
            let left_lanes = std::array::from_fn::<_, 8, _>(|lane| left[lane * steps + step]);
            let right_lanes = std::array::from_fn::<_, 8, _>(|lane| right[lane * steps + step]);
            accumulator = _mm256_fmadd_ps(
                _mm256_loadu_ps(left_lanes.as_ptr()),
                _mm256_loadu_ps(right_lanes.as_ptr()),
                accumulator,
            );
        }
        let mut lanes = [0.0_f32; 8];
        _mm256_storeu_ps(lanes.as_mut_ptr(), accumulator);
        lanes.into_iter().fold(0.0_f32, |sum, value| sum + value)
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn aarch64_dot(left: &[f32; 96], right: &[f32; 96]) -> f32 {
    use std::arch::aarch64::{vfmaq_f32, vld1q_f32, vst1q_f32};

    // SAFETY: the temporary arrays and output arrays contain exactly four
    // f32 lanes for each load/store.
    unsafe {
        let mut low = vld1q_f32([0.0_f32; 4].as_ptr());
        let mut high = vld1q_f32([0.0_f32; 4].as_ptr());
        for step in 0..12 {
            let left_low = std::array::from_fn::<_, 4, _>(|lane| left[lane * 12 + step]);
            let right_low = std::array::from_fn::<_, 4, _>(|lane| right[lane * 12 + step]);
            let left_high = std::array::from_fn::<_, 4, _>(|lane| left[(lane + 4) * 12 + step]);
            let right_high = std::array::from_fn::<_, 4, _>(|lane| right[(lane + 4) * 12 + step]);
            low = vfmaq_f32(
                low,
                vld1q_f32(left_low.as_ptr()),
                vld1q_f32(right_low.as_ptr()),
            );
            high = vfmaq_f32(
                high,
                vld1q_f32(left_high.as_ptr()),
                vld1q_f32(right_high.as_ptr()),
            );
        }
        let mut lanes = [0.0_f32; 8];
        vst1q_f32(lanes.as_mut_ptr(), low);
        vst1q_f32(lanes[4..].as_mut_ptr(), high);
        lanes.into_iter().fold(0.0_f32, |sum, value| sum + value)
    }
}

#[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
#[target_feature(enable = "avx,fma")]
unsafe fn x86_dot(left: &[f32; 96], right: &[f32; 96]) -> f32 {
    #[cfg(target_arch = "x86")]
    use std::arch::x86::{_mm256_fmadd_ps, _mm256_loadu_ps, _mm256_setzero_ps, _mm256_storeu_ps};
    #[cfg(target_arch = "x86_64")]
    use std::arch::x86_64::{
        _mm256_fmadd_ps, _mm256_loadu_ps, _mm256_setzero_ps, _mm256_storeu_ps,
    };

    // SAFETY: the temporary arrays and output array contain exactly eight f32
    // lanes for each unaligned load/store, and target features are enabled.
    unsafe {
        let mut accumulator = _mm256_setzero_ps();
        for step in 0..12 {
            let left_lanes = std::array::from_fn::<_, 8, _>(|lane| left[lane * 12 + step]);
            let right_lanes = std::array::from_fn::<_, 8, _>(|lane| right[lane * 12 + step]);
            accumulator = _mm256_fmadd_ps(
                _mm256_loadu_ps(left_lanes.as_ptr()),
                _mm256_loadu_ps(right_lanes.as_ptr()),
                accumulator,
            );
        }
        let mut lanes = [0.0_f32; 8];
        _mm256_storeu_ps(lanes.as_mut_ptr(), accumulator);
        lanes.into_iter().fold(0.0_f32, |sum, value| sum + value)
    }
}

#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn aarch64_project4(
    basis: &[f32],
    query: &[f32],
    routing: usize,
    output: usize,
) -> [f64; 4] {
    use std::arch::aarch64::{vdupq_n_f64, vfmaq_f64, vld1q_f64, vst1q_f64};

    // SAFETY: the public wrapper validated all slice and block bounds; local
    // arrays provide complete two-lane loads and output stores.
    unsafe {
        let mut low = vdupq_n_f64(0.0);
        let mut high = vdupq_n_f64(0.0);
        for (dimension, value) in query.iter().enumerate() {
            let start = dimension * routing + output;
            let coefficients = [
                f64::from(basis[start]),
                f64::from(basis[start + 1]),
                f64::from(basis[start + 2]),
                f64::from(basis[start + 3]),
            ];
            let scalar = vdupq_n_f64(f64::from(*value));
            low = vfmaq_f64(low, vld1q_f64(coefficients.as_ptr()), scalar);
            high = vfmaq_f64(high, vld1q_f64(coefficients.as_ptr().add(2)), scalar);
        }
        let mut result = [0.0_f64; 4];
        vst1q_f64(result.as_mut_ptr(), low);
        vst1q_f64(result.as_mut_ptr().add(2), high);
        result
    }
}

#[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
#[target_feature(enable = "avx,fma")]
unsafe fn x86_project4(basis: &[f32], query: &[f32], routing: usize, output: usize) -> [f64; 4] {
    #[cfg(target_arch = "x86")]
    use std::arch::x86::{_mm256_fmadd_pd, _mm256_loadu_pd, _mm256_set1_pd, _mm256_storeu_pd};
    #[cfg(target_arch = "x86_64")]
    use std::arch::x86_64::{_mm256_fmadd_pd, _mm256_loadu_pd, _mm256_set1_pd, _mm256_storeu_pd};

    // SAFETY: the public wrapper validated all slice and block bounds; local
    // arrays provide complete four-lane loads and output stores.
    unsafe {
        let mut accumulator = _mm256_set1_pd(0.0);
        for (dimension, value) in query.iter().enumerate() {
            let start = dimension * routing + output;
            let coefficients = [
                f64::from(basis[start]),
                f64::from(basis[start + 1]),
                f64::from(basis[start + 2]),
                f64::from(basis[start + 3]),
            ];
            accumulator = _mm256_fmadd_pd(
                _mm256_loadu_pd(coefficients.as_ptr()),
                _mm256_set1_pd(f64::from(*value)),
                accumulator,
            );
        }
        let mut result = [0.0_f64; 4];
        _mm256_storeu_pd(result.as_mut_ptr(), accumulator);
        result
    }
}

#[cfg(test)]
mod tests {
    use super::{
        FusedDot8x12, FusedDot64, FusedMatVec64, FusedMatVec768, FusedProjection4, Pq4Backend,
        Pq4BlockScorer, fused_dot_8x12, pq4_scalar_block_scores,
    };

    fn scalar(left: &[f32; 96], right: &[f32; 96]) -> f32 {
        let mut lanes = [0.0_f32; 8];
        for (lane, accumulator) in lanes.iter_mut().enumerate() {
            for step in 0..12 {
                let dimension = lane * 12 + step;
                *accumulator = left[dimension].mul_add(right[dimension], *accumulator);
            }
        }
        lanes.into_iter().fold(0.0_f32, |sum, value| sum + value)
    }

    fn scalar_dot<const N: usize>(left: &[f32; N], right: &[f32; N]) -> f32 {
        assert_eq!(N % 8, 0);
        let steps = N / 8;
        let mut lanes = [0.0_f32; 8];
        for (lane, accumulator) in lanes.iter_mut().enumerate() {
            for step in 0..steps {
                let dimension = lane * steps + step;
                *accumulator = left[dimension].mul_add(right[dimension], *accumulator);
            }
        }
        lanes.into_iter().fold(0.0_f32, |sum, value| sum + value)
    }

    #[test]
    fn v41_fma_dot64_matches_registered_scalar_bits() {
        let kernel = FusedDot64::detect().unwrap();
        for (left, right) in [
            ([0.0_f32; 64], [-0.0_f32; 64]),
            ([f32::from_bits(1); 64], [1.0_f32; 64]),
            (
                std::array::from_fn(|index| ((index * 37 % 101) as f32 - 50.0) / 103.0),
                std::array::from_fn(|index| ((index * 19 % 89) as f32 - 44.0) / 97.0),
            ),
            (
                std::array::from_fn(|index| (63 - index) as f32 / 67.0),
                std::array::from_fn(|index| (index as f32 - 31.0) / 71.0),
            ),
            ([f32::MAX / 128.0; 64], [f32::EPSILON; 64]),
        ] {
            assert_eq!(
                kernel.dot(&left, &right).to_bits(),
                scalar_dot(&left, &right).to_bits()
            );
        }
    }

    #[test]
    fn v41_fma_matvec64_and_768_match_registered_scalar_bits() {
        let matrix64 =
            std::array::from_fn::<_, 4096, _>(|index| ((index * 29 % 211) as f32 - 105.0) / 223.0);
        let vector64 =
            std::array::from_fn::<_, 64, _>(|index| ((index * 17 % 79) as f32 - 39.0) / 83.0);
        let expected64 = std::array::from_fn::<_, 64, _>(|row| {
            let coefficients: &[f32; 64] = matrix64[row * 64..(row + 1) * 64].try_into().unwrap();
            scalar_dot(coefficients, &vector64)
        });
        let actual64 = FusedMatVec64::detect()
            .unwrap()
            .matrix_vector_64x64(&matrix64, &vector64);
        assert_eq!(actual64.map(f32::to_bits), expected64.map(f32::to_bits));

        let matrix768 = std::array::from_fn::<_, 49_152, _>(|index| {
            ((index * 43 % 251) as f32 - 125.0) / 257.0
        });
        let vector768 =
            std::array::from_fn::<_, 768, _>(|index| ((index * 31 % 197) as f32 - 98.0) / 199.0);
        let expected768 = std::array::from_fn::<_, 64, _>(|row| {
            let coefficients: &[f32; 768] =
                matrix768[row * 768..(row + 1) * 768].try_into().unwrap();
            scalar_dot(coefficients, &vector768)
        });
        let actual768 = FusedMatVec768::detect()
            .unwrap()
            .matrix_vector_64x768(&matrix768, &vector768);
        assert_eq!(actual768.map(f32::to_bits), expected768.map(f32::to_bits));
    }

    #[test]
    fn fused_backend_matches_registered_scalar_bits() {
        let left = std::array::from_fn(|index| (index as f32 - 47.0) / 53.0);
        let right = std::array::from_fn(|index| (97.0 - index as f32) / 103.0);
        let (actual, _) = fused_dot_8x12(&left, &right).unwrap();
        assert_eq!(actual.to_bits(), scalar(&left, &right).to_bits());
        let kernel = FusedDot8x12::detect().unwrap();
        assert_eq!(kernel.dot(&left, &right).to_bits(), actual.to_bits());
        assert_eq!(kernel.backend(), fused_dot_8x12(&left, &right).unwrap().1);

        let subnormal = f32::from_bits(1);
        let left = [subnormal; 96];
        let right = [1.0_f32; 96];
        let (actual, _) = fused_dot_8x12(&left, &right).unwrap();
        assert_eq!(actual.to_bits(), scalar(&left, &right).to_bits());
    }

    #[test]
    fn fused_projection_four_outputs_match_increasing_source_scalar_bits() {
        let source = 97;
        let routing = 64;
        let basis = (0..source * routing)
            .map(|index| ((index * 37 % 251) as f32 - 125.0) / 257.0)
            .collect::<Vec<_>>();
        let query = (0..source)
            .map(|index| ((index * 19 % 113) as f32 - 56.0) / 127.0)
            .collect::<Vec<_>>();
        let kernel = FusedProjection4::detect().unwrap();
        for output in (0..routing).step_by(4) {
            let actual = kernel
                .project_source_major(&basis, &query, routing, output)
                .unwrap();
            let expected = std::array::from_fn::<_, 4, _>(|lane| {
                (0..source).fold(0.0_f64, |sum, dimension| {
                    f64::from(basis[dimension * routing + output + lane])
                        .mul_add(f64::from(query[dimension]), sum)
                })
            });
            assert!(
                actual
                    .iter()
                    .zip(expected)
                    .all(|(left, right)| left.to_bits() == right.to_bits())
            );
        }
        assert!(
            kernel
                .project_source_major(&basis[..basis.len() - 1], &query, routing, 0)
                .is_none()
        );
        assert!(
            kernel
                .project_source_major(&basis, &query, routing, routing - 3)
                .is_none()
        );
    }

    #[test]
    fn pq4_block_scalar_reference_decodes_nibbles_and_never_overflows() {
        let mut block = [0_u8; 512];
        for subspace in 0..32 {
            for packed_row in 0..16 {
                let even = ((subspace + packed_row * 2) % 16) as u8;
                let odd = ((15 + subspace - packed_row) % 16) as u8;
                block[subspace * 16 + packed_row] = even | (odd << 4);
            }
        }
        let tables = std::array::from_fn(|subspace| {
            std::array::from_fn(|centroid| ((subspace * 3 + centroid * 7) % 256) as u8)
        });

        let actual = pq4_scalar_block_scores(&block, &tables);
        for (row, score) in actual.into_iter().enumerate() {
            let expected = (0..32)
                .map(|subspace| {
                    let packed = block[subspace * 16 + row / 2];
                    let code = if row % 2 == 0 {
                        packed & 0x0f
                    } else {
                        packed >> 4
                    };
                    u16::from(tables[subspace][usize::from(code)])
                })
                .sum::<u16>();
            assert_eq!(score, expected, "row {row}");
            assert!(score <= 8_160);
        }

        assert_eq!(
            pq4_scalar_block_scores(&[0xff; 512], &[[255; 16]; 32]),
            [8_160; 32]
        );
    }

    #[test]
    fn pq4_block_backend_detection_is_explicit_and_portable() {
        let detected = Pq4BlockScorer::detect().unwrap();
        #[cfg(target_arch = "aarch64")]
        assert_eq!(detected.backend(), Pq4Backend::Aarch64Neon);
        #[cfg(any(target_arch = "x86", target_arch = "x86_64"))]
        assert_eq!(detected.backend(), Pq4Backend::X86Ssse3);
    }

    #[cfg(any(target_arch = "aarch64", target_arch = "x86", target_arch = "x86_64"))]
    #[test]
    fn pq4_block_simd_matches_scalar_for_boundary_patterns() {
        let scorer = Pq4BlockScorer::detect().unwrap();
        let tables = std::array::from_fn(|subspace| {
            std::array::from_fn(|centroid| ((subspace * 11 + centroid * 13) % 256) as u8)
        });
        for block in [
            [0_u8; 512],
            [0xff_u8; 512],
            std::array::from_fn(|index| (index as u8).wrapping_mul(73)),
        ] {
            assert_eq!(
                scorer.score(&block, &tables),
                pq4_scalar_block_scores(&block, &tables)
            );
        }
    }
}
