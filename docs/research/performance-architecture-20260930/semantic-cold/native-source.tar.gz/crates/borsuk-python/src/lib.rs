//! Native Python bindings for BORSUK.

use std::{collections::BTreeMap, path::PathBuf, sync::RwLock, time::Duration};

use borsuk::{
    AddReport, BorsukIndex, CompactionOptions, CompactionReport, DEFAULT_COMPACTION_MAX_SEGMENTS,
    DeleteReport, Fusion, GarbageCollectionOptions, GarbageCollectionReport, HybridOptions,
    HybridQuery, IncrementalMaintenanceOptions, IncrementalReport, IndexConfig, IndexStats,
    LeafCapability, LeafMode, OpenOptions, PurgeReport, RebuildOptions, RebuildReport,
    RequestCounts, SearchHit, SearchMode, SearchOptions, SearchReport, VectorKind, VectorMetric,
    VectorRecord, VectorSpec, WarmReport,
};
use pyo3::{
    buffer::PyBuffer,
    exceptions::{PyRuntimeError, PyValueError},
    prelude::*,
    types::PyAny,
};

pyo3::create_exception!(
    _borsuk,
    BorsukError,
    PyRuntimeError,
    "Runtime error raised by the BORSUK native core."
);

use borsuk::{Filter, MetaValue, Metadata};
use pyo3::types::{
    PyAnyMethods, PyBool, PyBoolMethods, PyDict, PyDictMethods, PyList, PyListMethods,
    PyTypeMethods,
};

/// A listed record as `(id, vector, metadata)` for the Python `list_records` API.
type PyRecordEntry = (String, Vec<f32>, Py<PyAny>);
type PySparseEntry = Option<(Vec<u32>, Vec<f32>)>;
type PyNamedVectorEntry = (
    String,
    Option<Vec<f32>>,
    Option<(Vec<u32>, Vec<f32>)>,
    Option<Vec<Vec<f32>>>,
);
type PyNamedVectorRecord = Vec<PyNamedVectorEntry>;
type PyVectorSpecEntry = (String, usize, String, String, String);

/// Convert a Python value into a typed `MetaValue`. `bool` is checked before
/// `int` (Python bools are ints), and `datetime` objects become epoch-ms
/// timestamps.
fn py_to_metavalue(value: &Bound<'_, PyAny>) -> PyResult<MetaValue> {
    if value.is_none() {
        return Ok(MetaValue::Null);
    }
    if let Ok(b) = value.cast::<PyBool>() {
        return Ok(MetaValue::Bool(b.is_true()));
    }
    if let Some(ms) = datetime_to_epoch_ms(value)? {
        return Ok(MetaValue::Timestamp(ms));
    }
    if let Ok(i) = value.extract::<i64>() {
        return Ok(MetaValue::Int(i));
    }
    if let Ok(f) = value.extract::<f64>() {
        return Ok(MetaValue::Float(f));
    }
    if let Ok(s) = value.extract::<String>() {
        return Ok(MetaValue::Str(s));
    }
    if let Ok(list) = value.cast::<PyList>() {
        return Ok(MetaValue::List(
            list.iter()
                .map(|item| py_to_metavalue(&item))
                .collect::<PyResult<_>>()?,
        ));
    }
    if let Ok(dict) = value.cast::<PyDict>() {
        return Ok(MetaValue::Map(py_to_metadata(dict)?));
    }
    Err(PyValueError::new_err(
        "unsupported metadata value; expected None/bool/int/float/str/datetime/list/dict",
    ))
}

fn datetime_to_epoch_ms(value: &Bound<'_, PyAny>) -> PyResult<Option<i64>> {
    let type_name = value.get_type().name()?;
    if type_name == "datetime" && value.hasattr("timestamp")? {
        let seconds: f64 = value.call_method0("timestamp")?.extract()?;
        return Ok(Some((seconds * 1000.0) as i64));
    }
    Ok(None)
}

/// Convert an optional per-record list of metadata dicts, checking the count
/// matches the number of vectors.
fn convert_metadata_list(
    metadata: Option<&[Bound<'_, PyAny>]>,
    expected: usize,
) -> PyResult<Option<Vec<Metadata>>> {
    let Some(rows) = metadata else {
        return Ok(None);
    };
    if rows.len() != expected {
        return Err(PyValueError::new_err(format!(
            "metadata length {} must match vectors length {expected}",
            rows.len()
        )));
    }
    let mut out = Vec::with_capacity(rows.len());
    for row in rows {
        let dict = row
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each metadata entry must be a dict"))?;
        out.push(py_to_metadata(dict)?);
    }
    Ok(Some(out))
}

fn convert_sparse_list(
    sparse: Option<&[PySparseEntry]>,
    expected: usize,
) -> PyResult<Option<Vec<PySparseEntry>>> {
    let Some(rows) = sparse else {
        return Ok(None);
    };
    if rows.len() != expected {
        return Err(PyValueError::new_err(format!(
            "sparse length {} must match vectors length {expected}",
            rows.len()
        )));
    }
    Ok(Some(rows.to_vec()))
}

fn convert_text_list(
    text: Option<&[Option<String>]>,
    expected: usize,
) -> PyResult<Option<Vec<Option<String>>>> {
    let Some(rows) = text else {
        return Ok(None);
    };
    if rows.len() != expected {
        return Err(PyValueError::new_err(format!(
            "text length {} must match vectors length {expected}",
            rows.len()
        )));
    }
    Ok(Some(rows.to_vec()))
}

fn convert_named_vectors_list(
    named_vectors: Option<&[Option<PyNamedVectorRecord>]>,
    expected: usize,
) -> PyResult<Option<Vec<Option<PyNamedVectorRecord>>>> {
    let Some(rows) = named_vectors else {
        return Ok(None);
    };
    if rows.len() != expected {
        return Err(PyValueError::new_err(format!(
            "named_vectors length {} must match vectors length {expected}",
            rows.len()
        )));
    }
    Ok(Some(rows.to_vec()))
}

fn py_to_metadata(dict: &Bound<'_, PyDict>) -> PyResult<Metadata> {
    let mut metadata = Metadata::new();
    for (key, value) in dict.iter() {
        let key: String = key
            .extract()
            .map_err(|_| PyValueError::new_err("metadata keys must be strings"))?;
        metadata.insert(key, py_to_metavalue(&value)?);
    }
    Ok(metadata)
}

fn metavalue_to_py(py: Python<'_>, value: &MetaValue) -> PyResult<Py<PyAny>> {
    use pyo3::IntoPyObjectExt;
    Ok(match value {
        MetaValue::Null => py.None(),
        MetaValue::Bool(b) => b.into_py_any(py)?,
        MetaValue::Int(i) | MetaValue::Timestamp(i) => i.into_py_any(py)?,
        MetaValue::Float(f) => f.into_py_any(py)?,
        MetaValue::Str(s) => s.as_str().into_py_any(py)?,
        MetaValue::List(items) => {
            let list = PyList::empty(py);
            for item in items {
                list.append(metavalue_to_py(py, item)?)?;
            }
            list.into_py_any(py)?
        }
        MetaValue::Map(map) => metadata_to_py(py, map)?,
    })
}

fn metadata_to_py(py: Python<'_>, metadata: &Metadata) -> PyResult<Py<PyAny>> {
    use pyo3::IntoPyObjectExt;
    let dict = PyDict::new(py);
    for (key, value) in metadata {
        dict.set_item(key, metavalue_to_py(py, value)?)?;
    }
    dict.into_py_any(py)
}

/// Parse a Pinecone-style filter dict into a `Filter` via JSON. Values keep
/// their JSON kinds (integral numbers become `Int`); timestamp operands can be
/// passed as epoch numbers.
fn py_to_filter(value: &Bound<'_, PyAny>) -> PyResult<Filter> {
    Filter::from_json(&py_to_json(value)?).map_err(to_py_error)
}

fn py_to_json(value: &Bound<'_, PyAny>) -> PyResult<serde_json::Value> {
    if value.is_none() {
        return Ok(serde_json::Value::Null);
    }
    if let Ok(b) = value.cast::<PyBool>() {
        return Ok(serde_json::Value::Bool(b.is_true()));
    }
    if let Ok(i) = value.extract::<i64>() {
        return Ok(serde_json::Value::from(i));
    }
    if let Ok(f) = value.extract::<f64>() {
        return Ok(serde_json::Value::from(f));
    }
    if let Ok(s) = value.extract::<String>() {
        return Ok(serde_json::Value::String(s));
    }
    if let Ok(list) = value.cast::<PyList>() {
        return Ok(serde_json::Value::Array(
            list.iter()
                .map(|item| py_to_json(&item))
                .collect::<PyResult<_>>()?,
        ));
    }
    if let Ok(dict) = value.cast::<PyDict>() {
        let mut map = serde_json::Map::new();
        for (key, item) in dict.iter() {
            map.insert(key.extract()?, py_to_json(&item)?);
        }
        return Ok(serde_json::Value::Object(map));
    }
    Err(PyValueError::new_err("unsupported value in filter"))
}

#[pyclass(name = "Hit", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyHit {
    #[pyo3(get)]
    id: String,
    #[pyo3(get)]
    id_bytes: Vec<u8>,
    #[pyo3(get)]
    distance: f32,
    metadata: Option<Metadata>,
}

#[pymethods]
impl PyHit {
    fn __repr__(&self) -> String {
        format!("Hit(id={:?}, distance={})", self.id, self.distance)
    }

    /// The hit's metadata dict, present only when `include_metadata=True`.
    #[getter]
    fn metadata(&self, py: Python<'_>) -> PyResult<Option<Py<PyAny>>> {
        self.metadata
            .as_ref()
            .map(|metadata| metadata_to_py(py, metadata))
            .transpose()
    }
}

#[pyclass(name = "IndexStats", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyIndexStats {
    #[pyo3(get)]
    metric: String,
    #[pyo3(get)]
    dimensions: usize,
    #[pyo3(get)]
    segment_max_vectors: usize,
    #[pyo3(get)]
    ram_budget_bytes: Option<u64>,
    #[pyo3(get)]
    text: bool,
    #[pyo3(get)]
    named_vectors: Vec<String>,
    #[pyo3(get)]
    sparse_encoded_vectors: usize,
    #[pyo3(get)]
    dense_encoded_vectors: usize,
    #[pyo3(get)]
    manifest_version: u64,
    #[pyo3(get)]
    routing_max_level: u8,
    #[pyo3(get)]
    routing_page_fanout: usize,
    #[pyo3(get)]
    routing_leaf_pages: usize,
    #[pyo3(get)]
    routing_pages: usize,
    #[pyo3(get)]
    segments: usize,
    #[pyo3(get)]
    records: usize,
    #[pyo3(get)]
    segment_bytes: u64,
    #[pyo3(get)]
    graph_bytes: u64,
    #[pyo3(get)]
    resident_bytes_estimate: u64,
    #[pyo3(get)]
    prepared_positioned_bytes: u64,
    #[pyo3(get)]
    collection_resident_bytes: u64,
    #[pyo3(get)]
    retained_bytes: u64,
    #[pyo3(get)]
    retained_capacity_bytes: u64,
    #[pyo3(get)]
    retained_peak_bytes: u64,
    #[pyo3(get)]
    transient_bytes: u64,
    #[pyo3(get)]
    transient_capacity_bytes: u64,
    #[pyo3(get)]
    transient_peak_bytes: u64,
}

#[pymethods]
impl PyIndexStats {
    fn __repr__(&self) -> String {
        format!(
            "IndexStats(metric={:?}, dimensions={}, segment_max_vectors={}, ram_budget_bytes={:?}, text={}, named_vectors={:?}, sparse_encoded_vectors={}, dense_encoded_vectors={}, manifest_version={}, routing_max_level={}, routing_page_fanout={}, routing_leaf_pages={}, routing_pages={}, segments={}, records={}, segment_bytes={}, graph_bytes={}, resident_bytes_estimate={}, prepared_positioned_bytes={}, collection_resident_bytes={}, retained_bytes={}, retained_capacity_bytes={}, retained_peak_bytes={}, transient_bytes={}, transient_capacity_bytes={}, transient_peak_bytes={})",
            self.metric,
            self.dimensions,
            self.segment_max_vectors,
            self.ram_budget_bytes,
            self.text,
            self.named_vectors,
            self.sparse_encoded_vectors,
            self.dense_encoded_vectors,
            self.manifest_version,
            self.routing_max_level,
            self.routing_page_fanout,
            self.routing_leaf_pages,
            self.routing_pages,
            self.segments,
            self.records,
            self.segment_bytes,
            self.graph_bytes,
            self.resident_bytes_estimate,
            self.prepared_positioned_bytes,
            self.collection_resident_bytes,
            self.retained_bytes,
            self.retained_capacity_bytes,
            self.retained_peak_bytes,
            self.transient_bytes,
            self.transient_capacity_bytes,
            self.transient_peak_bytes
        )
    }
}

#[pyclass(name = "WarmReport", frozen, skip_from_py_object)]
#[derive(Clone, Copy)]
struct PyWarmReport {
    #[pyo3(get)]
    segments_loaded: usize,
    #[pyo3(get)]
    segments_total: usize,
    #[pyo3(get)]
    segments_resident: usize,
    #[pyo3(get)]
    graphs_resident: usize,
    #[pyo3(get)]
    coverage_complete: bool,
    #[pyo3(get)]
    bytes_resident: u64,
}

#[pymethods]
impl PyWarmReport {
    fn __repr__(&self) -> String {
        format!(
            "WarmReport(segments_loaded={}, segments_total={}, segments_resident={}, graphs_resident={}, coverage_complete={}, bytes_resident={})",
            self.segments_loaded,
            self.segments_total,
            self.segments_resident,
            self.graphs_resident,
            self.coverage_complete,
            self.bytes_resident
        )
    }
}

#[pyclass(name = "RequestCounts", frozen, skip_from_py_object)]
#[derive(Clone, Copy)]
struct PyRequestCounts {
    #[pyo3(get)]
    gets: u64,
    #[pyo3(get)]
    puts: u64,
    #[pyo3(get)]
    deletes: u64,
    #[pyo3(get)]
    heads: u64,
    #[pyo3(get)]
    lists: u64,
    #[pyo3(get)]
    total: u64,
}

#[pymethods]
impl PyRequestCounts {
    fn __repr__(&self) -> String {
        format!(
            "RequestCounts(gets={}, puts={}, deletes={}, heads={}, lists={}, total={})",
            self.gets, self.puts, self.deletes, self.heads, self.lists, self.total
        )
    }
}

impl From<RequestCounts> for PyRequestCounts {
    fn from(counts: RequestCounts) -> Self {
        Self {
            gets: counts.gets,
            puts: counts.puts,
            deletes: counts.deletes,
            heads: counts.heads,
            lists: counts.lists,
            total: counts.total(),
        }
    }
}

#[pyclass(name = "AddReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyAddReport {
    #[pyo3(get)]
    segments_written: usize,
    #[pyo3(get)]
    graph_payloads_written: usize,
    #[pyo3(get)]
    manifest_tables_written: usize,
    #[pyo3(get)]
    routing_pages_written: usize,
    #[pyo3(get)]
    total_bytes_written: u64,
    #[pyo3(get)]
    bytes_per_vector: f64,
    #[pyo3(get)]
    requests: PyRequestCounts,
}

#[pymethods]
impl PyAddReport {
    fn __repr__(&self) -> String {
        format!(
            "AddReport(segments_written={}, graph_payloads_written={}, manifest_tables_written={}, routing_pages_written={}, total_bytes_written={}, bytes_per_vector={}, requests={})",
            self.segments_written,
            self.graph_payloads_written,
            self.manifest_tables_written,
            self.routing_pages_written,
            self.total_bytes_written,
            self.bytes_per_vector,
            self.requests.__repr__()
        )
    }
}

#[pyclass(name = "DeleteReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyDeleteReport {
    #[pyo3(get)]
    ids_submitted: usize,
    #[pyo3(get)]
    published: bool,
    #[pyo3(get)]
    requests: PyRequestCounts,
}

#[pymethods]
impl PyDeleteReport {
    fn __repr__(&self) -> String {
        format!(
            "DeleteReport(ids_submitted={}, published={}, requests={})",
            self.ids_submitted,
            self.published,
            self.requests.__repr__()
        )
    }
}

impl From<DeleteReport> for PyDeleteReport {
    fn from(report: DeleteReport) -> Self {
        Self {
            ids_submitted: report.ids_submitted,
            published: report.published,
            requests: report.requests.into(),
        }
    }
}

#[pyclass(name = "PurgeReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyPurgeReport {
    #[pyo3(get)]
    segments_rewritten: usize,
    #[pyo3(get)]
    records_purged: usize,
    #[pyo3(get)]
    tombstones_cleared: usize,
    #[pyo3(get)]
    published: bool,
    #[pyo3(get)]
    requests: PyRequestCounts,
}

#[pymethods]
impl PyPurgeReport {
    fn __repr__(&self) -> String {
        format!(
            "PurgeReport(segments_rewritten={}, records_purged={}, tombstones_cleared={}, published={}, requests={})",
            self.segments_rewritten,
            self.records_purged,
            self.tombstones_cleared,
            self.published,
            self.requests.__repr__()
        )
    }
}

impl From<PurgeReport> for PyPurgeReport {
    fn from(report: PurgeReport) -> Self {
        Self {
            segments_rewritten: report.segments_rewritten,
            records_purged: report.records_purged,
            tombstones_cleared: report.tombstones_cleared,
            published: report.published,
            requests: report.requests.into(),
        }
    }
}

#[pyclass(name = "IncrementalReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyIncrementalReport {
    #[pyo3(get)]
    splits: usize,
    #[pyo3(get)]
    merges: usize,
    #[pyo3(get)]
    segments_created: usize,
    #[pyo3(get)]
    segments_removed: usize,
    #[pyo3(get)]
    records_moved: usize,
    #[pyo3(get)]
    published: bool,
    #[pyo3(get)]
    requests: PyRequestCounts,
}

#[pymethods]
impl PyIncrementalReport {
    fn __repr__(&self) -> String {
        format!(
            "IncrementalReport(splits={}, merges={}, segments_created={}, segments_removed={}, records_moved={}, published={}, requests={})",
            self.splits,
            self.merges,
            self.segments_created,
            self.segments_removed,
            self.records_moved,
            self.published,
            self.requests.__repr__()
        )
    }
}

impl From<IncrementalReport> for PyIncrementalReport {
    fn from(report: IncrementalReport) -> Self {
        Self {
            splits: report.splits,
            merges: report.merges,
            segments_created: report.segments_created,
            segments_removed: report.segments_removed,
            records_moved: report.records_moved,
            published: report.published,
            requests: report.requests.into(),
        }
    }
}

#[pyclass(name = "SearchReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PySearchReport {
    #[pyo3(get)]
    hits: Vec<PyHit>,
    #[pyo3(get)]
    leaf_mode: String,
    #[pyo3(get)]
    termination_reason: String,
    #[pyo3(get)]
    recall_guarantee: String,
    #[pyo3(get)]
    segments_total: usize,
    #[pyo3(get)]
    segments_searched: usize,
    #[pyo3(get)]
    segments_skipped: usize,
    #[pyo3(get)]
    routing_page_indexes_read: usize,
    #[pyo3(get)]
    routing_pages_read: usize,
    #[pyo3(get)]
    bytes_read: u64,
    #[pyo3(get)]
    prefetched_bytes_unused: u64,
    #[pyo3(get)]
    graph_bytes_read: u64,
    #[pyo3(get)]
    decoded_cache_hits: usize,
    #[pyo3(get)]
    decoded_cache_bytes_read: u64,
    #[pyo3(get)]
    object_cache_hits: usize,
    #[pyo3(get)]
    object_cache_misses: usize,
    #[pyo3(get)]
    disk_cache_bytes_read: u64,
    #[pyo3(get)]
    backing_bytes_read: u64,
    #[pyo3(get)]
    disk_cache_reads: u64,
    #[pyo3(get)]
    backing_reads: u64,
    #[pyo3(get)]
    cache_repairs: usize,
    #[pyo3(get)]
    records_considered: usize,
    #[pyo3(get)]
    records_scored: usize,
    #[pyo3(get)]
    graph_candidates_added: usize,
    #[pyo3(get)]
    global_graph_chunks_searched: usize,
    #[pyo3(get)]
    global_scan_chunks_searched: usize,
    #[pyo3(get)]
    global_base_approximate_us: u64,
    #[pyo3(get)]
    global_base_head_admission_us: u64,
    #[pyo3(get)]
    global_base_head_fetch_us: u64,
    #[pyo3(get)]
    global_base_head_decode_admission_us: u64,
    #[pyo3(get)]
    global_base_head_decode_us: u64,
    #[pyo3(get)]
    global_base_exact_admission_us: u64,
    #[pyo3(get)]
    global_base_exact_fetch_us: u64,
    #[pyo3(get)]
    global_base_exact_read_us_max: u64,
    #[pyo3(get)]
    global_base_exact_read_us_sum: u64,
    #[pyo3(get)]
    global_base_exact_reads_over_20ms: u64,
    #[pyo3(get)]
    global_base_exact_reads_over_30ms: u64,
    #[pyo3(get)]
    global_base_exact_reads_over_50ms: u64,
    #[pyo3(get)]
    global_base_exact_reads_over_100ms: u64,
    #[pyo3(get)]
    global_base_exact_cpu_us: u64,
    #[pyo3(get)]
    global_base_exact_rerank_us: u64,
    #[pyo3(get)]
    resident_bytes_estimate: u64,
    #[pyo3(get)]
    prepared_positioned_bytes: u64,
    #[pyo3(get)]
    collection_resident_bytes: u64,
    #[pyo3(get)]
    retained_bytes: u64,
    #[pyo3(get)]
    retained_capacity_bytes: u64,
    #[pyo3(get)]
    retained_peak_bytes: u64,
    #[pyo3(get)]
    transient_bytes: u64,
    #[pyo3(get)]
    transient_capacity_bytes: u64,
    #[pyo3(get)]
    transient_peak_bytes: u64,
    #[pyo3(get)]
    elapsed_ms: u64,
    #[pyo3(get)]
    requests: PyRequestCounts,
    #[pyo3(get)]
    rows_evaluated: usize,
    #[pyo3(get)]
    rows_passed_filter: usize,
    #[pyo3(get)]
    segments_pruned_by_filter: usize,
}

#[pymethods]
impl PySearchReport {
    fn __repr__(&self) -> String {
        format!(
            "SearchReport(hits={}, leaf_mode={:?}, termination_reason={:?}, recall_guarantee={:?}, segments_total={}, segments_searched={}, segments_skipped={}, routing_page_indexes_read={}, routing_pages_read={}, bytes_read={}, prefetched_bytes_unused={}, graph_bytes_read={}, decoded_cache_hits={}, decoded_cache_bytes_read={}, object_cache_hits={}, object_cache_misses={}, disk_cache_bytes_read={}, backing_bytes_read={}, disk_cache_reads={}, backing_reads={}, cache_repairs={}, records_considered={}, records_scored={}, graph_candidates_added={}, global_graph_chunks_searched={}, global_scan_chunks_searched={}, global_base_approximate_us={}, global_base_head_admission_us={}, global_base_head_fetch_us={}, global_base_head_decode_admission_us={}, global_base_head_decode_us={}, global_base_exact_admission_us={}, global_base_exact_fetch_us={}, global_base_exact_cpu_us={}, global_base_exact_rerank_us={}, resident_bytes_estimate={}, prepared_positioned_bytes={}, collection_resident_bytes={}, retained_bytes={}, retained_capacity_bytes={}, retained_peak_bytes={}, transient_bytes={}, transient_capacity_bytes={}, transient_peak_bytes={}, elapsed_ms={}, requests={})",
            self.hits.len(),
            self.leaf_mode,
            self.termination_reason,
            self.recall_guarantee,
            self.segments_total,
            self.segments_searched,
            self.segments_skipped,
            self.routing_page_indexes_read,
            self.routing_pages_read,
            self.bytes_read,
            self.prefetched_bytes_unused,
            self.graph_bytes_read,
            self.decoded_cache_hits,
            self.decoded_cache_bytes_read,
            self.object_cache_hits,
            self.object_cache_misses,
            self.disk_cache_bytes_read,
            self.backing_bytes_read,
            self.disk_cache_reads,
            self.backing_reads,
            self.cache_repairs,
            self.records_considered,
            self.records_scored,
            self.graph_candidates_added,
            self.global_graph_chunks_searched,
            self.global_scan_chunks_searched,
            self.global_base_approximate_us,
            self.global_base_head_admission_us,
            self.global_base_head_fetch_us,
            self.global_base_head_decode_admission_us,
            self.global_base_head_decode_us,
            self.global_base_exact_admission_us,
            self.global_base_exact_fetch_us,
            self.global_base_exact_cpu_us,
            self.global_base_exact_rerank_us,
            self.resident_bytes_estimate,
            self.prepared_positioned_bytes,
            self.collection_resident_bytes,
            self.retained_bytes,
            self.retained_capacity_bytes,
            self.retained_peak_bytes,
            self.transient_bytes,
            self.transient_capacity_bytes,
            self.transient_peak_bytes,
            self.elapsed_ms,
            self.requests.__repr__()
        )
    }
}

#[pyclass(name = "CompactionReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyCompactionReport {
    #[pyo3(get)]
    compacted: bool,
    #[pyo3(get)]
    source_level: u8,
    #[pyo3(get)]
    target_level: u8,
    #[pyo3(get)]
    segments_read: usize,
    #[pyo3(get)]
    segments_written: usize,
    #[pyo3(get)]
    records_rewritten: usize,
    #[pyo3(get)]
    routing_page_indexes_read: usize,
    #[pyo3(get)]
    routing_pages_read: usize,
    #[pyo3(get)]
    routing_page_indexes_written: usize,
    #[pyo3(get)]
    routing_pages_written: usize,
    #[pyo3(get)]
    graph_payloads_read: usize,
    #[pyo3(get)]
    graph_bytes_read: u64,
    #[pyo3(get)]
    bytes_read: u64,
    #[pyo3(get)]
    bytes_written: u64,
    #[pyo3(get)]
    object_cache_hits: usize,
    #[pyo3(get)]
    object_cache_misses: usize,
    #[pyo3(get)]
    manifest_version: u64,
}

#[pymethods]
impl PyCompactionReport {
    fn __repr__(&self) -> String {
        format!(
            "CompactionReport(compacted={}, source_level={}, target_level={}, segments_read={}, segments_written={}, records_rewritten={}, routing_page_indexes_read={}, routing_pages_read={}, routing_page_indexes_written={}, routing_pages_written={}, graph_payloads_read={}, graph_bytes_read={}, bytes_read={}, bytes_written={}, object_cache_hits={}, object_cache_misses={}, manifest_version={})",
            self.compacted,
            self.source_level,
            self.target_level,
            self.segments_read,
            self.segments_written,
            self.records_rewritten,
            self.routing_page_indexes_read,
            self.routing_pages_read,
            self.routing_page_indexes_written,
            self.routing_pages_written,
            self.graph_payloads_read,
            self.graph_bytes_read,
            self.bytes_read,
            self.bytes_written,
            self.object_cache_hits,
            self.object_cache_misses,
            self.manifest_version
        )
    }
}

#[pyclass(name = "GarbageCollectionReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyGarbageCollectionReport {
    #[pyo3(get)]
    dry_run: bool,
    #[pyo3(get)]
    objects_scanned: usize,
    #[pyo3(get)]
    objects_deleted: usize,
    #[pyo3(get)]
    transaction_states_remaining: usize,
    #[pyo3(get)]
    routing_objects_deleted: usize,
    #[pyo3(get)]
    tables_deleted: usize,
    #[pyo3(get)]
    routing_page_indexes_read: usize,
    #[pyo3(get)]
    routing_pages_read: usize,
    #[pyo3(get)]
    bytes_read: u64,
    #[pyo3(get)]
    bytes_reclaimable: u64,
    #[pyo3(get)]
    bytes_reclaimed: u64,
    #[pyo3(get)]
    object_cache_hits: usize,
    #[pyo3(get)]
    object_cache_misses: usize,
    #[pyo3(get)]
    candidates: Vec<String>,
}

#[pymethods]
impl PyGarbageCollectionReport {
    fn __repr__(&self) -> String {
        format!(
            "GarbageCollectionReport(dry_run={}, objects_scanned={}, objects_deleted={}, transaction_states_remaining={}, routing_objects_deleted={}, tables_deleted={}, routing_page_indexes_read={}, routing_pages_read={}, bytes_read={}, bytes_reclaimable={}, bytes_reclaimed={}, object_cache_hits={}, object_cache_misses={}, candidates={})",
            self.dry_run,
            self.objects_scanned,
            self.objects_deleted,
            self.transaction_states_remaining,
            self.routing_objects_deleted,
            self.tables_deleted,
            self.routing_page_indexes_read,
            self.routing_pages_read,
            self.bytes_read,
            self.bytes_reclaimable,
            self.bytes_reclaimed,
            self.object_cache_hits,
            self.object_cache_misses,
            self.candidates.len()
        )
    }
}

#[pyclass(name = "RebuildReport", frozen, skip_from_py_object)]
#[derive(Clone)]
struct PyRebuildReport {
    #[pyo3(get)]
    compaction: PyCompactionReport,
    #[pyo3(get)]
    garbage_collection: PyGarbageCollectionReport,
}

#[pymethods]
impl PyRebuildReport {
    fn __repr__(&self) -> String {
        format!(
            "RebuildReport(compaction={}, garbage_collection={})",
            self.compaction.__repr__(),
            self.garbage_collection.__repr__()
        )
    }
}

#[pyclass(name = "Index")]
struct PyIndex {
    inner: RwLock<BorsukIndex>,
}

impl PyIndex {
    fn detached_read<T, F>(&self, py: Python<'_>, operation: F) -> PyResult<T>
    where
        T: Send,
        F: FnOnce(&BorsukIndex) -> PyResult<T> + Send,
    {
        py.detach(|| {
            let index = self
                .inner
                .read()
                .map_err(|_| PyRuntimeError::new_err("index lock poisoned"))?;
            operation(&index)
        })
    }

    fn detached<T, F>(&self, py: Python<'_>, operation: F) -> PyResult<T>
    where
        T: Send,
        F: FnOnce(&mut BorsukIndex) -> PyResult<T> + Send,
    {
        py.detach(|| {
            let mut index = self
                .inner
                .write()
                .map_err(|_| PyRuntimeError::new_err("index lock poisoned"))?;
            operation(&mut index)
        })
    }
}

#[pymethods]
impl PyIndex {
    #[new]
    fn new(py: Python<'_>, uri: String) -> PyResult<Self> {
        py.detach(move || {
            open(PythonOpenOptions {
                uri,
                cache_dir: None,
                ram_budget: None,
                resident_routing: true,
                cache_max_bytes: None,
                preload: false,
                max_active_searches: borsuk::DEFAULT_MAX_ACTIVE_SEARCHES,
                max_waiting_searches: borsuk::DEFAULT_MAX_WAITING_SEARCHES,
                leaf_read_width: borsuk::DEFAULT_LEAF_READ_WIDTH,
                max_inflight_leaf_reads: borsuk::DEFAULT_MAX_INFLIGHT_LEAF_READS,
                max_parallel_decode_rank_tasks: borsuk::DEFAULT_MAX_PARALLEL_DECODE_RANK_TASKS,
                exact_read_max_physical_amplification:
                    borsuk::DEFAULT_EXACT_READ_MAX_PHYSICAL_AMPLIFICATION,
            })
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (vectors, ids = None, metadata = None, sparse = None, text = None, named_vectors = None))]
    fn add(
        &self,
        py: Python<'_>,
        vectors: Vec<Vec<f32>>,
        ids: Option<Vec<String>>,
        metadata: Option<Vec<Bound<'_, PyAny>>>,
        sparse: Option<Vec<PySparseEntry>>,
        text: Option<Vec<Option<String>>>,
        named_vectors: Option<Vec<Option<PyNamedVectorRecord>>>,
    ) -> PyResult<Vec<String>> {
        let metadata = convert_metadata_list(metadata.as_deref(), vectors.len())?;
        let sparse = convert_sparse_list(sparse.as_deref(), vectors.len())?;
        let text = convert_text_list(text.as_deref(), vectors.len())?;
        let named_vectors = convert_named_vectors_list(named_vectors.as_deref(), vectors.len())?;
        self.detached(py, move |index| match ids {
            Some(ids) => {
                let ids = ids_for_vectors(Some(ids), vectors.len(), index)?;
                let records = records_from_vectors(
                    &ids,
                    vectors,
                    index.manifest().config.dimensions,
                    metadata.as_deref(),
                    sparse.as_deref(),
                    text.as_deref(),
                    named_vectors.as_deref(),
                    &index.manifest().config.named_vectors,
                )?;

                index.add(records).map_err(to_py_error)?;
                Ok(ids)
            }
            None => {
                if metadata.is_some() {
                    return Err(PyValueError::new_err(
                        "metadata requires explicit ids; pass ids=[...] alongside metadata=[...]",
                    ));
                }
                if sparse.is_some() || text.is_some() || named_vectors.is_some() {
                    let ids = ids_for_vectors(None, vectors.len(), index)?;
                    let records = records_from_vectors(
                        &ids,
                        vectors,
                        index.manifest().config.dimensions,
                        None,
                        sparse.as_deref(),
                        text.as_deref(),
                        named_vectors.as_deref(),
                        &index.manifest().config.named_vectors,
                    )?;

                    index.add(records).map_err(to_py_error)?;
                    return Ok(ids);
                }
                index.add_vectors(vectors).map_err(to_py_error)
            }
        })
    }

    /// Materialize the current write-ahead-log tail into immutable cells.
    ///
    /// Ordinary reads already include unflushed records. Call this before
    /// segment-level administration such as compaction, or when an external
    /// workflow needs all records represented by immutable cell objects.
    fn flush(&self, py: Python<'_>) -> PyResult<()> {
        self.detached(py, |index| index.flush().map_err(to_py_error))
    }

    /// Insert or replace records by id (MVCC upsert). Existing ids are
    /// overwritten atomically; reads see only the new version. Ids are required.
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (vectors, ids, metadata = None, sparse = None, text = None, named_vectors = None))]
    fn upsert(
        &self,
        py: Python<'_>,
        vectors: Vec<Vec<f32>>,
        ids: Vec<String>,
        metadata: Option<Vec<Bound<'_, PyAny>>>,
        sparse: Option<Vec<PySparseEntry>>,
        text: Option<Vec<Option<String>>>,
        named_vectors: Option<Vec<Option<PyNamedVectorRecord>>>,
    ) -> PyResult<Vec<String>> {
        let metadata = convert_metadata_list(metadata.as_deref(), vectors.len())?;
        let sparse = convert_sparse_list(sparse.as_deref(), vectors.len())?;
        let text = convert_text_list(text.as_deref(), vectors.len())?;
        let named_vectors = convert_named_vectors_list(named_vectors.as_deref(), vectors.len())?;
        self.detached(py, move |index| {
            let ids = ids_for_vectors(Some(ids), vectors.len(), index)?;
            let records = records_from_vectors(
                &ids,
                vectors,
                index.manifest().config.dimensions,
                metadata.as_deref(),
                sparse.as_deref(),
                text.as_deref(),
                named_vectors.as_deref(),
                &index.manifest().config.named_vectors,
            )?;
            index.upsert(records).map_err(to_py_error)?;
            Ok(ids)
        })
    }

    #[pyo3(signature = (vectors, ids = None))]
    fn add_with_report(
        &self,
        py: Python<'_>,
        vectors: Vec<Vec<f32>>,
        ids: Option<Vec<String>>,
    ) -> PyResult<(Vec<String>, PyAddReport)> {
        self.detached(py, move |index| {
            let (ids, report) = index.add_with_report(vectors, ids).map_err(to_py_error)?;
            Ok((ids, report.into()))
        })
    }

    fn add_id_bytes(
        &self,
        py: Python<'_>,
        vectors: Vec<Vec<f32>>,
        ids: Vec<Vec<u8>>,
    ) -> PyResult<Vec<Vec<u8>>> {
        self.detached(py, move |index| {
            let ids = id_bytes_for_vectors(ids, vectors.len())?;
            let records = ids
                .iter()
                .cloned()
                .zip(vectors)
                .map(|(id, vector)| VectorRecord::new_bytes(id, vector))
                .collect::<Vec<_>>();

            index.add(records).map_err(to_py_error)?;
            Ok(ids)
        })
    }

    #[pyo3(signature = (vectors, ids = None))]
    fn add_buffer(
        &self,
        py: Python<'_>,
        vectors: PyBuffer<f32>,
        ids: Option<Vec<String>>,
    ) -> PyResult<Vec<String>> {
        let flat = vectors.to_vec(py)?;
        self.detached(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let row_count = flat_vector_row_count(&flat, dimensions)?;
            match ids {
                Some(ids) => {
                    let ids = ids_for_vectors(Some(ids), row_count, index)?;
                    let records = records_from_flat_vectors(ids, &flat, dimensions)?;
                    let ids = records
                        .iter()
                        .map(|record| record.id.to_utf8_string().map_err(to_py_error))
                        .collect::<PyResult<Vec<_>>>()?;

                    index.add(records).map_err(to_py_error)?;
                    Ok(ids)
                }
                None => index
                    .add_vectors(vectors_from_flat_rows(&flat, dimensions, "vector buffer")?)
                    .map_err(to_py_error),
            }
        })
    }

    fn add_buffer_id_bytes(
        &self,
        py: Python<'_>,
        vectors: PyBuffer<f32>,
        ids: Vec<Vec<u8>>,
    ) -> PyResult<Vec<Vec<u8>>> {
        let flat = vectors.to_vec(py)?;
        self.detached(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let row_count = flat_vector_row_count(&flat, dimensions)?;
            let ids = id_bytes_for_vectors(ids, row_count)?;
            let records = records_from_flat_vectors_with_id_bytes(ids.clone(), &flat, dimensions)?;

            index.add(records).map_err(to_py_error)?;
            Ok(ids)
        })
    }

    fn stats(&self, py: Python<'_>) -> PyResult<PyIndexStats> {
        self.detached_read(py, |index| {
            index.try_stats().map(Into::into).map_err(to_py_error)
        })
    }

    /// Advance this handle to the latest atomically published snapshot.
    ///
    /// Returns true when the snapshot advanced and false when this handle was
    /// already current.
    fn refresh(&self, py: Python<'_>) -> PyResult<bool> {
        self.detached(py, |index| index.refresh().map_err(to_py_error))
    }

    fn warm(&self, py: Python<'_>) -> PyResult<PyWarmReport> {
        self.detached_read(py, |index| {
            index.warm().map(Into::into).map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan", filter = None, vector = String::new()))]
    fn search_ids(
        &self,
        py: Python<'_>,
        query: Vec<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
        filter: Option<Bound<'_, PyAny>>,
        vector: String,
    ) -> PyResult<Vec<String>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let filter = filter.as_ref().map(py_to_filter).transpose()?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;

        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            index
                .search_ids(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter,
                        include_metadata: false,
                        vector_name: vector,
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_id_bytes(
        &self,
        py: Python<'_>,
        query: Vec<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<u8>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;

        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            index
                .search_id_bytes(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan", vector = String::new()))]
    fn search_vectors(
        &self,
        py: Python<'_>,
        query: Vec<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
        vector: String,
    ) -> PyResult<Vec<Vec<f32>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;

        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            index
                .search_vectors(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: vector,
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    fn get_vector_by_id(&self, py: Python<'_>, id: Vec<u8>) -> PyResult<Option<Vec<f32>>> {
        self.detached_read(py, move |index| {
            index.get_vector_by_id(id).map_err(to_py_error)
        })
    }

    fn get_vector(&self, py: Python<'_>, id: &str) -> PyResult<Option<Vec<f32>>> {
        let id = id.to_owned();
        self.detached_read(py, move |index| index.get_vector(&id).map_err(to_py_error))
    }

    /// Load a stored vector and its metadata dict by id, or `None`.
    fn get_record(&self, py: Python<'_>, id: &str) -> PyResult<Option<(Vec<f32>, Py<PyAny>)>> {
        let id = id.to_owned();
        let record =
            self.detached_read(py, move |index| index.get_record(&id).map_err(to_py_error))?;
        match record {
            Some((vector, metadata)) => Ok(Some((vector, metadata_to_py(py, &metadata)?))),
            None => Ok(None),
        }
    }

    /// List up to `limit` live records starting at `offset`, as
    /// `(id, vector, metadata)` tuples. Backs "scroll"/"get all" in the
    /// drop-in adapters; scans segment payloads, so it is an export path.
    #[pyo3(signature = (offset = 0, limit = 100))]
    fn list_records(
        &self,
        py: Python<'_>,
        offset: usize,
        limit: usize,
    ) -> PyResult<Vec<PyRecordEntry>> {
        let records = self.detached_read(py, |index| {
            index.list_records(offset, limit).map_err(to_py_error)
        })?;
        records
            .into_iter()
            .map(|(id, vector, metadata)| {
                Ok((id.to_string(), vector, metadata_to_py(py, &metadata)?))
            })
            .collect()
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_ids_buffer(
        &self,
        py: Python<'_>,
        query: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<String>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = query.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let query = query_from_flat_vector(&flat, dimensions, "query buffer")?;
            index
                .search_ids(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_id_bytes_buffer(
        &self,
        py: Python<'_>,
        query: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<u8>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = query.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let query = query_from_flat_vector(&flat, dimensions, "query buffer")?;
            index
                .search_id_bytes(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_vectors_buffer(
        &self,
        py: Python<'_>,
        query: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<f32>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = query.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let query = query_from_flat_vector(&flat, dimensions, "query buffer")?;
            index
                .search_vectors(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_with_report_buffer(
        &self,
        py: Python<'_>,
        query: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<PySearchReport> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = query.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let query = query_from_flat_vector(&flat, dimensions, "query buffer")?;
            let report = index
                .search_with_report(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)?;

            report.try_into()
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_ids_batch(
        &self,
        py: Python<'_>,
        queries: Vec<Vec<f32>>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<String>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            index
                .search_ids_batch(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_id_bytes_batch(
        &self,
        py: Python<'_>,
        queries: Vec<Vec<f32>>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<Vec<u8>>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            index
                .search_id_bytes_batch(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_vectors_batch(
        &self,
        py: Python<'_>,
        queries: Vec<Vec<f32>>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<Vec<f32>>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            index
                .search_vectors_batch(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_id_bytes_batch_buffer(
        &self,
        py: Python<'_>,
        queries: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<Vec<u8>>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = queries.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let queries = vectors_from_flat_rows(&flat, dimensions, "query buffer")?;
            index
                .search_id_bytes_batch(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_ids_batch_buffer(
        &self,
        py: Python<'_>,
        queries: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<String>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = queries.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let queries = vectors_from_flat_rows(&flat, dimensions, "query buffer")?;
            index
                .search_ids_batch(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_vectors_batch_buffer(
        &self,
        py: Python<'_>,
        queries: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<Vec<Vec<f32>>>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = queries.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let queries = vectors_from_flat_rows(&flat, dimensions, "query buffer")?;
            index
                .search_vectors_batch(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_batch_with_report(
        &self,
        py: Python<'_>,
        queries: Vec<Vec<f32>>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<PySearchReport>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let reports = index
                .search_batch_with_report(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)?;

            reports
                .into_iter()
                .map(PySearchReport::try_from)
                .collect::<PyResult<Vec<_>>>()
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (queries, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan"))]
    fn search_batch_with_report_buffer(
        &self,
        py: Python<'_>,
        queries: PyBuffer<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
    ) -> PyResult<Vec<PySearchReport>> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let flat = queries.to_vec(py)?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let dimensions = index.manifest().config.dimensions;
            let queries = vectors_from_flat_rows(&flat, dimensions, "query buffer")?;
            let reports = index
                .search_batch_with_report(
                    &queries,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter: None,
                        include_metadata: false,
                        vector_name: String::new(),
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)?;

            reports
                .into_iter()
                .map(PySearchReport::try_from)
                .collect::<PyResult<Vec<_>>>()
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", eps = None, max_segments = None, max_bytes = None, max_latency_ms = None, routing_page_overfetch = None, max_candidates_per_segment = None, guaranteed_recall = false, prefetch_depth = None, cache_execution = "scan", filter = None, include_metadata = false, vector = String::new()))]
    fn search_with_report(
        &self,
        py: Python<'_>,
        query: Vec<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        eps: Option<f32>,
        max_segments: Option<usize>,
        max_bytes: Option<Bound<'_, PyAny>>,
        max_latency_ms: Option<u64>,
        routing_page_overfetch: Option<usize>,
        max_candidates_per_segment: Option<usize>,
        guaranteed_recall: bool,
        prefetch_depth: Option<usize>,
        cache_execution: &str,
        filter: Option<Bound<'_, PyAny>>,
        include_metadata: bool,
        vector: String,
    ) -> PyResult<PySearchReport> {
        let max_bytes = parse_optional_byte_size(max_bytes.as_ref(), "max_bytes")?;
        let filter = filter.as_ref().map(py_to_filter).transpose()?;
        let mode = parse_mode(
            mode,
            leaf_mode,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
        )?;
        let cache_execution = parse_cache_execution(cache_execution)?;
        self.detached_read(py, move |index| {
            let report = index
                .search_with_report(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall,
                        prefetch_depth: prefetch_depth
                            .unwrap_or(borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH),
                        filter,
                        include_metadata,
                        vector_name: vector,
                        disable_coarse_quantizer: false,
                        cache_execution,
                    },
                )
                .map_err(to_py_error)?;

            report.try_into()
        })
    }

    /// Run a query and return its plan and estimated object-storage cost as a
    /// dict: object-store GET/HEAD requests, bytes read, routing pruning, cache
    /// hit ratio, latency, and a dollar estimate under the S3-style cost model.
    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (query, k = 10, mode = "approx", leaf_mode = "srht-pq-scan", filter = None, vector = String::new(), request_price_per_million = 0.40, data_price_per_gib = 0.0))]
    fn explain(
        &self,
        py: Python<'_>,
        query: Vec<f32>,
        k: usize,
        mode: &str,
        leaf_mode: &str,
        filter: Option<Bound<'_, PyAny>>,
        vector: String,
        request_price_per_million: f64,
        data_price_per_gib: f64,
    ) -> PyResult<Py<PyDict>> {
        let filter = filter.as_ref().map(py_to_filter).transpose()?;
        let mode = parse_mode(mode, leaf_mode, None, None, None, None, None, None)?;
        let report = self.detached_read(py, move |index| {
            index
                .explain(
                    &query,
                    SearchOptions {
                        k,
                        mode,
                        guaranteed_recall: false,
                        prefetch_depth: borsuk::DEFAULT_SEARCH_PREFETCH_DEPTH,
                        filter,
                        include_metadata: false,
                        vector_name: vector,
                        disable_coarse_quantizer: false,
                        cache_execution: borsuk::CacheExecutionPolicy::Scan,
                    },
                    borsuk::QueryCostModel {
                        request_price_per_million,
                        data_price_per_gib,
                    },
                )
                .map_err(to_py_error)
        })?;

        let dict = PyDict::new(py);
        dict.set_item(
            "hits",
            report
                .hits
                .iter()
                .map(|hit| hit.id.to_string())
                .collect::<Vec<_>>(),
        )?;
        dict.set_item("get_requests", report.get_requests)?;
        dict.set_item("bytes_read", report.bytes_read)?;
        dict.set_item("estimated_cost_usd", report.estimated_cost_usd)?;
        dict.set_item("cache_hit_ratio", report.cache_hit_ratio)?;
        dict.set_item("elapsed_ms", report.elapsed_ms)?;
        dict.set_item("segments_total", report.segments_total)?;
        dict.set_item("segments_searched", report.segments_searched)?;
        dict.set_item("segments_skipped", report.segments_skipped)?;
        dict.set_item(
            "segments_pruned_by_filter",
            report.segments_pruned_by_filter,
        )?;
        Ok(dict.unbind())
    }

    /// Search a sparse (inverted-index) named vector for the top `k` record ids
    /// by inner-product similarity. The query is `indices`/`values`; nothing is
    /// densified, so it scales to huge lexical vocabularies.
    #[pyo3(signature = (name, indices, values, k = 10))]
    fn search_sparse_named(
        &self,
        py: Python<'_>,
        name: &str,
        indices: Vec<u32>,
        values: Vec<f32>,
        k: usize,
    ) -> PyResult<Vec<String>> {
        let name = name.to_owned();
        self.detached_read(py, move |index| {
            let hits = index
                .search_sparse_named(&name, indices, values, k)
                .map_err(to_py_error)?;
            Ok(hits.into_iter().map(|hit| hit.id.to_string()).collect())
        })
    }

    /// Exact ColBERT-style MaxSim over a named late-interaction token field.
    #[pyo3(signature = (name, query_tokens, k = 10))]
    fn search_late_interaction(
        &self,
        py: Python<'_>,
        name: &str,
        query_tokens: Vec<Vec<f32>>,
        k: usize,
    ) -> PyResult<Vec<String>> {
        let name = name.to_owned();
        self.detached_read(py, move |index| {
            let hits = index
                .search_late_interaction(&name, query_tokens, k)
                .map_err(to_py_error)?;
            Ok(hits.into_iter().map(|hit| hit.id.to_string()).collect())
        })
    }

    #[pyo3(signature = (text, k = 10))]
    fn search_text(&self, py: Python<'_>, text: &str, k: usize) -> PyResult<Vec<String>> {
        let text = text.to_owned();
        self.detached_read(py, move |index| {
            let report = index.search_text(&text, k).map_err(to_py_error)?;
            search_report_ids(report)
        })
    }

    #[pyo3(signature = (text, k = 10, include_metadata = false))]
    fn search_text_with_report(
        &self,
        py: Python<'_>,
        text: &str,
        k: usize,
        include_metadata: bool,
    ) -> PyResult<PySearchReport> {
        let text = text.to_owned();
        self.detached_read(py, move |index| {
            let report = index.search_text(&text, k).map_err(to_py_error)?;
            search_report_with_optional_metadata(index, report, include_metadata)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (*, vectors = None, text = None, k = 10, fusion = "rrf", rrf_k = 60, weights = None))]
    fn search_hybrid(
        &self,
        py: Python<'_>,
        vectors: Option<Vec<PyNamedVectorEntry>>,
        text: Option<String>,
        k: usize,
        fusion: &str,
        rrf_k: usize,
        weights: Option<Vec<(String, f32)>>,
    ) -> PyResult<Vec<String>> {
        let options = hybrid_options(k, fusion, rrf_k, weights)?;
        self.detached_read(py, move |index| {
            let query = hybrid_query(
                vectors,
                text,
                index.manifest().config.dimensions,
                &index.manifest().config.named_vectors,
            )?;
            let report = index.search_hybrid(&query, options).map_err(to_py_error)?;

            search_report_ids(report)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (*, vectors = None, text = None, k = 10, fusion = "rrf", rrf_k = 60, weights = None, include_metadata = false))]
    fn search_hybrid_with_report(
        &self,
        py: Python<'_>,
        vectors: Option<Vec<PyNamedVectorEntry>>,
        text: Option<String>,
        k: usize,
        fusion: &str,
        rrf_k: usize,
        weights: Option<Vec<(String, f32)>>,
        include_metadata: bool,
    ) -> PyResult<PySearchReport> {
        let options = hybrid_options(k, fusion, rrf_k, weights)?;
        self.detached_read(py, move |index| {
            let query = hybrid_query(
                vectors,
                text,
                index.manifest().config.dimensions,
                &index.manifest().config.named_vectors,
            )?;
            let report = index.search_hybrid(&query, options).map_err(to_py_error)?;

            search_report_with_optional_metadata(index, report, include_metadata)
        })
    }

    #[allow(clippy::too_many_arguments)]
    #[pyo3(signature = (*, source_level = 0, target_level = 1, max_segments = None, all_matching = false, min_segments = 2, target_segment_max_vectors = None, target_segment_max_radius = None))]
    fn compact(
        &self,
        py: Python<'_>,
        source_level: u8,
        target_level: u8,
        max_segments: Option<usize>,
        all_matching: bool,
        min_segments: usize,
        target_segment_max_vectors: Option<usize>,
        target_segment_max_radius: Option<f32>,
    ) -> PyResult<PyCompactionReport> {
        if all_matching && max_segments.is_some() {
            return Err(PyValueError::new_err(
                "all_matching cannot be combined with max_segments",
            ));
        }
        let max_segments = if all_matching {
            None
        } else {
            Some(max_segments.unwrap_or(DEFAULT_COMPACTION_MAX_SEGMENTS))
        };
        self.detached(py, move |index| {
            index
                .compact(CompactionOptions {
                    source_level,
                    target_level,
                    max_segments,
                    min_segments,
                    target_segment_max_vectors,
                    target_segment_max_radius,
                })
                .map(Into::into)
                .map_err(to_py_error)
        })
    }

    #[pyo3(signature = (*, source_level = 0, target_level = 1, min_segments = 1, target_segment_max_vectors = None, delete_obsolete = false))]
    fn rebuild(
        &self,
        py: Python<'_>,
        source_level: u8,
        target_level: u8,
        min_segments: usize,
        target_segment_max_vectors: Option<usize>,
        delete_obsolete: bool,
    ) -> PyResult<PyRebuildReport> {
        self.detached(py, move |index| {
            index
                .rebuild(RebuildOptions {
                    source_level,
                    target_level,
                    min_segments,
                    target_segment_max_vectors,
                    delete_obsolete,
                })
                .map(Into::into)
                .map_err(to_py_error)
        })
    }

    /// Logically delete records by id. Hidden from search immediately; reclaimed
    /// by compaction or purge.
    fn delete(&self, py: Python<'_>, ids: Vec<String>) -> PyResult<PyDeleteReport> {
        self.detached(py, move |index| {
            index.delete(ids).map(Into::into).map_err(to_py_error)
        })
    }

    /// Physically remove deleted records and clear the tombstone, re-enabling
    /// those ids for add.
    fn purge(&self, py: Python<'_>) -> PyResult<PyPurgeReport> {
        self.detached(py, |index| {
            index
                .purge_with_report()
                .map(Into::into)
                .map_err(to_py_error)
        })
    }

    /// Run one incremental-maintenance pass: split oversized bubbles and merge
    /// sparse ones locally.
    #[pyo3(signature = (*, max_segment_vectors = None, max_segment_radius = None, min_segment_vectors = None, max_operations = None))]
    fn maintain(
        &self,
        py: Python<'_>,
        max_segment_vectors: Option<usize>,
        max_segment_radius: Option<f32>,
        min_segment_vectors: Option<usize>,
        max_operations: Option<usize>,
    ) -> PyResult<PyIncrementalReport> {
        let defaults = IncrementalMaintenanceOptions::default();
        let options = IncrementalMaintenanceOptions {
            max_segment_vectors: max_segment_vectors.unwrap_or(defaults.max_segment_vectors),
            max_segment_radius,
            min_segment_vectors: min_segment_vectors.unwrap_or(defaults.min_segment_vectors),
            max_operations: max_operations.unwrap_or(defaults.max_operations),
        };
        self.detached(py, move |index| {
            index
                .run_incremental_maintenance(options)
                .map(Into::into)
                .map_err(to_py_error)
        })
    }

    #[pyo3(signature = (*, dry_run = true, min_age_seconds = 86_400.0))]
    fn gc_obsolete_segments(
        &self,
        py: Python<'_>,
        dry_run: bool,
        min_age_seconds: f64,
    ) -> PyResult<PyGarbageCollectionReport> {
        let min_age = duration_from_seconds(min_age_seconds, "min_age_seconds")?;
        self.detached(py, move |index| {
            index
                .gc_obsolete_segments(GarbageCollectionOptions { dry_run, min_age })
                .map(Into::into)
                .map_err(to_py_error)
        })
    }
}

#[pyfunction]
fn vector_distance(metric: String, left: Vec<f32>, right: Vec<f32>) -> PyResult<f32> {
    let metric = metric.parse::<VectorMetric>().map_err(to_py_value_error)?;
    metric.distance(&left, &right).map_err(to_py_value_error)
}

#[pyfunction]
fn vector_metric_names() -> Vec<String> {
    borsuk::vector_metric_names()
        .iter()
        .map(|name| (*name).to_string())
        .collect()
}

#[pyfunction]
fn leaf_mode_names() -> Vec<String> {
    borsuk::leaf_mode_names()
        .iter()
        .map(|name| (*name).to_string())
        .collect()
}

#[pyfunction]
fn recall_at_k(exact_ids: Vec<String>, actual_ids: Vec<String>, k: usize) -> PyResult<f32> {
    borsuk::recall_at_k(&exact_ids, &actual_ids, k).map_err(to_py_value_error)
}

#[pyfunction]
fn tie_aware_recall_at_k(
    exact_distances: Vec<f32>,
    actual_distances: Vec<f32>,
    k: usize,
) -> PyResult<f32> {
    borsuk::tie_aware_recall_at_k(&exact_distances, &actual_distances, k).map_err(to_py_value_error)
}

#[pyfunction]
#[allow(clippy::too_many_arguments)]
#[pyo3(signature = (*, uri, metric, vector_element_type = "float32", dim = None, dimensions = None, segment_size = None, segment_max_vectors = None, routing_page_fanout = None, graph_neighbors = None, leaf_capability = "pq-scan-only", global_scan_codec = "srht-pq-scan", global_pq_layout = "adaptive", global_pq_code_bytes = None, turboquant_bits = 0, turboquant_qjl_bits = 0, turboquant_shards = 1, ram_budget = None, cache_dir = None, text = false, named_vectors = None))]
fn create(
    py: Python<'_>,
    uri: String,
    metric: String,
    vector_element_type: &str,
    dim: Option<usize>,
    dimensions: Option<usize>,
    segment_size: Option<usize>,
    segment_max_vectors: Option<usize>,
    routing_page_fanout: Option<usize>,
    graph_neighbors: Option<usize>,
    leaf_capability: &str,
    global_scan_codec: &str,
    global_pq_layout: &str,
    global_pq_code_bytes: Option<usize>,
    turboquant_bits: u8,
    turboquant_qjl_bits: u32,
    turboquant_shards: u32,
    ram_budget: Option<String>,
    cache_dir: Option<String>,
    text: bool,
    named_vectors: Option<Vec<PyVectorSpecEntry>>,
) -> PyResult<PyIndex> {
    let dimensions = resolve_dimensions(dim, dimensions)?;
    let segment_max_vectors =
        resolve_segment_max_vectors(segment_size, segment_max_vectors, dimensions)?;
    let metric = metric.parse::<VectorMetric>().map_err(to_py_error)?;
    let vector_element_type = vector_element_type
        .parse::<borsuk::VectorElementType>()
        .map_err(to_py_error)?;
    let ram_budget_bytes = ram_budget
        .as_deref()
        .map(borsuk::parse_ram_budget)
        .transpose()
        .map_err(to_py_value_error)?
        .or(Some(borsuk::DEFAULT_RAM_BUDGET_BYTES));
    let leaf_capability = leaf_capability
        .parse::<LeafCapability>()
        .map_err(to_py_value_error)?;
    let global_pq_layout = global_pq_layout
        .parse::<borsuk::GlobalPqLayout>()
        .map_err(to_py_value_error)?;
    let global_scan_codec = global_scan_codec
        .parse::<borsuk::GlobalScanCodec>()
        .map_err(to_py_value_error)?;
    let named_vectors = named_vector_specs(named_vectors)?;
    let index = py.detach(move || {
        BorsukIndex::create_with_cache_routing_page_fanout_graph_neighbors_leaf_capability_and_build_config(
            IndexConfig {
                uri,
                metric,
                dimensions,
                segment_max_vectors,
                ram_budget_bytes,
                text,
                named_vectors,
            },
            cache_dir.map(PathBuf::from),
            routing_page_fanout.unwrap_or(borsuk::DEFAULT_ROUTING_PAGE_FANOUT),
            graph_neighbors.unwrap_or(borsuk::DEFAULT_GRAPH_NEIGHBORS),
            leaf_capability,
            borsuk::BuildConfig {
                vector_element_type,
                global_pq_layout,
                global_pq_code_bytes,
                global_scan_codec,
                global_turboquant_bits: turboquant_bits,
                global_turboquant_qjl_bits: turboquant_qjl_bits,
                global_turboquant_shards: turboquant_shards,
                ..borsuk::BuildConfig::default()
            },
        )
        .map_err(to_py_error)
    })?;

    Ok(PyIndex {
        inner: RwLock::new(index),
    })
}

#[pyfunction]
#[pyo3(signature = (uri, cache_dir = None, ram_budget = None, resident_routing = false, cache_max_bytes = None, preload = false, max_active_searches = 8, max_waiting_searches = 16, leaf_read_width = 32, max_inflight_leaf_reads = 48, exact_read_max_physical_amplification = 1, max_parallel_decode_rank_tasks = 1))]
#[pyo3(name = "open")]
#[allow(clippy::too_many_arguments)] // These are explicit Python keyword controls.
fn open_py(
    py: Python<'_>,
    uri: String,
    cache_dir: Option<String>,
    ram_budget: Option<String>,
    resident_routing: bool,
    cache_max_bytes: Option<String>,
    preload: bool,
    max_active_searches: usize,
    max_waiting_searches: usize,
    leaf_read_width: usize,
    max_inflight_leaf_reads: usize,
    exact_read_max_physical_amplification: u64,
    max_parallel_decode_rank_tasks: usize,
) -> PyResult<PyIndex> {
    py.detach(move || {
        open(PythonOpenOptions {
            uri,
            cache_dir,
            ram_budget,
            resident_routing,
            cache_max_bytes,
            preload,
            max_active_searches,
            max_waiting_searches,
            leaf_read_width,
            max_inflight_leaf_reads,
            max_parallel_decode_rank_tasks,
            exact_read_max_physical_amplification,
        })
    })
}

#[pymodule]
fn _borsuk(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add("BorsukError", module.py().get_type::<BorsukError>())?;
    module.add_class::<PyCompactionReport>()?;
    module.add_class::<PyGarbageCollectionReport>()?;
    module.add_class::<PyRebuildReport>()?;
    module.add_class::<PyDeleteReport>()?;
    module.add_class::<PyPurgeReport>()?;
    module.add_class::<PyIncrementalReport>()?;
    module.add_class::<PyHit>()?;
    module.add_class::<PyIndexStats>()?;
    module.add_class::<PyWarmReport>()?;
    module.add_class::<PyAddReport>()?;
    module.add_class::<PySearchReport>()?;
    module.add_class::<PyRequestCounts>()?;
    module.add_class::<PyIndex>()?;
    module.add_function(wrap_pyfunction!(create, module)?)?;
    module.add_function(wrap_pyfunction!(open_py, module)?)?;
    module.add_function(wrap_pyfunction!(leaf_mode_names, module)?)?;
    module.add_function(wrap_pyfunction!(recall_at_k, module)?)?;
    module.add_function(wrap_pyfunction!(tie_aware_recall_at_k, module)?)?;
    module.add_function(wrap_pyfunction!(vector_distance, module)?)?;
    module.add_function(wrap_pyfunction!(vector_metric_names, module)?)?;
    Ok(())
}

struct PythonOpenOptions {
    uri: String,
    cache_dir: Option<String>,
    ram_budget: Option<String>,
    resident_routing: bool,
    cache_max_bytes: Option<String>,
    preload: bool,
    max_active_searches: usize,
    max_waiting_searches: usize,
    leaf_read_width: usize,
    max_inflight_leaf_reads: usize,
    max_parallel_decode_rank_tasks: usize,
    exact_read_max_physical_amplification: u64,
}

fn open(options: PythonOpenOptions) -> PyResult<PyIndex> {
    let ram_budget_bytes = options
        .ram_budget
        .as_deref()
        .map(borsuk::parse_ram_budget)
        .transpose()
        .map_err(to_py_value_error)?
        .or(Some(borsuk::DEFAULT_RAM_BUDGET_BYTES));
    let cache_max_bytes = options
        .cache_max_bytes
        .as_deref()
        .map(|value| borsuk::parse_byte_size(value, "cache_max_bytes"))
        .transpose()
        .map_err(to_py_value_error)?;
    let index = BorsukIndex::open_with_options(
        &options.uri,
        OpenOptions {
            cache_dir: options.cache_dir.map(PathBuf::from),
            cache_max_bytes,
            ram_budget_bytes,
            resident_routing: options.resident_routing,
            preload: options.preload,
            max_active_searches: options.max_active_searches,
            max_waiting_searches: options.max_waiting_searches,
            leaf_read_width: options.leaf_read_width,
            max_inflight_leaf_reads: options.max_inflight_leaf_reads,
            max_parallel_decode_rank_tasks: options.max_parallel_decode_rank_tasks,
            exact_read_max_physical_amplification: options.exact_read_max_physical_amplification,
            ..OpenOptions::default()
        },
    )
    .map_err(to_py_error)?;
    Ok(PyIndex {
        inner: RwLock::new(index),
    })
}

fn named_vector_specs(
    named_vectors: Option<Vec<PyVectorSpecEntry>>,
) -> PyResult<BTreeMap<String, VectorSpec>> {
    let mut out = BTreeMap::new();
    for (name, dimensions, metric, kind, element_type) in named_vectors.unwrap_or_default() {
        let kind = match kind.as_str() {
            "" | "dense" => VectorKind::Dense,
            "sparse" => VectorKind::Sparse,
            "late" | "late-interaction" | "multivector" => VectorKind::LateInteraction,
            other => {
                return Err(PyValueError::new_err(format!(
                    "named vector kind must be 'dense', 'sparse', or 'late-interaction', got '{other}'"
                )));
            }
        };
        out.insert(
            name,
            VectorSpec {
                dimensions,
                metric: metric.parse::<VectorMetric>().map_err(to_py_error)?,
                kind,
                element_type: element_type
                    .parse::<borsuk::VectorElementType>()
                    .map_err(to_py_error)?,
            },
        );
    }
    Ok(out)
}

fn ids_for_vectors(
    ids: Option<Vec<String>>,
    expected_len: usize,
    index: &BorsukIndex,
) -> PyResult<Vec<String>> {
    match ids {
        Some(ids) if ids.len() != expected_len => Err(PyValueError::new_err(
            "ids must have the same length as vectors",
        )),
        Some(ids) => Ok(ids),
        None => index.generate_ids(expected_len).map_err(to_py_error),
    }
}

fn id_bytes_for_vectors(ids: Vec<Vec<u8>>, expected_len: usize) -> PyResult<Vec<Vec<u8>>> {
    if ids.len() != expected_len {
        return Err(PyValueError::new_err(
            "ids must have the same length as vectors",
        ));
    }
    Ok(ids)
}

#[allow(clippy::too_many_arguments)]
fn records_from_vectors(
    ids: &[String],
    vectors: Vec<Vec<f32>>,
    dimensions: usize,
    metadata: Option<&[Metadata]>,
    sparse: Option<&[PySparseEntry]>,
    text: Option<&[Option<String>]>,
    named_vectors: Option<&[Option<PyNamedVectorRecord>]>,
    named_specs: &BTreeMap<String, VectorSpec>,
) -> PyResult<Vec<VectorRecord>> {
    ids.iter()
        .cloned()
        .zip(vectors)
        .enumerate()
        .map(|(row, (id, vector))| {
            let mut record = if let Some(rows) = sparse
                && let Some((indices, values)) = &rows[row]
            {
                VectorRecord::from_sparse(id, indices.clone(), values.clone(), dimensions)
                    .map_err(to_py_error)?
            } else {
                VectorRecord::new(id, vector)
            };
            if let Some(rows) = metadata {
                record = record.with_metadata(rows[row].clone());
            }
            if let Some(rows) = text
                && let Some(text) = &rows[row]
            {
                record = record.with_text(text.clone());
            }
            if let Some(rows) = named_vectors
                && let Some(entries) = &rows[row]
            {
                for (name, dense, sparse, multi) in entries {
                    match (dense, sparse, multi) {
                        (Some(vector), None, None) => {
                            record = record.with_named_vector(name.clone(), vector.clone());
                        }
                        (None, None, Some(tokens)) => {
                            record = record
                                .with_late_interaction(name.clone(), tokens.clone())
                                .map_err(to_py_error)?;
                        }
                        (None, Some((indices, values)), None) => {
                            let spec = named_specs.get(name).ok_or_else(|| {
                                PyValueError::new_err(format!("unknown named vector `{name}`"))
                            })?;
                            record = match spec.kind {
                                // A sparse-kind named vector keeps the sparse form
                                // (inverted-index backend); a dense-kind one
                                // densifies the sparse input into its child index.
                                VectorKind::Sparse => record
                                    .with_named_sparse_vector(
                                        name.clone(),
                                        indices.clone(),
                                        values.clone(),
                                    )
                                    .map_err(to_py_error)?,
                                VectorKind::Dense => record
                                    .with_named_sparse(
                                        name.clone(),
                                        indices.clone(),
                                        values.clone(),
                                        spec.dimensions,
                                    )
                                    .map_err(to_py_error)?,
                                VectorKind::LateInteraction => {
                                    return Err(PyValueError::new_err(format!(
                                        "late-interaction named vector `{name}` requires a token matrix"
                                    )));
                                }
                            };
                        }
                        _ => {
                            return Err(PyValueError::new_err(
                                "named vector entries must contain exactly one dense, sparse, or token-matrix value",
                            ));
                        }
                    }
                }
            }
            Ok(record)
        })
        .collect()
}

fn records_from_flat_vectors(
    ids: Vec<String>,
    vectors: &[f32],
    dimensions: usize,
) -> PyResult<Vec<VectorRecord>> {
    if !vectors.len().is_multiple_of(dimensions) {
        return Err(PyValueError::new_err(format!(
            "flat vector buffer length must be a multiple of index dimensions (dimensions {dimensions}, got {} float32 values)",
            vectors.len()
        )));
    }

    let expected_values = ids
        .len()
        .checked_mul(dimensions)
        .ok_or_else(|| PyValueError::new_err("flat vector buffer length exceeds platform usize"))?;
    if vectors.len() != expected_values {
        return Err(PyValueError::new_err(format!(
            "flat vector buffer length must equal ids length * index dimensions (expected {expected_values} float32 values, got {})",
            vectors.len()
        )));
    }

    Ok(ids
        .into_iter()
        .zip(vectors.chunks_exact(dimensions))
        .map(|(id, vector)| VectorRecord::new(id, vector.to_vec()))
        .collect())
}

fn records_from_flat_vectors_with_id_bytes(
    ids: Vec<Vec<u8>>,
    vectors: &[f32],
    dimensions: usize,
) -> PyResult<Vec<VectorRecord>> {
    if !vectors.len().is_multiple_of(dimensions) {
        return Err(PyValueError::new_err(format!(
            "flat vector buffer length must be a multiple of index dimensions (dimensions {dimensions}, got {} float32 values)",
            vectors.len()
        )));
    }

    let expected_values = ids
        .len()
        .checked_mul(dimensions)
        .ok_or_else(|| PyValueError::new_err("flat vector buffer length exceeds usize"))?;
    if vectors.len() != expected_values {
        return Err(PyValueError::new_err(format!(
            "flat vector buffer length must equal ids length * index dimensions (expected {expected_values} float32 values, got {})",
            vectors.len()
        )));
    }

    Ok(ids
        .into_iter()
        .zip(vectors.chunks_exact(dimensions))
        .map(|(id, vector)| VectorRecord::new_bytes(id, vector.to_vec()))
        .collect())
}

fn flat_vector_row_count(vectors: &[f32], dimensions: usize) -> PyResult<usize> {
    if !vectors.len().is_multiple_of(dimensions) {
        return Err(PyValueError::new_err(format!(
            "flat vector buffer length must be a multiple of index dimensions (dimensions {dimensions}, got {} float32 values)",
            vectors.len()
        )));
    }

    Ok(vectors.len() / dimensions)
}

fn vectors_from_flat_rows(
    vectors: &[f32],
    dimensions: usize,
    label: &str,
) -> PyResult<Vec<Vec<f32>>> {
    if dimensions == 0 {
        return Err(PyValueError::new_err(
            "index dimensions must be greater than zero",
        ));
    }
    if !vectors.len().is_multiple_of(dimensions) {
        return Err(PyValueError::new_err(format!(
            "flat {label} length must be a multiple of index dimensions ({dimensions}); got {} float32 values",
            vectors.len()
        )));
    }

    Ok(vectors
        .chunks_exact(dimensions)
        .map(<[f32]>::to_vec)
        .collect())
}

fn query_from_flat_vector(query: &[f32], dimensions: usize, label: &str) -> PyResult<Vec<f32>> {
    if query.len() != dimensions {
        return Err(PyValueError::new_err(format!(
            "flat {label} length must equal index dimensions ({dimensions}); got {} float32 values",
            query.len()
        )));
    }

    Ok(query.to_vec())
}

fn search_report_ids(report: SearchReport) -> PyResult<Vec<String>> {
    report
        .hits
        .into_iter()
        .map(|hit| hit.id.to_utf8_string().map_err(to_py_error))
        .collect()
}

fn search_report_with_optional_metadata(
    index: &BorsukIndex,
    mut report: SearchReport,
    include_metadata: bool,
) -> PyResult<PySearchReport> {
    if include_metadata {
        for hit in &mut report.hits {
            let id = hit.id.to_utf8_string().map_err(to_py_error)?;
            hit.metadata = index
                .get_record(&id)
                .map_err(to_py_error)?
                .map(|(_, metadata)| metadata);
        }
    }
    report.try_into()
}

fn dimensions_for_vector_name(
    name: &str,
    primary_dimensions: usize,
    named_specs: &BTreeMap<String, VectorSpec>,
) -> PyResult<usize> {
    if name.is_empty() {
        return Ok(primary_dimensions);
    }
    named_specs
        .get(name)
        .map(|spec| spec.dimensions)
        .ok_or_else(|| PyValueError::new_err(format!("unknown named vector `{name}`")))
}

fn hybrid_query(
    vectors: Option<Vec<PyNamedVectorEntry>>,
    text: Option<String>,
    primary_dimensions: usize,
    named_specs: &BTreeMap<String, VectorSpec>,
) -> PyResult<HybridQuery> {
    let mut query = HybridQuery::new();
    for (name, dense, sparse, multi) in vectors.unwrap_or_default() {
        match (dense, sparse, multi) {
            (Some(vector), None, None) => {
                query = query.with_vector(name, vector);
            }
            (None, Some((indices, values)), None) => {
                // A sparse-kind named vector is scored by its inverted-index
                // backend (never densified); anything else densifies the sparse
                // input into a dense leg.
                if named_specs
                    .get(&name)
                    .is_some_and(|spec| spec.kind == VectorKind::Sparse)
                {
                    query = query.with_named_sparse_query(name, indices, values);
                } else {
                    let dimensions =
                        dimensions_for_vector_name(&name, primary_dimensions, named_specs)?;
                    query = query
                        .with_sparse_vector(name, indices, values, dimensions)
                        .map_err(to_py_error)?;
                }
            }
            (None, None, Some(_)) => {
                return Err(PyValueError::new_err(
                    "late-interaction queries use search_late_interaction, not rank fusion",
                ));
            }
            _ => {
                return Err(PyValueError::new_err(
                    "hybrid vector entries must contain exactly one value",
                ));
            }
        }
    }
    if let Some(text) = text {
        query = query.with_text(text);
    }
    Ok(query)
}

fn hybrid_options(
    k: usize,
    fusion: &str,
    rrf_k: usize,
    weights: Option<Vec<(String, f32)>>,
) -> PyResult<HybridOptions> {
    let mut options = HybridOptions::new(k);
    options.fusion = match fusion {
        "rrf" => Fusion::Rrf { k: rrf_k },
        "weighted" => Fusion::Weighted {
            weights: weights.unwrap_or_default().into_iter().collect(),
        },
        other => {
            return Err(PyValueError::new_err(format!(
                "unknown hybrid fusion `{other}`; expected 'rrf' or 'weighted'"
            )));
        }
    };
    Ok(options)
}

fn resolve_dimensions(dim: Option<usize>, dimensions: Option<usize>) -> PyResult<usize> {
    match (dim, dimensions) {
        (Some(left), Some(right)) if left != right => {
            Err(PyValueError::new_err("dim and dimensions disagree"))
        }
        (Some(value), _) | (_, Some(value)) => Ok(value),
        (None, None) => Err(PyValueError::new_err("dim or dimensions is required")),
    }
}

fn resolve_segment_max_vectors(
    segment_size: Option<usize>,
    segment_max_vectors: Option<usize>,
    dimensions: usize,
) -> PyResult<usize> {
    match (segment_size, segment_max_vectors) {
        (Some(left), Some(right)) if left != right => Err(PyValueError::new_err(
            "segment_size and segment_max_vectors disagree",
        )),
        (Some(value), _) | (_, Some(value)) => Ok(value),
        (None, None) => Ok(borsuk::recommended_segment_max_vectors(dimensions)),
    }
}

#[allow(clippy::too_many_arguments)]
fn parse_mode(
    mode: &str,
    leaf_mode: &str,
    eps: Option<f32>,
    max_segments: Option<usize>,
    max_bytes: Option<u64>,
    max_latency_ms: Option<u64>,
    routing_page_overfetch: Option<usize>,
    max_candidates_per_segment: Option<usize>,
) -> PyResult<SearchMode> {
    match mode {
        "exact" => Ok(SearchMode::Exact),
        "approx" => Ok(SearchMode::Approx {
            leaf_mode: leaf_mode.parse::<LeafMode>().map_err(to_py_value_error)?,
            eps,
            max_segments,
            max_bytes,
            max_latency_ms,
            routing_page_overfetch,
            max_candidates_per_segment,
            adaptive_stop: None,
            projected_reads: None,
        }),
        other => Err(PyValueError::new_err(format!(
            "unknown search mode `{other}`"
        ))),
    }
}

fn parse_cache_execution(value: &str) -> PyResult<borsuk::CacheExecutionPolicy> {
    value
        .parse::<borsuk::CacheExecutionPolicy>()
        .map_err(to_py_value_error)
}

fn parse_optional_byte_size(
    value: Option<&Bound<'_, PyAny>>,
    field_name: &str,
) -> PyResult<Option<u64>> {
    let Some(value) = value else {
        return Ok(None);
    };

    if let Ok(bytes) = value.extract::<u64>() {
        return Ok(Some(bytes));
    }

    if let Ok(text) = value.extract::<String>() {
        return borsuk::parse_byte_size(&text, field_name)
            .map(Some)
            .map_err(to_py_value_error);
    }

    Err(PyValueError::new_err(format!(
        "{field_name} must be an integer byte count or byte-size string"
    )))
}

fn duration_from_seconds(value: f64, field_name: &str) -> PyResult<Duration> {
    if value.is_finite() && value >= 0.0 {
        Ok(Duration::from_secs_f64(value))
    } else {
        Err(PyValueError::new_err(format!(
            "{field_name} must be a non-negative finite number"
        )))
    }
}

fn to_py_error(error: borsuk::BorsukError) -> PyErr {
    let code = error.code();
    let message = error.to_string();
    Python::attach(|py| {
        let err = BorsukError::new_err(message);
        if let Err(setattr_error) = err.value(py).setattr("code", code) {
            return setattr_error;
        }
        err
    })
}

fn to_py_value_error(error: borsuk::BorsukError) -> PyErr {
    PyValueError::new_err(error.to_string())
}

impl From<IndexStats> for PyIndexStats {
    fn from(stats: IndexStats) -> Self {
        Self {
            metric: stats.metric,
            dimensions: stats.dimensions,
            segment_max_vectors: stats.segment_max_vectors,
            ram_budget_bytes: stats.ram_budget_bytes,
            text: stats.text,
            named_vectors: stats.named_vectors,
            sparse_encoded_vectors: stats.sparse_encoded_vectors,
            dense_encoded_vectors: stats.dense_encoded_vectors,
            manifest_version: stats.manifest_version,
            routing_max_level: stats.routing_max_level,
            routing_page_fanout: stats.routing_page_fanout,
            routing_leaf_pages: stats.routing_leaf_pages,
            routing_pages: stats.routing_pages,
            segments: stats.segments,
            records: stats.records,
            segment_bytes: stats.segment_bytes,
            graph_bytes: stats.graph_bytes,
            resident_bytes_estimate: stats.resident_bytes_estimate,
            prepared_positioned_bytes: stats.prepared_positioned_bytes,
            collection_resident_bytes: stats.collection_resident_bytes,
            retained_bytes: stats.retained_bytes,
            retained_capacity_bytes: stats.retained_capacity_bytes,
            retained_peak_bytes: stats.retained_peak_bytes,
            transient_bytes: stats.transient_bytes,
            transient_capacity_bytes: stats.transient_capacity_bytes,
            transient_peak_bytes: stats.transient_peak_bytes,
        }
    }
}

impl From<WarmReport> for PyWarmReport {
    fn from(report: WarmReport) -> Self {
        Self {
            segments_loaded: report.segments_loaded,
            segments_total: report.segments_total,
            segments_resident: report.segments_resident,
            graphs_resident: report.graphs_resident,
            coverage_complete: report.coverage_complete,
            bytes_resident: report.bytes_resident,
        }
    }
}

impl From<AddReport> for PyAddReport {
    fn from(report: AddReport) -> Self {
        Self {
            segments_written: report.segments_written,
            graph_payloads_written: report.graph_payloads_written,
            manifest_tables_written: report.manifest_tables_written,
            routing_pages_written: report.routing_pages_written,
            total_bytes_written: report.total_bytes_written,
            bytes_per_vector: report.bytes_per_vector,
            requests: report.requests.into(),
        }
    }
}

impl TryFrom<SearchHit> for PyHit {
    type Error = PyErr;

    fn try_from(hit: SearchHit) -> PyResult<Self> {
        let id = hit
            .id
            .to_utf8_string()
            .unwrap_or_else(|_| hit.id.to_string());
        let id_bytes = hit.id.as_bytes().to_vec();
        Ok(Self {
            id,
            id_bytes,
            distance: hit.distance,
            metadata: hit.metadata,
        })
    }
}

impl TryFrom<SearchReport> for PySearchReport {
    type Error = PyErr;

    fn try_from(report: SearchReport) -> PyResult<Self> {
        let hits = report
            .hits
            .into_iter()
            .map(PyHit::try_from)
            .collect::<PyResult<Vec<_>>>()?;
        Ok(Self {
            hits,
            leaf_mode: report.leaf_mode,
            termination_reason: report.termination_reason.to_string(),
            recall_guarantee: report.recall_guarantee.to_string(),
            segments_total: report.segments_total,
            segments_searched: report.segments_searched,
            segments_skipped: report.segments_skipped,
            routing_page_indexes_read: report.routing_page_indexes_read,
            routing_pages_read: report.routing_pages_read,
            bytes_read: report.bytes_read,
            prefetched_bytes_unused: report.prefetched_bytes_unused,
            graph_bytes_read: report.graph_bytes_read,
            decoded_cache_hits: report.decoded_cache_hits,
            decoded_cache_bytes_read: report.decoded_cache_bytes_read,
            object_cache_hits: report.object_cache_hits,
            object_cache_misses: report.object_cache_misses,
            disk_cache_bytes_read: report.disk_cache_bytes_read,
            backing_bytes_read: report.backing_bytes_read,
            disk_cache_reads: report.disk_cache_reads,
            backing_reads: report.backing_reads,
            cache_repairs: report.cache_repairs,
            records_considered: report.records_considered,
            records_scored: report.records_scored,
            graph_candidates_added: report.graph_candidates_added,
            global_graph_chunks_searched: report.global_graph_chunks_searched,
            global_scan_chunks_searched: report.global_scan_chunks_searched,
            global_base_approximate_us: report.global_base_approximate_us,
            global_base_head_admission_us: report.global_base_head_admission_us,
            global_base_head_fetch_us: report.global_base_head_fetch_us,
            global_base_head_decode_admission_us: report.global_base_head_decode_admission_us,
            global_base_head_decode_us: report.global_base_head_decode_us,
            global_base_exact_admission_us: report.global_base_exact_admission_us,
            global_base_exact_fetch_us: report.global_base_exact_fetch_us,
            global_base_exact_read_us_max: report.global_base_exact_read_us_max,
            global_base_exact_read_us_sum: report.global_base_exact_read_us_sum,
            global_base_exact_reads_over_20ms: report.global_base_exact_reads_over_20ms,
            global_base_exact_reads_over_30ms: report.global_base_exact_reads_over_30ms,
            global_base_exact_reads_over_50ms: report.global_base_exact_reads_over_50ms,
            global_base_exact_reads_over_100ms: report.global_base_exact_reads_over_100ms,
            global_base_exact_cpu_us: report.global_base_exact_cpu_us,
            global_base_exact_rerank_us: report.global_base_exact_rerank_us,
            resident_bytes_estimate: report.resident_bytes_estimate,
            prepared_positioned_bytes: report.prepared_positioned_bytes,
            collection_resident_bytes: report.collection_resident_bytes,
            retained_bytes: report.retained_bytes,
            retained_capacity_bytes: report.retained_capacity_bytes,
            retained_peak_bytes: report.retained_peak_bytes,
            transient_bytes: report.transient_bytes,
            transient_capacity_bytes: report.transient_capacity_bytes,
            transient_peak_bytes: report.transient_peak_bytes,
            elapsed_ms: report.elapsed_ms,
            requests: report.requests.into(),
            rows_evaluated: report.rows_evaluated,
            rows_passed_filter: report.rows_passed_filter,
            segments_pruned_by_filter: report.segments_pruned_by_filter,
        })
    }
}

impl From<CompactionReport> for PyCompactionReport {
    fn from(report: CompactionReport) -> Self {
        Self {
            compacted: report.compacted,
            source_level: report.source_level,
            target_level: report.target_level,
            segments_read: report.segments_read,
            segments_written: report.segments_written,
            records_rewritten: report.records_rewritten,
            routing_page_indexes_read: report.routing_page_indexes_read,
            routing_pages_read: report.routing_pages_read,
            routing_page_indexes_written: report.routing_page_indexes_written,
            routing_pages_written: report.routing_pages_written,
            graph_payloads_read: report.graph_payloads_read,
            graph_bytes_read: report.graph_bytes_read,
            bytes_read: report.bytes_read,
            bytes_written: report.bytes_written,
            object_cache_hits: report.object_cache_hits,
            object_cache_misses: report.object_cache_misses,
            manifest_version: report.manifest_version,
        }
    }
}

impl From<GarbageCollectionReport> for PyGarbageCollectionReport {
    fn from(report: GarbageCollectionReport) -> Self {
        Self {
            dry_run: report.dry_run,
            objects_scanned: report.objects_scanned,
            objects_deleted: report.objects_deleted,
            transaction_states_remaining: report.transaction_states_remaining,
            routing_objects_deleted: report.routing_objects_deleted,
            tables_deleted: report.tables_deleted,
            routing_page_indexes_read: report.routing_page_indexes_read,
            routing_pages_read: report.routing_pages_read,
            bytes_read: report.bytes_read,
            bytes_reclaimable: report.bytes_reclaimable,
            bytes_reclaimed: report.bytes_reclaimed,
            object_cache_hits: report.object_cache_hits,
            object_cache_misses: report.object_cache_misses,
            candidates: report.candidates,
        }
    }
}

impl From<RebuildReport> for PyRebuildReport {
    fn from(report: RebuildReport) -> Self {
        Self {
            compaction: report.compaction.into(),
            garbage_collection: report.garbage_collection.into(),
        }
    }
}
