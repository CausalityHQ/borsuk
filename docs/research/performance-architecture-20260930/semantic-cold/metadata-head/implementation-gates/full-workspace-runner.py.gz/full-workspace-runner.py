import sys,os,json,subprocess,time,hashlib
from pathlib import Path
root=Path('/home/rb/worktrees/borsuk-prod-ready-v9');tree=Path('/home/rb/worktrees/borsuk-semantic-metadata-known-lengths-20261001');sys.path.insert(0,str(root))
from scripts.check_native_startup_build import source_hashes,source_identity
out=Path('/tmp/borsuk-semantic-metadata-full-a0001');out.mkdir(exist_ok=False)
before=source_hashes(tree);assert source_identity(before)=='b095ba7d738a65a31faefa0d705ce34e12cb83aeaa153c25079564c53b129c70';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()=='520f2bc47a4c042e7d5db5cdad164a55b53115b8'
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/data/target',RUSTC_WRAPPER='',RAYON_NUM_THREADS='2',TOKIO_WORKER_THREADS='2',RUST_TEST_THREADS='1')
env.update(PATH='/data/cache/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin',CARGO_HOME='/data/cache/cargo',RUSTUP_HOME='/data/cache/rustup')
env.pop('RUSTFLAGS',None)
command=['/data/cache/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo','test','--release','--locked','--workspace','--all-targets']
r={'schema':'borsuk-semantic-native-full-execution-v1','source_sha256':before,'source_identity_sha256':source_identity(before),'source_file_count':len(before),'cwd':str(tree),'compiled_worker_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),'root_commit_before_integration':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'equivalent_main_commit':None,'command':command,'environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_TARGET_DIR','RUSTC_WRAPPER','RAYON_NUM_THREADS','TOKIO_WORKER_THREADS','RUST_TEST_THREADS','PATH','CARGO_HOME','RUSTUP_HOME']},'wall_cap_seconds':7200,'memory_max_bytes':8589934592,'memory_swap_max_bytes':0,'cpu_quota_percent':200,'task_cap':512,'started_epoch':time.time()}
(out/'reservation.json').write_text(json.dumps(r,indent=2)+'\n')
with (out/'test.log').open('xb') as log:
 r['exit_status']=subprocess.run(['/usr/bin/time','-v','-o',str(out/'time.txt'),'timeout','--signal=TERM','--kill-after=5','7200',*command],cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
r['finished_epoch']=time.time();r['source_unchanged']=before==source_hashes(tree)
r['artifacts']={name:{'bytes':(out/name).stat().st_size,'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest()} for name in ['test.log','time.txt']}
entry=next(line[3:] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'));cg=Path('/sys/fs/cgroup')/entry.lstrip('/')
r['cgroup']={name:(cg/name).read_text().strip() for name in ['memory.max','memory.peak','memory.swap.max','memory.swap.peak','memory.events','cpu.stat','pids.max','pids.peak','pids.events']}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
raise SystemExit(r['exit_status'] if r['source_unchanged'] else 99)
