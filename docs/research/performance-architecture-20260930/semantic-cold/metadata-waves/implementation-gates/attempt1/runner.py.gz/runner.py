import hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path('/home/rb/worktrees/borsuk-semantic-metadata-waves-20261001')
out=pathlib.Path(__file__).parent
os.chdir(root)
sys.path.insert(0,str(root))
from scripts.run_native_semantic_router_cold import native_inventory, encoded
inventory=native_inventory()
identity=hashlib.sha256(encoded(inventory).encode()).hexdigest()
owned=['crates/borsuk/src/object_native_generation.rs','crates/borsuk/src/two_bit_generation.rs','scripts/check_native_semantic_router_stats.py','scripts/run_native_semantic_router_cold.py','scripts/check_native_semantic_concurrency.py']
source=dict(base_revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),native_source_identity_sha256=identity,native_source_file_count=len(inventory),native_inventory=inventory,owned={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in owned},diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff','--binary'])).hexdigest())
(out/'source.json').write_text(json.dumps(source,sort_keys=True,indent=2)+'\n')
commands=[
('object-native',['cargo','test','--locked','-p','borsuk','--lib','object_native_generation::tests','--','--test-threads=1']),
('generation',['cargo','test','--locked','-p','borsuk','--lib','two_bit_generation::','--','--test-threads=1']),
('http-release',['cargo','build','--locked','--release','-p','borsuk','--example','two_bit_http']),
('clippy',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','clippy::correctness','-D','clippy::suspicious']),
('workspace-test-build',['bash','scripts/check_rust_test_build.sh']),
]
selected=sys.argv[1:]
for name,command in commands:
    if selected and name not in selected: continue
    assert native_inventory()==inventory, 'source changed during qualification'
    start=time.time_ns()
    log=out/(name+'.log')
    print(json.dumps(dict(phase='start',name=name,command=command,source_identity=identity,pid=os.getpid())),flush=True)
    with log.open('wb') as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT)
        (out/'active.json').write_text(json.dumps(dict(name=name,pid=child.pid,runner_pid=os.getpid(),start_ns=start,command=command))+'\n')
        status=child.wait()
    body=log.read_bytes()
    receipt=dict(name=name,command=command,base_revision=source['base_revision'],native_source_identity_sha256=identity,owned=source['owned'],diff_sha256=source['diff_sha256'],environment={k:os.environ.get(k) for k in ['RUSTC_WRAPPER','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','BORSUK_TEST_BUILD_JOBS']},start_ns=start,end_ns=time.time_ns(),status=status,log=str(log),log_bytes=len(body),log_sha256=hashlib.sha256(body).hexdigest())
    (out/(name+'-receipt.json')).write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(phase='terminal',name=name,status=status,log_bytes=len(body),log_sha256=receipt['log_sha256'])),flush=True)
    assert native_inventory()==inventory, 'source changed during qualification'
    if status: sys.exit(status)
print('QUALIFICATION TERMINAL',flush=True)
