#!/bin/bash
set -euo pipefail
systemd-run --unit=native-semantic-router-cold-stop --on-active=3600s /usr/sbin/shutdown -h now
root=/mnt/native-semantic-metadata-waves-cold
mkdir -p "$root" && cd "$root"
phase=bootstrap
export ARTIFACT_NAMES=run-closed.log
finish() {
  original_code=$?
  code=$original_code
  trap - EXIT TERM
  set +e
  cd "$root"
  { printf 'BORSUK_BOOTSTRAP phase=%s original_exit_code=%s\n' "$phase" "$original_code"; tail -c 4096 run.log; printf '\n'; } >/dev/ttyS0 2>/dev/null || true
  cp run.log run-closed.log || code=96
  token=$(curl -fsS --connect-timeout 2 --max-time 5 -X PUT -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' http://169.254.169.254/latest/api/token) || code=96
  instance_id=$(curl -fsS --connect-timeout 2 --max-time 5 -H "X-aws-ec2-metadata-token: $token" http://169.254.169.254/latest/meta-data/instance-id) || code=96
  aws_ready=0
  if command -v aws >/dev/null; then
    aws_ready=1
    for name in $ARTIFACT_NAMES; do
      if [ -f "$name" ]; then
        timeout --kill-after=5 60 aws s3 cp "$name" "s3://borsuk-bench-453182569524-euc1/research/semantic-router/20261001/metadata-waves-offered-a0001/artifacts/$name" --only-show-errors || code=96
      fi
    done
  else code=96; fi
  write_terminal() {
    INSTANCE_ID="$instance_id" EXIT_CODE="$code" ORIGINAL_EXIT_CODE="$original_code" PHASE="$phase" python3 - <<'PY' >terminal.json
import hashlib,json,os
from pathlib import Path
artifacts={}
for name in os.environ['ARTIFACT_NAMES'].split():
    path=Path(name)
    if path.is_file():
        digest=hashlib.sha256()
        with path.open('rb') as source:
            for chunk in iter(lambda: source.read(1024*1024),b''):
                digest.update(chunk)
        artifacts[name]={'bytes':path.stat().st_size,'sha256':digest.hexdigest()}
code=int(os.environ['EXIT_CODE'])
print(json.dumps({'schema':'borsuk-native-semantic-metadata-waves-cold-offered-spot-v1','source_commit':'52b14ff0c939ee328245719e209800c373ab094f',
  'source_archive_sha256':'0000000000000000000000000000000000000000000000000000000000000000','config_sha256': 'f96e2da10958e89add50c57abae366c3b435d21c26d6a318713496effb713726', 'role_bindings': {'control': {'native_role': 'control', 'config_sha256': 'f96e2da10958e89add50c57abae366c3b435d21c26d6a318713496effb713726', 'binary_sha256': '82c02967f3b2de8c7bf1f2dcfc0e94496882ba6e749b7195f1fca824ab2b7ec1', 'binary_bytes': 16189792, 'proof_sha256': '528591dd8e6d88c850b445ef17234a700638e5fae939378318fa9cc7d299abbe', 'source_manifest_sha256': '2cfbead9e036ae09ed4c2cf2e1f9e8bec3e324c8716173f61c1ffbaef75cb004', 'native_source_identity_sha256': 'b095ba7d738a65a31faefa0d705ce34e12cb83aeaa153c25079564c53b129c70', 'checker_sha256': '93db7c38b40aa9480f70076d359f35754850d46c2e853a1d9107621ba9bc07d8', 'checker_authority_sha256': 'c90ecbee9443ea46b75ede73b034040fdfcfcb61e0329e2d060235bb0b61a0b0'}, 'candidate': {'native_role': 'candidate', 'config_sha256': 'f96e2da10958e89add50c57abae366c3b435d21c26d6a318713496effb713726', 'binary_sha256': 'e3516453797add1f8e76daddcc97a8fb5e4c1c3467749ae9cb732934b3bc2c0e', 'binary_bytes': 16259024, 'proof_sha256': '2a3104109738822581167161db9d535602fa03666c2bbd4ef5865da9ba3a873d', 'source_manifest_sha256': '38a19170e8974de3259d90e7a1137c66b9eccf93c1978f90f4cba42a43d45894', 'native_source_identity_sha256': '714794a10c2d886f7a53a9926a4bb63e093cec16858676268e31833aeead2681', 'checker_sha256': 'd1fb970c0ab6ec98ec5311204a54277180631116d48a29a564ed3bbd68e5c5c2', 'checker_authority_sha256': 'c90ecbee9443ea46b75ede73b034040fdfcfcb61e0329e2d060235bb0b61a0b0'}}, 'artifact_roster_sha256': '1677e2733fee307ca5783ba0a1cc44e2572aecc619e6e25afc33101e6ade4be5', 'code_identity_sha256': '6326f3b2d9cfe1e3397645a73473d712626b04a639ddce74cfb2bd59d1c19d7f', 'awscli_version': '2.36.11', 'awscli_sha256': '50fbb7a2f44a78eab4a210088040e8f0bc4b9937cac8043c2354269d58614df6', 'runtime_abi_sha256':artifacts.get('runtime-abi.json',{}).get('sha256'),
  'instance_id':os.environ['INSTANCE_ID'],'exit_code':code,'original_exit_code':int(os.environ['ORIGINAL_EXIT_CODE']),'source_qualification_sha256':artifacts.get('source-qualification.json',{}).get('sha256'),
  'phase':os.environ['PHASE'],
  'status':'complete' if code==0 and os.environ['PHASE']=='complete' else 'failed',
  'artifacts':artifacts},sort_keys=True,separators=(',',':')))
PY
  }
  terminal_ready=0
  if command -v python3 >/dev/null; then write_terminal && terminal_ready=1 || code=96; else code=96; fi
  { if [ "$terminal_ready" = 1 ]; then printf 'BORSUK_TERMINAL '; cat terminal.json; else printf 'BORSUK_TERMINAL unavailable\n'; fi; } >>/dev/ttyS0 2>/dev/null || true
  if [ "$aws_ready" = 1 ] && [ "$terminal_ready" = 1 ]; then
    timeout --kill-after=5 60 aws s3 cp terminal.json "s3://borsuk-bench-453182569524-euc1/research/semantic-router/20261001/metadata-waves-offered-a0001/terminal.json" --only-show-errors || { code=96; write_terminal || terminal_ready=0; }
  fi
  printf 'BORSUK_FINISH phase=%s original_exit_code=%s exit_code=%s\n' "$phase" "$original_code" "$code" >>/dev/ttyS0 2>/dev/null || true
  shutdown -h now || true
  exit "$code"
}
trap finish EXIT
trap 'exit 97' TERM
exec >run.log 2>&1
export DEBIAN_FRONTEND=noninteractive AWS_MAX_ATTEMPTS=1
phase=apt-update
timeout --kill-after=30 180 apt-get -qq -o DPkg::Lock::Timeout=120 update
phase=apt-install
timeout --kill-after=30 300 apt-get -qq -y -o DPkg::Lock::Timeout=120 install curl unzip python3-boto3 python3.12 time tar gzip util-linux binutils
phase=awscli-download
curl -fsSL --connect-timeout 10 --max-time 180 --output awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64-2.36.11.zip
printf '%s  awscliv2.zip\n' '50fbb7a2f44a78eab4a210088040e8f0bc4b9937cac8043c2354269d58614df6' | sha256sum -c -
test "$(stat -c %s awscliv2.zip)" = 73022935
phase=awscli-install
timeout --kill-after=30 120 unzip -q awscliv2.zip
timeout --kill-after=30 120 ./aws/install
cli_version=$(aws --version)
[[ "$cli_version" == aws-cli/2.36.11\ * ]]
phase=source-download
aws s3 cp 's3://borsuk-bench-453182569524-euc1/research/source-archives/0000000000000000000000000000000000000000000000000000000000000000.tar.gz' source.tar.gz --only-show-errors
printf '%s  source.tar.gz\n' '0000000000000000000000000000000000000000000000000000000000000000' | sha256sum -c -
mkdir repo && tar -xzf source.tar.gz -C repo
phase=install
python3.12 -c 'import boto3'
python3.12 -c 'import base64,gzip; from pathlib import Path; Path("source-qualification.json").write_bytes(gzip.decompress(base64.b64decode("H4sIAAAAAAAC/72ayXIcSXKG3wVngoh96bN0mMuMmWSma1ksHmANARSmFnKoNr27vigszAIKJFpszaHbGlXo9Ej33/8lE79flO1+PUrbr7ab3V62q92nYny4+O1ChxjFRGuHiFWxFR+TrUUV3ZpzYnw0RVoLOkvgpzKatVppCaWLq+IvPlyUw/7TZrvef1s9Vdld/Pb7RSt3fd3LXi7bJ2mfZfvx/tvH6/+eX9Vve+F3sgrpw8XzUUwtxmSphfIjaZd1jTaXFF2pzuowajVDFdXbUEOc9VJ0r9Kqbqn74C7+58Oi6P12sxkf/77b3C0qWqu8XZYs3IzTKkebkjE+afqhA5fN3VsflBlF2RBCM7V2J8On4HvJtVjOZftpyd3msG3ysqaL3sVFTZuKzjoqSTm6Ltb43LOSWLS2sYVQM/0e2TadYxpZDddqcaY4251P+fQ2r8pud9iWuyZX7WZ9T4dfVk9hUbvlzlV1q9E174JXKbYRVKgl+ZKSYwC6xxoUDUgujz6c60NZ23wMMupPat9srhelTUwmLKuroE3R1UgJLUTjZbhhlG6u9a5a12lW8Wa0KKKcSrX7WF0cTUJwOr155+Nwc3P5dbP9vLsvTS7H+q7cvOqDz2k5hTyUqTmYXkcIscgwY5hulba1hyiqVQ/0jEreZxtHCmMM7scoTlZqK3/oLKd9sUAs+cVZgi8tepPE+pQiK+BT1MZlR3OCH8NGG5222bGekrwuorRWgEWUCRztrbNcy51sy369uXuNSbNEpKbFrsSk+oijxsR0lFclOkmsYrFJpcSu+hijC7oJa9NVMcVUb0qO76h/2oGg8gkwfKWtzfcehqV+rgm4t8SyVi9uDMnJG+ugIMfq+N4aCxFSBzKpsJhvHeDTfn9/uZUbKbvXaxn0yWKYRH3rbSlex2pYy1J1AP4+G03LjRqD/5Jgq9eghcqhuq5jME2Hd53gRROc8/FkO4Jw4xn4mxR6EqMdTJyCUy2W6uEK6bn6Rg/y8EBFl5EdjCwQg35zNzf179L2l3cM4svrLqS8PIIFh82olquDXFMAqhGqc9UqkKHN0LZrI3rykgs1+hB0yXZucSgjvu8IL9qgVVpOwkbYqHQdDPeXSxwlKViL9U3GqQFJWqbDGKT3IqVk0IFkaSf0ofU3F/P7TlJ2f1kP65v+qht22Q3xKoB3B+61Ttm44n0V2yRm4yHjCgyU1GBpYlQNIQlupEmaNmSR8YdOctqUFJRSy6PYFgw9gAZohLK92R48euz9gCU6Ap5tasq54YOdFK9cb7EOxinB2NOjrG/vb+RW7vbH3bz8Itv1WLezRGFtXi7q1NkYkC7mH+AAU/EDjq2ow6mY0f7mkMUUOCmioYbvZsQ+ah7Bt2pOz/GAh8vnzpxRTr3kKTSDksZUqR3NTENlrQGiHoCoQ1kp215rsg45bd3FJErBJAEa07qOs9UfRXtftqfmxCKF7P+SpfAm0/0MXSuS5QOLoAAI467WBERVMqLuWEzmBAp6h+bCVG40Nj7I14MVunz2TC/v+UXNhjNoVSQ7Z6UcV066RFsVN8k69NFGq0GLsugG7cGyWF+r4rOiqjrW3Nztt5ubN21YjHm5gBw9D9wXN4MnpCiYKi6HHmqFhyQOH63W2Ac0Es/mBnwxtIKhpep0UvK8CdP2ZONRPp91h/FgvdSSVxVqlKEjnF+iAmlJ/CiSAflc9TRKbi12kzPsL8uCb1gwXNCJ02yjSumZrgXENEOgjc+Y52CCWEqLLUOAphWMDE83PUbFJLBOVSm3qLjY64JQtb308wZE8/8tjtC9tkFDrFqSKi7mmHuvXrXEMZi1agYpwgpb76rBjOLDfEEL8sCQW/uuI7xkWghkyfZOIpLrkjjMXWitAmPpk+4512x4RXidxokN2yb/t54UOm1UpTPj/BEerOD5HmCzF/V1LZ7EoXvD2YSqS1fapQrjYIZ76E1Z1V2fPmQCjH9oTY/ajTL1oL6j/itDqvMSB0Xh94B1gpqMQXdCSFExeAynzeKEL0kcQeaa29BsCaMH7Hvt9MTn8yd4lx1NRp8QPCJoYg6jhF6JH6n4oUQ7kzs5qOcpwk5U8BnvVEO0QLTEiiW3BS0Yf+AkL8yo8+rkJL0lBwIBpYq1Tc8V6yxJElCpZaIW5yARDGJBBo6hVMu65AbXk13a+ZM8WqA3YHFiBgE7veaSOF6D9zVAIA4cqSEuVKxnm4RX5gp3XPDAqYYAMYTUpOEH3nOAl04snCyGHjKK0Rk2Sgq5l9RsM6Rk5AbNiaoj+R3qzTV2sGu60Sl2P0APJ1DnT/Bd7N/oglpmgjoNhk1kYEBvspsdAR7Gwu3wQwuTtYovJWW8q1J4pqpGVQ6bXCT6d57hle2Iy0M0kWoQ1ShUJh/4CDVGXxA24mKzwUOfhtyoMWbMp/nCjuHNGBY5/YSkfir2mIYlDkPt0vAS3VRuKUMOmWU0WKsK9Q8pNThyYilmBBK5ngkGD2pNQ4BTMWdqvy312uMrlwiY2duZ2gJOJ2P4mEUfhk3AfHScMZ5Ct6JS10izQSoJhSna6QZ7MidLMPcPxf+Ry4L20rK8a7F5SJCEOp0fXlAB70DYAGjNYMGCh5aJhoVsaAZBCEZMOAVD5DZHH35f7uTmBz4j4buXtjvokUxPcB63VTTM4ofVZB1GrwB15/YYLwrkDXaPwCzEoWCUD85OSaRm+bqDfr8/XPIgEs/A4s50ycgca6VmmHTTQyr4pWbg1UrjI3YMsTMhd5+Qxj7CxfMl6d5uPW/gwny04aPWF9PK3d6X9fXdaoezuS1zaTbb3eHz5dO4+fBuv26Xt7IvWL5y+bV8kd1l2wD/DUq5RSh395v95Zfj5TZdVuuOLZ6Psr7jEGs3iBwdhhON8uYYnC/RTqNLTA/ohgJ6Fv2GKxy8ZCqhsWMaco/j6cpPF/z9Yte26/v97urox1YPh109nXHFclzLbrXDnO+wanM0TcdujTI9diyw499eGWcSDqkkJFqj0cMzeXo7lRNPGCdjRPIR0s0JzpZ86s/32rMzDzV1buhc99K6sBx1JAHYVgEMPf1BTkQO0Om9KvxWCZFbh3z7GC2gWD+tud0cjs8hv99m18QEcpRis6Vl0OyxmYbeAooYcZYkG+xxd2x3LsAOr0L4D5jDRmp9syT7vj/crx5y1rEU0X6g7TFVRNx5Nx+3RNxmgkV1xxASZzUCSMQTy3c4IyQQWYJbZPifllrclQ+zWeT1ymWHx7CLOAPZmWYN4sYPkYgQMetxpn8F1U73RdDwbEtelLoph7v26S3AzNmtJpof6krANvlMUk0NeZpGWYdWTIvZcpdWNRZAUY1F9PxWgEFTIP4TIFMo/c2698LY9O2iFLFc4RPH6JMSFYZZZ+gTkYCiPT1zlajUnJhmeis4vlrJjb4PMn1V7c1S5wG6qNyxsCYTuzAm9HXOsnJDdBwhM11Xh0+tWEeFWnkLE6XIZoaRS3J+vKPyI0xf1K3sfEQOYa4ccSWxWNi6zuztEcAgbCdel6XEu6hpcwvjRBMjR5gR6c26jwAiN431jSxKuoIXlZFjJxrBz0YGDU8QZSGwRHGeyWk7iDKZOyMyVlQQvxt9LdmdmecX7SOF1rdl+22Fnu7WdX1zpL7noikZqzOaMkGZQ9OBGFKGDtOYkdRCdvjQijJmDJBhopXQz+IWqDKneq5odCu8WFn3VV3fdTp7e396p5UgyJaQTJKHwqL24/jsB4HH+BxXv8NK7H+lFXU+JCCSao6awJoti6K43s/lejHOxzYvHkweS2IoIRmyl1bIX/Tk024MVC81moHbTQYCiKaYbkVweQAYU47lKyhkdsuSW7kvW3kFpPtDvXlS/4etIWhlExWpDtWNsHjHcAJjKH1G02yYY3TT8Ayq5DEFCJi1yB4x70XNLa6ORso/17u9YK1WN5vyyHSEGSVgIipUNWSvMFIJejPRY6aH5EzCVdXIccI2pZiV9bEM6EPhK5ZVDndPd3Vch7HeUvYfB9l+e6hFQq4JT4IXhAxUm88suGZpTgUWRLT2TeNoUUyjuQ/rxaYR/JQRk6r+Qa1HtX7c+tj6wKcYVKkVAgDxqLfqcKEWsRhTNtgP+BPg4l6NddPIlTqLguDzdc7x6aMWWmMmnmtUviGplebVJiHLfAJc8kylyYEhr0AmTVW6Gm+VHp2cXNP5ek88+mAPH/eN7EXCzXnAWGbSc54BoI2EQdI47C6dMMIGKF+a9wifMQpn3ECM7fYHlR47uJoPpB+KRfZ3TqzFBORlYHcNaJyAybpUD4lFUdUbPbAcZM+RaAFBsDeHOtbzxX5oKnwdnZMjRzp4T15008Qr0G9wzy7B3vAZiTJo3y1qWfmMBaBcVj3+pOKCqx/qzUfDhKbUiQ8Zyiax6flYQ9HeQYihCKG6a9i6YivIfORYbFvB2fiR3hjc4Y4dXvQRDh6MbTpABNwEkJawCdjbBOXjwZo2SeOfsC4q2czaoU7Jua4TRdSPqryeGt6nIeu2w8rNEouBnvYOqLO6FqeBI4PYIZcWkWVNVsG0Y+FxA9jI8JhMxvp6dV/2n+Y6bdqRQqRs26ere9mOzfZ2JrTL+cF6L21/2Mol/pPMadXVs62ejb469dZXT7b6ocRD6Hgu+OypR0YiiVEqE1oS29u9arBOLbiy0Gx11mNaSDod5kBaNEQSUDz2Cc80c0E7bLdY9dV8xLHaHTgm97NjbZGW24vf9tuDfLg4fvn8/GM10+9K/intsD9miYdfemw4alS2azl9db0MTMH4jO3+cPFZ5iCeO/bcjwf8Xc1GYcT1Y+q8goj09EExx4k5nHQksBIW8A7Y8/mGq+lmXYhxRvfcKpEuw1m2NsMyXu2/bjjd/giCixnsjmO72t/eXz0GnreSzvNRXlxi8V7h1862yLknrYLm2ek/3CogrUwO8Zi3ILqIdxt4xjE5yQEBfEAtgagBE2l2VI9WsAZQco3s2f+pVZ/vNl/vLm/k7nr/6R0t+9UzHoPyI+a2MkPJ/uK3UW52QHEr/zis575f36xre4HEmXzTxaLfDx9wNX464rev767P4HcC+9vqFYwfP//zsPD8dmP1/S9C/rwXGd+v/v1R5a8nxv8HZnqaLUOZ9/08iudvHh5DnXnUEDVK6ChOTpqqEovHI6JcJO4aLAHSNhCEL06B0BimpiRri2AY+WkaqOMLl9Wf9/ctAP/htGzNekz+/HP/jmXBHS9g+kQhL2H6y/v3L4fpfCkZm03VqUIUS2rE+TyvW58HXhub6lV3jIAkbgsxQPOt0cS22hT6/i+B6eMgfg5SghCJMnYQVYLn4hgqQDRfvzaxTubTkmTnm3lN9jdexczisZlVm4wneQ3SX37/9wOQ/vqbvsmvB3pwK0+sPHl3Ppd5+nhz5Ny//BvfHCqfHfjuv/79P/7zL3/76+r4qXEfj1f6X1OyX5mHJwAA")))'
export ARTIFACT_NAMES=$(PYTHONPATH="$root/repo" python3.12 -c "from scripts.launch_native_semantic_metadata_cold_spot import OFFERED_ARTIFACTS; print(' '.join(OFFERED_ARTIFACTS))")
phase=binary-qualification
lscpu >cpu.txt
test "$(uname -m)" = x86_64
mkdir -p binaries/control binaries/candidate
aws s3 cp s3://borsuk-bench-453182569524-euc1/research/semantic-router/20261001/native/82c02967f3b2de8c7bf1f2dcfc0e94496882ba6e749b7195f1fca824ab2b7ec1/two_bit_http binaries/control/two_bit_http --only-show-errors
aws s3 cp s3://borsuk-bench-453182569524-euc1/research/semantic-router/20261001/native/e3516453797add1f8e76daddcc97a8fb5e4c1c3467749ae9cb732934b3bc2c0e/two_bit_http binaries/candidate/two_bit_http --only-show-errors
PYTHONPATH="$root/repo" python3.12 -m scripts.launch_native_semantic_metadata_cold_spot --offered --stage "$root/repo" "$root"
phase=profile
set +e
systemd-run --unit=native-semantic-metadata-waves-cold --wait --pipe -p MemoryMax=8G -p MemorySwapMax=0 -p RuntimeMaxSec=3030 -p WorkingDirectory="$root/repo" \
 --setenv=PYTHONPATH="$root/repo" --setenv=TOKIO_WORKER_THREADS=4 --setenv=AWS_MAX_ATTEMPTS=1 --setenv=BORSUK_NATIVE_MEMORY_BYTES=536870912 \
 /usr/bin/time -v -o "$root/profile-resources.txt" timeout --signal=TERM --kill-after=30 3000 \
 bash -c 'ulimit -v 4194304 || exit 96; taskset -c 4-5 python3.12 -m scripts.launch_native_semantic_metadata_cold_spot --offered --run-offered research/semantic-router/20261001/metadata-waves-offered-a0001 docs/research/performance-architecture-20260930/semantic-cold/metadata-waves/offered-config.json f96e2da10958e89add50c57abae366c3b435d21c26d6a318713496effb713726 "$1/binaries/control/two_bit_http" "$1/control-proof.json" "$1/binaries/candidate/two_bit_http" "$1/candidate-proof.json" "$1/screen"; code=$?; taskset -c 0-3 python3.12 -m scripts.check_native_startup_build --cgroup "$1/profile-cgroup.json" 8589934592; resources=$?; if [ "$code" = 0 ] && [ "$resources" != 0 ]; then code=96; fi; exit "$code"' _ "$root" >profile.log 2>&1
profile_code=$?
set -e
if [ "$profile_code" -gt 1 ]; then exit "$profile_code"; fi
if ! PYTHONPATH="$root/repo" python3.12 -m scripts.launch_native_semantic_metadata_cold_spot --offered --check-closed "$root"; then
  if [ "$profile_code" = 0 ]; then profile_code=96; fi
  exit "$profile_code"
fi
for name in $ARTIFACT_NAMES; do
  if [ "$name" = run-closed.log ]; then test -s "$root/run.log"; else test -s "$root/$name"; fi
done
phase=complete
exit "$profile_code"
