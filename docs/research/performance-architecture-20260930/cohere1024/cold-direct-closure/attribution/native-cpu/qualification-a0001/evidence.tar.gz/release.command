cargo build --locked --release -p borsuk --example native_process_cpu
