cargo clippy --locked -p borsuk --example native_process_cpu --profile test -- -D clippy::correctness -D clippy::suspicious
