cargo test --locked -p borsuk --example native_process_cpu -- --list
