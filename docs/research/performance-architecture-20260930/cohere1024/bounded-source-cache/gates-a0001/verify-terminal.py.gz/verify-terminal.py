import pathlib,json,hashlib,tarfile,re,subprocess
p=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
t=json.loads((p/'terminal.json').read_text());w=json.loads((p/'wait.json').read_text())
assert t['instance_id']==w['instance_id']=='i-0ad0cffa253fefc0d' and w['terminated'] and w['wait_exit']==0
assert t['phase']=='complete' and [t[k] for k in ['exit','native_exit','original_exit']]==[0,0,0]
z=(p/'evidence.tar.gz').read_bytes();assert len(z)==t['evidence']['bytes'] and sha(z)==t['evidence']['sha256']
expected={}
for line in (p/'artifacts.sha256').read_text().splitlines():
 h,name=line.split('  ',1);assert re.fullmatch('[0-9a-f]{64}',h) and name.startswith('./');name=name[2:];assert name not in expected;expected[name]=h
out=p/'collected';out.mkdir(exist_ok=True);seen=set()
with tarfile.open(p/'evidence.tar.gz') as archive:
 for m in archive:
  if m.isdir():continue
  assert m.isfile() and m.name.startswith('./');name=m.name[2:];parts=pathlib.PurePosixPath(name).parts;assert parts and all(v not in ['.','..'] for v in parts) and not pathlib.PurePosixPath(name).is_absolute()
  assert name in expected and name not in seen;body=archive.extractfile(m).read();assert sha(body)==expected[name];seen.add(name);dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
assert seen==set(expected)
assert (out/'gates.sh').read_bytes()==(p/'gates.sh').read_bytes()
for f in ['source-files.sha256','native-source.json']:assert (out/f).read_bytes()==(p/f).read_bytes()
support=[line.split('  ',1)[1] for line in (p/'source-files.sha256').read_text().splitlines()];assert len(support)==len(set(support))==2449
for f in ['source-before.log','source-after.log']:
 lines=(out/f).read_text().splitlines();assert len(lines)==2449 and lines==[name+': OK' for name in support]
native=json.loads((p/'native-source.json').read_text());assert len(native)==414 and sha(json.dumps(native,sort_keys=True,separators=(',',':')).encode())==t['native_source_identity_sha256']
commit=t['source_commit'];tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],text=True).splitlines();n=[f for f in tracked if f.endswith('.rs') or pathlib.PurePosixPath(f).name in ['Cargo.toml','Cargo.lock']];assert set(n)==set(native)
proc=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name in sorted(native):
 proc.stdin.write((commit+':'+name+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().split();assert header[1]=='blob';size=int(header[2]);body=proc.stdout.read(size);assert proc.stdout.read(1)==b'\n' and sha(body)==native[name]
proc.stdin.close();assert proc.wait()==0
envelope=json.loads((p/'prospective-envelope.json').read_text()); stages=envelope['stages']
contract=json.loads(pathlib.Path('/tmp/borsuk-bounded-compressed-source-cache-contract.json').read_text());new=contract['test_names'];assert len(new)==3
receipts=[]
expected_counts={'source-walks-debug':17,'cache-release-oracle':1,'source-fetch-tests':12,'baseline-tests':9,'reducer-tests':8}
for stage in stages:
 name=stage['name'];command=stage['command']
 assert (out/(name+'.command')).read_text().strip()==command
 assert (out/(name+'.native-exit')).read_text().strip()=='0' and (out/(name+'.tee-exit')).read_text().strip()=='0'
 log=(out/(name+'.log')).read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
 if name in expected_counts:assert counts==[(str(expected_counts[name]),'0','0')],(name,counts)
 if name=='source-walks-debug':
  for test in new:assert len(re.findall(r'^test '+re.escape(test)+r' \.\.\. ok$',log,re.M))==1
 if name=='cache-release-oracle':assert len(re.findall(r'^test '+re.escape(new[0])+r' \.\.\. ok$',log,re.M))==1
 receipts.append({'name':name,'command':command,'exit':0,'tee_exit':0,'test_counts':counts,'started':(out/(name+'.started')).read_text().strip(),'finished':(out/(name+'.finished')).read_text().strip()})
assert len(receipts)==8 and (out/'final-exit').read_text().strip()==(out/'gates-exit').read_text().strip()=='0'
for f,value in [('cpu.max.before','200000 100000'),('memory.max.before','8589934592'),('memory.swap.max.before','0'),('pids.max.before','512')]:assert (out/f).read_text().strip()==value
for f in ['memory.swap.current.after','memory.swap.peak.after']:assert (out/f).read_text().strip()=='0'
events=dict(line.split() for line in (out/'memory.events.after').read_text().splitlines());assert events['oom']==events['oom_kill']=='0'
unit=dict(line.split('=',1) for line in (out/'systemd-after.txt').read_text().splitlines());assert unit['MainPID']=='0' and unit['ActiveState']=='inactive' and unit['ExecMainStatus']=='0' and unit['Result']=='success'
x={'status':'NATIVE_QUALIFIED','source_commit':commit,'source_file_count':414,'native_source_identity_sha256':t['native_source_identity_sha256'],'full_source_before_after_root_match':True,'build_support_count':2449,'instance_id':t['instance_id'],'terminated':True,'stage_count':8,'stages':receipts,'artifacts':len(seen),'compiler_memory_peak_bytes':int((out/'memory.peak.after').read_text()),'swap_peak_bytes':0,'oom_kill':0,'main_pid_after':0,'scope':'Compiler and synthetic source-cache correctness only. No cache performance, serving RAM, cold vendor or production-readiness claim.'}
(p/'root-verification.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
