**Required test fixes before acceptance; release remains on HOLD.** I found no demonstrated production correctness defect in `93d806c7e1d44b1a9c3b2232925fbac905e55289`. Candidate parent, file hash, and single-file scope match the contract.

1. **[P2 — test gap] The concurrency regression does not exercise a retained cache hit during eviction.**  
   [two_bit_generation.rs:5447](/home/rb/worktrees/borsuk-bounded-compressed-source-cache/crates/borsuk/src/two_bit_generation.rs:5447) resets the cache before joining two identical queries. Both can miss; the assertions require neither a hit nor eviction while a copied hit remains live. Consequently, the comment’s ownership claim is not established.  
   **Smallest repair:** prefill a one-slot cache, retain a full-block hit, fetch a colliding block, then compare the retained hit against the original payload. For the concurrent claim, use a controlled interleaving and assert that the hit occurred before eviction.

2. **[P2 — test gap] Full-block cache hits lack a direct byte oracle.**  
   The full-hit phase at [line 5358](/home/rb/worktrees/borsuk-bounded-compressed-source-cache/crates/borsuk/src/two_bit_generation.rs:5358) compares plans, traces, and rankings. Those are useful, but the fixture repeats source vectors every 77 rows and gives every SQ8 row identical scoring values ([line 4903](/home/rb/worktrees/borsuk-bounded-compressed-source-cache/crates/borsuk/src/two_bit_generation.rs:4903)). Equal page maxima can conceal changed source bytes. The mixed-range byte assertions check a fetched full block and a cached one-record tail.  
   **Smallest repair:** after warming, fetch the full original range again and assert its exact start and bytes against `payload`, alongside zero source reads. Keep the existing cache-independent local reference.

The production path otherwise holds up under static inspection:

- Generation ownership binds entries to the immutable root, source location, ETag, and authenticated authority. Reopens start empty.
- Full-cover admission precedes cache lookup. Only wholly cached original ranges bypass fetching; misses retain their original geometry.
- Locks cover tag checks and owned copies, with no lock across an await. For hit bytes `H` and miss bytes `M`, `H + 2M` fits the existing `2(H + M)` payload allowance. Extra cache/vector charges are admitted before allocation.
- The shared fetcher preserves miss ordering, collects all admitted outcomes, and returns failure charges. Failed batches insert nothing.
- Hits return zero source-read charges. `verified_bytes` remains authenticated payload, **not total network bytes**; failed transferred bytes and transport attempts require the separate transport counters.

**Release blocker:** all native gates remain UNRUN. Complete the contract’s affected tests, release build, workspace Clippy, and complete test-build gate on the exact final source revision. The modeled allocation allowances still need runtime qualification. Preserve all five sibling `769 → 1025` repairs from `230e863…` during root integration; no child rebase is needed.

Mutex sharding, single-flight fetching, and alternate eviction policies are optional optimizations requiring measurements.

At eventual 10M/D1024, 32 MiB covers **less than 1.27%** of approximately 2.64 GB of source payload after overhead. Direct-map collisions and whole-range hit requirements further constrain usefulness. Locality, latency improvement, QPS, RSS, and vendor parity remain unmeasured; the 100k baseline establishes none of those scale claims.

Review only: no edits, builds, dataset access, network activity, or additional consultations.
