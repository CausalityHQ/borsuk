set -uo pipefail
source "$FH_SRC"
PATH=$FH_BIN:/usr/bin:/bin
OUT=$FH_WOUT BATCH=BATCHFIX MOCK_ACTIVE=true
mkfifo "$OUT/fifo/nap"; exec {NAPFD}<> "$OUT/fifo/nap"
kill_owned_units() { # SPY replacing the exact function (a dependency of start_watchdog): counts calls, may block the FIRST one
  local n=0; [[ -r $OUT/fifo/ko.count ]] && n=$(< "$OUT/fifo/ko.count"); n=$((n + 1)); echo "$n" > "$OUT/fifo/ko.count"
  echo "call $n" >> "$OUT/fifo/ko.log"
  if (( n == 1 )) && [[ ${FH_BLOCK_FIRST:-0} == 1 ]]; then read -r -t "${FH_BLOCK_S:-10}" -u "$NAPFD" || :; fi
  return 0
}
start_watchdog
case $FH_MODE in
  driver-wins) read -r -t 0.3 -u "$NAPFD" || :; mkdir "$OUT/fifo/arbiter"; read -r -t 2.5 -u "$NAPFD" || :; : > "$OUT/fifo/terminal-done" ;;
  watchdog-wins) read -r -t 3 -u "$NAPFD" || :; : > "$OUT/fifo/terminal-done" ;;
  hard-stop) read -r -t 40 -u "$NAPFD" || : ;;
esac
wait
