#!/usr/bin/env bash
set -euo pipefail
# Runs only inside the freshly admitted payload cgroup; the driver validates placement and limits
# BEFORE it writes `release`. The exec is the first native-helper instruction.
[[ $# == 7 ]] || exit 125
fifo=$1 ready=$2 helper=$3 config=$4 config_sha=$5 report=$6 mode=$7
[[ "$fifo" == /* && -p "$fifo" && "$ready" == /* && "$helper" == /* && "$config" == /* && "$report" == /* ]] || exit 125
[[ "$config_sha" =~ ^[0-9a-f]{64}$ ]] || exit 125
case "$mode" in
  ordinary) ;;
  context) export BORSUK_NATIVE_CPU_DISPOSABLE_CGROUP=1 ;;
  publication-failure) trap '' XFSZ ;;
  *) exit 125 ;;
esac
: > "$ready"
IFS= read -r release < "$fifo"
[[ "$release" == release ]] || exit 125
exec "$helper" "$config" "$config_sha" "$report"
