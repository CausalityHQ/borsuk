readonly SCTL_S=10 STOP_S=20 LAUNCH_S=30
readonly MEMORY_MAX=268435456 PIDS_MAX=128 PAYLOAD=payload
readonly DELEGATE_CONTROLLERS='cpu cpuset memory pids'
declare -A P=()
tmo() { local t=$1 b=$TIMEOUT_BIN; shift; [[ $MOCK_ACTIVE == true ]] && b=timeout; "$b" -k 2 "$t" "$@"; }
span_us() { # systemd human timespan (us ms s min h) -> microseconds; anything else is refused
  local -a toks; local tok total=0
  [[ -n $1 && $1 != infinity ]] || return 1
  read -ra toks <<<"$1"
  for tok in "${toks[@]}"; do
    [[ $tok =~ ^([0-9]+)(us|ms|s|min|h)$ ]] || return 1
    case ${BASH_REMATCH[2]} in
      us) total=$((total + BASH_REMATCH[1])) ;;
      ms) total=$((total + BASH_REMATCH[1] * 1000)) ;;
      s) total=$((total + BASH_REMATCH[1] * 1000000)) ;;
      min) total=$((total + BASH_REMATCH[1] * 60000000)) ;;
      h) total=$((total + BASH_REMATCH[1] * 3600000000)) ;;
    esac
  done
  printf '%s' "$total"
}
nap() { read -r -t "$1" -u "$NAPFD" || :; }
ev() { local k v; [[ -r $1 ]] || return 1; while read -r k v; do [[ $k == "$2" ]] && { printf '%s' "$v"; return 0; }; done < "$1"; return 1; }
rd() { local v; if IFS= read -r v 2>/dev/null < "$1"; then printf '%s' "$v"; else printf '<unreadable>'; fi; }
dl() { [[ -e $OUT/fifo/deadline-fired ]]; }
wait_for() { # seconds predicate...: 0 ok, 1 timeout, 2 batch deadline (checked BEFORE the predicate: nothing succeeds after expiry)
  local limit=$(( ${EPOCHREALTIME/./} + $1 * 1000000 )); shift
  while :; do
    dl && return 2
    "$@" && return 0
    (( ${EPOCHREALTIME/./} < limit )) || return 1
    nap "${POLL:-0.005}" # POLL=0.05 for predicates that fork systemctl
  done
}
show_to() { # unit file: full `systemctl show` into file and P[]
  local k v
  P=()
  tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager -- "$1.service" > "$2" 2>/dev/null || return 1
  while IFS='=' read -r k v; do P[$k]=$v; done < "$2"
}
sub_stop_post() { [[ $(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=SubState --value -- "$unit.service" 2>/dev/null) == stop-post ]]; }
unit_ended() { [[ $(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ActiveState --value -- "$unit.service" 2>/dev/null) =~ ^(inactive|failed)$ ]]; }
payload_drained() { [[ ! -e $pc/cgroup.events ]] || [[ $(ev "$pc/cgroup.events" populated) == 0 ]]; }
unit_cg() { # unit -> ACTUAL ControlGroup: recorded at pre-release, else asked of systemd (bounded); name-derived path only as last resort
  local u=$1 n=${1#"borsuk-ncpu-$BATCH-"} c=''
  [[ -r $OUT/fifo/$n.cg ]] && c=$(<"$OUT/fifo/$n.cg")
  [[ -n $c ]] || c=$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ControlGroup --value -- "$u.service" 2>/dev/null)
  [[ $c == /*"/$u.service" && $c != *..* ]] || c=/system.slice/$u.service
  printf '%s' "$c"
}
kill_owned_units() { # [unit...]: default every unit this run named
  local -a us=("$@")
  (( ${#us[@]} )) || mapfile -t us < "$UNITS"
  local u cg i rf rfd pop rc=0
  for u in "${us[@]}"; do
    [[ $u == "borsuk-ncpu-$BATCH-"* ]] || continue
    cg=$CGROOT$(unit_cg "$u")
    rf=$OUT/fifo/${u#"borsuk-ncpu-$BATCH-"}.release
    if [[ -p $rf ]] && { exec {rfd}<>"$rf"; } 2>/dev/null; then printf 'release\n' >&"$rfd"; exec {rfd}>&-; fi
    [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
    tmo "$SCTL_S" "$SYSTEMCTL" kill --kill-whom=all --signal=SIGKILL -- "$u.service" >/dev/null 2>&1
    [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
    tmo "$STOP_S" "$SYSTEMCTL" stop -- "$u.service" >/dev/null 2>&1
    for ((i = 0; i < 100; i++)); do
      [[ -e $cg/cgroup.events && $(ev "$cg/cgroup.events" populated) != 0 ]] || break
      (( i % 10 == 9 )) && tmo "$SCTL_S" "$SYSTEMCTL" kill --kill-whom=all --signal=SIGKILL -- "$u.service" >/dev/null 2>&1
      [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
      nap 0.1
    done
    tmo "$SCTL_S" "$SYSTEMCTL" reset-failed -- "$u.service" >/dev/null 2>&1
    pop=gone
    [[ -e $cg/cgroup.events ]] && { pop=$(ev "$cg/cgroup.events" populated) || pop=unreadable; }
    if [[ $pop == gone || $pop == 0 ]]; then printf '%s drained=%s\n' "$u" "$pop" >> "$OUT/fifo/cleanup.log"
    else printf '%s CLEANUP_FAILED populated=%s\n' "$u" "$pop" >> "$OUT/fifo/cleanup.log"; rc=1; fi
  done
  return "$rc"
}
stat_fields() { # pid -> SF_STATE SF_PPID SF_START (starttime ticks); fails when unreadable
  local line rest f
  IFS= read -r line 2>/dev/null < "$PROC/$1/stat" || return 1
  rest=${line##*) }
  read -ra f <<<"$rest"
  SF_STATE=${f[0]:-} SF_PPID=${f[1]:-} SF_START=${f[19]:-}
  [[ -n $SF_START ]]
}
pid_live() { stat_fields "$1" && [[ $SF_STATE != [ZX] && $SF_START == "$2" ]]; }
epc_write() { printf '%s\n' "+${DELEGATE_CONTROLLERS// / +}" > "$1/cgroup.subtree_control"; }
epc_has() { local want=$1; shift; [[ " $* " == *" $want "* ]]; }
epc_cpus_allowed() { # pid -> the main's own affinity (Cpus_allowed_list of /proc/<pid>/status), independent of the cgroup files
  local k v
  # bare return: the status of the print, so a failed print is a failed read
  while IFS=$' \t' read -r k v; do [[ $k == Cpus_allowed_list: ]] && { printf '%s' "$v"; return; }; done 2>/dev/null < "$PROC/$1/status"
  return 1
}
epc_snapshot() { # uc pc evdir tag : mandatory evidence copies of available/subtree controls and effective cpusets
  local uc=$1 pc=$2 ev=$3 tag=$4 f
  for f in cgroup.controllers cgroup.subtree_control cgroup.procs; do cat "$uc/$f" > "$ev/unit.$f.$tag" || return 1; done
  for f in cgroup.controllers cgroup.subtree_control cgroup.procs; do cat "$pc/$f" > "$ev/payload.$f.$tag" || return 1; done
  for f in unit:$uc payload:$pc; do
    if [[ -e ${f#*:}/cpuset.cpus.effective ]]; then cat "${f#*:}/cpuset.cpus.effective" > "$ev/${f%%:*}.cpuset.cpus.effective.$tag" || return 1
    else printf 'ABSENT\n' > "$ev/${f%%:*}.cpuset.cpus.effective.$tag" || return 1; fi
  done
}
enable_payload_controllers() { # unit cg main main_start evdir : reasons are appended to FAIL; returns 1 on any failure
  local unit=$1 cg=$2 main=$3 mstart=$4 ev=$5 uc pc c x wrc we=''
  local -a want have on pav miss=() snapf=()
  uc=$CGROOT$cg pc=$CGROOT$cg/$PAYLOAD
  read -ra want <<<"$DELEGATE_CONTROLLERS"
  [[ $cg == "/system.slice/$unit.service" && -d $uc && -d $pc && -d $ev ]] || { FAIL+=("epc: not the owned unit cgroup [$cg]"); return 1; }
  pid_live "$main" "$mstart" || { FAIL+=("epc: gated main $main (starttime $mstart) is not live"); return 1; }
  [[ $(rd "$PROC/$main/cgroup") == "0::$cg/$PAYLOAD" ]] || { FAIL+=("epc: gated main is not in payload"); return 1; }
  [[ -r $uc/cgroup.procs ]] || { FAIL+=("epc: unit cgroup.procs unreadable"); return 1; }
  if IFS= read -r x < "$uc/cgroup.procs"; then FAIL+=("epc: unit cgroup is not empty [$x]"); return 1; fi
  printf 'pid=%s starttime=%s location=%s unit_cgroup=%s\n' "$main" "$mstart" "$(rd "$PROC/$main/cgroup")" "$cg" > "$ev/gated-main.txt" \
    || { FAIL+=("epc: cannot record the gated main"); return 1; }
  epc_snapshot "$uc" "$pc" "$ev" before || { FAIL+=("epc: cannot record the before-state"); return 1; }
  x=$(epc_cpus_allowed "$main") && [[ -n $x ]] || { FAIL+=("epc: cannot read the gated main affinity before the write"); return 1; }
  printf '%s\n' "$x" > "$ev/gated-main.cpus_allowed_list.before" || { FAIL+=("epc: cannot record the before-affinity"); return 1; }
  read -ra have < "$uc/cgroup.controllers" || { FAIL+=("epc: unit cgroup.controllers unreadable"); return 1; }
  for c in "${want[@]}"; do epc_has "$c" "${have[@]}" || miss+=("$c"); done
  (( ${#miss[@]} == 0 )) || { FAIL+=("epc: controllers not available in the unit cgroup [${miss[*]}] (have: ${have[*]})"); return 1; }
  # after EVERY attempted write (failed or not) BOTH after-snapshots are attempted before any validation can return; the original
  # write failure and every snapshot failure are all retained in FAIL
  # the write's own diagnostic (stderr) is evidence: the file is established BEFORE the write (no write if it cannot be) and read back after
  : > "$ev/subtree_control.write.stderr" || { FAIL+=("epc: cannot establish the write-stderr evidence file"); return 1; }
  wrc=0; epc_write "$uc" 2>> "$ev/subtree_control.write.stderr" || wrc=$?
  we=$(tr '\n' ' ' < "$ev/subtree_control.write.stderr") || snapf+=("epc: cannot read the write-stderr evidence")
  epc_snapshot "$uc" "$pc" "$ev" after || snapf+=("epc: cannot record the after-state")
  if x=$(epc_cpus_allowed "$main") && [[ -n $x ]]; then
    printf '%s\n' "$x" > "$ev/gated-main.cpus_allowed_list.after" || snapf+=("epc: cannot record the after-affinity")
  else
    x='<unreadable>'; snapf+=("epc: cannot read the gated main affinity after the write")
    printf '%s\n' "$x" > "$ev/gated-main.cpus_allowed_list.after" || snapf+=("epc: cannot record the unreadable after-affinity")
  fi
  (( wrc == 0 )) || { FAIL+=("epc: checked subtree_control write failed (rc $wrc) [stderr: ${we:0:300}]" "${snapf[@]}"); return 1; }
  (( ${#snapf[@]} == 0 )) || { FAIL+=("${snapf[@]}"); return 1; }
  read -ra on < "$uc/cgroup.subtree_control" || { FAIL+=("epc: subtree_control unreadable after the write"); return 1; }
  read -ra pav < "$pc/cgroup.controllers" || { FAIL+=("epc: payload cgroup.controllers unreadable after the write"); return 1; }
  miss=(); for c in "${want[@]}"; do epc_has "$c" "${on[@]}" || miss+=("$c"); done
  (( ${#miss[@]} == 0 )) || { FAIL+=("epc: not enabled in the unit subtree_control [${miss[*]}] (on: ${on[*]})"); return 1; }
  miss=(); for c in "${want[@]}"; do epc_has "$c" "${pav[@]}" || miss+=("$c"); done
  (( ${#miss[@]} == 0 )) || { FAIL+=("epc: not listed in the payload cgroup.controllers [${miss[*]}]"); return 1; }
  [[ $(rd "$uc/cpuset.cpus.effective") == 0 && $(rd "$pc/cpuset.cpus.effective") == 0 ]] \
    || { FAIL+=("epc: effective cpuset is not exactly 0 (unit [$(rd "$uc/cpuset.cpus.effective")] payload [$(rd "$pc/cpuset.cpus.effective")])"); return 1; }
  # independent of the cgroup files: the still-gated main's own affinity read above (CPU list only; Mems_allowed_list is deliberately
  # NOT frozen, CPU0 may belong to another NUMA node on a supported host)
  [[ $x == 0 ]] || { FAIL+=("epc: gated main Cpus_allowed_list is [$x], not exactly 0"); return 1; }
}
