#!/usr/bin/env bash
set -euo pipefail
root=/mnt/borsuk-ncpu
cd "$root"
mkdir -m 0700 -p evidence
phase=faults
printf '%s\n' "$phase" > evidence/phase
run_stage() {
  local name=$1 seconds=$2 rc show_rc; shift 2
  set +e
  systemd-run --quiet --unit="borsuk-ncpu-stage-$name" --service-type=exec --wait --pipe \
    -p CPUQuota=100% -p AllowedCPUs=0 -p MemoryMax=268435456 -p MemorySwapMax=0 \
    -p TasksMax=128 -p LimitCORE=0 -p KillMode=control-group -p TimeoutStopSec=5 \
    -p "RuntimeMaxSec=$seconds" -p "WorkingDirectory=$root" \
    -p "ExecStartPre=/bin/bash $root/assets/stage-admit.sh $name" \
    /bin/bash "$@" > "evidence/$name.stdout" 2> "evidence/$name.stderr"
  rc=$?
  set -e
  printf '%s\n' "$rc" > "evidence/$name.original-exit"
  set +e
  systemctl show "borsuk-ncpu-stage-$name.service" > "evidence/$name.systemd-after"
  show_rc=$?
  set -e
  printf '%s\n' "$show_rc" > "evidence/$name.systemd-show-exit"
  [[ $rc == 0 ]] || return "$rc"
  if grep -qx 'LoadState=loaded' "evidence/$name.systemd-after"; then
    [[ $show_rc == 0 ]] || return 125
    grep -qx 'ExecMainCode=1' "evidence/$name.systemd-after" || return 125
    grep -qx 'ExecMainStatus=0' "evidence/$name.systemd-after" || return 125
  else
    grep -qx 'LoadState=not-found' "evidence/$name.systemd-after" || return 125
    printf '%s\n' 'Unit garbage-collected after original systemd-run --wait exit0; retain original exit and pre-exec resource proof.' > "evidence/$name.garbage-collected"
  fi
}
run_stage faults 120 assets/fault-harness.sh "$root/assets/driver.sh"
tail -n 1 evidence/faults.stdout > evidence/fault-summary.json
jq -e '.passed == 84 and .failed == 0 and .skipped_budget == 0 and .helper_or_fixture_invocations == 0 and .tripwire == "clear" and .driver_sha256 == "1f17e7432af5c6c92148a85b9ecf89baf2de1060fb31e69b4b1d1a78d5211602"' evidence/fault-summary.json
work=$(jq -er .workdir evidence/fault-summary.json)
[[ $work == /tmp/ncpu-fault.* && -d $work && ! -L $work ]]
cp -a -- "$work" evidence/source-fault-artifacts
phase=canary
printf '%s\n' "$phase" > evidence/phase
run_stage canary 120 assets/target-canary.sh "$root/assets/driver.sh" "$root/canary"
jq -e '.state == "PASS" and .cleanup_incomplete == false and .publication_errors == "" and .checks_recorded == 44 and (.checks|length) == 44 and all(.checks[]; .ok == true) and .driver_sha256 == "1f17e7432af5c6c92148a85b9ecf89baf2de1060fb31e69b4b1d1a78d5211602"' canary/canary-result.json
(cd canary && sha256sum --check --quiet SHA256SUMS)
phase=fixtures
printf '%s\n' "$phase" > evidence/phase
run_stage fixtures 300 assets/driver.sh "$root/assets/native_process_cpu" \
  1ce0405566852577e15dae1b7beeb626626af561d716af45baa75add4f6c4b74 "$root/fixtures"
jq -e '.final_state == "MECHANICS_VERIFIED" and .driver_exit_code == 0 and .mock_seams_active == false' fixtures/TERMINAL.json
[[ $(sha256sum fixtures/result.json | cut -d' ' -f1) == "$(jq -er .result_sha256 fixtures/TERMINAL.json)" ]]
[[ $(sha256sum fixtures/SHA256SUMS | cut -d' ' -f1) == "$(jq -er .manifest_sha256 fixtures/TERMINAL.json)" ]]
jq -e '.state == "MECHANICS_VERIFIED" and .mock_seams_active == false and .plan.deadline_fired == false and .plan.invocations == 12 and .fixture_processes_released == 15 and (.cases|length) == 12 and all(.cases[]; .state == "MECHANICS_VERIFIED") and .claims.performance == false and .claims.numerical_CPU_accuracy == false and .claims.overhead_GO == false' fixtures/result.json
(cd fixtures && sha256sum --check --quiet SHA256SUMS)
phase=closed
printf '%s\n' "$phase" > evidence/phase
