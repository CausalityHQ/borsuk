#!/usr/bin/env bash
set -euo pipefail
name=${1:?}
case $name in faults|canary|fixtures) ;; *) exit 125 ;; esac
cg=$(sed -n 's/^0:://p' /proc/self/cgroup)
cg=${cg%/.control}
[[ ${cg##*/} == "borsuk-ncpu-stage-$name.service" ]]
dir=/mnt/borsuk-ncpu/evidence/$name.pre-exec
mkdir -m 0700 "$dir"
for field in cpu.max cpuset.cpus.effective memory.max memory.swap.max pids.max cpu.stat memory.events; do
  cat "/sys/fs/cgroup$cg/$field" > "$dir/$field"
done
[[ $(cat "$dir/cpu.max") == '100000 100000' ]]
[[ $(cat "$dir/cpuset.cpus.effective") == 0 ]]
[[ $(cat "$dir/memory.max") == 268435456 ]]
[[ $(cat "$dir/memory.swap.max") == 0 ]]
[[ $(cat "$dir/pids.max") == 128 ]]
cat /proc/self/cgroup /proc/self/limits > "$dir/process.txt"
sync -f "$dir"
