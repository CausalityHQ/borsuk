#!/bin/bash
# DUMMY standing in for the native helper: $1=sha $2=report. Never the real helper.
cat /proc/self/cgroup > "$2"
exit 7
