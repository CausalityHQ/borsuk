#!/usr/bin/env bash
set -euo pipefail
# ExecStopPost: runs in <unit>/.control, outside payload. Never kills or retries anything.
# The receipt file proves the hold itself read `release` and terminated normally.
[[ $# == 2 && "$1" == /* && -p "$1" && "$2" == /* ]] || exit 125
IFS= read -r release < "$1"
[[ "$release" == release ]] || exit 125
: > "$2"
