# --- exact declarations from the driver
set -uo pipefail
readonly RESULT_SCHEMA=borsuk-native-cpu-fixture-batch-result-v1
readonly CASE_SCHEMA=borsuk-native-cpu-fixture-case-v1
readonly ADMISSION_SCHEMA=borsuk-native-cpu-fixture-admission-v1
readonly DEADLINE_S_PROD=60 CLEANUP_ALLOWANCE_S=1 PUBLICATION_ALLOWANCE_S=1 OUTER_RUNTIME_MAX_DECLARED_S=300
readonly SCTL_S=10 STOP_S=20 LAUNCH_S=30
readonly FIXTURE_CAP=16 RESERVED_COMPILER_TEST=1
readonly MEMORY_MAX=268435456 PIDS_MAX=128 PAYLOAD=payload
readonly COLLECTOR_SCHEMA=native-process-cpu-collector-v1
readonly TIMEOUT_PROD=/usr/bin/timeout
readonly TERMINAL_SCHEMA=borsuk-native-cpu-fixture-terminal-v1
readonly -a CASES=(
  'pulse ordinary 0 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'threads ordinary 0 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'waited ordinary 0 - 2 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'io ordinary 0 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'late ordinary 0 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'delay ordinary 0 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'nonzero ordinary 7 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'survivor context 0 - 2 REFUSE'
  'unwaited context 0 - 2 REFUSE'
  'sigpipe ordinary - 13 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE'
  'publication-failure publication-failure 0 - 1 REFUSE'
  'timeout-KILL ordinary - 9 1 REFUSE'
)
DEADLINE_S=${FH_DEADLINE_S:-60} # FIXTURE (the driver sets this in its mock/prod block)
HARD_STOP_S=$((DEADLINE_S + CLEANUP_ALLOWANCE_S + PUBLICATION_ALLOWANCE_S))
declare -A P=()
FINALIZED=0
declare -a INV=() INC=() FAIL=() CASE_FILES=() CASE_STATES=() PUB_ERR=()
CLOSURE=0
EVID_DURABLE=false
CONTROL_RESULTS=()
# --- exact functions from the driver
sha() { local o; o=$(sha256sum -- "$1") || return 1; printf '%s' "${o%% *}"; }
rd() { local v; if IFS= read -r v 2>/dev/null < "$1"; then printf '%s' "$v"; else printf '<unreadable>'; fi; }
ev() { local k v; [[ -r $1 ]] || return 1; while read -r k v; do [[ $k == "$2" ]] && { printf '%s' "$v"; return 0; }; done < "$1"; return 1; }
inv() { INV+=("$1"); }
inc() { INC+=("$1"); }
eq() { [[ "$2" == "$3" ]] || FAIL+=("$1: got [$2] want [$3]"); }
jarr() { if (( $# )); then printf '%s\0' "$@" | jq -Rsc 'split("\u0000")[:-1]'; else printf '[]'; fi; }
nap() { read -r -t "$1" -u "$NAPFD" || :; }
dl() { [[ -e $OUT/fifo/deadline-fired ]]; }
tmo() { local t=$1 b=$TIMEOUT_BIN; shift; [[ $MOCK_ACTIVE == true ]] && b=timeout; "$b" -k 2 "$t" "$@"; }
span_us() { # systemd human timespan (us ms s min h) -> microseconds; anything else is refused
  local -a toks; local tok total=0
  [[ -n $1 && $1 != infinity ]] || return 1
  read -ra toks <<<"$1"
  for tok in "${toks[@]}"; do
    [[ $tok =~ ^([0-9]+)(us|ms|s|min|h)$ ]] || return 1
    case ${BASH_REMATCH[2]} in
      us) total=$((total + BASH_REMATCH[1])) ;;
      ms) total=$((total + BASH_REMATCH[1] * 1000)) ;;
      s) total=$((total + BASH_REMATCH[1] * 1000000)) ;;
      min) total=$((total + BASH_REMATCH[1] * 60000000)) ;;
      h) total=$((total + BASH_REMATCH[1] * 3600000000)) ;;
    esac
  done
  printf '%s' "$total"
}
unit_cg() { # unit -> ACTUAL ControlGroup: recorded at pre-release, else asked of systemd (bounded); name-derived path only as last resort
  local u=$1 n=${1#"borsuk-ncpu-$BATCH-"} c=''
  [[ -r $OUT/fifo/$n.cg ]] && c=$(<"$OUT/fifo/$n.cg")
  [[ -n $c ]] || c=$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ControlGroup --value -- "$u.service" 2>/dev/null)
  [[ $c == /*"/$u.service" && $c != *..* ]] || c=/system.slice/$u.service
  printf '%s' "$c"
}
kill_owned_units() { # [unit...]: default every unit this run named
  local -a us=("$@")
  (( ${#us[@]} )) || mapfile -t us < "$UNITS"
  local u cg i rf rfd pop rc=0
  for u in "${us[@]}"; do
    [[ $u == "borsuk-ncpu-$BATCH-"* ]] || continue
    cg=$CGROOT$(unit_cg "$u")
    rf=$OUT/fifo/${u#"borsuk-ncpu-$BATCH-"}.release
    if [[ -p $rf ]] && { exec {rfd}<>"$rf"; } 2>/dev/null; then printf 'release\n' >&"$rfd"; exec {rfd}>&-; fi
    [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
    tmo "$SCTL_S" "$SYSTEMCTL" kill --kill-whom=all --signal=SIGKILL -- "$u.service" >/dev/null 2>&1
    [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
    tmo "$STOP_S" "$SYSTEMCTL" stop -- "$u.service" >/dev/null 2>&1
    for ((i = 0; i < 100; i++)); do
      [[ -e $cg/cgroup.events && $(ev "$cg/cgroup.events" populated) != 0 ]] || break
      (( i % 10 == 9 )) && tmo "$SCTL_S" "$SYSTEMCTL" kill --kill-whom=all --signal=SIGKILL -- "$u.service" >/dev/null 2>&1
      [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
      nap 0.1
    done
    tmo "$SCTL_S" "$SYSTEMCTL" reset-failed -- "$u.service" >/dev/null 2>&1
    pop=gone
    [[ -e $cg/cgroup.events ]] && { pop=$(ev "$cg/cgroup.events" populated) || pop=unreadable; }
    if [[ $pop == gone || $pop == 0 ]]; then printf '%s drained=%s\n' "$u" "$pop" >> "$OUT/fifo/cleanup.log"
    else printf '%s CLEANUP_FAILED populated=%s\n' "$u" "$pop" >> "$OUT/fifo/cleanup.log"; rc=1; fi
  done
  return "$rc"
}
wait_cleanup_outcome() { # deadline intervention: wait (cleanup allowance) for the watchdog's CHECKED cleanup outcome
  local i
  for ((i = 0; i < CLEANUP_ALLOWANCE_S * 10; i++)); do
    [[ -e $OUT/fifo/deadline-cleanup-done ]] && return 0
    [[ -e $OUT/fifo/deadline-cleanup-failed ]] && return 1
    nap 0.1
  done
  return 1
}
start_watchdog() {
  local start_us=${EPOCHREALTIME/./} dpid=$$ dstart='' line rest
  local -a f
  local dl_us=$((start_us + DEADLINE_S * 1000000)) hard_us=$((start_us + HARD_STOP_S * 1000000))
  IFS= read -r line 2>/dev/null < "/proc/$dpid/stat" && { rest=${line##*) }; read -ra f <<<"$rest"; dstart=${f[19]:-}; }
  (
    exec 0</dev/null >> "$OUT/watchdog.log" 2>&1
    while [[ ! -e $OUT/fifo/terminal-done && ! -e $OUT/fifo/hard-stop ]]; do
      if (( ${EPOCHREALTIME/./} >= dl_us )); then
        if mkdir "$OUT/fifo/arbiter" 2>/dev/null; then # the driver has not closed admission: the deadline wins
          : > "$OUT/fifo/deadline-fired"
          if kill_owned_units; then : > "$OUT/fifo/deadline-cleanup-done"; else : > "$OUT/fifo/deadline-cleanup-failed"; fi
        fi
        while [[ ! -e $OUT/fifo/terminal-done && ! -e $OUT/fifo/hard-stop ]]; do read -r -t 0.1 -u "$NAPFD" || :; done # handled once
        exit 0
      fi
      read -r -t 0.1 -u "$NAPFD" || :
    done
  ) &
  WD=$!
  (
    exec 0</dev/null >> "$OUT/hardstop.log" 2>&1
    while [[ ! -e $OUT/fifo/terminal-done ]]; do
      if (( ${EPOCHREALTIME/./} >= hard_us )); then
        : > "$OUT/fifo/hard-stop"
        if [[ -n $dstart ]] && IFS= read -r line 2>/dev/null < "/proc/$dpid/stat"; then
          rest=${line##*) }; read -ra f <<<"$rest"
          [[ ${f[19]:-} == "$dstart" ]] && kill -KILL "$dpid" 2>/dev/null # same process only (start time unchanged)
        fi
        kill_owned_units
        rm -f -- "$OUT/result.json" "$OUT/TERMINAL.json"
        printf '{"schema":"%s","state":"INVALID","mock_seams_active":%s,"hard_stop":true,"claims":{"numerical_CPU_accuracy":false,"overhead_GO":false,"performance":false},"note":"independent hard-stop process killed the driver; no acceptance"}\n' \
          "$RESULT_SCHEMA" "$MOCK_ACTIVE" > "$OUT/result.json"
        : > "$OUT/fifo/terminal-done"
        exit 0
      fi
      read -r -t 0.1 -u "$NAPFD" || :
    done
  ) &
  WD2=$!
}
wait_for() { # seconds predicate...: 0 ok, 1 timeout, 2 batch deadline (checked BEFORE the predicate: nothing succeeds after expiry)
  local limit=$(( ${EPOCHREALTIME/./} + $1 * 1000000 )); shift
  while :; do
    dl && return 2
    "$@" && return 0
    (( ${EPOCHREALTIME/./} < limit )) || return 1
    nap "${POLL:-0.005}" # POLL=0.05 for predicates that fork systemctl
  done
}
show_to() { # unit file: full `systemctl show` into file and P[]
  local k v
  P=()
  tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager -- "$1.service" > "$2" 2>/dev/null || return 1
  while IFS='=' read -r k v; do P[$k]=$v; done < "$2"
}
sub_stop_post() { [[ $(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=SubState --value -- "$unit.service" 2>/dev/null) == stop-post ]]; }
unit_ended() { [[ $(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ActiveState --value -- "$unit.service" 2>/dev/null) =~ ^(inactive|failed)$ ]]; }
payload_drained() { [[ ! -e $pc/cgroup.events ]] || [[ $(ev "$pc/cgroup.events" populated) == 0 ]]; }
cpu_usec() { ev "$1" usage_usec; }
diagnostic() {
  local i f cu why='' d=null ns=null ij=null fj=null cj=null child
  i=$(cpu_usec "$cdir/cg/payload.cpu.stat.initial") f=$(cpu_usec "$cdir/cg/payload.cpu.stat.final")
  cu=$(cpu_usec "$cdir/cg/unit.cpu.stat.final")
  if ! [[ $i =~ ^[0-9]{1,15}$ && $f =~ ^[0-9]{1,15}$ ]]; then why=cpu_stat_missing_or_malformed
  elif (( f < i )); then why=cpu_stat_decreased
  elif (( f - i > 3600000000 )); then why=cpu_stat_delta_over_one_hour
  else ij=$i fj=$f d=$((f - i)) ns=$(( (f - i) * 1000 )); fi
  [[ $cu =~ ^[0-9]{1,15}$ ]] && cj=$cu
  [[ -z $why ]] || inv "CPU_STAT_INVALID:$why"
  child=$(jq -r '.child_cpu.cpu_ns // empty' "$report" 2>/dev/null)
  [[ $child =~ ^[0-9]{1,18}$ ]] || child=null
  jq -n --argjson ij "$ij" --argjson fj "$fj" --argjson d "$d" --argjson ns "$ns" --argjson cj "$cj" --argjson child "$child" \
    --arg why "$why" --argjson mock "$MOCK_ACTIVE" \
    '{payload_usage_usec_initial:$ij, payload_usage_usec_final:$fj, payload_delta_usec:$d, payload_delta_ns:$ns,
      unit_usage_usec_final_includes_hold:$cj, report_child_cpu_ns:$child,
      payload_delta_minus_report_child_ns:(if $ns != null and $child != null then $ns - $child else null end),
      refused:(if $why == "" then null else $why end), mock_seams_active:$mock,
      scope:"observed separation only; includes gate, outer helper and omitted final costs; not an error bound, not completeness"}' \
    > "$cdir/diagnostic.json" 2>/dev/null || { printf 'null\n' > "$cdir/diagnostic.json"; inv DIAGNOSTIC_BUILD_FAILED; }
}
unwaited_witness() { # known >=20ms descendant CPU is in the payload cgroup delta but absent from the wait4 child CPU
  local inj
  inj=$(jq -r 'map(select(.fixture == "late" and has("injected_cpu_ns"))) | first | .injected_cpu_ns // empty' "$cdir/stdout.json" 2>/dev/null)
  [[ $inj =~ ^[0-9]{1,18}$ ]] || inj=0
  jq -e --argjson i "$inj" '.payload_delta_minus_report_child_ns != null and .payload_delta_minus_report_child_ns >= $i and $i >= 20000000' "$cdir/diagnostic.json" >/dev/null 2>&1 \
    || inv UNWAITED_WITNESS_NOT_DEMONSTRATED
}
frag_object() { jq -e 'type == "object"' "$cdir/$1.json" >/dev/null 2>&1; }
finish_case() {
  local state=MECHANICS_VERIFIED f cj=$cdir/case.json ninv ninc
  # mandatory evidence fragments: exactly one JSON value each (an empty file would slurp as [] and hide a missing
  # observation); required fragments must be objects. Done BEFORE the state is derived.
  for f in proc.main exec-main survivor diagnostic collector-receipt; do
    if [[ ! -e $cdir/$f.json ]]; then printf 'null\n' > "$cdir/$f.json" || inv "EVIDENCE_WRITE_FAILED:$f"
    elif ! jq -s -e 'length == 1' "$cdir/$f.json" >/dev/null 2>&1; then
      inv "EVIDENCE_SHAPE:$f"; printf 'null\n' > "$cdir/$f.json" || inv "EVIDENCE_WRITE_FAILED:$f"
    fi
  done
  (( PRE_VALIDATED )) && { frag_object proc.main || inv EVIDENCE_MISSING:proc.main; }
  (( CAPTURED )) && { frag_object exec-main || inv EVIDENCE_MISSING:exec-main; }
  (( CAPTURED )) && { frag_object collector-receipt || inv EVIDENCE_MISSING:collector-receipt; }
  (( CAPTURED )) && { frag_object diagnostic || inv EVIDENCE_MISSING:diagnostic; }
  (( OBSERVED )) && { frag_object survivor || inv EVIDENCE_MISSING:survivor; }
  (( ${#INC[@]} )) && state=INCONCLUSIVE
  (( ${#INV[@]} )) && state=INVALID
  if ! { jq -n --arg schema "$CASE_SCHEMA" --arg id "$id" --arg unit "$unit.service" --arg state "$state" \
    --argjson inv "$(jarr "${INV[@]}")" --argjson inc "$(jarr "${INC[@]}")" --argjson released "$RELEASED" --argjson rel "$REL_US" \
    --arg gmode "$gmode" --arg ee "$exp_exit" --arg es "$exp_sig" --argjson procs "$procs" --arg acct "$acct" \
    --arg cfgsha "${cfg_sha:-}" --arg exe "${exe:-}" --argjson args "$(jarr "${args[@]}")" \
    --argjson mock "$MOCK_ACTIVE" --argjson durable "$EVID_DURABLE" --arg dirname "${name:-$id}" \
    --slurpfile main "$cdir/proc.main.json" --slurpfile exec "$cdir/exec-main.json" --slurpfile sv "$cdir/survivor.json" \
    --slurpfile diag "$cdir/diagnostic.json" --slurpfile rcpt "$cdir/collector-receipt.json" \
    '{schema:$schema, id:$id, unit:$unit, state:$state, reasons:{invalid:$inv, inconclusive:$inc},
      mock_seams_active:$mock, released:$released, release_epoch_us:$rel, evidence_durable:$durable,
      expected:{gate_mode:$gmode, exit_code:$ee, signal:$es, fixture_processes:$procs, accounting_completeness:$acct, config_sha256:$cfgsha, executable:$exe, args:$args},
      observed:{main_process_prerelease:$main[0], exec_main:$exec[0], survivor:$sv[0], diagnostic:$diag[0], collector_receipt:$rcpt[0]},
      evidence_dir:("cases/" + $dirname), accounting_decision:"NOT_QUALIFIED",
      claims:{numerical_CPU_accuracy:false, overhead_GO:false, performance:false, descendant_complete:false}}' \
    > "$cj.tmp"; } 2>"$cj.err" || ! mv -f -T -- "$cj.tmp" "$cj"; then
    # fallback: the recorded state itself becomes INVALID BEFORE it is appended; write errors are retained
    ninv=${#INV[@]} ninc=${#INC[@]}
    state=INVALID; INV+=(CASE_JSON_BUILD_FAILED)
    if ! printf '{"schema":"%s","id":"%s","state":"INVALID","released":%s,"mock_seams_active":%s,"evidence_durable":%s,"reasons":{"invalid":["CASE_JSON_BUILD_FAILED"],"original_invalid_count":%s,"original_inconclusive_count":%s}}\n' \
        "$CASE_SCHEMA" "$id" "$RELEASED" "$MOCK_ACTIVE" "$EVID_DURABLE" "$ninv" "$ninc" > "$cj.fallback" \
      || ! mv -f -T -- "$cj.fallback" "$cj"; then
      PUB_ERR+=("CASE_JSON_FALLBACK_WRITE_FAILED:$id")
    fi
  fi
  CASE_FILES+=("$cj") CASE_STATES+=("$state")
  [[ -n ${GOFD:-} ]] && exec {GOFD}>&-
  [[ -n ${RELFD:-} ]] && exec {RELFD}>&-
  return 0
}
not_run_case() { # index id reason (the JSON id is the plain roster id, like every run case)
  local d cj
  printf -v d '%s/cases/%02d-%s' "$OUT" "$1" "$2"
  cj=$d/case.json
  if ! { mkdir -p -- "$d" && chmod 0700 "$d" && jq -n --arg schema "$CASE_SCHEMA" --arg id "$2" --arg r "$3" --argjson mock "$MOCK_ACTIVE" --arg dirname "${d##*/}" \
    '{schema:$schema, id:$id, state:"INCONCLUSIVE", released:false, mock_seams_active:$mock, reasons:{invalid:[], inconclusive:[$r]}, evidence_dir:("cases/" + $dirname), accounting_decision:"NOT_QUALIFIED",
      claims:{numerical_CPU_accuracy:false, overhead_GO:false, performance:false, descendant_complete:false}}' > "$cj.tmp" \
    && mv -f -T -- "$cj.tmp" "$cj"; } 2>/dev/null; then
    PUB_ERR+=("NOT_RUN_CASE_JSON_WRITE_FAILED:$2")
  fi
  CASE_FILES+=("$cj") CASE_STATES+=(INCONCLUSIVE)
}
persist_evidence() { # evidence is not durable until the hash list AND the files/dir are synced with checked errors
  EVID_DURABLE=false
  if ! ( cd "$cdir" && find . -type f ! -name 'evidence.sha256*' -print0 | sort -z | xargs -0 sha256sum ) > "$cdir/evidence.sha256.tmp" 2>/dev/null \
    || ! mv -f -T -- "$cdir/evidence.sha256.tmp" "$cdir/evidence.sha256"; then
    inv EVIDENCE_HASH_FAILED; CLOSURE=1; return 1
  fi
  if ! sync -f -- "$cdir/evidence.sha256" "$cdir" 2>/dev/null; then inv EVIDENCE_SYNC_FAILED; CLOSURE=1; return 1; fi
  EVID_DURABLE=true
}
capture_stop_post() {
  local f hp
  show_to "$unit" "$cdir/show.stop-post.txt" || inv SHOW_STOP_POST_UNREADABLE
  if ! [[ -d $pc && -r $pc/cgroup.events ]]; then
    inv PAYLOAD_SUBGROUP_VANISHED; CLOSURE=1
    kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"
    return
  fi
  CAPTURED=1
  for f in cpu.stat cgroup.events cgroup.procs memory.events pids.events memory.peak memory.swap.peak; do
    if [[ -e $pc/$f ]]; then cat -- "$pc/$f" > "$cdir/cg/payload.$f.final" 2>/dev/null || inv "READBACK_FAILED:payload/$f"
    elif [[ $f != memory.*peak ]]; then inv "READBACK_FAILED:payload/$f"; fi
    if [[ -e $uc/$f ]]; then cat -- "$uc/$f" > "$cdir/cg/unit.$f.final" 2>/dev/null || inv "READBACK_FAILED:unit/$f"; fi
  done
  if [[ $(ev "$pc/cgroup.events" populated) != 0 ]]; then
    inv PAYLOAD_NOT_DRAINED; CLOSURE=1
    kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"
  fi
  for f in oom oom_kill; do [[ $(ev "$pc/memory.events" "$f") == 0 && $(ev "$uc/memory.events" "$f") == 0 ]] || inv "MEMORY_EVENT:$f"; done
  [[ $(ev "$pc/pids.events" max) == 0 && $(ev "$uc/pids.events" max) == 0 ]] || inv 'PIDS_EVENT:max'
  hp=${P[ControlPID]:-0}
  if [[ $hp =~ ^[1-9][0-9]*$ ]]; then
    [[ $(rd "$PROC/$hp/cgroup") == "0::$cg/.control" ]] || inv "HOLD_NOT_IN_CONTROL_CGROUP:$(rd "$PROC/$hp/cgroup")"
  else inv 'HOLD_NOT_RUNNING'; fi
  jq -n --arg pid "${P[ExecMainPID]:-}" --arg code "${P[ExecMainCode]:-}" --arg status "${P[ExecMainStatus]:-}" --arg result "${P[Result]:-}" \
    --arg active "${P[ActiveState]:-}" --arg sub "${P[SubState]:-}" --arg ctl "$hp" --arg ts "${P[ExecMainExitTimestampMonotonic]:-}" \
    '{ExecMainPID:$pid, ExecMainCode:$code, ExecMainStatus:$status, Result:$result, ActiveState:$active, SubState:$sub, ControlPID:$ctl,
      ExecMainExitTimestampMonotonic:$ts, note:"systemd view of the unit main process (the outer helper); distinct from the native report"}' > "$cdir/exec-main.json" \
    || inv EVIDENCE_WRITE_FAILED:exec-main
  FAIL=() # reset BEFORE the PID check (it used to be wiped by the status branches)
  eq exec.main.pid "${P[ExecMainPID]:-}" "$main"
  if [[ $exp_sig != - ]]; then eq ExecMainCode "${P[ExecMainCode]:-}" 2; eq ExecMainStatus "${P[ExecMainStatus]:-}" "$exp_sig"
  else eq ExecMainCode "${P[ExecMainCode]:-}" 1; eq ExecMainStatus "${P[ExecMainStatus]:-}" "$exp_exit"; fi
  for m in "${FAIL[@]}"; do inv "EXEC_MAIN:$m"; done
  check_native_outputs
}
run_case() {
  local idx=$1 id=$2 gmode=$3 exp_exit=$4 exp_sig=$5 procs=$6 acct=$7
  local nn name unit cdir scratch cfg report so se go ready rel holdok exe exe_bytes exe_sha cfg_sha rc=0
  printf -v nn '%02d' "$idx"
  name=$nn-$id unit=borsuk-ncpu-$BATCH-$nn-$id
  cdir=$OUT/cases/$name scratch=$cdir/scratch cfg=$cdir/config.json
  report=$cdir/report.json so=$cdir/stdout se=$cdir/stderr
  go=$OUT/fifo/$name.go ready=$OUT/fifo/$name.ready rel=$OUT/fifo/$name.release holdok=$OUT/fifo/$name.hold-ok
  INV=() INC=() FAIL=()
  RELEASED=false REL_US=null CLOSURE=0 EVID_DURABLE=false PRE_VALIDATED=0 CAPTURED=0 OBSERVED=0
  local main='' main_start='' cg='' uc='' pc='' GOFD='' RELFD='' f m
  local -a args=() procs_in ifaces
  mkdir -m 0700 -- "$cdir" "$scratch" "$cdir/cg" || { inv CASE_DIR_CREATE_FAILED; finish_case; return 3; }
  { : > "$so" && : > "$se" && chmod 0600 "$so" "$se"; } || { inv CASE_OUTPUT_FILES_CREATE_FAILED; finish_case; return 3; }
  mkfifo -m 0600 -- "$go" "$rel" || { inv FIFO_CREATE_FAILED; finish_case; return 3; }
  if [[ $id == timeout-KILL ]]; then
    exe=$TIMEOUT_BIN exe_bytes=$TIMEOUT_BYTES exe_sha=$TIMEOUT_SHA
    args=(--signal=KILL 0.2 "$HELPER_BIN" --fixture delay)
  else
    exe=$HELPER_BIN exe_bytes=$HELPER_BYTES exe_sha=$HELPER_SHA
    [[ $id == publication-failure ]] && args=(--fixture pulse) || args=(--fixture "$id")
  fi
  printf '%s\0' "${args[@]}" | jq -Rsc --arg p "$exe" --argjson b "$exe_bytes" --arg s "$exe_sha" \
    '{schema: "native-process-cpu-config-v1", executable: {path: $p, bytes: $b, sha256: $s}, args: (split("\u0000")[:-1])}' > "$cfg" \
    || { inv CONFIG_BUILD_FAILED; finish_case; return 3; }
  chmod 0400 "$cfg" || { inv CONFIG_CHMOD_FAILED; finish_case; return 3; }
  cfg_sha=$(sha "$cfg") && printf '%s\n' "$cfg_sha" > "$cdir/config.sha256" || { inv CONFIG_HASH_FAILED; finish_case; return 3; }
  exec {GOFD}<>"$go" {RELFD}<>"$rel" || { inv FIFO_OPEN_FAILED; finish_case; return 3; }

  local -a sr=(
    --unit="$unit" --service-type=exec
    -p User=root -p Restart=no
    -p 'Delegate=cpu cpuset memory pids' -p "DelegateSubgroup=$PAYLOAD"
    -p CPUAccounting=yes -p CPUQuota=100% -p AllowedCPUs=0
    -p "MemoryMax=$MEMORY_MAX" -p MemorySwapMax=0 -p "TasksMax=$PIDS_MAX"
    -p PrivateNetwork=yes -p 'SystemCallFilter=~@network-io'
    -p LimitCORE=0 -p KillMode=process -p TimeoutStopSec=60s
  )
  [[ $gmode == publication-failure ]] && sr+=(-p LimitFSIZE=1024)
  sr+=(
    -p "StandardOutput=append:$so" -p "StandardError=append:$se"
    -p "ExecStopPost=/bin/bash --noprofile --norc $OUT/scripts/hold.sh $rel $holdok"
    -- /usr/bin/env -i PATH=/usr/bin:/bin LC_ALL=C HOME=/root SHELL=/bin/bash "TMPDIR=$scratch"
    /bin/bash --noprofile --norc "$OUT/scripts/gate.sh" "$go" "$ready" "$HELPER_BIN" "$cfg" "$cfg_sha" "$report" "$gmode"
  )
  { printf '%s\n' "$SYSTEMD_RUN"; printf '%s\n' "${sr[@]}"; } > "$cdir/systemd-run.argv" || { inv ARGV_RECORD_FAILED; finish_case; return 3; }
  # ownership is registered (checked, synced to the list) BEFORE launch so every actually-created unit is drainable
  printf '%s\n' "$unit" >> "$UNITS" || { inv UNIT_REGISTRATION_FAILED; finish_case; return 3; }
  tmo "$LAUNCH_S" "$SYSTEMD_RUN" "${sr[@]}" > "$cdir/systemd-run.stdout" 2> "$cdir/systemd-run.stderr"; rc=$?
  if (( rc != 0 )); then # a failed/timed-out launcher does not prove nothing was created: drain the exact unit
    inv "LAUNCH_FAILED_rc$rc"
    kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"
    finish_case; return 3
  fi

  # ----- pre-release validation: the helper has NOT run; any failure kills only this unit -----
  if ! wait_for 10 test -e "$ready"; then inv GATE_NOT_READY; kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"; finish_case; return 3; fi
  show_to "$unit" "$cdir/show.pre-release.txt" || FAIL+=(show_pre_release_unreadable)
  main=${P[MainPID]:-0} cg=${P[ControlGroup]:-}
  [[ $cg == /*"/$unit.service" && $cg != *..* ]] && { printf '%s\n' "$cg" > "$OUT/fifo/$name.cg" || FAIL+=(controlgroup_record_failed); }
  uc=$CGROOT$cg pc=$CGROOT$cg/$PAYLOAD
  eq show.ActiveState "${P[ActiveState]:-}" active
  eq show.SubState "${P[SubState]:-}" running
  eq show.Type "${P[Type]:-}" exec
  eq show.KillMode "${P[KillMode]:-}" process
  eq show.Delegate "${P[Delegate]:-}" yes
  eq show.DelegateSubgroup "${P[DelegateSubgroup]:-}" $PAYLOAD
  eq show.ControlGroup "$cg" "/system.slice/$unit.service"
  [[ $main =~ ^[1-9][0-9]*$ ]] || FAIL+=("MainPID [$main]")
  [[ -d $uc && -d $pc ]] || FAIL+=(payload_subgroup_missing)
  if stat_fields "$main"; then main_start=$SF_START; else FAIL+=(main_stat_unreadable); fi
  eq main.cgroup "$(rd "$PROC/$main/cgroup")" "0::$cg/$PAYLOAD"
  mapfile -t procs_in 2>/dev/null < "$pc/cgroup.procs"; eq payload.procs "${procs_in[*]:-}" "$main"
  mapfile -t procs_in 2>/dev/null < "$uc/cgroup.procs"; eq unit.procs "${procs_in[*]:-}" ""
  eq cpu.max "$(rd "$uc/cpu.max")" '100000 100000'
  eq cpuset.cpus "$(rd "$uc/cpuset.cpus")" 0
  eq cpuset.effective.unit "$(rd "$uc/cpuset.cpus.effective")" 0
  eq cpuset.effective.payload "$(rd "$pc/cpuset.cpus.effective")" 0
  eq memory.max "$(rd "$uc/memory.max")" $MEMORY_MAX
  eq memory.swap.max "$(rd "$uc/memory.swap.max")" 0
  eq pids.max "$(rd "$uc/pids.max")" $PIDS_MAX
  for f in cpu.stat cgroup.events memory.events pids.events; do [[ -r $pc/$f ]] || FAIL+=("payload/$f unreadable"); done
  eq main.uid "$(awk '/^Uid:/ { print $2, $3, $4, $5 }' "$PROC/$main/status" 2>/dev/null)" "$ROOT_UID $ROOT_UID $ROOT_UID $ROOT_UID"
  [[ $(tr '\0' ' ' < "$PROC/$main/cmdline" 2>/dev/null) == *"$OUT/scripts/gate.sh"* ]] || FAIL+=(main_is_not_gate)
  [[ $(tr '\0' '\n' < "$PROC/$main/environ" 2>/dev/null) == *"TMPDIR=$scratch"* ]] || FAIL+=(tmpdir_not_scratch)
  eq rlimit.core "$(limit_of "$main" 'Max core file size')" '0 0'
  local sigign; sigign=$(awk '/^SigIgn:/ { print $2 }' "$PROC/$main/status" 2>/dev/null)
  if [[ $gmode == publication-failure ]]; then
    eq rlimit.fsize "$(limit_of "$main" 'Max file size')" '1024 1024'
    [[ $sigign =~ ^[0-9a-f]+$ ]] && (( (16#$sigign >> 24) & 1 )) || FAIL+=(sigxfsz_not_ignored)
  else
    eq rlimit.fsize "$(limit_of "$main" 'Max file size')" 'unlimited unlimited'
    [[ $sigign =~ ^[0-9a-f]+$ ]] && (( ((16#$sigign >> 24) & 1) == 0 )) || FAIL+=(sigxfsz_unexpectedly_ignored)
  fi
  [[ $(readlink "$PROC/$main/ns/net") != "$(readlink "$PROC/self/ns/net")" ]] || FAIL+=(network_namespace_shared)
  mapfile -t ifaces < <(awk -F: 'NR > 2 { gsub(/ /, "", $1); print $1 }' "$PROC/$main/net/dev" 2>/dev/null)
  eq net.interfaces "${ifaces[*]:-}" lo
  [[ $(fstype "$cdir") == ext4 && $(fstype "$scratch") == ext4 ]] || FAIL+=(case_not_ext4)
  owner_ok "$cdir" && owner_ok "$scratch" || FAIL+=(case_dir_ownership)
  eq helper.sha "$(sha "$HELPER_BIN")" "$HELPER_SHA"
  elf_ok "$HELPER_BIN" || FAIL+=(helper_not_elf)
  if [[ $id == timeout-KILL ]]; then
    eq timeout.sha "$(sha "$TIMEOUT_BIN")" "$TIMEOUT_SHA"
    elf_ok "$TIMEOUT_BIN" || FAIL+=(timeout_not_elf)
  fi
  eq config.sha "$(sha "$cfg")" "$cfg_sha"
  eq config.sha.binds.executable "$(jq -r .executable.sha256 "$cfg" 2>/dev/null)" "$exe_sha"
  eq gate.sha "$(sha "$OUT/scripts/gate.sh")" "$GATE_SHA"
  eq hold.sha "$(sha "$OUT/scripts/hold.sh")" "$HOLD_SHA"
  [[ ! -e $report ]] || FAIL+=(report_not_absent)
  jq -n --argjson pid "${main:-0}" --arg start "$main_start" --arg cg "$(rd "$PROC/$main/cgroup")" --arg uid "$(awk '/^Uid:/ { print $2, $3, $4, $5 }' "$PROC/$main/status" 2>/dev/null)" \
    --arg core "$(limit_of "$main" 'Max core file size')" --arg fsize "$(limit_of "$main" 'Max file size')" --arg sigign "$sigign" \
    --arg netns "$(readlink "$PROC/$main/ns/net")" --arg ifaces "${ifaces[*]:-}" --arg cmd "$(tr '\0' ' ' < "$PROC/$main/cmdline" 2>/dev/null)" \
    '{pid:$pid, starttime_ticks:$start, cgroup:$cg, uid:$uid, rlimit_core:$core, rlimit_fsize:$fsize, sig_ign:$sigign, netns:$netns, interfaces:$ifaces, cmdline:$cmd}' > "$cdir/proc.main.json" \
    && PRE_VALIDATED=1 || FAIL+=(proc_main_evidence_write_failed)
  cat -- "$pc/cpu.stat" > "$cdir/cg/payload.cpu.stat.initial" 2>/dev/null || FAIL+=(initial_cpu_stat_unreadable)
  if (( ${#FAIL[@]} )); then
    for m in "${FAIL[@]}"; do inv "PRE_RELEASE:$m"; done
    kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"; finish_case; return 3
  fi
  dl && { inc BATCH_DEADLINE_BEFORE_RELEASE; kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"; finish_case; return 3; }

  # ----- release: first moment the native helper can run -----
  if ! printf 'release\n' >&"$GOFD"; then
    inv RELEASE_WRITE_FAILED; kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"; finish_case; return 3
  fi
  REL_US=${EPOCHREALTIME/./} RELEASED=true
  exec {GOFD}>&-; GOFD=''

  wait_for 30 main_ended; rc=$?
  if (( rc == 0 )) && [[ $id == survivor ]]; then observe_survivor; fi
  (( rc == 0 )) && { POLL=0.05 wait_for 10 sub_stop_post; rc=$?; }
  if (( rc == 0 )); then wait_for 10 payload_drained; rc=$?; fi
  if (( rc == 2 )); then
    inc BATCH_DEADLINE
    wait_cleanup_outcome || inv DEADLINE_CLEANUP_NOT_COMPLETED # the watchdog drains every owned unit
  elif (( rc == 1 )); then
    inv 'TIMEOUT_WAITING_FOR_MAIN_STOP_POST_OR_DRAIN'; CLOSURE=1
    kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit" # KillMode=process leaves leftovers: drain this exact unit only
  else capture_stop_post; fi

  persist_evidence # hash + sync with checked errors BEFORE stop-post is released
  printf 'release\n' >&"$RELFD" || { inv HOLD_RELEASE_WRITE_FAILED; CLOSURE=1; }
  exec {RELFD}>&-; RELFD=''
  if POLL=0.05 wait_for 15 unit_ended; then
    show_to "$unit" "$cdir/show.final.txt" || inv SHOW_FINAL_UNREADABLE
    tmo "$SCTL_S" "$SYSTEMCTL" reset-failed -- "$unit.service" >/dev/null 2>&1
    # independent stop-post termination check: the hold itself must have read `release` and exited normally
    if (( rc == 0 )) && [[ ! -e $holdok ]]; then inv HOLD_DID_NOT_COMPLETE; CLOSURE=1; fi
    if ! payload_drained; then
      inv UNIT_ENDED_WITH_POPULATED_PAYLOAD; CLOSURE=1
      kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"
    fi
  elif dl; then # deadline fired while waiting for the unit to end after the hold release: recorded, never swallowed
    inc BATCH_DEADLINE_AFTER_HOLD_RELEASE
    wait_cleanup_outcome || inv DEADLINE_CLEANUP_NOT_COMPLETED
  else
    inv UNIT_DID_NOT_END_AFTER_HOLD_RELEASE; CLOSURE=1
    kill_owned_units "$unit" || inv "CLEANUP_FAILED:$unit"
  fi
  finish_case
  (( CLOSURE )) && return 4 # closure failure: never launch another case on top of an unverified unit
  return 0
}
publish_result() { # final extra released_procs
  local tmp=$OUT/result.json.tmp ctmp=$OUT/cases.json.tmp state=$1 f
  local -a existing=()
  for f in "${CASE_FILES[@]}"; do
    if [[ -f $f && -s $f ]]; then existing+=("$f"); else PUB_ERR+=("CASE_FILE_UNREADABLE:$(basename "$(dirname "$f")")"); fi
  done
  # checked intermediate (a process substitution would hide the inner jq exit and publish null cases)
  if (( ${#existing[@]} )); then
    jq -s . "${existing[@]}" > "$ctmp" 2>/dev/null || { PUB_ERR+=(CASES_SERIALIZATION_FAILED); printf '[]\n' > "$ctmp"; }
  else printf '[]\n' > "$ctmp"; fi
  # exact count, frozen-roster id order, schema and per-case states against what this run recorded:
  # a vanished/empty/mismatched case file can never leave a success result over the remainder
  local -a ids=(); local row n=0
  for row in "${CASES[@]}"; do (( n++ < ${#CASE_FILES[@]} )) && ids+=("${row%% *}"); done
  if (( ${#CASE_FILES[@]} > ${#CASES[@]} )) || ! jq -e --argjson n "${#CASE_FILES[@]}" --arg states "${CASE_STATES[*]:-}" --arg ids "${ids[*]:-}" --arg schema "$CASE_SCHEMA" \
    'type == "array" and length == $n and ([.[].state] | join(" ")) == $states and ([.[].id] | join(" ")) == $ids
     and all(.[]; .schema == $schema and (.state | IN("MECHANICS_VERIFIED", "INCONCLUSIVE", "INVALID")))' "$ctmp" >/dev/null 2>&1; then
    PUB_ERR+=(CASES_VALIDATION_FAILED); printf '[]\n' > "$ctmp"
  fi
  (( ${#PUB_ERR[@]} )) && state=INVALID
  if jq -n --arg schema "$RESULT_SCHEMA" --arg state "$state" --arg batch "$BATCH" --arg extra "$2" \
    --argjson mock "$MOCK_ACTIVE" --argjson deadline "$DEADLINE_S" --argjson fired "$([[ -e $OUT/fifo/deadline-fired ]] && echo true || echo false)" \
    --argjson released_procs "$3" --argjson controls "$(jarr "${CONTROL_RESULTS[@]}")" --argjson perr "$(jarr "${PUB_ERR[@]}")" \
    --argjson ncases "${#CASE_FILES[@]}" --argjson nexisting "${#existing[@]}" --arg dsha "$DRIVER_SHA" --arg hsha "$HELPER_SHA" --arg tsha "$TIMEOUT_SHA" \
    --slurpfile cases "$ctmp" \
    '{schema:$schema, state:$state,
      claims:{numerical_CPU_accuracy:false, overhead_GO:false, performance:false, query_wall_gate:false, descendant_complete:false, quantitative_error_bound:"UNQUALIFIED"},
      mock_seams_active:$mock, batch:$batch, abort_note:(if $extra == "" then null else $extra end), publication_errors:$perr,
      driver_sha256:$dsha, helper_sha256:$hsha, timeout_sha256:$tsha,
      plan:{invocations:12, fixture_processes:15, reserved_compiler_test_child:1, cap:16, retries:0, deadline_s:$deadline, deadline_fired:$fired},
      cases_recorded:$ncases, case_files_readable:$nexisting, fixture_processes_released:$released_procs,
      closed_artifact_controls:$controls,
      case_states:($cases[0] | map({id, state})), cases:$cases[0],
      remaining:["independent quantitative accounting error bound and full observer cost", "root protocol review", "new exact-input admission and canary before any performance experiment"]}' \
    > "$tmp" 2>/dev/null && [[ -s $tmp ]] && mv -f -T -- "$tmp" "$OUT/result.json"; then
    rm -f -- "$ctmp"
    return 0
  fi
  rm -f -- "$ctmp"
  PUB_ERR+=(RESULT_JSON_BUILD_OR_PUBLISH_FAILED)
  # minimal jq-free fallback: still INVALID, still mock-marked, still claims false. A previously published
  # success result must not survive a failed replacement: retract it first.
  rm -f -- "$OUT/result.json" || PUB_ERR+=(RESULT_RETRACT_FAILED)
  printf '{"schema":"%s","state":"INVALID","mock_seams_active":%s,"claims":{"numerical_CPU_accuracy":false,"overhead_GO":false,"performance":false},"publication_errors":"%s"}\n' \
    "$RESULT_SCHEMA" "$MOCK_ACTIVE" "${PUB_ERR[*]}" > "$tmp" 2>/dev/null && mv -f -T -- "$tmp" "$OUT/result.json" 2>/dev/null || PUB_ERR+=(RESULT_FALLBACK_WRITE_FAILED)
  return 1
}
publish_manifest() {
  if ! { ( cd "$OUT" && find . -type f ! -name 'SHA256SUMS*' ! -name 'TERMINAL.json*' -print0 | sort -z | xargs -0 sha256sum ) > "$OUT/SHA256SUMS.tmp" \
    && mv -f -T -- "$OUT/SHA256SUMS.tmp" "$OUT/SHA256SUMS"; } 2>/dev/null; then PUB_ERR+=(MANIFEST_FAILED); return 1; fi
  sync -f -- "$OUT/result.json" "$OUT/SHA256SUMS" "$OUT" 2>/dev/null || { PUB_ERR+=(FINAL_SYNC_FAILED); return 1; }
}
close_admission() { # stop admission, arbitrate atomically with the watchdog, join its CHECKED cleanup outcome
  local i
  : > "$OUT/fifo/batch-done" || PUB_ERR+=(BATCH_DONE_MARKER_FAILED)
  mkdir "$OUT/fifo/arbiter" 2>/dev/null && return 0 # the driver won: the batch deadline can no longer fire
  for ((i = 0; i < 50; i++)); do dl && break; nap 0.1; done
  if dl; then wait_cleanup_outcome || PUB_ERR+=(DEADLINE_CLEANUP_NOT_COMPLETED)
  else PUB_ERR+=(ARBITER_MKDIR_FAILED); fi
}
retract_stale_success() { # a non-INVALID result.json must never survive when the final state is INVALID
  jq -e '.state == "INVALID"' "$OUT/result.json" >/dev/null 2>&1 || rm -f -- "$OUT/result.json" || PUB_ERR+=(RESULT_RETRACT_FAILED)
}
final_rc() { case $1 in MECHANICS_VERIFIED) echo 0 ;; INCONCLUSIVE) echo 1 ;; *) echo 2 ;; esac; }
publish_terminal() { # final rc result_sha manifest_sha: the ONLY artifact that can authorize acceptance
  local tmp=$OUT/TERMINAL.json.tmp
  jq -n --arg schema "$TERMINAL_SCHEMA" --arg state "$1" --argjson rc "$2" --arg rsha "$3" --arg msha "$4" --argjson mock "$MOCK_ACTIVE" --arg batch "$BATCH" \
    '{schema:$schema, final_state:$state, driver_exit_code:$rc, result_sha256:$rsha, manifest_sha256:$msha, mock_seams_active:$mock, batch:$batch,
      acceptance:"valid only if this file exists, driver_exit_code is 0, final_state is MECHANICS_VERIFIED and both hashes match the files; result.json and SHA256SUMS alone never authorize acceptance"}' \
    > "$tmp" 2>/dev/null && mv -f -T -- "$tmp" "$OUT/TERMINAL.json" && sync -f -- "$OUT/TERMINAL.json" "$OUT" 2>/dev/null
}
finalize() {
  local final=MECHANICS_VERIFIED s c extra=${1:-} released_procs=0 i=0 row p e perr='' n0 rsha='' msha='' rcode g
  FINALIZED=1
  close_admission
  for s in "${CASE_STATES[@]}"; do [[ $s == INVALID ]] && final=INVALID; done
  if [[ $final != INVALID ]]; then
    for s in "${CASE_STATES[@]}"; do [[ $s == INCONCLUSIVE ]] && final=INCONCLUSIVE; done
    (( ${#CASE_STATES[@]} == ${#CASES[@]} )) || final=INCONCLUSIVE
  fi
  for c in "${CONTROL_RESULTS[@]}"; do
    [[ $c == *:INVALID ]] && final=INVALID
    [[ $c == *:INCONCLUSIVE && $final == MECHANICS_VERIFIED ]] && final=INCONCLUSIVE
  done
  [[ -n $extra && $final == MECHANICS_VERIFIED ]] && final=INCONCLUSIVE
  [[ -e $OUT/fifo/deadline-fired && $final == MECHANICS_VERIFIED ]] && final=INCONCLUSIVE # a deadline intervention is never a success
  [[ -e $OUT/fifo/deadline-cleanup-failed ]] && PUB_ERR+=(CLEANUP_FAILED)
  [[ -e $OUT/fifo/hard-stop ]] && PUB_ERR+=(HARD_STOP_FIRED) # the supervisor already declared this run dead: never a success
  if [[ -e $OUT/fifo/cleanup.log ]]; then
    grep -q CLEANUP_FAILED "$OUT/fifo/cleanup.log"; g=$?
    (( g == 0 )) && PUB_ERR+=(CLEANUP_FAILED)
    (( g > 1 )) && PUB_ERR+=(CLEANUP_LOG_READ_FAILED)
  fi
  for row in "${CASES[@]}"; do
    read -r _ _ _ _ p _ <<<"$row"
    [[ -s ${CASE_FILES[i]:-} ]] && jq -e '.released == true' "${CASE_FILES[i]}" >/dev/null 2>&1 && released_procs=$((released_procs + p))
    i=$((i + 1))
  done
  for _ in 1 2; do # pass 2 only when a publication step failed after a non-INVALID result was written
    (( ${#PUB_ERR[@]} )) && final=INVALID
    n0=${#PUB_ERR[@]}
    publish_result "$final" "$extra" "$released_procs"
    publish_manifest
    rsha=$(sha "$OUT/result.json" 2>/dev/null) || { rsha=''; PUB_ERR+=(RESULT_SHA_FAILED); }
    msha=$(sha "$OUT/SHA256SUMS" 2>/dev/null) || { msha=''; PUB_ERR+=(MANIFEST_SHA_FAILED); }
    (( ${#PUB_ERR[@]} > n0 )) && [[ $final != INVALID ]] || break
  done
  (( ${#PUB_ERR[@]} )) && final=INVALID
  [[ $final == INVALID ]] && retract_stale_success
  for e in "${PUB_ERR[@]}"; do perr+="\"${e//[^A-Za-z0-9_.:\/-]/_}\","; done
  # stdout summary FIRST (checked), terminal receipt LAST: a failed summary can still turn the outcome INVALID
  if ! printf '{"final_state":"%s","result":"%s","result_sha256":"%s","publication_errors":[%s],"mock_seams_active":%s}\n' \
    "$final" "$OUT/result.json" "$rsha" "${perr%,}" "$MOCK_ACTIVE"; then
    PUB_ERR+=(STDOUT_WRITE_FAILED); final=INVALID
    publish_result "$final" "$extra" "$released_procs"; publish_manifest
    rsha=$(sha "$OUT/result.json" 2>/dev/null) || rsha=''; msha=$(sha "$OUT/SHA256SUMS" 2>/dev/null) || msha=''
    retract_stale_success
  fi
  rcode=$(final_rc "$final")
  if ! publish_terminal "$final" "$rcode" "$rsha" "$msha"; then
    PUB_ERR+=(TERMINAL_RECEIPT_FAILED); final=INVALID; rcode=2
    rm -f -- "$OUT/TERMINAL.json"
    publish_result "$final" "$extra" "$released_procs"; publish_manifest; retract_stale_success
  fi
  if ! : > "$OUT/fifo/terminal-done"; then # the watchdog would otherwise hard-stop a finished driver
    rm -f -- "$OUT/TERMINAL.json" "$OUT/result.json"; rcode=2
  fi
  return "$rcode"
}
