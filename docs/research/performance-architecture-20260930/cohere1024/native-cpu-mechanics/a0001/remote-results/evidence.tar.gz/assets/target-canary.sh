#!/usr/bin/env bash
# Disposable-host systemd/environment canary for check_native_process_cpu_fixtures.sh   (UNVERIFIED, never run locally)
#
#   target-canary.sh /ABS/check_native_process_cpu_fixtures.sh /ABS/NEW_OUTPUT_DIR_ON_ROOT_EXT4
#
# Run ONLY by root on a DISPOSABLE root-ext4 systemd>=254 host, inside a service bounded to <=120 s,
# CPU1/AllowedCPUs0/256Mi/noSwap/pids128. Root remains sole executor and freeze owner. NEVER invokes the native
# helper or any fixture: the "helper" is the declared DUMMY command  /bin/bash <canary dummy script>.
# No numerical CPU evidence: cpu.stat is only checked for retention (readable, parses, not decreasing).
#
# SOURCE-BOUND, not mirrored: the gate/hold script bytes (heredocs), the exact systemd-run property array of run_case,
# and the driver functions tmo/span_us/nap/ev/rd/dl/wait_for/show_to/sub_stop_post/unit_ended/payload_drained/unit_cg/
# kill_owned_units are cut out of the SHA-pinned driver source by text extraction and used as-is.
#
# REAL systemd/host operations (this canary): transient units created with the driver's exact property set; env -i gate
#   reaching ready under HOME/SHELL + PrivateNetwork + SystemCallFilter=~@network-io; DelegateSubgroup=payload placement;
#   ExecStopPost hold in .control; ExecMainCode/Status at stop-post for exit 0 and exit 7; payload cpu.stat retained after
#   populated=0 while the hold is active; hold release -> unit end + hold receipt; the driver's own kill_owned_units draining
#   a sleeping dummy; bounded manager calls through the authenticated timeout; EXIT cleanup of canary-owned units only.
# NOT exercised (mocked elsewhere / out of scope): native helper + all 12 fixtures; driver admission, package authentication,
#   outer-bound parsing, watchdog/hard stop, finalize/TERMINAL; publication-failure (LimitFSIZE) shape; "launch-response
#   failure" is a CANARY DECISION (the launcher actually succeeded) -- only the cleanup path is real.
# shellcheck disable=SC2154,SC2317,SC2329,SC2034,SC1090,SC1091,SC2015,SC2016,SC2094
set -uo pipefail # same shell options as the driver, so extracted functions keep their error propagation
export LC_ALL=C PATH=/usr/sbin:/usr/bin:/sbin:/bin
EXPECT_DRIVER_SHA=8b5f023a528b8a4a7cc84ea95c12d8b6a1bb8a61a7d5a7b3a736e9141639e618
EXPECT_GATE_SHA=4f75286be37158c13a00cb60c8f77bdeba2f1303bdf5876394cb180389af1b85
EXPECT_HOLD_SHA=fcfa6b243d6f069ef6b312c891b594c3186c931c4651364d194ab3d004d32dbb
BUDGET_S=100
DRIVER=${1:?usage: target-canary.sh /ABS/driver /ABS/NEW_OUT}
OUT=${2:?usage: target-canary.sh /ABS/driver /ABS/NEW_OUT}
T0=${EPOCHREALTIME/./}

refuse() { printf 'CANARY REFUSED: %s\n' "$*" >&2; exit 125; }
safe_abs() { [[ $1 =~ ^/[A-Za-z0-9._/-]+$ && $1 != *//* && $1 != */ && $1 != */. && $1 != */.. && $1 != */./* && $1 != */../* ]]; }
[[ $EUID == 0 ]] || refuse 'root required'
safe_abs "$DRIVER" && safe_abs "$OUT" || refuse 'paths must be absolute [A-Za-z0-9._/-]'
[[ $(sha256sum -- "$DRIVER" | cut -d' ' -f1) == "$EXPECT_DRIVER_SHA" ]] || refuse 'driver is not the SHA-pinned d5fd3ff1 source'
for t in jq awk sha256sum findmnt mkfifo systemctl systemd-run timeout realpath stat uname cut tr sort; do command -v "$t" > /dev/null || refuse "missing tool $t"; done
[[ $(stat -fc %T /sys/fs/cgroup) == cgroup2fs ]] || refuse 'unified cgroup2 required'
PARENT=${OUT%/*}; PARENT=${PARENT:-/}
[[ -d $PARENT && $(findmnt -no FSTYPE -T "$PARENT") == ext4 ]] || refuse 'output parent must exist on ext4'
mkdir -m 0700 -- "$OUT" 2> /dev/null || refuse 'output dir must be NEW'
[[ $(findmnt -no FSTYPE -T "$OUT") == ext4 ]] || refuse 'output dir is not ext4'
mkdir -m 0700 "$OUT"/{scripts,fifo,cases,evidence} || refuse 'cannot create layout'

FAILMSG='' COMPLETED=0 CLEANUP_BAD=0
: > "$OUT/checks.jsonl" || refuse 'cannot create checks.jsonl'
die() { FAILMSG=$*; printf 'CANARY FAIL: %s\n' "$*" >&2; exit 1; }
budget() { (( ${EPOCHREALTIME/./} - T0 < BUDGET_S * 1000000 )) || die "canary budget ${BUDGET_S}s exceeded"; }
ck() { # name detail cmd... : record one check; the FIRST failure stops the canary (no retries)
  local n=$1 d=$2 ok=true; shift 2
  "$@" || ok=false
  jq -cn --arg n "$n" --argjson ok "$ok" --arg d "$d" '{check:$n, ok:$ok, detail:$d}' >> "$OUT/checks.jsonl" \
    || { printf 'FAIL (cannot record) %s\n' "$n"; die "cannot append check record: $n"; }
  if $ok; then printf 'PASS %s\n' "$n"; else printf 'FAIL %s\n' "$n"; die "check failed: $n"; fi
}

# ---------------------------------------------------------------- source-bound extraction (text only)
fn() { awk -v n="$1" 'BEGIN { pat = "^" n "\\(\\) \\{" } $0 ~ pat && !on { on = 1; print; if ($0 ~ /\}[[:space:]]*$/) exit; next } on { print; if ($0 == "}") exit }' "$DRIVER"; }
hd() { awk -v s="cat > \"\$OUT/scripts/$1.sh\" <<'$2'" -v e="$2" '$0 == s { on = 1; next } on && $0 == e { exit } on { print }' "$DRIVER"; }
{
  grep -E '^readonly (SCTL_S=|MEMORY_MAX=)' "$DRIVER"; grep '^declare -A P=()$' "$DRIVER"
  for f in tmo span_us nap ev rd dl wait_for show_to sub_stop_post unit_ended payload_drained unit_cg kill_owned_units; do fn "$f"; done
} > "$OUT/evidence/extracted-functions.sh" || die 'cannot write extracted functions'
[[ -s $OUT/evidence/extracted-functions.sh ]] || die 'extracted functions are empty'
bash -n "$OUT/evidence/extracted-functions.sh" || die 'extracted functions do not parse'
SRTXT=$(awk '/^  local -a sr=\($/ { on = 1 } on { print } on && /^  \)$/ { n++; if (n == 2) exit }' "$DRIVER")
[[ -n $SRTXT ]] || die 'systemd-run property array not found in the driver'
printf '%s\n' "$SRTXT" > "$OUT/evidence/extracted-sr-array.txt" || die 'cannot write extracted sr array'
{ hd gate GATE > "$OUT/scripts/gate.sh" && hd hold HOLD > "$OUT/scripts/hold.sh"; } || die 'cannot extract gate/hold heredocs'
[[ -s $OUT/scripts/gate.sh && -s $OUT/scripts/hold.sh ]] || die 'gate/hold heredoc extraction is empty'
GATE_SHA=$(sha256sum "$OUT/scripts/gate.sh" | cut -d' ' -f1) HOLD_SHA=$(sha256sum "$OUT/scripts/hold.sh" | cut -d' ' -f1)
eval "$(grep '^chmod 0500 "\$OUT/scripts/gate.sh"' "$DRIVER")" || die 'chmod of extracted scripts failed'
source "$OUT/evidence/extracted-functions.sh"

# ---------------------------------------------------------------- environment, authenticated timeout, outer bound
BATCH=canary-$(date -u +%Y%m%dT%H%M%SZ)-$$ MOCK_ACTIVE=false CGROOT=/sys/fs/cgroup POLL=0.005
SYSTEMCTL=$(command -v systemctl) TIMEOUT_BIN=/usr/bin/timeout UNITS=$OUT/fifo/units; : > "$UNITS"
mkfifo "$OUT/fifo/nap" && exec {NAPFD}<> "$OUT/fifo/nap" || die 'nap fifo'
write_result() { # state publication_errors : checked tmp + mv (a failure is returned, never swallowed)
  jq -n --arg state "$1" --arg pub "$2" --arg fail "$FAILMSG" --argjson bad "$CLEANUP_BAD" --arg batch "$BATCH" --arg dsha "$EXPECT_DRIVER_SHA" \
    --arg gate "${GATE_SHA:-}" --arg hold "${HOLD_SHA:-}" --slurpfile checks "$OUT/checks.jsonl" \
    '{schema:"borsuk-native-cpu-fixture-canary-v1", state:$state, failure:$fail, publication_errors:$pub, cleanup_incomplete:($bad == 1), batch:$batch,
      driver_sha256:$dsha, gate_sha256:$gate, hold_sha256:$hold, checks_recorded:($checks | length), checks:$checks,
      dummy_command:"/bin/bash <canary dummy script> (exit 0 | exit 7 | exec sleep 100); the native helper and all fixtures are NEVER invoked",
      real_operations:["transient units via the driver exact systemd-run property array","env -i gate reaching ready under HOME/SHELL + PrivateNetwork + ~@network-io","DelegateSubgroup=payload placement","ExecStopPost hold in .control","ExecMainCode/Status at stop-post (exit 0 and exit 7)","payload cpu.stat retained after populated=0 while hold active","hold release -> unit end + hold receipt","driver kill_owned_units draining a sleeping dummy","bounded manager calls via the authenticated timeout","EXIT cleanup of canary-owned units only"],
      not_exercised:["native helper and fixtures","driver admission/package auth/outer-bound parsing/watchdog/hard stop/finalize/TERMINAL","publication-failure LimitFSIZE shape","survivor/unwaited/sigpipe/timeout-KILL cases","launch-response failure is a CANARY DECISION, only the cleanup is real"],
      claims:{numerical_CPU_accuracy:false, overhead_GO:false, performance:false}}' > "$OUT/canary-result.json.tmp" 2> /dev/null \
    && mv -f -T -- "$OUT/canary-result.json.tmp" "$OUT/canary-result.json"
}
write_manifest() { # find|sort|xargs under pipefail; then sync result + manifest + directory, all checked
  (cd "$OUT" && find . -type f ! -name 'SHA256SUMS*' -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.tmp) 2> /dev/null \
    && mv -f -T -- "$OUT/SHA256SUMS.tmp" "$OUT/SHA256SUMS" \
    && sync -f -- "$OUT/canary-result.json" "$OUT/SHA256SUMS" "$OUT"
}
on_exit() {
  local rc=$? left lrc state=FAIL pub=''
  trap - EXIT INT TERM
  if declare -F kill_owned_units > /dev/null && [[ -s $UNITS ]]; then kill_owned_units || CLEANUP_BAD=1; fi # canary-owned units only (prefix-checked inside)
  left=$(tmo "$SCTL_S" "$SYSTEMCTL" list-units "borsuk-ncpu-$BATCH-*" --all --no-legend 2> /dev/null); lrc=$?
  [[ $lrc == 0 && -z $left ]] || CLEANUP_BAD=1
  printf '%s\n' "$left" > "$OUT/evidence/units-left-after-cleanup.txt" || pub+=' UNITS_LEFT_WRITE_FAILED'
  (( rc == 0 && COMPLETED == 1 && CLEANUP_BAD == 0 )) && [[ -z $FAILMSG && -z $pub ]] && state=PASS
  write_result "$state" "$pub" || { state=FAIL; pub+=' RESULT_WRITE_FAILED'; }
  write_manifest || { state=FAIL; pub+=' MANIFEST_OR_SYNC_FAILED'; }
  if [[ $state == FAIL && -n $pub ]]; then # a publication step failed after a possibly-PASS result was written: rewrite FAIL, else retract
    write_result FAIL "$pub" || rm -f -- "$OUT/canary-result.json" || pub+=' RETRACT_FAILED'
    write_manifest || pub+=' MANIFEST_RETRY_FAILED'
  fi
  if ! printf '{"canary_state":"%s","result":"%s/canary-result.json","publication_errors":"%s"}\n' "$state" "$OUT" "$pub"; then
    state=FAIL # a stdout summary that cannot be written is never reported as success
    write_result FAIL "$pub STDOUT_WRITE_FAILED" || rm -f -- "$OUT/canary-result.json"
    write_manifest
  fi
  [[ $state == PASS ]] && exit 0
  exit $(( rc > 0 ? rc : 1 ))
}
trap on_exit EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# timeout authentication (minimal; package ownership is RECORDED, the full package check lives in driver admission)
ck 'timeout is a symlink-free regular GNU coreutils ELF' "$TIMEOUT_BIN" bash -c '[[ $(realpath -e "$1") == "$1" && -f $1 && -x $1 ]] && [[ $(head -c4 "$1") == $'"'"'\177ELF'"'"' ]] && [[ $(env -i "$1" --version | head -n1) == "timeout (GNU coreutils) "* ]]' _ "$TIMEOUT_BIN"
{ sha256sum "$TIMEOUT_BIN"; dpkg-query -S "$TIMEOUT_BIN" 2>&1 || rpm -qf "$TIMEOUT_BIN" 2>&1; : ; } > "$OUT/evidence/timeout-identity.txt" 2>&1 || die 'cannot record timeout identity' 
SDV=$(tmo "$SCTL_S" "$SYSTEMCTL" --version 2> /dev/null | { read -r _ v _; printf '%s' "${v:-}"; })
ck 'systemd >= 254' "$SDV" bash -c '[[ $1 =~ ^[0-9]+$ ]] && (( $1 >= 254 ))' _ "$SDV"
[[ $(< /proc/self/cgroup) =~ ([^/]+\.service)(/|$) ]] || die 'canary must run inside a bounded service'
OUTER=${BASH_REMATCH[1]}
tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager -p RuntimeMaxUSec -p CPUQuotaPerSecUSec -p AllowedCPUs -p MemoryMax -p MemorySwapMax -p TasksMax -- "$OUTER" > "$OUT/evidence/outer-unit-limits.txt" 2>&1 || die 'cannot record outer unit limits' 
OUTER_RT=$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=RuntimeMaxUSec --value -- "$OUTER") && OUTER_US=$(span_us "$OUTER_RT") || die "outer RuntimeMaxUSec [$OUTER_RT] not a finite timespan"
ck 'outer service RuntimeMaxSec <= 120 s (other outer limits recorded only)' "$OUTER_RT" test "$OUTER_US" -gt 0 -a "$OUTER_US" -le 120000000
{ uname -a; tmo "$SCTL_S" "$SYSTEMCTL" --version | head -n2; findmnt -T "$OUT"; cat /proc/self/cgroup; } > "$OUT/evidence/host.txt" 2>&1 || die 'cannot record host evidence' 

# ---------------------------------------------------------------- one real unit (driver's exact property array, dummy command)
build_sr() { local -a sr; eval "$SRTXT"; SR=("${sr[@]}"); }
launch() { # nn id dummy_script_body   -> globals: unit name cdir pc cg uc ready go rel holdok report main
  nn=$1 id=$2 name=$1-$2 unit=borsuk-ncpu-$BATCH-$1-$2 gmode=ordinary
  cdir=$OUT/cases/$name scratch=$cdir/scratch so=$cdir/stdout se=$cdir/stderr report=$cdir/report.json
  go=$OUT/fifo/$name.go ready=$OUT/fifo/$name.ready rel=$OUT/fifo/$name.release holdok=$OUT/fifo/$name.hold-ok
  mkdir -m 0700 "$cdir" "$scratch" || die "mkdir $name"
  cfg=$cdir/dummy.sh
  printf '#!/bin/bash\n# DUMMY standing in for the native helper: $1=sha $2=report. Never the real helper.\ncat /proc/self/cgroup > "$2"\n%s\n' "$3" > "$cfg" && chmod 0500 "$cfg" || die "dummy script $name"
  cfg_sha=$(sha256sum "$cfg" | cut -d' ' -f1) HELPER_BIN=/bin/bash
  { : > "$so" && : > "$se" && chmod 0600 "$so" "$se"; } || die "output files $name"; mkfifo -m 0600 "$go" "$rel" || die "fifo $name"
  exec {GOFD}<> "$go" {RELFD}<> "$rel" || die "fifo open $name"
  build_sr && printf '%s\n' "$SYSTEMD_RUN_BIN" "${SR[@]}" > "$cdir/systemd-run.argv" || die "systemd-run argv $name"
  printf '%s\n' "$unit" >> "$UNITS" || die 'unit registration'
  tmo "$LAUNCH_S" "$SYSTEMD_RUN_BIN" "${SR[@]}" > "$cdir/systemd-run.stdout" 2> "$cdir/systemd-run.stderr" || die "systemd-run failed rc=$? for $name"
}
SYSTEMD_RUN_BIN=$(command -v systemd-run) # LAUNCH_S / PAYLOAD / MEMORY_MAX / PIDS_MAX come from the extracted readonly constants
save_proc() { # every read and write is mandatory and must leave a non-empty file
  local p=$1 d=$2 pre=$3 f
  for f in cgroup status limits comm; do cat "/proc/$p/$f" > "$d/$pre.proc.$f" && [[ -s $d/$pre.proc.$f ]] || return 1; done
  tr '\0' ' ' < "/proc/$p/cmdline" > "$d/$pre.proc.cmdline" && [[ -s $d/$pre.proc.cmdline ]] || return 1
  tr '\0' '\n' < "/proc/$p/environ" > "$d/$pre.proc.environ" && [[ -s $d/$pre.proc.environ ]] || return 1
}
pre_release() {
  ck "[$name] gate reached ready under env -i HOME/SHELL + PrivateNetwork + ~@network-io" "$ready" wait_for 10 test -e "$ready"
  show_to "$unit" "$cdir/show.pre-release.txt" || die 'show pre-release'
  main=${P[MainPID]:-0} cg=${P[ControlGroup]:-}; uc=$CGROOT$cg pc=$CGROOT$cg/$PAYLOAD
  save_proc "$main" "$cdir" main || die "[$name] cannot record main process evidence"
  cat "$pc/cpu.stat" > "$cdir/payload.cpu.stat.initial" && [[ -s $cdir/payload.cpu.stat.initial ]] || die "[$name] cannot record initial payload cpu.stat"
  ck "[$name] unit properties" "${P[ActiveState]:-}|${P[SubState]:-}|${P[Type]:-}|${P[KillMode]:-}|${P[Delegate]:-}|${P[DelegateSubgroup]:-}|$cg" \
    test "${P[ActiveState]:-}|${P[SubState]:-}|${P[Type]:-}|${P[KillMode]:-}|${P[Delegate]:-}|${P[DelegateSubgroup]:-}|$cg" = "active|running|exec|process|yes|payload|/system.slice/$unit.service"
  ck "[$name] delegated main is in payload; unit cgroup holds no process" "$(rd "/proc/$main/cgroup")" \
    test "$(rd "/proc/$main/cgroup")|$(tr '\n' ' ' < "$pc/cgroup.procs")|$(cat "$uc/cgroup.procs")" = "0::$cg/$PAYLOAD|$main |"
  ck "[$name] limits: cpu.max cpuset memory swap pids" "$(rd "$uc/cpu.max") $(rd "$uc/cpuset.cpus.effective") $(rd "$pc/cpuset.cpus.effective") $(rd "$uc/memory.max") $(rd "$uc/memory.swap.max") $(rd "$uc/pids.max")" \
    test "$(rd "$uc/cpu.max")|$(rd "$uc/cpuset.cpus.effective")|$(rd "$pc/cpuset.cpus.effective")|$(rd "$uc/memory.max")|$(rd "$uc/memory.swap.max")|$(rd "$uc/pids.max")" = "100000 100000|0|0|268435456|0|128"
  ck "[$name] network namespace is private with only lo" "$(rd "/proc/$main/ns/net")" \
    bash -c '[[ $(readlink /proc/$1/ns/net) != $(readlink /proc/self/ns/net) ]] && [[ $(awk -F: "NR>2{gsub(/ /,\"\",\$1);printf \"%s\",\$1}" /proc/$1/net/dev) == lo ]]' _ "$main"
  ck "[$name] main process: root, RLIMIT_CORE 0, cmdline is the extracted gate" "$(tr '\0' ' ' < "/proc/$main/cmdline")" \
    bash -c '[[ $(awk "/^Uid:/{print \$2\$3\$4\$5}" /proc/$1/status) == 0000 ]] && grep -q "^Max core file size *0 *0" /proc/$1/limits && tr "\0" " " < /proc/$1/cmdline | grep -qF "$2"' _ "$main" "$OUT/scripts/gate.sh"
  ck "[$name] gate/hold script bytes equal the pinned driver heredocs" "$GATE_SHA $HOLD_SHA" test "$GATE_SHA $HOLD_SHA" = "$EXPECT_GATE_SHA $EXPECT_HOLD_SHA"
}
release_and_hold_checks() { # $1 expected raw exit status of the dummy
  printf 'release\n' >&"$GOFD" || die 'gate release write'; exec {GOFD}>&-
  POLL=0.05 wait_for 10 sub_stop_post || die "[$name] stop-post never reached"
  show_to "$unit" "$cdir/show.stop-post.txt" || die 'show stop-post'
  ck "[$name] raw main status at stop-post is available: ExecMainCode=1 ExecMainStatus=$1, same PID as pre-release" "${P[ExecMainCode]:-}/${P[ExecMainStatus]:-}/${P[ExecMainPID]:-}" \
    test "${P[ExecMainCode]:-}/${P[ExecMainStatus]:-}/${P[ExecMainPID]:-}" = "1/$1/$main"
  hp=${P[ControlPID]:-0}; save_proc "$hp" "$cdir" hold || die "[$name] cannot record hold process evidence"
  ck "[$name] stop-post hold runs in .control, outside payload" "$(rd "/proc/$hp/cgroup")" test "$(rd "/proc/$hp/cgroup")" = "0::$cg/.control"
  ck "[$name] payload drained (populated 0) while the hold is still active" "$(ev "$pc/cgroup.events" populated)" wait_for 10 payload_drained
  ck "[$name] payload cpu.stat retained after populated=0 (initial and final readable, final >= initial)" "$(ev "$pc/cgroup.events" populated)" \
    bash -c 'cat "$1/cpu.stat" > "$2/payload.cpu.stat.final" && i=$(awk "/^usage_usec/{print \$2}" "$2/payload.cpu.stat.initial") && f=$(awk "/^usage_usec/{print \$2}" "$2/payload.cpu.stat.final") && [[ $i =~ ^[0-9]+$ && $f =~ ^[0-9]+$ ]] && (( f >= i )) && kill -0 "$3"' _ "$pc" "$cdir" "$hp"
  ck "[$name] the exec-ed dummy ran inside payload (its own /proc/self/cgroup)" "$(cat "$report" 2> /dev/null)" test "$(cat "$report" 2> /dev/null)" = "0::$cg/$PAYLOAD"
  printf 'release\n' >&"$RELFD" || die 'hold release write'; exec {RELFD}>&-
  POLL=0.05 wait_for 15 unit_ended || die "[$name] unit did not end after hold release"
  ck "[$name] hold completed (receipt) and the unit ended" "$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ActiveState --value -- "$unit.service")" test -e "$holdok"
  show_to "$unit" "$cdir/show.final.txt" || die "[$name] cannot record final unit status"; tmo "$SCTL_S" "$SYSTEMCTL" reset-failed -- "$unit.service" > /dev/null 2>&1
  budget
}

# ---------------------------------------------------------------- real canary cases
launch 01 exit0 'exit 0'; pre_release; release_and_hold_checks 0
launch 02 exit7 'exit 7'; pre_release; release_and_hold_checks 7
launch 03 sleeper 'exec sleep 100'; pre_release
printf 'release\n' >&"$GOFD"; exec {GOFD}>&-
ck '[sleeper] dummy is a live sleeping process inside payload' "$(cat "/proc/$main/comm" 2> /dev/null)" wait_for 5 bash -c '[[ $(cat /proc/$1/comm) == sleep ]]' _ "$main"
save_proc "$main" "$cdir" sleeping || die '[sleeper] cannot record sleeping process evidence'
# LAUNCH-RESPONSE FAILURE is a canary DECISION here: the launcher succeeded; only the cleanup below is real.
kill_owned_units "$unit"; krc=$?
ck '[sleeper] driver kill_owned_units returned 0 (cgroup drained)' "rc=$krc" test "$krc" = 0
ck '[sleeper] cleanup log shows exact unit drained, no CLEANUP_FAILED' "$(cat "$OUT/fifo/cleanup.log" 2> /dev/null)" bash -c 'grep -q "^$1 drained=" "$2" && ! grep -q CLEANUP_FAILED "$2"' _ "$unit" "$OUT/fifo/cleanup.log"
ck '[sleeper] the sleeping dummy and its cgroup are gone' "$(ls -d "$CGROOT$cg" 2>&1)" bash -c '[[ ! -e /proc/$1 || $(cat /proc/$1/comm 2>/dev/null) != sleep ]] && { [[ ! -e $2/cgroup.events ]] || grep -q "^populated 0" $2/cgroup.events; }' _ "$main" "$CGROOT$cg"
ck '[sleeper] unit is no longer active' "$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ActiveState --value -- "$unit.service")" \
  bash -c '[[ $1 =~ ^(inactive|failed)$ ]]' _ "$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ActiveState --value -- "$unit.service")"
budget
COMPLETED=1
