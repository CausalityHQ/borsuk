#!/usr/bin/env bash
# Source-bound fault harness for scripts/check_native_process_cpu_fixtures.sh (Bash + jq ONLY: no gcc, no Python).
#
#   fault-harness.sh /path/to/check_native_process_cpu_fixtures.sh [SECTION ...]
#   SECTION: fin diag fc cap kill launch tail arb wd persist   (default: all)
#
# WHAT THIS IS: the EXACT function bodies are cut out of the authenticated driver source by name (awk, text only)
# and executed with spy/failure-injection dependencies (PATH wrappers for jq/sha256sum/sync/mv/systemctl/systemd-run).
# It is NOT a re-implementation: no driver logic is mirrored here. The only independent logic is the acceptance
# boundary below: `h_structural_mock_acceptance` (harness baseline ONLY: exit 0 + TERMINAL/result structure + hashes, with BOTH
# mock markers required to be true, so it can never be mistaken for production acceptance) and
# `h_strict_production_acceptance` (the rule a REAL remote run must satisfy: any mock_seams_active=true artifact is rejected).
# Every mocked case here must be strict-production-REJECTED, and every failure test must be rejected by BOTH predicates.
# ZERO helper / fixture / real-systemd invocations: systemd-run is a spy that never executes its command, the
# "helper" is a tripwire script that must never run, nothing touches real cgroups or units.
#
# HONEST SCOPE (printed again at the end): function-level and exact-region execution only. NOT exercised: admission,
# run_case pre-release validation and release/observe middle, observe_survivor, check_native_outputs oracles, closed_controls,
# the main loop and on_exit, real systemd/cgroup semantics, ext4/syncfs durability (tests run on /tmp), the 15 s
# unit_ended timeout and 60 s production batch deadline (deadline-like branches use labelled constant overrides or
# pre-seeded marker files). A passing run is source-level fault evidence only, never mechanics acceptance.
# shellcheck disable=SC1090,SC2034,SC2154,SC2317,SC2329,SC2016
set -uo pipefail # same shell options as the driver
export LC_ALL=C

DRIVER=${1:?usage: fault-harness.sh /path/to/check_native_process_cpu_fixtures.sh [SECTION ...]}
shift
SECTIONS=${*:-all}
EXPECT_SHA=8b5f023a528b8a4a7cc84ea95c12d8b6a1bb8a61a7d5a7b3a736e9141639e618
BUDGET_S=${FH_BUDGET_S:-105} # whole harness cap (remote unit must stay <= 120 s)
ZERO64=0000000000000000000000000000000000000000000000000000000000000000

got=$(sha256sum -- "$DRIVER" | cut -d' ' -f1)
if [[ $got != "$EXPECT_SHA" ]]; then echo "REFUSED: driver sha256 $got != $EXPECT_SHA (not the authenticated source)"; exit 125; fi
for tool in jq awk sha256sum sync mv mkfifo timeout find xargs sort; do command -v "$tool" >/dev/null || { echo "REFUSED: missing tool $tool"; exit 125; }; done

W=$(mktemp -d /tmp/ncpu-fault.XXXXXX) || exit 125
T0=$EPOCHREALTIME
h_elapsed() { local now=${EPOCHREALTIME/./} s=${T0/./}; echo $(( (now - s) / 1000000 )); }
PASS=0 FAILN=0 SKIPN=0

# ---------------------------------------------------------------- source-bound extraction
SRCTEXT=$W/extracted.sh
FUNCS="sha rd ev inv inc eq jarr nap dl tmo span_us unit_cg kill_owned_units wait_cleanup_outcome start_watchdog wait_for show_to
sub_stop_post unit_ended payload_drained cpu_usec diagnostic unwaited_witness frag_object finish_case not_run_case persist_evidence
capture_stop_post run_case publish_result publish_manifest close_admission retract_stale_success final_rc publish_terminal finalize"
h_fn() { # name: exact text of the top-level function (one-liner, or header..first line that is exactly "}")
  awk -v n="$1" 'BEGIN { pat = "^" n "\\(\\) \\{" } $0 ~ pat && !on { on = 1; print; if ($0 ~ /\}[[:space:]]*$/) exit; next } on { print; if ($0 == "}") exit }' "$DRIVER"
}
{
  echo "# --- exact declarations from the driver"
  grep '^set -uo pipefail$' "$DRIVER"
  awk '/^readonly [A-Za-z_]+=/ { print }' "$DRIVER"
  awk '/^readonly -a CASES=\(/,/^\)/' "$DRIVER"
  echo 'DEADLINE_S=${FH_DEADLINE_S:-60} # FIXTURE (the driver sets this in its mock/prod block)'
  grep '^HARD_STOP_S=' "$DRIVER"
  grep -E '^(declare -A P=\(\)|FINALIZED=0|declare -a INV=|CLOSURE=0|EVID_DURABLE=false|CONTROL_RESULTS=\(\))' "$DRIVER"
  echo '# --- exact functions from the driver'
  for f in $FUNCS; do h_fn "$f"; done
} > "$SRCTEXT"
# exact tail region of run_case (persist_evidence ... up to the standalone finish_case line), executed via eval
awk '/^  persist_evidence # hash \+ sync with checked errors BEFORE stop-post is released$/ { on = 1 } /^  finish_case$/ { on = 0 } on { print }' "$DRIVER" > "$W/region_tail.txt"
bash -n "$SRCTEXT" || { echo "REFUSED: extraction does not parse"; exit 125; }
[[ -s $W/region_tail.txt ]] || { echo "REFUSED: tail region not found"; exit 125; }
for f in $FUNCS; do
  [[ -n $(h_fn "$f") ]] || { echo "REFUSED: function $f not found in driver"; exit 125; }
done
# variants: default, and 'fast' with constant overrides (LABELLED: values only, no logic change)
cp "$SRCTEXT" "$W/src.default.sh"
sed -e 's/CLEANUP_ALLOWANCE_S=120/CLEANUP_ALLOWANCE_S=1/' -e 's/PUBLICATION_ALLOWANCE_S=60/PUBLICATION_ALLOWANCE_S=1/' "$SRCTEXT" > "$W/src.fast.sh"
echo "== extracted from $(basename "$DRIVER") sha256 $EXPECT_SHA"
for f in $FUNCS; do
  ln=$(grep -n "^$f() {" "$DRIVER" | head -n1 | cut -d: -f1)
  printf '   %-24s line %-4s text-sha256 %s\n' "$f" "$ln" "$(h_fn "$f" | sha256sum | cut -c1-16)"
done
echo "   tail-region of run_case  text-sha256 $(sha256sum < "$W/region_tail.txt" | cut -c1-16) ($(wc -l < "$W/region_tail.txt") lines, eval'd)"
echo "   constant overrides in src.fast: CLEANUP_ALLOWANCE_S=1 PUBLICATION_ALLOWANCE_S=1; FH_DEADLINE_S overrides (labelled)"

# ---------------------------------------------------------------- spies / failure injection (PATH wrappers)
mkdir -p "$W/bin"
cat > "$W/bin/jq" <<'EOF'
#!/usr/bin/env bash
K=${FH_KNOBS:?}; a=" $* "
kv() { [[ -r $K/$1 ]] && cat "$K/$1"; }
cnt() { local f=$K/count.$1 n=0; [[ -r $f ]] && n=$(<"$f"); n=$((n + 1)); echo "$n" > "$f"; echo "$n"; }
f=$(kv jq_fail)
case $f in
  case:*) if [[ $a == *"fixture-case-v1"* && $a == *" --arg id ${f#case:} "* ]]; then
      [[ $(kv jq_mkdir) == 1 ]] && { out=$(readlink "/proc/$$/fd/1"); mkdir -p "${out%.tmp}" 2>/dev/null; }
      exit 3
    fi ;;
  result) [[ $a == *"batch-result-v1"* ]] && exit 3 ;;
  result_after:*) if [[ $a == *"batch-result-v1"* ]]; then
      n=$(cnt result)
      if (( n > ${f#result_after:} )); then
        if [[ $(kv jq_mkdir_result_tmp) == 1 ]]; then
          # the driver's own redirection has ALREADY created result.json.tmp as a regular file: set it aside (checked), then make a
          # DIRECTORY there (checked). If the injection cannot be established, say so loudly (marker + exit 97), never silently.
          t=$FH_OUT/result.json.tmp
          if /usr/bin/mkdir -p "$K/aside" && { [[ ! -e $t ]] || /usr/bin/mv -f -- "$t" "$K/aside/result.json.tmp.regular"; } && /usr/bin/mkdir -- "$t" && [[ -d $t ]]; then
            echo injected > "$K/injected.result_tmp_dir"
          else
            echo failed > "$K/injected.result_tmp_dir.FAILED"; exit 97
          fi
        fi
        exit 3
      fi
    fi ;;
  terminal) [[ $a == *"terminal-v1"* ]] && exit 3 ;;
esac
exec /usr/bin/jq "$@"
EOF
cat > "$W/bin/sha256sum" <<'EOF'
#!/usr/bin/env bash
K=${FH_KNOBS:?}; a=" $* "
kv() { [[ -r $K/$1 ]] && cat "$K/$1"; }
cnt() { local f=$K/count.$1 n=0; [[ -r $f ]] && n=$(<"$f"); n=$((n + 1)); echo "$n" > "$f"; echo "$n"; }
case $(kv sha_fail) in
  manifest) [[ $PWD == "$FH_OUT" && $# -gt 2 ]] && exit 3 ;;
  manifest_once) if [[ $PWD == "$FH_OUT" && $# -gt 2 ]]; then n=$(cnt manifest); (( n == 1 )) && exit 3; fi ;;
  result) [[ $a == *"/result.json "* && $# -le 2 ]] && exit 3 ;;
esac
exec /usr/bin/sha256sum "$@"
EOF
cat > "$W/bin/sync" <<'EOF'
#!/usr/bin/env bash
K=${FH_KNOBS:?}; a=" $* "
kv() { [[ -r $K/$1 ]] && cat "$K/$1"; }
case $(kv sync_fail) in
  final) [[ $a == *"/result.json "* ]] && exit 3 ;;
  terminal) [[ $a == *"/TERMINAL.json "* ]] && exit 3 ;;
  evidence) [[ $a == *"/evidence.sha256 "* ]] && exit 3 ;;
esac
exec /usr/bin/sync "$@"
EOF
cat > "$W/bin/mv" <<'EOF'
#!/usr/bin/env bash
K=${FH_KNOBS:?}; a=" $* "
kv() { [[ -r $K/$1 ]] && cat "$K/$1"; }
case $(kv mv_fail) in terminal) [[ $a == *"/TERMINAL.json "* ]] && exit 1 ;; esac
exec /usr/bin/mv "$@"
EOF
cat > "$W/bin/systemctl" <<'EOF'
#!/usr/bin/env bash
# SPY: records every call (command|unit|cgroup.kill content at call time); never touches real systemd.
K=${FH_KNOBS:?}; L=${FH_SPY_LOG:?}
kv() { [[ -r $K/$1 ]] && cat "$K/$1"; }
cmd=$1; shift; unit='' prop='' value=0
for a in "$@"; do case $a in *.service) unit=${a%.service} ;; --property=*) prop=${a#--property=} ;; --value) value=1 ;; esac; done
d=''; [[ -n $unit ]] && d=$(find "$FH_CGROOT" -type d -name "$unit.service" 2>/dev/null | head -n1)
ck=''; [[ -n $d && -r $d/cgroup.kill ]] && ck=$(<"$d/cgroup.kill")
printf '%s|%s|cgroup.kill=%s\n' "$cmd" "$unit" "$ck" >> "$L"
case $cmd in
  --version) echo 'systemd 259 (spy)' ;;
  show)
    if [[ $prop == ControlGroup ]]; then echo "/system.slice/$unit.service"
    elif [[ $prop == ActiveState ]]; then v=$(kv active); echo "${v:-inactive}"
    elif [[ $prop == SubState ]]; then echo stop-post
    elif [[ -r $FH_SHOW_FILE ]]; then cat "$FH_SHOW_FILE"
    fi ;;
  stop) if [[ $(kv stop_drains) != 0 && -n $d ]]; then printf 'populated 0\nfrozen 0\n' > "$d/cgroup.events"; fi ;;
  kill|reset-failed) ;;
esac
exit 0
EOF
cat > "$W/bin/systemd-run" <<'EOF'
#!/usr/bin/env bash
# SPY: never executes the unit command. Records the call, whether the unit was already registered, then fails after
# having "created" the unit (cgroup tree exists), to exercise launch-created-response-failed.
K=${FH_KNOBS:?}; L=${FH_SPY_LOG:?}
kv() { [[ -r $K/$1 ]] && cat "$K/$1"; }
unit=''; for a in "$@"; do [[ $a == --unit=* ]] && unit=${a#--unit=}; done
reg=no; [[ -r $FH_UNITS ]] && grep -qx "$unit" "$FH_UNITS" && reg=yes
printf 'systemd-run|%s|registered=%s\n' "$unit" "$reg" >> "$L"
mkdir -p "$FH_CGROOT/system.slice/$unit.service" && printf 'populated 1\nfrozen 0\n' > "$FH_CGROOT/system.slice/$unit.service/cgroup.events" && : > "$FH_CGROOT/system.slice/$unit.service/cgroup.kill"
rc=$(kv launch_rc); exit "${rc:-3}"
EOF
chmod +x "$W/bin/"*

# ---------------------------------------------------------------- independent acceptance rule (NOT driver logic)
h_accept_core() { # OUT external_exit_code required_mock_marker(true|false): same checks, parameterised ONLY by the marker value
  local o=$1 rc=$2 want=$3 t=$1/TERMINAL.json r=$1/result.json
  [[ $rc == 0 && -s $t && -s $r ]] || return 1
  /usr/bin/jq -e --argjson m "$want" '.mock_seams_active == $m' "$t" > /dev/null 2>&1 || return 1 # TERMINAL marker
  /usr/bin/jq -e --argjson m "$want" '.mock_seams_active == $m' "$r" > /dev/null 2>&1 || return 1 # result marker (consistency with TERMINAL)
  /usr/bin/jq -e '.final_state == "MECHANICS_VERIFIED" and .driver_exit_code == 0' "$t" > /dev/null 2>&1 || return 1
  [[ $(/usr/bin/jq -r .result_sha256 "$t") == "$(/usr/bin/sha256sum "$o/result.json" 2> /dev/null | cut -d' ' -f1)" ]] || return 1
  [[ $(/usr/bin/jq -r .manifest_sha256 "$t") == "$(/usr/bin/sha256sum "$o/SHA256SUMS" 2> /dev/null | cut -d' ' -f1)" ]] || return 1
  /usr/bin/jq -e '.state == "MECHANICS_VERIFIED"' "$r" > /dev/null 2>&1 || return 1
  (cd "$o" && /usr/bin/sha256sum -c --quiet SHA256SUMS) > /dev/null 2>&1
}
h_structural_mock_acceptance() { h_accept_core "$1" "$2" true; }   # harness baseline ONLY (mock=true in BOTH artifacts); NOT production acceptance
h_strict_production_acceptance() { h_accept_core "$1" "$2" false; } # production rule: mock=true anywhere => rejected; markers must also agree
h_not_accepted() { ! h_structural_mock_acceptance "$@" && ! h_strict_production_acceptance "$@"; }
BAD=0
h_chk() { local d=$1; shift; if "$@" 2> /dev/null; then :; else echo "    ASSERT FAILED: $d" >&2; BAD=1; fi; }
h_has() { [[ $1 == *"$2"* ]]; }
h_not() { ! "$@"; }
h_je() { /usr/bin/jq -e "$@" > /dev/null 2>&1; }
h_knob() { printf '%s\n' "$2" > "$FH_KNOBS/$1"; }

# ---------------------------------------------------------------- fixtures (environment only)
h_env() { # fresh OUT/CGROOT/PROC + driver globals as the driver's mock block would provide
  T=$(mktemp -d "$W/t.XXXXXX")
  OUT=$T/out CGROOT=$T/cg PROC=$T/proc
  mkdir -p "$OUT"/{fifo,cases,closed-artifact-controls,bin,scripts} "$CGROOT" "$PROC"
  export FH_OUT=$OUT FH_CGROOT=$CGROOT FH_SPY_LOG=$T/spy.log FH_KNOBS=$T/knobs FH_SHOW_FILE=$T/show.txt FH_UNITS=$OUT/fifo/units
  mkdir -p "$FH_KNOBS"; : > "$FH_SPY_LOG"
  MOCK_ACTIVE=true BATCH=BATCHFIX DRIVER_SHA=$EXPECT_SHA HELPER_SHA=$ZERO64 TIMEOUT_SHA=$ZERO64 ROOT_UID=$(id -u) CLK_TCK=100
  SYSTEMCTL=$W/bin/systemctl SYSTEMD_RUN=$W/bin/systemd-run TIMEOUT_BIN=/usr/bin/timeout
  mkfifo "$T/nap"; exec {NAPFD}<> "$T/nap"
  UNITS=$OUT/fifo/units; : > "$UNITS"
  PUB_ERR=() INV=() INC=() FAIL=() CASE_FILES=() CASE_STATES=()
}
h_cases() { # 12 valid case.json files in frozen roster order + matching state arrays + controls
  local row id i=0 nn cj
  CASE_FILES=() CASE_STATES=()
  for row in "${CASES[@]}"; do
    i=$((i + 1)); id=${row%% *}; printf -v nn '%02d' "$i"
    mkdir -p "$OUT/cases/$nn-$id"; cj=$OUT/cases/$nn-$id/case.json
    /usr/bin/jq -n --arg schema "$CASE_SCHEMA" --arg id "$id" '{schema:$schema, id:$id, state:"MECHANICS_VERIFIED", released:true}' > "$cj"
    CASE_FILES+=("$cj") CASE_STATES+=(MECHANICS_VERIFIED)
  done
  CONTROL_RESULTS=(missing_receipt:MECHANICS_VERIFIED premature_late:MECHANICS_VERIFIED)
}
h_fin() { # runs the REAL finalize; sets frc, FOUT (stdout text)
  finalize "${1:-}" > "$T/fin.stdout" 2> "$T/fin.stderr"; frc=$?
  FOUT=$(< "$T/fin.stdout")
}
h_term() { /usr/bin/jq -r "$1" "$OUT/TERMINAL.json" 2> /dev/null; }

# ================================================================ SECTION fin: finalization / publication
t_fin_happy() {
  h_env; h_cases; h_fin
  h_chk 'exit 0' test "$frc" = 0
  h_chk 'structurally accepted as a MOCK baseline (both markers true, exit 0, hashes)' h_structural_mock_acceptance "$OUT" "$frc"
  h_chk 'both artifacts carry mock_seams_active=true' bash -c '/usr/bin/jq -e ".mock_seams_active == true" "$1/TERMINAL.json" "$1/result.json" > /dev/null' _ "$OUT"
  h_chk 'STRICT production acceptance is FALSE for this mocked case' h_not h_strict_production_acceptance "$OUT" "$frc"
  h_chk 'stdout state MECHANICS_VERIFIED, no publication errors' h_je '.final_state == "MECHANICS_VERIFIED" and (.publication_errors | length) == 0' <<< "$FOUT"
  h_chk 'released processes counted (15)' h_je '.fixture_processes_released == 15' "$OUT/result.json"
  h_chk 'claims all false' h_je '.claims.numerical_CPU_accuracy == false and .claims.overhead_GO == false and .claims.performance == false' "$OUT/result.json"
}
t_fin_marker_mismatch() { # a baseline whose TERMINAL marker disagrees with result.json must satisfy neither predicate
  h_env; h_cases; h_fin
  /usr/bin/jq '.mock_seams_active = false' "$OUT/TERMINAL.json" > "$T/term.edit" && /usr/bin/mv -- "$T/term.edit" "$OUT/TERMINAL.json"
  h_chk 'precondition: the unedited baseline exit was 0' test "$frc" = 0
  h_chk 'inconsistent markers: structural predicate false' h_not h_structural_mock_acceptance "$OUT" "$frc"
  h_chk 'inconsistent markers: strict predicate false (result.json still mock=true)' h_not h_strict_production_acceptance "$OUT" "$frc"
}
t_fin_missing_case() {
  h_env; h_cases; rm -f -- "${CASE_FILES[4]}"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'CASE_FILE_UNREADABLE reported' h_has "$FOUT" CASE_FILE_UNREADABLE
  h_chk 'no success result survives' h_not h_je '.state == "MECHANICS_VERIFIED"' "$OUT/result.json"
  h_chk 'terminal receipt says INVALID/2' test "$(h_term '.final_state + "/" + (.driver_exit_code | tostring)')" = INVALID/2
}
t_fin_empty_case() {
  h_env; h_cases; : > "${CASE_FILES[4]}"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'CASE_FILE_UNREADABLE reported' h_has "$FOUT" CASE_FILE_UNREADABLE
}
t_fin_reordered_case() {
  h_env; h_cases; mv -- "${CASE_FILES[2]}" "$T/swap"; mv -- "${CASE_FILES[3]}" "${CASE_FILES[2]}"; mv -- "$T/swap" "${CASE_FILES[3]}"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'CASES_VALIDATION_FAILED reported' h_has "$FOUT" CASES_VALIDATION_FAILED
}
t_fin_state_mismatch() {
  h_env; h_cases; /usr/bin/jq '.state = "INVALID"' "${CASE_FILES[1]}" > "$T/x" && mv -- "$T/x" "${CASE_FILES[1]}"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'CASES_VALIDATION_FAILED reported' h_has "$FOUT" CASES_VALIDATION_FAILED
}
t_fin_result_jq_fail() {
  h_env; h_cases; h_knob jq_fail result; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'build failure reported' h_has "$FOUT" RESULT_JSON_BUILD_OR_PUBLISH_FAILED
  h_chk 'fallback result is INVALID and mock-marked' h_je '.state == "INVALID" and .mock_seams_active == true' "$OUT/result.json"
}
t_fin_manifest_fail() {
  h_env; h_cases; h_knob sha_fail manifest; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'MANIFEST_FAILED reported' h_has "$FOUT" MANIFEST_FAILED
  h_chk 'result rewritten INVALID' h_je '.state == "INVALID"' "$OUT/result.json"
}
t_fin_final_sync_fail() {
  h_env; h_cases; h_knob sync_fail final; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'FINAL_SYNC_FAILED reported' h_has "$FOUT" FINAL_SYNC_FAILED
}
t_fin_result_sha_fail() {
  h_env; h_cases; h_knob sha_fail result; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'RESULT_SHA_FAILED reported' h_has "$FOUT" RESULT_SHA_FAILED
}
t_fin_terminal_jq_fail() {
  h_env; h_cases; h_knob jq_fail terminal; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'no terminal receipt exists' test ! -e "$OUT/TERMINAL.json"
  h_chk 'stale success result retracted/INVALID' h_not h_je '.state == "MECHANICS_VERIFIED"' "$OUT/result.json"
}
t_fin_terminal_mv_fail() {
  h_env; h_cases; h_knob mv_fail terminal; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'no terminal receipt exists' test ! -e "$OUT/TERMINAL.json"
}
t_fin_terminal_sync_fail() {
  h_env; h_cases; h_knob sync_fail terminal; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'no terminal receipt left' test ! -e "$OUT/TERMINAL.json"
}
t_fin_stdout_fail() {
  h_env; h_cases
  finalize > /dev/full 2> "$T/fin.stderr"; frc=$?
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'terminal receipt says INVALID/2' test "$(h_term '.final_state + "/" + (.driver_exit_code | tostring)')" = INVALID/2
  h_chk 'result republished INVALID with STDOUT_WRITE_FAILED' h_je '.state == "INVALID" and (.publication_errors | index("STDOUT_WRITE_FAILED"))' "$OUT/result.json"
}
t_fin_stale_success_failed_invalid_rewrite() { # pass1 success; manifest fails once; pass2 jq AND fallback printf both fail
  h_env; h_cases; h_knob jq_fail result_after:1; h_knob jq_mkdir_result_tmp 1; h_knob sha_fail manifest_once; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'injection established (checked): result.json.tmp is a DIRECTORY, marker written, no injection-failure marker' test -d "$OUT/result.json.tmp" -a -e "$FH_KNOBS/injected.result_tmp_dir" -a ! -e "$FH_KNOBS/injected.result_tmp_dir.FAILED"
  h_chk 'stale success result.json does not survive' h_not h_je '.state == "MECHANICS_VERIFIED"' "$OUT/result.json"
  h_chk 'fallback write failure retained' h_has "$FOUT" RESULT_FALLBACK_WRITE_FAILED
  h_chk 'terminal receipt INVALID/2 (never success)' test "$(h_term '.final_state + "/" + (.driver_exit_code | tostring)')" = INVALID/2
}
t_fin_deadline_never_success() {
  h_env; h_cases; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; : > "$OUT/fifo/deadline-cleanup-done"; h_fin
  h_chk 'exit 1 (INCONCLUSIVE, never 0)' test "$frc" = 1
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'terminal receipt INCONCLUSIVE/1' test "$(h_term '.final_state + "/" + (.driver_exit_code | tostring)')" = INCONCLUSIVE/1
}
t_fin_deadline_cleanup_failed() {
  h_env; h_cases; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; : > "$OUT/fifo/deadline-cleanup-failed"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'CLEANUP_FAILED and DEADLINE_CLEANUP_NOT_COMPLETED reported' h_has "$FOUT" CLEANUP_FAILED
}
t_fin_hard_stop_marker() {
  h_env; h_cases; : > "$OUT/fifo/hard-stop"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'HARD_STOP_FIRED reported' h_has "$FOUT" HARD_STOP_FIRED
}
t_fin_cleanup_log_failed() {
  h_env; h_cases; echo 'borsuk-ncpu-x CLEANUP_FAILED populated=1' > "$OUT/fifo/cleanup.log"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
}
t_fin_cleanup_log_unreadable() {
  h_env; h_cases; mkdir "$OUT/fifo/cleanup.log"; h_fin
  h_chk 'exit 2' test "$frc" = 2
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
  h_chk 'CLEANUP_LOG_READ_FAILED reported' h_has "$FOUT" CLEANUP_LOG_READ_FAILED
}
t_fin_extra_inconclusive() { # unexpected-interrupt class: extra note => INCONCLUSIVE, never success
  h_env; h_cases; h_fin DRIVER_INTERRUPTED_rc130
  h_chk 'exit 1' test "$frc" = 1
  h_chk 'NOT accepted (structural-mock AND strict-production both false)' h_not_accepted "$OUT" "$frc"
}

# ================================================================ SECTION arb: admission/deadline arbitration (close_admission)
t_arb_driver_wins() {
  h_env; close_admission
  h_chk 'arbiter created by the driver' test -d "$OUT/fifo/arbiter"
  h_chk 'no publication error' test "${#PUB_ERR[@]}" = 0
  h_chk 'batch-done marker written' test -e "$OUT/fifo/batch-done"
}
t_arb_watchdog_won_done() {
  h_env; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; : > "$OUT/fifo/deadline-cleanup-done"; close_admission
  h_chk 'no publication error when the watchdog cleanup is done' test "${#PUB_ERR[@]}" = 0
}
t_arb_watchdog_won_failed() {
  h_env; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; : > "$OUT/fifo/deadline-cleanup-failed"; close_admission
  h_chk 'DEADLINE_CLEANUP_NOT_COMPLETED recorded' h_has "${PUB_ERR[*]:-}" DEADLINE_CLEANUP_NOT_COMPLETED
}
t_arb_watchdog_won_no_outcome() { # uses src.fast (CLEANUP_ALLOWANCE_S=1, labelled)
  h_env; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; close_admission
  h_chk 'DEADLINE_CLEANUP_NOT_COMPLETED after the (overridden 1 s) allowance' h_has "${PUB_ERR[*]:-}" DEADLINE_CLEANUP_NOT_COMPLETED
}
t_arb_mkdir_error() { # arbiter exists but the deadline never fired: unexplained => error (waits ~5 s)
  h_env; mkdir "$OUT/fifo/arbiter"; close_admission
  h_chk 'ARBITER_MKDIR_FAILED recorded' h_has "${PUB_ERR[*]:-}" ARBITER_MKDIR_FAILED
}

# ================================================================ SECTION diag: cpu counters + unwaited witness
h_diag_env() { # initial final: payload cpu.stat samples; report with child CPU 3 ms
  h_env; cdir=$T/case; report=$cdir/report.json; mkdir -p "$cdir/cg"
  [[ $1 != - ]] && printf 'usage_usec %s\nuser_usec 0\nsystem_usec 0\n' "$1" > "$cdir/cg/payload.cpu.stat.initial"
  [[ $2 == EMPTY ]] && : > "$cdir/cg/payload.cpu.stat.final"
  [[ $2 != - && $2 != EMPTY ]] && printf 'usage_usec %s\nuser_usec 0\nsystem_usec 0\n' "$2" > "$cdir/cg/payload.cpu.stat.final"
  printf 'usage_usec 9999\n' > "$cdir/cg/unit.cpu.stat.final"
  /usr/bin/jq -n '{child_cpu:{cpu_ns:3000000}}' > "$report"
  INV=()
}
t_diag() { # initial final expected_reason|ok
  h_diag_env "$1" "$2"; diagnostic
  if [[ $3 == ok ]]; then
    h_chk 'no CPU_STAT_INVALID' test "${#INV[@]}" = 0
    h_chk 'delta fields, both raw samples kept' h_je '.payload_usage_usec_initial == 1000000 and .payload_usage_usec_final == 6000000 and .payload_delta_usec == 5000000 and .payload_delta_ns == 5000000000 and .refused == null and .payload_delta_minus_report_child_ns == 4997000000' "$cdir/diagnostic.json"
  else
    h_chk "CPU_STAT_INVALID:$3 recorded" h_has "${INV[*]:-}" "CPU_STAT_INVALID:$3"
    h_chk 'diagnostic refused, no delta published' h_je --arg r "$3" '.refused == $r and .payload_delta_ns == null and .payload_delta_minus_report_child_ns == null' "$cdir/diagnostic.json"
  fi
}
t_witness() { # delta_usec expect(pass|fail)
  h_diag_env 1000000 $((1000000 + $1)); diagnostic
  /usr/bin/jq -n '[{fixture:"late", injected_cpu_ns:20300000}]' > "$cdir/stdout.json"
  INV=(); unwaited_witness
  if [[ $2 == pass ]]; then h_chk 'witness demonstrated' test "${#INV[@]}" = 0
  else h_chk 'UNWAITED_WITNESS_NOT_DEMONSTRATED' h_has "${INV[*]:-}" UNWAITED_WITNESS_NOT_DEMONSTRATED; fi
}
t_witness_absolute_vs_delta() { # large INITIAL, tiny delta: absolute final would pass, the delta must not
  h_diag_env 100000000 100010000; diagnostic
  /usr/bin/jq -n '[{fixture:"late", injected_cpu_ns:20300000}]' > "$cdir/stdout.json"
  INV=(); unwaited_witness
  h_chk 'refused because the DELTA (10 ms) is too small' h_has "${INV[*]:-}" UNWAITED_WITNESS_NOT_DEMONSTRATED
}

# ================================================================ SECTION fc: finish_case fallback + evidence shapes
h_fc_env() {
  h_env; cdir=$T/case name=01-pulse id=pulse unit=borsuk-ncpu-BATCHFIX-01-pulse gmode=ordinary exp_exit=0 exp_sig=- procs=1 acct=X cfg_sha=$ZERO64 exe=/x
  args=(--fixture pulse); mkdir -p "$cdir"
  RELEASED=false REL_US=null EVID_DURABLE=false PRE_VALIDATED=0 CAPTURED=0 OBSERVED=0 GOFD='' RELFD=''
  INV=() INC=()
}
t_fc_jq_fail_state_invalid() {
  h_fc_env; h_knob jq_fail case:pulse; finish_case
  h_chk 'recorded state INVALID (not the earlier success)' test "${CASE_STATES[-1]}" = INVALID
  h_chk 'fallback case.json INVALID with reason' h_je '.state == "INVALID" and (.reasons.invalid | index("CASE_JSON_BUILD_FAILED")) and .mock_seams_active == true' "$cdir/case.json"
  h_chk 'no publication error when the fallback write works' test "${#PUB_ERR[@]}" = 0
}
t_fc_fallback_write_fail() {
  h_fc_env; h_knob jq_fail case:pulse; h_knob jq_mkdir 1; finish_case
  h_chk 'recorded state INVALID' test "${CASE_STATES[-1]}" = INVALID
  h_chk 'fallback write error retained' h_has "${PUB_ERR[*]:-}" CASE_JSON_FALLBACK_WRITE_FAILED:pulse
}
t_fc_empty_fragment() {
  h_fc_env; : > "$cdir/proc.main.json"; finish_case
  h_chk 'EVIDENCE_SHAPE:proc.main' h_has "${INV[*]:-}" EVIDENCE_SHAPE:proc.main
  h_chk 'state INVALID' test "${CASE_STATES[-1]}" = INVALID
}
t_fc_required_fragment_missing() {
  h_fc_env; PRE_VALIDATED=1; printf 'null\n' > "$cdir/proc.main.json"; finish_case
  h_chk 'EVIDENCE_MISSING:proc.main' h_has "${INV[*]:-}" EVIDENCE_MISSING:proc.main
  h_chk 'state INVALID' test "${CASE_STATES[-1]}" = INVALID
}
t_fc_baseline() {
  h_fc_env; PRE_VALIDATED=1; /usr/bin/jq -n '{pid:1}' > "$cdir/proc.main.json"; finish_case
  h_chk 'state MECHANICS_VERIFIED' test "${CASE_STATES[-1]}" = MECHANICS_VERIFIED
  h_chk 'actual evidence dir name' h_je '.evidence_dir == "cases/01-pulse" and .mock_seams_active == true' "$cdir/case.json"
}

# ================================================================ SECTION cap: capture_stop_post (main PID retained)
h_cap_env() { # $1 = ExecMainPID reported by the spy show
  h_env; cdir=$T/case name=01-pulse id=pulse unit=borsuk-ncpu-BATCHFIX-01-pulse main=123 exp_sig=- exp_exit=0 gmode=ordinary
  cg=/system.slice/$unit.service uc=$CGROOT$cg pc=$CGROOT$cg/payload
  mkdir -p "$cdir/cg" "$pc" "$PROC/555"
  local b; for b in "$uc" "$pc"; do
    printf 'populated 0\nfrozen 0\n' > "$b/cgroup.events"; : > "$b/cgroup.procs"
    printf 'usage_usec 5\n' > "$b/cpu.stat"; printf 'low 0\nmax 0\noom 0\noom_kill 0\n' > "$b/memory.events"; printf 'max 0\n' > "$b/pids.events"
  done
  printf '0::%s/.control\n' "$cg" > "$PROC/555/cgroup"
  printf 'ExecMainPID=%s\nExecMainCode=1\nExecMainStatus=0\nResult=success\nActiveState=deactivating\nSubState=stop-post\nControlPID=555\nExecMainExitTimestampMonotonic=1\n' "$1" > "$FH_SHOW_FILE"
  check_native_outputs() { :; } # SPY for the (separately covered elsewhere / unexercised here) output oracles
  INV=() FAIL=() CAPTURED=0
}
t_cap_pid_mismatch() {
  h_cap_env 999; capture_stop_post
  h_chk 'ExecMainPID mismatch is RETAINED' h_has "${INV[*]:-}" 'EXEC_MAIN:exec.main.pid: got [999] want [123]'
}
t_cap_pid_match() {
  h_cap_env 123; capture_stop_post
  h_chk 'no EXEC_MAIN entries when the PID matches' h_not h_has "${INV[*]:-}" EXEC_MAIN
  h_chk 'exec-main evidence written as one object' h_je 'type == "object" and .ExecMainPID == "123"' "$cdir/exec-main.json"
}
t_cap_hold_in_payload() {
  h_cap_env 123; printf '0::%s/payload\n' "$cg" > "$PROC/555/cgroup"; capture_stop_post
  h_chk 'HOLD_NOT_IN_CONTROL_CGROUP' h_has "${INV[*]:-}" HOLD_NOT_IN_CONTROL_CGROUP
}

# ================================================================ SECTION kill: kill_owned_units / unit_cg
h_unit() { # n id: owned unit with a populated fake cgroup + release FIFO
  U=borsuk-ncpu-BATCHFIX-$1-$2
  mkdir -p "$CGROOT/system.slice/$U.service"; printf 'populated 1\nfrozen 0\n' > "$CGROOT/system.slice/$U.service/cgroup.events"; : > "$CGROOT/system.slice/$U.service/cgroup.kill"
  mkfifo "$OUT/fifo/$1-$2.release"; printf '%s\n' "$U" >> "$UNITS"
}
t_kill_order_and_fifo() {
  h_env; h_unit 01 pulse; exec 8<> "$OUT/fifo/01-pulse.release"
  kill_owned_units "$U"; krc=$?
  h_chk 'returns 0 (drained)' test "$krc" = 0
  h_chk 'DIRECT cgroup.kill was written BEFORE the first manager kill' h_has "$(grep '^kill|' "$FH_SPY_LOG" | head -n1)" 'cgroup.kill=1'
  h_chk 'cleanup.log records drained=0' h_has "$(< "$OUT/fifo/cleanup.log")" "$U drained=0"
  h_chk 'hold FIFO was released' test "$(read -r -t 2 -u 8 x; echo "$x")" = release
}
t_kill_exact_unit_only() {
  h_env; h_unit 01 pulse; U1=$U; h_unit 02 threads; U2=$U
  kill_owned_units "$U1"
  h_chk 'only the named unit was addressed' h_not h_has "$(< "$FH_SPY_LOG")" "|$U2|"
  h_chk 'named unit killed and stopped' h_has "$(< "$FH_SPY_LOG")" "stop|$U1|"
}
t_kill_foreign_ignored() {
  h_env; kill_owned_units not-an-owned-unit; krc=$?
  h_chk 'returns 0' test "$krc" = 0
  h_chk 'no manager call for a foreign unit' test ! -s "$FH_SPY_LOG"
}
t_kill_uses_recorded_cg() {
  h_env; h_unit 01 pulse; rm -rf "${CGROOT:?}/system.slice"
  mkdir -p "$CGROOT/custom.slice/$U.service"; printf 'populated 1\nfrozen 0\n' > "$CGROOT/custom.slice/$U.service/cgroup.events"; : > "$CGROOT/custom.slice/$U.service/cgroup.kill"
  printf '/custom.slice/%s.service\n' "$U" > "$OUT/fifo/01-pulse.cg"
  kill_owned_units "$U"
  h_chk 'actual ControlGroup path used' test "$(< "$CGROOT/custom.slice/$U.service/cgroup.kill")" = 1
  h_chk 'name-derived path not invented' test ! -e "$CGROOT/system.slice"
}
t_kill_invalid_recorded_cg_falls_back() {
  h_env; h_unit 01 pulse; printf '/../evil/%s.service\n' "$U" > "$OUT/fifo/01-pulse.cg"
  h_chk 'traversal-looking record rejected' test "$(unit_cg "$U")" = "/system.slice/$U.service"
}
t_kill_cleanup_failure() { # stop does not drain: ~10 s bounded loop
  h_env; h_unit 01 pulse; h_knob stop_drains 0
  kill_owned_units "$U"; krc=$?
  h_chk 'returns 1' test "$krc" = 1
  h_chk 'CLEANUP_FAILED logged' h_has "$(< "$OUT/fifo/cleanup.log")" 'CLEANUP_FAILED populated=1'
}

# ================================================================ SECTION launch: launch-created-response-failed
t_launch_created_response_failed() {
  h_env; H=$OUT/bin/native_process_cpu
  printf '#!/bin/sh\necho executed > "%s/TRIPWIRE"\n' "$W" > "$H"; chmod +x "$H"
  HELPER_BIN=$H HELPER_BYTES=$(stat -c %s "$H") HELPER_SHA=$(/usr/bin/sha256sum "$H" | cut -d' ' -f1) TIMEOUT_BYTES=1 GATE_SHA=$ZERO64 HOLD_SHA=$ZERO64
  run_case 1 pulse ordinary 0 - 1 UNQUALIFIED_UNTIL_RUNTIME_EVIDENCE; rc=$?
  local U=borsuk-ncpu-BATCHFIX-01-pulse
  h_chk 'run_case returns 3 (the STOP code the main loop maps to NOT_RUN_AFTER_PRE_RELEASE_FAILURE)' test "$rc" = 3
  h_chk 'LAUNCH_FAILED_rc3 recorded' h_has "${INV[*]:-}" LAUNCH_FAILED_rc3
  h_chk 'unit was registered BEFORE the launcher ran' h_has "$(< "$FH_SPY_LOG")" "systemd-run|$U|registered=yes"
  h_chk 'exact unit killed' h_has "$(< "$FH_SPY_LOG")" "kill|$U|"
  h_chk 'exact unit stopped' h_has "$(< "$FH_SPY_LOG")" "stop|$U|"
  h_chk 'direct cgroup.kill written for the created unit' test "$(< "$CGROOT/system.slice/$U.service/cgroup.kill")" = 1
  h_chk 'cleanup.log: exact unit drained, nothing else' test "$(< "$OUT/fifo/cleanup.log")" = "$U drained=0"
  h_chk 'case recorded INVALID' test "${CASE_STATES[-1]}" = INVALID
  h_chk 'gate never ready / helper never ran' h_not test -e "$OUT/fifo/01-pulse.ready"
  h_chk 'no report was ever created' h_not test -e "$OUT/cases/01-pulse/report.json"
  h_chk 'tripwire clear (helper never executed)' h_not test -e "$W/TRIPWIRE"
  h_chk 'launcher invoked exactly once (no retry)' test "$(grep -c '^systemd-run|' "$FH_SPY_LOG")" = 1
}

# ================================================================ SECTION tail: exact run_case tail region (hold-ok / deadline-after-hold)
t_tail() { # scenario
  h_env; cdir=$T/case; mkdir -p "$cdir/cg"; unit=borsuk-ncpu-BATCHFIX-01-pulse holdok=$OUT/fifo/01-pulse.hold-ok rc=0 pc=$T/no-such-payload
  INV=() INC=() CLOSURE=0 EVID_DURABLE=false
  case $1 in
    holdok-missing) h_knob active inactive ;;
    holdok-present) h_knob active inactive; : > "$holdok" ;;
    deadline-done) h_knob active active; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; : > "$OUT/fifo/deadline-cleanup-done" ;;
    deadline-failed) h_knob active active; mkdir "$OUT/fifo/arbiter"; : > "$OUT/fifo/deadline-fired"; : > "$OUT/fifo/deadline-cleanup-failed" ;;
    holdok-not-required-after-timeout) h_knob active inactive; rc=1 ;;
  esac
  local RELFD; exec {RELFD}> "$cdir/relsink"
  eval "$(< "$W/region_tail.txt")"
  case $1 in
    holdok-missing)
      h_chk 'HOLD_DID_NOT_COMPLETE' h_has "${INV[*]:-}" HOLD_DID_NOT_COMPLETE
      h_chk 'closure failure flagged' test "$CLOSURE" = 1 ;;
    holdok-present)
      h_chk 'no invalid reasons' test "${#INV[@]}" = 0
      h_chk 'closure not flagged' test "$CLOSURE" = 0
      h_chk 'final show recorded' test -s "$cdir/show.final.txt" -o -e "$cdir/show.final.txt" ;;
    deadline-done)
      h_chk 'post-hold deadline recorded (not swallowed)' h_has "${INC[*]:-}" BATCH_DEADLINE_AFTER_HOLD_RELEASE
      h_chk 'checked cleanup outcome accepted' test "${#INV[@]}" = 0 ;;
    deadline-failed)
      h_chk 'post-hold deadline recorded' h_has "${INC[*]:-}" BATCH_DEADLINE_AFTER_HOLD_RELEASE
      h_chk 'failed cleanup outcome => invalid' h_has "${INV[*]:-}" DEADLINE_CLEANUP_NOT_COMPLETED ;;
    holdok-not-required-after-timeout)
      h_chk 'no HOLD_DID_NOT_COMPLETE when the case already failed earlier' h_not h_has "${INV[*]:-}" HOLD_DID_NOT_COMPLETE ;;
  esac
}

# ================================================================ SECTION persist: evidence durability
t_persist() { # ok|sync-fail
  h_env; cdir=$T/case; mkdir -p "$cdir/cg"; echo x > "$cdir/stdout"; INV=() CLOSURE=0 EVID_DURABLE=false
  [[ $1 == sync-fail ]] && h_knob sync_fail evidence
  persist_evidence
  if [[ $1 == ok ]]; then
    h_chk 'durable' test "$EVID_DURABLE" = true
    h_chk 'evidence.sha256 lists the evidence' h_has "$(< "$cdir/evidence.sha256")" ./stdout
  else
    h_chk 'EVIDENCE_SYNC_FAILED' h_has "${INV[*]:-}" EVIDENCE_SYNC_FAILED
    h_chk 'not durable and closure failure' test "$EVID_DURABLE/$CLOSURE" = false/1
    h_chk 'failed evidence retained' test -s "$cdir/evidence.sha256"
  fi
}

# ================================================================ SECTION wd: start_watchdog (real process, sacrificial driver)
h_wd() { # mode variant deadline_s first_cleanup_blocks(0|1) block_s -> sets wrc wdir
  wdir=$(mktemp -d "$W/wd.XXXXXX"); mkdir -p "$wdir/out/fifo" "$wdir/knobs"
  export FH_KNOBS=$wdir/knobs FH_SPY_LOG=$wdir/spy.log FH_OUT=$wdir/out FH_CGROOT=$wdir/cg
  cat > "$wdir/driver.sh" <<'EOS'
set -uo pipefail
source "$FH_SRC"
PATH=$FH_BIN:/usr/bin:/bin
OUT=$FH_WOUT BATCH=BATCHFIX MOCK_ACTIVE=true
mkfifo "$OUT/fifo/nap"; exec {NAPFD}<> "$OUT/fifo/nap"
kill_owned_units() { # SPY replacing the exact function (a dependency of start_watchdog): counts calls, may block the FIRST one
  local n=0; [[ -r $OUT/fifo/ko.count ]] && n=$(< "$OUT/fifo/ko.count"); n=$((n + 1)); echo "$n" > "$OUT/fifo/ko.count"
  echo "call $n" >> "$OUT/fifo/ko.log"
  if (( n == 1 )) && [[ ${FH_BLOCK_FIRST:-0} == 1 ]]; then read -r -t "${FH_BLOCK_S:-10}" -u "$NAPFD" || :; fi
  return 0
}
start_watchdog
case $FH_MODE in
  driver-wins) read -r -t 0.3 -u "$NAPFD" || :; mkdir "$OUT/fifo/arbiter"; read -r -t 2.5 -u "$NAPFD" || :; : > "$OUT/fifo/terminal-done" ;;
  watchdog-wins) read -r -t 3 -u "$NAPFD" || :; : > "$OUT/fifo/terminal-done" ;;
  hard-stop) read -r -t 40 -u "$NAPFD" || : ;;
esac
wait
EOS
  FH_SRC=$W/src.$2.sh FH_BIN=$W/bin FH_WOUT=$wdir/out FH_MODE=$1 FH_DEADLINE_S=$3 FH_BLOCK_FIRST=$4 FH_BLOCK_S=$5 setsid bash "$wdir/driver.sh" > "$wdir/driver.log" 2>&1 &
  wpid=$!
  wait "$wpid"; wrc=$?
  sleep 1 # let the (independent) hard-stop process finish its post-kill steps before the group is reaped
  kill -KILL -- "-$wpid" 2> /dev/null
  return 0
}
t_wd_driver_wins() {
  h_wd driver-wins default 1 0 0
  local o=$wdir/out/fifo
  h_chk 'driver exit 0' test "$wrc" = 0
  h_chk 'the driver won the arbiter: no deadline intervention' h_not test -e "$o/deadline-fired"
  h_chk 'cleanup never ran' h_not test -e "$o/ko.count"
}
t_wd_watchdog_wins() {
  h_wd watchdog-wins default 1 0 0
  local o=$wdir/out/fifo
  h_chk 'driver exit 0' test "$wrc" = 0
  h_chk 'deadline fired and arbiter created by the watchdog' test -e "$o/deadline-fired" -a -d "$o/arbiter"
  h_chk 'checked cleanup outcome published (done)' test -e "$o/deadline-cleanup-done"
  h_chk 'cleanup ran exactly once' test "$(< "$o/ko.count")" = 1
}
t_wd_hard_stop_independent_of_slow_cleanup() { # src.fast: allowances 1+1 => hard stop at 3 s; the first (deadline) cleanup blocks 12 s
  local t0=${EPOCHREALTIME/./}
  h_wd hard-stop fast 1 1 12
  local o=$wdir/out/fifo dt=$(( (${EPOCHREALTIME/./} - t0) / 1000000 ))
  h_chk 'driver was killed (SIGKILL=137)' test "$wrc" = 137
  h_chk 'killed well before the 12 s blocked cleanup ended' test "$dt" -lt 9
  h_chk 'hard-stop marker' test -e "$o/hard-stop"
  h_chk 'hard-stop process wrote an INVALID hard_stop result' h_je '.state == "INVALID" and .hard_stop == true' "$wdir/out/result.json"
  h_chk 'no terminal receipt (nothing can be accepted)' test ! -e "$wdir/out/TERMINAL.json"
  h_chk 'hard-stop process finished its post-kill steps' test -e "$o/terminal-done"
  h_chk 'cleanup was attempted by both processes' test "$(< "$o/ko.count")" -ge 2
}

# ---------------------------------------------------------------- runner
sel() { [[ $SECTIONS == all || " $SECTIONS " == *" $1 "* ]]; }
run_test() { # section variant name func args...
  local sec=$1 variant=$2 name=$3; shift 3
  sel "$sec" || return 0
  if (( $(h_elapsed) > BUDGET_S )); then echo "SKIP(budget) $name"; SKIPN=$((SKIPN + 1)); return 0; fi
  if ( source "$W/src.$variant.sh" && PATH=$W/bin:/usr/bin:/bin && BAD=0 && "$@" && exit "$BAD" ) > "$W/log.$name" 2>&1; then
    echo "PASS $name"; PASS=$((PASS + 1))
  else
    echo "FAIL $name"; sed 's/^/    | /' "$W/log.$name" | head -n 25; FAILN=$((FAILN + 1))
  fi
}

run_test fin default fin_happy t_fin_happy
run_test fin default fin_marker_mismatch t_fin_marker_mismatch
run_test fin default fin_missing_case t_fin_missing_case
run_test fin default fin_empty_case t_fin_empty_case
run_test fin default fin_reordered_case t_fin_reordered_case
run_test fin default fin_state_mismatch t_fin_state_mismatch
run_test fin default fin_result_jq_fail t_fin_result_jq_fail
run_test fin default fin_manifest_fail t_fin_manifest_fail
run_test fin default fin_final_sync_fail t_fin_final_sync_fail
run_test fin default fin_result_sha_fail t_fin_result_sha_fail
run_test fin default fin_terminal_jq_fail t_fin_terminal_jq_fail
run_test fin default fin_terminal_mv_fail t_fin_terminal_mv_fail
run_test fin default fin_terminal_sync_fail t_fin_terminal_sync_fail
run_test fin default fin_stdout_fail t_fin_stdout_fail
run_test fin default fin_stale_success_failed_invalid_rewrite t_fin_stale_success_failed_invalid_rewrite
run_test fin default fin_deadline_never_success t_fin_deadline_never_success
run_test fin default fin_deadline_cleanup_failed t_fin_deadline_cleanup_failed
run_test fin default fin_hard_stop_marker t_fin_hard_stop_marker
run_test fin default fin_cleanup_log_failed t_fin_cleanup_log_failed
run_test fin default fin_cleanup_log_unreadable t_fin_cleanup_log_unreadable
run_test fin default fin_extra_inconclusive t_fin_extra_inconclusive
run_test diag default diag_normal t_diag 1000000 6000000 ok
run_test diag default diag_decreasing t_diag 6000000 1000000 cpu_stat_decreased
run_test diag default diag_malformed t_diag 1000000 abc cpu_stat_missing_or_malformed
run_test diag default diag_overflow_digits t_diag 1000000 1234567890123456 cpu_stat_missing_or_malformed
run_test diag default diag_delta_over_one_hour t_diag 1 3600000002 cpu_stat_delta_over_one_hour
run_test diag default diag_missing_final t_diag 1000000 - cpu_stat_missing_or_malformed
run_test diag default diag_empty_final t_diag 1000000 EMPTY cpu_stat_missing_or_malformed
run_test diag default diag_missing_initial t_diag - 6000000 cpu_stat_missing_or_malformed
run_test diag default witness_pass t_witness 5000000 pass
run_test diag default witness_small_delta t_witness 10000 fail
run_test diag default witness_delta_not_absolute t_witness_absolute_vs_delta
run_test fc default fc_jq_fail_state_invalid t_fc_jq_fail_state_invalid
run_test fc default fc_fallback_write_fail t_fc_fallback_write_fail
run_test fc default fc_empty_fragment t_fc_empty_fragment
run_test fc default fc_required_fragment_missing t_fc_required_fragment_missing
run_test fc default fc_baseline t_fc_baseline
run_test cap default cap_pid_mismatch t_cap_pid_mismatch
run_test cap default cap_pid_match t_cap_pid_match
run_test cap default cap_hold_in_payload t_cap_hold_in_payload
run_test kill default kill_order_and_fifo t_kill_order_and_fifo
run_test kill default kill_exact_unit_only t_kill_exact_unit_only
run_test kill default kill_foreign_ignored t_kill_foreign_ignored
run_test kill default kill_uses_recorded_cg t_kill_uses_recorded_cg
run_test kill default kill_invalid_recorded_cg t_kill_invalid_recorded_cg_falls_back
run_test launch default launch_created_response_failed t_launch_created_response_failed
run_test tail default tail_holdok_missing t_tail holdok-missing
run_test tail default tail_holdok_present t_tail holdok-present
run_test tail default tail_deadline_done t_tail deadline-done
run_test tail default tail_deadline_failed t_tail deadline-failed
run_test tail default tail_holdok_not_required_after_timeout t_tail holdok-not-required-after-timeout
run_test persist default persist_ok t_persist ok
run_test persist default persist_sync_fail t_persist sync-fail
run_test arb default arb_driver_wins t_arb_driver_wins
run_test arb default arb_watchdog_won_done t_arb_watchdog_won_done
run_test arb default arb_watchdog_won_failed t_arb_watchdog_won_failed
run_test arb fast arb_watchdog_won_no_outcome t_arb_watchdog_won_no_outcome
run_test arb default arb_mkdir_error t_arb_mkdir_error
run_test wd default wd_driver_wins t_wd_driver_wins
run_test wd default wd_watchdog_wins t_wd_watchdog_wins
run_test wd fast wd_hard_stop_independent t_wd_hard_stop_independent_of_slow_cleanup
run_test kill default kill_cleanup_failure t_kill_cleanup_failure # slowest (~10 s): last among the kill tests

# ---------------------------------------------------------------- summary
trip=clear; [[ -e $W/TRIPWIRE ]] && trip=TRIPPED
elapsed=$(h_elapsed)
cat <<EOF
== SCOPE (honest): source-bound FUNCTION-LEVEL / exact-region execution with spies; 0 helper, 0 fixture, 0 real-systemd invocations.
   NOT exercised: admission (all of it), run_case pre-release validation + release/observe middle, observe_survivor, check_native_outputs
   oracles, closed_controls, main loop and on_exit abort classes, unit_ended 15 s timeout, 60 s production deadline (deadline-like
   branches use pre-seeded markers or labelled constant overrides), real systemd/cgroup/.control semantics, ext4+syncfs durability
   (ran on /tmp), EPOCHREALTIME clock steps. No local run was made by the author; first execution is root's bounded remote run.
EOF
printf '{"harness":"fault-harness.sh","driver_sha256":"%s","passed":%d,"failed":%d,"skipped_budget":%d,"elapsed_s":%s,"budget_s":%s,"helper_or_fixture_invocations":0,"tripwire":"%s","workdir":"%s"}\n' \
  "$EXPECT_SHA" "$PASS" "$FAILN" "$SKIPN" "$elapsed" "$BUDGET_S" "$trip" "$W"
(( FAILN == 0 && SKIPN == 0 )) && [[ $trip == clear ]] && exit 0
exit 1
