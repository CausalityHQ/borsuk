readonly SCTL_S=10 STOP_S=20 LAUNCH_S=30
readonly MEMORY_MAX=268435456 PIDS_MAX=128 PAYLOAD=payload
declare -A P=()
tmo() { local t=$1 b=$TIMEOUT_BIN; shift; [[ $MOCK_ACTIVE == true ]] && b=timeout; "$b" -k 2 "$t" "$@"; }
span_us() { # systemd human timespan (us ms s min h) -> microseconds; anything else is refused
  local -a toks; local tok total=0
  [[ -n $1 && $1 != infinity ]] || return 1
  read -ra toks <<<"$1"
  for tok in "${toks[@]}"; do
    [[ $tok =~ ^([0-9]+)(us|ms|s|min|h)$ ]] || return 1
    case ${BASH_REMATCH[2]} in
      us) total=$((total + BASH_REMATCH[1])) ;;
      ms) total=$((total + BASH_REMATCH[1] * 1000)) ;;
      s) total=$((total + BASH_REMATCH[1] * 1000000)) ;;
      min) total=$((total + BASH_REMATCH[1] * 60000000)) ;;
      h) total=$((total + BASH_REMATCH[1] * 3600000000)) ;;
    esac
  done
  printf '%s' "$total"
}
nap() { read -r -t "$1" -u "$NAPFD" || :; }
ev() { local k v; [[ -r $1 ]] || return 1; while read -r k v; do [[ $k == "$2" ]] && { printf '%s' "$v"; return 0; }; done < "$1"; return 1; }
rd() { local v; if IFS= read -r v 2>/dev/null < "$1"; then printf '%s' "$v"; else printf '<unreadable>'; fi; }
dl() { [[ -e $OUT/fifo/deadline-fired ]]; }
wait_for() { # seconds predicate...: 0 ok, 1 timeout, 2 batch deadline (checked BEFORE the predicate: nothing succeeds after expiry)
  local limit=$(( ${EPOCHREALTIME/./} + $1 * 1000000 )); shift
  while :; do
    dl && return 2
    "$@" && return 0
    (( ${EPOCHREALTIME/./} < limit )) || return 1
    nap "${POLL:-0.005}" # POLL=0.05 for predicates that fork systemctl
  done
}
show_to() { # unit file: full `systemctl show` into file and P[]
  local k v
  P=()
  tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager -- "$1.service" > "$2" 2>/dev/null || return 1
  while IFS='=' read -r k v; do P[$k]=$v; done < "$2"
}
sub_stop_post() { [[ $(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=SubState --value -- "$unit.service" 2>/dev/null) == stop-post ]]; }
unit_ended() { [[ $(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ActiveState --value -- "$unit.service" 2>/dev/null) =~ ^(inactive|failed)$ ]]; }
payload_drained() { [[ ! -e $pc/cgroup.events ]] || [[ $(ev "$pc/cgroup.events" populated) == 0 ]]; }
unit_cg() { # unit -> ACTUAL ControlGroup: recorded at pre-release, else asked of systemd (bounded); name-derived path only as last resort
  local u=$1 n=${1#"borsuk-ncpu-$BATCH-"} c=''
  [[ -r $OUT/fifo/$n.cg ]] && c=$(<"$OUT/fifo/$n.cg")
  [[ -n $c ]] || c=$(tmo "$SCTL_S" "$SYSTEMCTL" show --no-pager --property=ControlGroup --value -- "$u.service" 2>/dev/null)
  [[ $c == /*"/$u.service" && $c != *..* ]] || c=/system.slice/$u.service
  printf '%s' "$c"
}
kill_owned_units() { # [unit...]: default every unit this run named
  local -a us=("$@")
  (( ${#us[@]} )) || mapfile -t us < "$UNITS"
  local u cg i rf rfd pop rc=0
  for u in "${us[@]}"; do
    [[ $u == "borsuk-ncpu-$BATCH-"* ]] || continue
    cg=$CGROOT$(unit_cg "$u")
    rf=$OUT/fifo/${u#"borsuk-ncpu-$BATCH-"}.release
    if [[ -p $rf ]] && { exec {rfd}<>"$rf"; } 2>/dev/null; then printf 'release\n' >&"$rfd"; exec {rfd}>&-; fi
    [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
    tmo "$SCTL_S" "$SYSTEMCTL" kill --kill-whom=all --signal=SIGKILL -- "$u.service" >/dev/null 2>&1
    [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
    tmo "$STOP_S" "$SYSTEMCTL" stop -- "$u.service" >/dev/null 2>&1
    for ((i = 0; i < 100; i++)); do
      [[ -e $cg/cgroup.events && $(ev "$cg/cgroup.events" populated) != 0 ]] || break
      (( i % 10 == 9 )) && tmo "$SCTL_S" "$SYSTEMCTL" kill --kill-whom=all --signal=SIGKILL -- "$u.service" >/dev/null 2>&1
      [[ -w $cg/cgroup.kill ]] && printf '1\n' > "$cg/cgroup.kill" 2>/dev/null
      nap 0.1
    done
    tmo "$SCTL_S" "$SYSTEMCTL" reset-failed -- "$u.service" >/dev/null 2>&1
    pop=gone
    [[ -e $cg/cgroup.events ]] && { pop=$(ev "$cg/cgroup.events" populated) || pop=unreadable; }
    if [[ $pop == gone || $pop == 0 ]]; then printf '%s drained=%s\n' "$u" "$pop" >> "$OUT/fifo/cleanup.log"
    else printf '%s CLEANUP_FAILED populated=%s\n' "$u" "$pop" >> "$OUT/fifo/cleanup.log"; rc=1; fi
  done
  return "$rc"
}
