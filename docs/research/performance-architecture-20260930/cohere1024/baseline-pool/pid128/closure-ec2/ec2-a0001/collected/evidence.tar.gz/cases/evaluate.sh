set -Eeuo pipefail
export LC_ALL=C
source "$1/functions.sh"
source "$1/types.sh"
recipe_sha=$2; config_copy=$3/config.json
campaign_evidence_root=$3/campaign; evidence=$3/evaluation
authenticate_admission_closure "$campaign_evidence_root/admission/admission.json"
