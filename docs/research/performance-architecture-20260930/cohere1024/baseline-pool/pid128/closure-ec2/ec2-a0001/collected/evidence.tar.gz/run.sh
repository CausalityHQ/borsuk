set -Eeuo pipefail
root=/var/lib/borsuk-validator
cg=$(awk -F: '$1==0 {print $3}' /proc/self/cgroup)
[[ $cg == /system.slice/borsuk-validator-tests.service ]] || exit 125
c=/sys/fs/cgroup$cg
cat /proc/self/status > "$root/process.status"
for file in cpu.max memory.max memory.swap.max pids.max memory.events pids.events; do
    cat "$c/$file" > "$root/$file.before"
done
[[ $(awk '/^Cpus_allowed_list:/ {print $2}' /proc/self/status) == 0 ]] || exit 125
[[ $(cat "$c/cpu.max") == '100000 100000' ]] || exit 125
[[ $(cat "$c/memory.max") == 268435456 && $(cat "$c/memory.swap.max") == 0 && $(cat "$c/pids.max") == 128 ]] || exit 125
rc=0
bash "$root/harness.sh" "$root/recipe.sh" "$root/cases" || rc=$?
printf '%s\n' "$rc" > "$root/harness.exit"
for file in memory.events pids.events cpu.stat; do cat "$c/$file" > "$root/$file.after"; done
exit "$rc"
