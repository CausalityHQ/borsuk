die() { printf 'INVALID: %s\n' "$*" >&2; exit 98; }
canonical() {
    [[ $1 == /* && $1 != *[$'\t\r\n\\']* && $(realpath -e -- "$1") == "$1" ]] || die "noncanonical: $1"
}
sha_of() { local digest; digest=$(sha256sum < "$1"); printf '%s\n' "${digest%% *}"; }
authenticate() {
    local path=$1 bytes=$2 sha=$3 stamp
    canonical "$path"
    [[ -f $path && ! -L $path && $bytes =~ ^[1-9][0-9]*$ && $sha =~ ^[0-9a-f]{64}$ ]] || die "file pin: $path"
    stamp=$(stat -c '%d:%i:%s:%y:%z' -- "$path")
    [[ $(stat -c %s -- "$path") == "$bytes" && $(sha_of "$path") == "$sha" && $(stat -c '%d:%i:%s:%y:%z' -- "$path") == "$stamp" ]] || die "identity drift: $path"
    jq -cn --arg path "$path" --argjson bytes "$bytes" --arg sha256 "$sha" --arg stamp "$stamp" \
        '{path:$path,bytes:$bytes,sha256:$sha256,stamp:$stamp}'
}
descriptor() { authenticate "$1" "$(stat -c %s -- "$1")" "$(sha_of "$1")" | jq 'del(.stamp)'; }
small_json() {
    canonical "$1"
    [[ -f $1 && ! -L $1 ]] || die 'JSON regular file'
    local bytes; bytes=$(stat -c %s -- "$1")
    (( bytes > 0 && bytes <= 65536 )) || die "JSON cap: $1"
    one_object "$1" 65536
}
one_object() {
    local path=$1 cap=$2 bytes
    canonical "$path"
    [[ -f $path && ! -L $path ]] || die 'JSON object regular file'
    bytes=$(stat -c %s -- "$path")
    (( bytes > 0 && bytes <= cap )) || die 'JSON object byte cap'
    jq -es 'length==1 and (.[0]|type=="object")' "$path" >/dev/null || die 'exactly one JSON object required'
}
auth_art() {
    local art=$1 path bytes sha
    path=$(jq -er .path <<< "$art"); bytes=$(jq -er .bytes <<< "$art"); sha=$(jq -er .sha256 <<< "$art")
    authenticate "$path" "$bytes" "$sha"
}
cfg() { jq -er "$1" "$config_copy"; }
authenticate_admission_closure() {
    local admission_path=$1 admission_dir key path terminal manifest wrapper outer raw_manager raw_exit raw_events
    local admission_sha terminal_sha manifest_sha wrapper_sha outer_unit outer_id outer_cg
    admission_dir=${admission_path%/*}
    canonical "$admission_dir"
    [[ $admission_path == "$admission_dir/admission.json" &&
       $admission_dir == "$campaign_evidence_root/"* ]] || die 'admission evidence location'
    for key in terminal manifest wrapper_exit outer; do
        path=$(cfg ".admission_closure.$key.path")
        [[ $path == "$campaign_evidence_root/"* ]] || die 'closure outside counted campaign evidence'
        (( $(cfg ".admission_closure.$key.bytes") <= 4194304 )) || die 'closure artifact cap'
        auth_art "$(cfg ".admission_closure.$key")" > "$evidence/admission-$key.identity"
    done
    terminal=$(cfg .admission_closure.terminal.path)
    manifest=$(cfg .admission_closure.manifest.path)
    wrapper=$(cfg .admission_closure.wrapper_exit.path)
    outer=$(cfg .admission_closure.outer.path)
    [[ $terminal == "$admission_dir/terminal.json" && $manifest == "$admission_dir/closure.sha256" &&
       $wrapper == "$admission_dir/wrapper.exit" && $outer != "$admission_dir/"* ]] || die 'closure artifact roles'
    small_json "$terminal"; small_json "$outer"
    admission_sha=$(cfg .admission.sha256)
    terminal_sha=$(cfg .admission_closure.terminal.sha256)
    manifest_sha=$(cfg .admission_closure.manifest.sha256)
    wrapper_sha=$(cfg .admission_closure.wrapper_exit.sha256)
    jq -e --slurpfile a "$admission_path" '
      .schema=="borsuk-native-pid128-terminal-v1" and .status=="SOURCE_ADMITTED_ROOT_GATE_REQUIRED" and
      .stage=="closure" and .original_exit==0 and .intended_exit==0 and .cleanup_exit==0 and
      .config_sha256==$a[0].config_sha256 and .original_observer_manager_and_outer_exits_required==true and
      .performance_claim==false and .cold_claim==false and .competitor_claim==false and .one_million_claim==false' \
        "$terminal" > "$evidence/admission-terminal.validated"
    [[ $(stat -c %s "$wrapper") == 2 && $(< "$wrapper") == 0 ]] || die 'admission wrapper exit'
    # Authenticate the exact immutable closure roster, not merely selected hashes.
    awk -v a="$admission_sha" -v t="$terminal_sha" '
      {digest=substr($0,1,64); path=substr($0,69);
       if (length(digest)!=64 || digest ~ /[^0-9a-f]/ || substr($0,65,4)!="  ./" ||
           path !~ /^[A-Za-z0-9._\/-]+$/ || path ~ /(^|\/)\.\.?($|\/)/ || seen[path]++) exit 1;
       if (path=="admission.json") {if (digest!=a) exit 1; admissions++}
       if (path=="terminal.json") {if (digest!=t) exit 1; terminals++}
       print "./" path}
      END {if (admissions!=1 || terminals!=1) exit 1}' "$manifest" > "$evidence/admission-closure.paths" || die 'admission closure roster'
    sort "$evidence/admission-closure.paths" > "$evidence/admission-closure.sorted"
    (cd "$admission_dir" && find . -type l -print) > "$evidence/admission-closure.symlinks"
    [[ ! -s $evidence/admission-closure.symlinks ]] || die 'admission closure symlink'
    (cd "$admission_dir" && find . -type f ! -path ./closure.sha256 ! -path ./wrapper.exit -print | sort) > "$evidence/admission-closure.actual"
    cmp "$evidence/admission-closure.sorted" "$evidence/admission-closure.actual"
    (cd "$admission_dir" && sha256sum --check --strict --status "$manifest") || die 'admission closure body hashes'
    jq -e --arg recipe "$recipe_sha" --arg admission "$admission_sha" --arg terminal "$terminal_sha" \
      --arg manifest "$manifest_sha" --arg wrapper "$wrapper_sha" --slurpfile t "$terminal" "$JQ_TYPES
      keys_are([\"schema\",\"status\",\"recipe_sha256\",\"config_sha256\",\"admission_sha256\",\"terminal_sha256\",\"manifest_sha256\",\"wrapper_exit_sha256\",\"unit\",\"invocation_id\",\"control_group\",\"manager_show\",\"outer_exit_file\",\"drain_events\",\"actual_outer_exit\",\"populated_zero\"]) and
      .schema==\"borsuk-native-pid128-outer-closure-v1\" and .status==\"CLOSED\" and
      .recipe_sha256==\$recipe and .config_sha256==\$t[0].config_sha256 and
      .admission_sha256==\$admission and .terminal_sha256==\$terminal and .manifest_sha256==\$manifest and .wrapper_exit_sha256==\$wrapper and
      (.unit|type==\"string\" and test(\"^borsuk-pid128-observer-[a-z0-9-]+\\\\.service$\")) and
      (.invocation_id|type==\"string\" and test(\"^[0-9a-f]{32}$\")) and .control_group==(\"/system.slice/\"+.unit) and
      ([.manager_show,.outer_exit_file,.drain_events]|all(.[];art and .bytes<=65536)) and
      .actual_outer_exit==0 and .populated_zero==true" "$outer" > "$evidence/admission-outer.validated"
    for key in manager_show outer_exit_file drain_events; do
        path=$(jq -er ".$key.path" "$outer")
        [[ $path == "$campaign_evidence_root/"* && $path != "$admission_dir/"* ]] || die 'external closure proof location'
        auth_art "$(jq -c ".$key" "$outer")" > "$evidence/admission-outer-$key.identity"
    done
    raw_manager=$(jq -er .manager_show.path "$outer")
    raw_exit=$(jq -er .outer_exit_file.path "$outer")
    raw_events=$(jq -er .drain_events.path "$outer")
    outer_unit=$(jq -er .unit "$outer"); outer_id=$(jq -er .invocation_id "$outer"); outer_cg=$(jq -er .control_group "$outer")
    one_object "$admission_dir/observer.identity.json" 65536
    jq -e --arg id "$outer_id" --arg cg "$outer_cg" '
      keys==["control_group","invocation_id","schema"] and
      .schema=="borsuk-native-pid128-observer-identity-v1" and
      .invocation_id==$id and .control_group==$cg' "$admission_dir/observer.identity.json" \
        > "$evidence/admission-observer-identity.validated"
    for key in initial before-admission final; do
        jq -es --arg path "/sys/fs/cgroup$outer_cg" \
            'length>0 and .[0].path==$path' "$admission_dir/observer.$key" \
            > "$evidence/admission-observer-$key.validated"
    done
    awk -F= -v unit="$outer_unit" -v id="$outer_id" -v cg="$outer_cg" '
      $1=="Id" {if ($2!=unit || seen[$1]++) bad=1}
      $1=="Description" {if ($2!=unit || seen[$1]++) bad=1}
      $1=="InvocationID" {if ($2!=id || seen[$1]++) bad=1}
      $1=="ControlGroup" {if ($2!=cg || seen[$1]++) bad=1}
      $1=="Result" {if ($2!="success" || seen[$1]++) bad=1}
      $1=="ExecMainCode" {if ($2!="1" || seen[$1]++) bad=1}
      $1=="ExecMainStatus" {if ($2!="0" || seen[$1]++) bad=1}
      END {if (bad || length(seen)!=7) exit 1}' "$raw_manager" || die 'original observer manager failure'
    [[ $(stat -c %s "$raw_exit") == 2 && $(< "$raw_exit") == 0 ]] || die 'actual enclosing observer exit'
    awk '$1=="populated" {if (NF!=2 || $2!="0" || n++) bad=1} END {if (bad || n!=1) exit 1}' \
        "$raw_events" || die 'observer drain evidence'
}
