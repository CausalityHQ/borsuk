payload_fs_device=$(stat -c %d -- "$ROOT") || die 'payload filesystem identity unavailable'
evidence_fs_device=$(stat -c %d -- "$campaign_evidence_root") || die 'evidence filesystem identity unavailable'
[[ $payload_fs_device =~ ^[0-9]+$ && $evidence_fs_device == "$payload_fs_device" ]] || die 'payload and evidence must share filesystem'
