readonly JQ_TYPES='def keys_are($k): type=="object" and keys==($k|sort);
 def uint: type=="number" and .>=0 and .<=9007199254740991 and floor==.;
 def sha: type=="string" and test("^[0-9a-f]{64}$");
 def art: keys_are(["path","bytes","sha256"]) and (.path|type=="string" and startswith("/")) and (.bytes|uint and .>0) and (.sha256|sha);'
