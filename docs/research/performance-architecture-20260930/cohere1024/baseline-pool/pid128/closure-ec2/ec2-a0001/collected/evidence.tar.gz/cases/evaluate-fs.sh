set -Eeuo pipefail
source "$1/functions.sh"
ROOT=$2/payload; campaign_evidence_root=$2/evidence
source "$1/filesystem-guard.sh"
