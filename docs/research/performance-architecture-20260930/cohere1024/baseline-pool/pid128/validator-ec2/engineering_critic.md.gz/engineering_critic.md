**Do not launch these wrappers yet.** I found three blockers and three smaller corrections.

1. **[P1] The Ubuntu 24.04 dependency installation fails.**  
   [worker.sh:37](/tmp/borsuk-pid128-validator-ec2/worker.sh:37) installs `awscli` through APT, but Noble’s release archive has no such package. This stops execution before the cases; the exit handler also depends on the missing tools. Ubuntu’s [package search](https://packages.ubuntu.com/search?keywords=awscli&searchon=names&suite=noble&section=all) and publication records confirm the omission. Install an authenticated, pinned AWS CLI v2 distribution and verify its API model before running cases. Conditional S3 writes require **2.17.34 or later**, according to the [upstream changelog](https://raw.githubusercontent.com/aws/aws-cli/2.17.34/CHANGELOG.rst).

2. **[P1] Immediate instance discovery can abandon cleanup.**  
   [watch.sh:18](/tmp/borsuk-pid128-validator-ec2/watch.sh:18) makes one `DescribeInstances` call and immediately requires an EBS mapping. A propagation delay exits into a trap that attempts termination once, without waiting for termination or checking volume deletion. AWS explicitly warns that both discovery and termination can return `InvalidInstanceID.NotFound` immediately after launch—and that this does **not** establish termination. Use bounded discovery retries and route early failures through the same verified cleanup path. [AWS eventual-consistency guidance](https://docs.aws.amazon.com/ec2/latest/devguide/eventual-consistency.html)

3. **[P1] The worker can archive evidence while tests still run.**  
   [worker.sh:71](/tmp/borsuk-pid128-validator-ec2/worker.sh:71) sets `RuntimeMaxSec=120` but leaves the stop timeout unspecified. A process ignoring SIGTERM can remain alive during systemd’s default 90-second stop grace. At 135 seconds, [line 79](/tmp/borsuk-pid128-validator-ec2/worker.sh:79) exits directly into `finish()`, bypassing the stop/drain checks. The archive can therefore contain changing files and an interim service result—or fail to upload entirely. Set a short explicit `TimeoutStopSec` and make every failure path stop, drain and capture the definitive result before packaging. [Service semantics](https://manpages.ubuntu.com/manpages/noble/man5/systemd.service.5.html), [default timeout](https://manpages.ubuntu.com/manpages/noble/man5/systemd-system.conf.5.html)

4. **[P2] The stated deadline arithmetic omits material work.**  
   [watch.sh:23](/tmp/borsuk-pid128-validator-ec2/watch.sh:23) starts its 900-second clock after discovery. Poll overshoot, the termination request, two subsequent describe calls, and timeout kill grace sit outside `900 + 180 + 60`. A late terminal can push the permitted path beyond 1,200 seconds before local processing. Likewise, [campaign.pending.md:15](/tmp/borsuk-pid128-validator-ec2/campaign.pending.md:15)’s $0.025 compute allowance buys exactly 900 seconds at $0.10/hour, leaving no launch/discovery/request margin. Anchor the termination deadline to the launch receipt, reserve cleanup time, and calculate the independent service limit from the complete path.

5. **[P2] Download limits are checked after the downloads.**  
   [watch.sh:40](/tmp/borsuk-pid128-validator-ec2/watch.sh:40) downloads both objects before validating terminal size or the advertised archive size. An oversized object consumes root disk and transfer allowance before rejection. Check terminal `ContentLength` first, download and validate it, then check archive metadata against its declared size and the 16 MiB ceiling. Bind downloads to the observed version or ETag; retain the existing hash and actual-size checks.

6. **[P2] One volume lookup can reject otherwise successful cleanup.**  
   [watch.sh:37](/tmp/borsuk-pid128-validator-ec2/watch.sh:37) requires immediate `InvalidVolume.NotFound`. If deletion remains in progress, the watcher exits and skips evidence collection. Poll deletion within the cleanup deadline, distinguishing “still present” from API errors. Collect available evidence even when closure remains INVALID.

The normal service-result path is materially better: `RemainAfterExit=yes`, retained failed units, and capture before `stop` avoid the ordinary garbage-collection race. It also reads `ExecMainStatus` instead of treating asynchronous `systemd-run` success as test success. [systemd retention rules](https://manpages.ubuntu.com/manpages/noble/man5/systemd.unit.5.html)

The collector’s zero exit establishes **collection only**: it does not validate terminal status, phase or exit fields. Preserve that distinction when accepting the nine-case result. The synthetic-only and separate-r3 claims are appropriately narrow.

Reviewed hashes: worker `e9e535c9740e…`, watcher `2dc276014aa1…`, campaign `ea8b7d5c7e92…`. No files edited or experiments run. Launch assembly, IAM/network configuration, and actual EC2 execution remain unverified.
