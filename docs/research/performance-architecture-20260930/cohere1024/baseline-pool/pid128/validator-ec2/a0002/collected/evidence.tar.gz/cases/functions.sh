die() { printf 'INVALID: %s\n' "$*" >&2; exit 98; }
canonical() {
    [[ $1 == /* && $1 != *[$'\t\r\n\\']* && $(realpath -e -- "$1") == "$1" ]] || die "noncanonical: $1"
}
small_json() {
    canonical "$1"
    [[ -f $1 && ! -L $1 ]] || die 'JSON regular file'
    local bytes; bytes=$(stat -c %s -- "$1")
    (( bytes > 0 && bytes <= 65536 )) || die "JSON cap: $1"
    one_object "$1" 65536
}
one_object() {
    local path=$1 cap=$2 bytes
    canonical "$path"
    [[ -f $path && ! -L $path ]] || die 'JSON object regular file'
    bytes=$(stat -c %s -- "$path")
    (( bytes > 0 && bytes <= cap )) || die 'JSON object byte cap'
    jq -es 'length==1 and (.[0]|type=="object")' "$path" >/dev/null || die 'exactly one JSON object required'
}
sha_of() { local digest; digest=$(sha256sum < "$1"); printf '%s\n' "${digest%% *}"; }
authenticate() {
    local path=$1 bytes=$2 sha=$3 stamp
    canonical "$path"
    [[ -f $path && ! -L $path && $bytes =~ ^[1-9][0-9]*$ && $sha =~ ^[0-9a-f]{64}$ ]] || die "file pin: $path"
    stamp=$(stat -c '%d:%i:%s:%y:%z' -- "$path")
    [[ $(stat -c %s -- "$path") == "$bytes" && $(sha_of "$path") == "$sha" && $(stat -c '%d:%i:%s:%y:%z' -- "$path") == "$stamp" ]] || die "identity drift: $path"
    jq -cn --arg path "$path" --argjson bytes "$bytes" --arg sha256 "$sha" --arg stamp "$stamp" \
        '{path:$path,bytes:$bytes,sha256:$sha256,stamp:$stamp}'
}
validate_result() {
    local result=$1 native_config=$2 count=$3 dir=$4 bytes prefix_bytes sealed_bytes prefix_sha sealed_sha actual seal_line records
    canonical "$result"
    small_json "$native_config"
    bytes=$(stat -c %s -- "$result")
    (( bytes > 0 && bytes <= 67108864 )) || die 'native result byte cap'
    # Drop traces/timing payloads one record at a time: closure never calculates a performance metric.
    jq -c 'if .phase=="query" then {phase,ordinal,truth_opened,underfill,returned_count,returned}
      elif .phase=="recall" then {phase,ordinal,underfill,returned_count,hits10,recall10} else
      {phase,success,truth_opened,count,selected_count,population_count,requires_successful_sync,requires_successful_directory_sync,
       prefix_bytes,prefix_sha256,requests_sha256,generation_root_sha256,summary,
       binary_sha256,config_sha256,fetch_parallelism,execution,cohort_receipt_sha256,derivation_receipt_sha256,
       native_source_sha256,native_sq8_sha256,native_order_sha256,truth_sha256,producer_authority} end' "$result" > "$dir/result.closure-rows.jsonl"
    jq -es --argjson n "$count" --arg sha "$(sha_of "$native_config")" --slurpfile c "$native_config" '
      . as $r | $c[0] as $c |
      ([range(0;length)|select($r[.].phase=="all_queries_sealed")][0]) as $seal |
      ([.[]|select(.phase=="identity")]|length)==1 and .[0].phase=="identity" and .[0].config_sha256==$sha and
      .[0].binary_sha256=="59fe47aa1001b3ca24d1f9ff31444f97fcda72e3e297c8d7d846f5c3d811bfc3" and
      .[0].fetch_parallelism==$c.fetch_parallelism and .[0].execution==$c.execution and
      ([.[]|select(.phase=="bound_inputs")]|length)==1 and
      all(.[]|select(.phase=="bound_inputs"); .cohort_receipt_sha256==$c.cohort_receipt.sha256 and
        .derivation_receipt_sha256==$c.derivation_receipt.sha256 and .producer_authority==$c.producer_authority and
        .native_source_sha256==$c.native_source.source_sha256 and .native_sq8_sha256==$c.native_source.sq8_sha256 and
        .native_order_sha256==$c.native_source.source_order_sha256 and .requests_sha256==$c.requests.sha256 and
        .truth_sha256==$c.truth.sha256 and .generation_root_sha256==$c.generation_root_sha256) and
      ([.[]|select(.phase=="source_binding" and .success==true)]|length)==1 and
      ([.[]|select(.phase=="generation_open" and .success==true)]|length)==1 and
      ([.[]|select(.phase=="query")|.ordinal])==(if $n==1 then [0] else [range(0;32)] end) and
      all(.[]|select(.phase=="query"); .underfill==false and .returned_count==10 and .truth_opened==false and
        (.returned|length)==10 and ([.returned[].id]|unique|length)==10 and
        all(.returned[].id; type=="number" and floor==. and .>=0 and .<100000)) and
      ([.[]|select(.phase=="all_queries_sealed")]|length)==1 and
      ([$r[0:$seal][]|select(.phase=="query")]|length)==$n and
      ([$r[($seal+1):][]|.phase])==([range(0;$n)|"recall"]+["terminal"]) and
      ([$r[($seal+1):][]|select(.phase=="recall")|.ordinal])==(if $n==1 then [0] else [range(0;32)] end) and
      all($r[($seal+1):][]|select(.phase=="recall"); .underfill==false and .returned_count==10 and
        (.hits10|type=="number" and floor==. and .>=0 and .<=10) and .recall10==(.hits10/10)) and
      all($r[0:($seal+1)][]; .truth_opened==false) and
      $r[$seal].count==$n and $r[$seal].selected_count==$n and $r[$seal].population_count==32 and
      $r[$seal].requires_successful_sync==true and $r[$seal].requires_successful_directory_sync==true and
      ([.[]|select(.phase=="terminal")]|length)==1 and .[-1].phase=="terminal" and
      (.[-1].summary | .status=="MEASURED" and .complete==true and .queries==$n and .executed_count==$n and
        .selected_count==$n and .population_count==32 and .underfilled_queries==0 and .all_queries_sealed==true and
        .requests_sha256==$c.requests.sha256 and .truth_sha256==$c.truth.sha256 and
        .generation_root_sha256==$c.generation_root_sha256 and .execution==$c.execution and
        .population_percentiles_valid==false and .full_cohort_qualification==false and .physical_s3_measured==false and .external_gate_required==true and
        .prefix_bytes==$r[$seal].prefix_bytes and .prefix_sha256==$r[$seal].prefix_sha256)' \
        "$dir/result.closure-rows.jsonl" > "$dir/result.validated"
    jq -s '.[-1].summary' "$dir/result.closure-rows.jsonl" > "$dir/summary.json"
    prefix_bytes=$(jq -er .prefix_bytes "$dir/summary.json"); sealed_bytes=$(jq -er .sealed_bytes "$dir/summary.json")
    prefix_sha=$(jq -er .prefix_sha256 "$dir/summary.json"); sealed_sha=$(jq -er .sealed_sha256 "$dir/summary.json")
    [[ $prefix_bytes =~ ^[1-9][0-9]*$ && $sealed_bytes =~ ^[1-9][0-9]*$ && $prefix_sha =~ ^[0-9a-f]{64}$ && $sealed_sha =~ ^[0-9a-f]{64}$ ]] || die 'prefix seal shape'
    (( prefix_bytes < sealed_bytes && sealed_bytes < bytes )) || die 'seal bounds'
    # Parse ONE object per raw line with constant aggregate state, then bind offsets
    # to the actual seal line. Hashes at arbitrary interior byte positions do not suffice.
    jq -Rn 'reduce inputs as $line ({records:0,seals:0,seal_line:0};
      ($line|fromjson) as $row | if ($row|type)!="object" then error("JSONL object required") else
        .records+=1 | if $row.phase=="all_queries_sealed" then .seals+=1 | .seal_line=.records else . end end)
      | if .seals==1 then . else error("one seal line required") end' "$result" > "$dir/raw-record-boundaries.json"
    records=$(jq -er .records "$dir/raw-record-boundaries.json")
    seal_line=$(jq -er .seal_line "$dir/raw-record-boundaries.json")
    awk -v line="$seal_line" -v records="$records" -v bytes="$bytes" \
        -v prefix="$prefix_bytes" -v sealed="$sealed_bytes" '
      NR==line {before=total; after=total+length($0)+1; found++}
      {total+=length($0)+1}
      END {if (found!=1 || NR!=records || total!=bytes || before!=prefix || after!=sealed) exit 1;
           printf "prefix_bytes=%s sealed_bytes=%s records=%s final_newline=true\n",before,after,NR}' \
        "$result" > "$dir/seal-boundaries.validated" || die 'raw JSONL seal boundaries'
    actual=$(head -c "$prefix_bytes" "$result" | sha256sum); [[ ${actual%% *} == "$prefix_sha" ]] || die 'query prefix SHA'
    actual=$(head -c "$sealed_bytes" "$result" | sha256sum); [[ ${actual%% *} == "$sealed_sha" ]] || die 'durable seal SHA'
    jq -S . "$dir/summary.json" > "$dir/summary.sorted.json"
    one_object "$dir/native.stdout" 1048576
    jq -S . "$dir/native.stdout" > "$dir/stdout.sorted.json"
    cmp "$dir/summary.sorted.json" "$dir/stdout.sorted.json"
    authenticate "$result" "$bytes" "$(sha_of "$result")" > "$dir/result.identity"
}
