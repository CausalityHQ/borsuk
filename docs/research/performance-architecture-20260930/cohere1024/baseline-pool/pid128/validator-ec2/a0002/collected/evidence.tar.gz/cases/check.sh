set -Eeuo pipefail
export LC_ALL=C
evidence=$4
stage=fixture status=INVALID
source "$1"
validate_result "$2/result.jsonl" "$2/config.json" 1 "$3"
