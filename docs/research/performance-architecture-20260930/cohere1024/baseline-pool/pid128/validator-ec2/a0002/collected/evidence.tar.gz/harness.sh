#!/usr/bin/env bash
# Remote-only SOURCE UNVERIFIED fault checks; synthetic shape evidence, no ANN claim.
# shellcheck disable=SC2129 # Each append deliberately records a distinct JSONL phase.
# API: SHA-pinned recipe NEW_OUT. No native executable, corpus or truth is opened.
set -Eeuo pipefail
umask 077
export LC_ALL=C
recipe=${1:?}; out=${2:?}
[[ $# == 2 && $recipe == /* && $out == /* && ! -e $out && ! -L $out ]] || exit 125
[[ $(sha256sum "$recipe" | cut -d' ' -f1) == 3e63380b93320f00dd5888497cd582bc448b5954edce7b8349a66f2dadd5734d ]] || exit 125
mkdir "$out"
cp "$recipe" "$out/recipe.sh"
[[ $(sha256sum "$out/recipe.sh" | cut -d' ' -f1) == 3e63380b93320f00dd5888497cd582bc448b5954edce7b8349a66f2dadd5734d ]] || exit 125
recipe=$out/recipe.sh
for name in die canonical small_json one_object sha_of authenticate validate_result; do
    awk -v name="$name" 'index($0,name"() {")==1 {on=1;n++;single=($0!="" && substr($0,length($0),1)=="}")} on {print} on && ($0=="}" || single) {on=0;single=0} END {if(n!=1 || on) exit 1}' "$recipe" >> "$out/functions.sh"
done
# Run only extracted reviewed functions in an isolated subprocess. Never source recipe.
cat > "$out/check.sh" <<'EOF'
set -Eeuo pipefail
export LC_ALL=C
evidence=$4
stage=fixture status=INVALID
source "$1"
validate_result "$2/result.jsonl" "$2/config.json" 1 "$3"
EOF
zero=$(printf '%064d' 0)
mkdir "$out/base"
jq -n --arg z "$zero" '{fetch_parallelism:16,execution:{kind:"diagnostic",ordinal:0},cohort_receipt:{sha256:$z},derivation_receipt:{sha256:$z},producer_authority:{fixture:true},native_source:{source_sha256:$z,sq8_sha256:$z,source_order_sha256:$z},requests:{sha256:$z},truth:{sha256:$z},generation_root_sha256:$z}' > "$out/base/config.json"
config_sha=$(sha256sum "$out/base/config.json" | cut -d' ' -f1)
jq -cn --arg sha "$config_sha" --slurpfile c "$out/base/config.json" '{phase:"identity",truth_opened:false,config_sha256:$sha,binary_sha256:"59fe47aa1001b3ca24d1f9ff31444f97fcda72e3e297c8d7d846f5c3d811bfc3",fetch_parallelism:16,execution:$c[0].execution}' > "$out/base/result.jsonl"
jq -cn --slurpfile c "$out/base/config.json" '$c[0] as $c|{phase:"bound_inputs",truth_opened:false,cohort_receipt_sha256:$c.cohort_receipt.sha256,derivation_receipt_sha256:$c.derivation_receipt.sha256,producer_authority:$c.producer_authority,native_source_sha256:$c.native_source.source_sha256,native_sq8_sha256:$c.native_source.sq8_sha256,native_order_sha256:$c.native_source.source_order_sha256,requests_sha256:$c.requests.sha256,truth_sha256:$c.truth.sha256,generation_root_sha256:$c.generation_root_sha256}' >> "$out/base/result.jsonl"
printf '%s\n' '{"phase":"source_binding","success":true,"truth_opened":false}' '{"phase":"generation_open","success":true,"truth_opened":false}' >> "$out/base/result.jsonl"
jq -cn '{phase:"query",ordinal:0,truth_opened:false,underfill:false,returned_count:10,returned:[range(0;10)|{id:.}]}' >> "$out/base/result.jsonl"
prefix_bytes=$(stat -c %s "$out/base/result.jsonl")
prefix_sha=$(sha256sum "$out/base/result.jsonl" | cut -d' ' -f1)
jq -cn --argjson bytes "$prefix_bytes" --arg sha "$prefix_sha" '{phase:"all_queries_sealed",truth_opened:false,count:1,selected_count:1,population_count:32,requires_successful_sync:true,requires_successful_directory_sync:true,prefix_bytes:$bytes,prefix_sha256:$sha}' >> "$out/base/result.jsonl"
sealed_bytes=$(stat -c %s "$out/base/result.jsonl")
sealed_sha=$(sha256sum "$out/base/result.jsonl" | cut -d' ' -f1)
jq -cn '{phase:"recall",ordinal:0,underfill:false,returned_count:10,hits10:10,recall10:1}' >> "$out/base/result.jsonl"
jq -cn --slurpfile c "$out/base/config.json" --argjson p "$prefix_bytes" --arg ps "$prefix_sha" --argjson s "$sealed_bytes" --arg ss "$sealed_sha" '$c[0] as $c|{status:"MEASURED",complete:true,queries:1,executed_count:1,selected_count:1,population_count:32,underfilled_queries:0,all_queries_sealed:true,requests_sha256:$c.requests.sha256,truth_sha256:$c.truth.sha256,generation_root_sha256:$c.generation_root_sha256,execution:$c.execution,population_percentiles_valid:false,full_cohort_qualification:false,physical_s3_measured:false,external_gate_required:true,prefix_bytes:$p,prefix_sha256:$ps,sealed_bytes:$s,sealed_sha256:$ss}' > "$out/base/native.stdout"
jq -cn --slurpfile s "$out/base/native.stdout" '{phase:"terminal",summary:$s[0]}' >> "$out/base/result.jsonl"
passed=0
for case in positive missing_newline doubled_object recall_mismatch ordinal_mismatch underfill duplicate_id interior_offset multi_document_stdout; do
    dir=$out/$case; mkdir "$dir" "$dir/evidence"
    cp "$out/base/"* "$dir/"
    case $case in
      positive) ;;
      missing_newline) truncate -s -1 "$dir/result.jsonl" ;;
      doubled_object) sed -i '1s/$/{}/' "$dir/result.jsonl" ;;
      recall_mismatch) sed -i 's/"recall10":1/"recall10":0.9/' "$dir/result.jsonl" ;;
      ordinal_mismatch) sed -i '/"phase":"recall"/s/"ordinal":0/"ordinal":1/' "$dir/result.jsonl" ;;
      underfill) sed -i '/"phase":"query"/s/"underfill":false/"underfill":true/' "$dir/result.jsonl" ;;
      duplicate_id) sed -i '/"phase":"query"/s/"id":9/"id":0/' "$dir/result.jsonl" ;;
      interior_offset)
        # Keep the internally matched seal/summary hashes, but choose a byte inside a record.
        p=$((prefix_bytes-1)); ps=$(head -c "$p" "$dir/result.jsonl" | sha256sum | cut -d' ' -f1)
        jq -c --argjson p "$p" --arg ps "$ps" 'if .phase=="all_queries_sealed" then .prefix_bytes=$p|.prefix_sha256=$ps elif .phase=="terminal" then .summary.prefix_bytes=$p|.summary.prefix_sha256=$ps else . end' "$dir/result.jsonl" > "$dir/changed"
        mv "$dir/changed" "$dir/result.jsonl"
        jq -c --argjson p "$p" --arg ps "$ps" '.prefix_bytes=$p|.prefix_sha256=$ps' "$dir/native.stdout" > "$dir/changed"; mv "$dir/changed" "$dir/native.stdout" ;;
      multi_document_stdout) printf '%s\n' '{}' >> "$dir/native.stdout" ;;
    esac
    cp "$dir/native.stdout" "$dir/evidence/native.stdout"
    rc=0
    bash "$out/check.sh" "$out/functions.sh" "$dir" "$dir/evidence" "$dir/evidence" > "$dir/check.stdout" 2> "$dir/check.stderr" || rc=$?
    printf '%s\n' "$rc" > "$dir/check.exit"
    case $case in
      positive) ((rc==0)) || exit 1 ;;
      missing_newline|interior_offset)
        ((rc==98)) && grep -Fx 'INVALID: raw JSONL seal boundaries' "$dir/check.stderr" >/dev/null || exit 1 ;;
      multi_document_stdout)
        ((rc==98)) && grep -Fx 'INVALID: exactly one JSON object required' "$dir/check.stderr" >/dev/null || exit 1 ;;
      *) ((rc==1)) && grep -Fx false "$dir/evidence/result.validated" >/dev/null || exit 1 ;;
    esac
    passed=$((passed+1))
done
jq -n --argjson passed "$passed" '{status:"SYNTHETIC_VALIDATOR_CHECKS_ONLY",passed:$passed,native_executed:false,corpus_or_truth_opened:false,performance_claim:false,production_qualification:false}' > "$out/result.json"
sync -f "$out"
