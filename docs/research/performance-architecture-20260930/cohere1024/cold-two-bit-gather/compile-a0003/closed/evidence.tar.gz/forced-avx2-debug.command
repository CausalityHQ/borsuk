cargo test --locked -p borsuk --lib rotated_two_bit::tests::two_bit_gather_forced_avx2_and_checked_bounds -- --ignored --exact --test-threads=1
