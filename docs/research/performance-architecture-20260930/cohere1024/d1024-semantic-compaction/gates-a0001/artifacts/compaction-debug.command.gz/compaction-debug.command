env CARGO_BUILD_JOBS=1 cargo test --locked -p borsuk --lib two_bit_compaction::tests:: -- --test-threads=1
