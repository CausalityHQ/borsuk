env CARGO_BUILD_JOBS=1 cargo build --locked --release -p borsuk
