env CARGO_BUILD_JOBS=1 cargo test --locked -p borsuk --test two_bit_application_ids -- --test-threads=1
