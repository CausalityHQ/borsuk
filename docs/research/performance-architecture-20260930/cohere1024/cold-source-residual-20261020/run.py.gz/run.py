#!/usr/bin/env python3
import json,hashlib,pathlib,subprocess,os,signal,time,resource,struct,math,traceback,shutil,sys
E=pathlib.Path('/mnt/borsuk-workspace/evidence/csr-a0001')
OLD=pathlib.Path('/mnt/borsuk-workspace/evidence/fp32-concurrent-full1000-root-a0001')
BIN=pathlib.Path('/mnt/borsuk-workspace/evidence/fp32-concurrency-screen-root-a0001/bin')
RUN=BIN/'check_cohere_native_baseline'; READER=BIN/'compare_native_replay'
PERF=pathlib.Path('/mnt/borsuk-retained-root/usr/lib/linux-tools/7.0.0-1013-aws/perf')
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
def call(name,args,seconds,cap=False):
 with (E/(name+'.stdout')).open('xb') as o,(E/(name+'.stderr')).open('xb') as e:
  def limits():
   if cap:resource.setrlimit(resource.RLIMIT_FSIZE,(67108864,67108864))
  p=subprocess.Popen(args,stdout=o,stderr=e,start_new_session=True,preexec_fn=limits)
  timeout=False
  try:r=p.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(p.pid,signal.SIGTERM)
   try:r=p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);r=p.wait()
 write(E/(name+'.process.json'),dict(exit=r,timeout=timeout,argv=args))
 assert r==0 and not timeout,(name,r,timeout)
def prepare():
 assert not E.exists();E.mkdir()
 assert sha(RUN.read_bytes())=='afcbbfbd616d7c35aa29beb71968435f4b0e6142c526f11051796ccb21076648'
 assert sha(READER.read_bytes())=='cea18d35d66862cc4723d3c4b25aa8abe5bb2bc87e6577c5f2f9a6941d0fb545'
 assert pathlib.Path('/sys/devices/virtual/dmi/id/board_asset_tag').read_text().strip()=='i-0a91ae83b36498ae1'
 source=pathlib.Path('/mnt/borsuk-workspace/source-query-groups-native-a0001')
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD:crates'],text=True).strip()=='0f73631f67df77e20f186ffcdeaa27958c5aa3a1'
 pins={}
 for label,oldname in [('admit','admit-A'),('canary','canary-A'),('A1','admit-A'),('B1','admit-A'),('B2','admit-A'),('A2','admit-A')]:
  c=json.loads((OLD/(oldname+'-config.json')).read_bytes());ex=json.loads((OLD/(oldname+'-expected.json')).read_bytes())
  assert c['source_cache_bytes']==0 and c['max_active_queries']==1 and c['fetch_parallelism']==64 and c['semantic_leaf_limit']==64
  prefix=str(E/('scratch-'+label+'-')); n=len(c['scratch_parent'])-len(prefix);assert n>0
  c['scratch_parent']=prefix+'x'*n
  assert len(c['scratch_parent'])==len(json.loads((OLD/(oldname+'-config.json')).read_bytes())['scratch_parent'])
  write(E/(label+'-config.json'),c);ex['identity']['config_sha256']=sha((E/(label+'-config.json')).read_bytes())
  write(E/(label+'-expected.json'),ex)
  pins[label]=dict(config_sha256=ex['identity']['config_sha256'],expected_sha256=sha((E/(label+'-expected.json')).read_bytes()))
 write(E/'protocol.json',dict(schema='borsuk-cold-source-passive-profile-v1',main='edad92fb5d59995df2184e65a7b300739fe1648c',measurement_source='0cddd79569db2f92bf2079f1d9bbc3b90759a895',instance='i-0a91ae83b36498ae1',pins=pins,order=['admit','canary','A1','B1','B2','A2'],sample_hz=199,perf_event='cpu-clock:u',callgraph='dwarf,4096',max_perf_bytes_per_file=67108864,sequence='runtime native admission8 then separate canary2 then ABBA8',negative_control='same executable/config semantics, external sampling off/on',native_seconds=90,reader_seconds=45,outer_seconds=1200,cpu='0-7/800%',memory=8589934592,swap=0,limit='whole-process sampled user CPU, NOT exclusive SOURCE residual or latency. No new Rust instrumentation.',semantic='exact gold IDs, physical ordinals, scorebits, plans, traces, charges, canonical shortlist and independent f64 oracle',claims='application cache0; provider eviction unproven; no population p95 or vendor comparison'))
 print('PREPARED_6_CELLS_SAME_LENGTH_SCRATCH')
def run():
 protocol=json.loads((E/'protocol.json').read_bytes())
 assert sha(RUN.read_bytes())=='afcbbfbd616d7c35aa29beb71968435f4b0e6142c526f11051796ccb21076648'
 assert sha(READER.read_bytes())=='cea18d35d66862cc4723d3c4b25aa8abe5bb2bc87e6577c5f2f9a6941d0fb545'
 assert pathlib.Path('/sys/devices/virtual/dmi/id/board_asset_tag').read_text().strip()==protocol['instance']
 raw=(OLD/'gold-full1000.json').read_bytes();assert len(raw)==48684516 and sha(raw)=='ce13a10a30f0cbaafe2a8aaefdeea54a5e1118ed3bf812168d371d690c18f74c'
 gold=json.loads(raw);refs={q['ordinal']:q for q in gold['records']};assert list(refs)==list(range(1000))
 global query,truth,G,canonical,digests,oracle
 query=pathlib.Path('/mnt/borsuk-sq8-shortlist/inputs/queries.f32').read_bytes()
 truth=pathlib.Path('/mnt/borsuk-sq8-shortlist/inputs/truth.u64').read_bytes()
 assert sha(query)=='8460a81ff2f979deff7d82bede874a1301f47dfd3e4589305c9f53e020920d5e'
 assert sha(truth)=='0e38d943adaf62f197b98fe8b01b2edec2008010df760717ababfa5054693b7f'
 G=pathlib.Path('/mnt/borsuk-workspace/data/fp32-rerank-serving-real1m-a0001/generation')
 rootraw=(G/'manifest.json').read_bytes();assert sha(rootraw)==gold['generation_root_sha256']
 root=json.loads(rootraw);digests=(G/'canonical_row_digests.bin').read_bytes();assert sha(digests)==root['canonical']['row_digests_sha256']
 canonical=(G/'canonical.bin').open('rb');assert canonical.seek(0,2)==4104000000
 code=(OLD/'oracle-reused.py').read_bytes();assert sha(code)=='6a8f9e381ff11c6c9a1e6a6f40987cee155d7d9b8dcce36894194f2f4e807f2a'
 exec(compile(code,str(OLD/'oracle-reused.py'),'exec'),globals())
 # Self-check reused exact oracle on sealed historical rows before new native calls.
 oldrows=[json.loads(b) for b in (OLD/'admit-A.jsonl').read_bytes().splitlines()]
 for q in oldrows:
  if q.get('phase')=='query':oracle(q)
 call('tool-canary',[str(PERF),'record','-e','cpu-clock:u','-F','199','--call-graph','dwarf,4096','-o',str(E/'tool-canary.perf'),'--','/bin/true'],15,True)
 results={}
 for name in protocol['order']:
  cpath=E/(name+'-config.json');c=json.loads(cpath.read_bytes());ex=json.loads((E/(name+'-expected.json')).read_bytes());pin=protocol['pins'][name]
  assert sha(cpath.read_bytes())==pin['config_sha256'] and sha((E/(name+'-expected.json')).read_bytes())==pin['expected_sha256']
  scratch=pathlib.Path(c['scratch_parent']);scratch.mkdir();assert not any(scratch.iterdir())
  rawpath=E/(name+'.jsonl');args=[str(RUN),str(cpath),sha(cpath.read_bytes()),str(rawpath)]
  sampled=name.startswith('B')
  if sampled:args=[str(PERF),'record','-e','cpu-clock:u','-F','199','--call-graph','dwarf,4096','-m','128','-o',str(E/(name+'.perf')),'--']+args
  call(name+'-native',args,90,sampled)
  assert not any(scratch.iterdir())
  raw=rawpath.read_bytes();assert len(raw)<67108864 and raw.endswith(b'\n')
  rows=[json.loads(b) for b in raw.splitlines()];assert rows[:2]==[ex['identity'],ex['bound_inputs']]
  rc={'schema':'borsuk-completed-native-reduction-config-v4','input':{'path':str(rawpath),'bytes':len(raw),'sha256':sha(raw)},'expected_identity':ex['identity'],'expected_bound_inputs':ex['bound_inputs']}
  rcp=E/(name+'-reader-config.json');write(rcp,rc)
  call(name+'-reader',[str(READER),'--fp32-serving',str(rcp),sha(rcp.read_bytes()),str(E/(name+'-report.json'))],45)
  assert json.loads((E/(name+'-report.json')).read_bytes())['valid'] is True
  qs=[q for q in rows if q.get('phase')=='query'];assert [q['ordinal'] for q in qs]==c['execution']['ordinals']
  for q in qs:
   oracle(q);ref=refs[q['ordinal']]
   for k in ['returned','returned_physical_ordinals','plan','trace','charges']:assert q[k]==ref[k],(name,q['ordinal'],k)
   assert q['canonical_stage']['shortlist']==ref['canonical_shortlist']
  summary=rows[-1]['summary'];assert summary['complete'] and summary['all_queries_sealed'] and summary['status']=='MEASURED'
  hits=sum(len({h['id'] for h in q['returned']}&set(struct.unpack_from('<10Q',truth,q['ordinal']*80))) for q in qs);assert hits==summary['recall_numerator']
  results[name]={'queries':len(qs),'hits':hits,'native_exit':0,'strict_reader_exit':0,'gold_exact':True,'independent_oracle':True,'raw_sha256':sha(raw),'summary':summary}
  write(E/(name+'-verification.json'),results[name])
 write(E/'result.json',dict(status='VALID_PASSIVE_CURRENT_Q1_SELECTED8',results=results,performance_claim=False,exclusive_residual_identified=False))
if __name__=='__main__':
 if sys.argv[1:] == ['prepare']:prepare()
 else:
  try:run();write(E/'terminal.json',{'native_controller_exit':0,'status':'COMPLETE'})
  except BaseException:
   with (E/'failure.txt').open('x') as f:traceback.print_exc(file=f)
   raise

