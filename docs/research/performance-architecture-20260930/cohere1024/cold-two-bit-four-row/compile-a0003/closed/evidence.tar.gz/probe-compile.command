cargo test --locked --release -p borsuk --lib --no-run --message-format=json
