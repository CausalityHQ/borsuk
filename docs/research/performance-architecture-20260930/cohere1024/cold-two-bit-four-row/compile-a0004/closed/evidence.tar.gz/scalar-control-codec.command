env CARGO_TARGET_DIR=/mnt/borsuk-http/target-scalar-control cargo test --locked --features scalar-control -p borsuk --lib rotated_two_bit::tests:: -- --test-threads=1
