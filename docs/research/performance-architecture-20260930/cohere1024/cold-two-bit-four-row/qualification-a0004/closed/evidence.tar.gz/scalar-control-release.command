env CARGO_TARGET_DIR=/mnt/borsuk-http/target-scalar-control cargo test --locked --release --features scalar-control -p borsuk --lib --message-format=json rotated_two_bit::tests:: -- --test-threads=1
