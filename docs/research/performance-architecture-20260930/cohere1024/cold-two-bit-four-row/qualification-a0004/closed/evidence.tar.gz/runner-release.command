cargo test --locked --release -p borsuk --bin check_cohere_native_baseline -- --test-threads=1
