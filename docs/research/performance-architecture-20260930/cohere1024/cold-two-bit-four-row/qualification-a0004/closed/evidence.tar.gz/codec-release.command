cargo test --locked --release -p borsuk --lib rotated_two_bit::tests:: -- --test-threads=1
