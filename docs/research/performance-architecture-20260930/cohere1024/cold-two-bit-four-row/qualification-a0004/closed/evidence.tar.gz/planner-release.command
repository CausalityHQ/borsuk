cargo test --locked --release -p borsuk --lib two_bit_generation::source_walk_tests:: -- --test-threads=1
