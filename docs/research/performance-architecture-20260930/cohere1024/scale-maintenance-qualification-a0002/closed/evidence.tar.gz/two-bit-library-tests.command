cargo test --locked -p borsuk --lib two_bit_ -- --test-threads=1
