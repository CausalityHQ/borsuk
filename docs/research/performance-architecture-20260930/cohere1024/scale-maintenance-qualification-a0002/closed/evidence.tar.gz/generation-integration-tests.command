cargo test --locked -p borsuk --test two_bit_generation -- --test-threads=1
