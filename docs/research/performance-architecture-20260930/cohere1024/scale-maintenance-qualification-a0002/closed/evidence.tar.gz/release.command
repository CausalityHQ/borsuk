cargo build --release --locked -p borsuk --lib --bin publish_two_bit_generation --bin check_cohere_native_baseline
