sample_disk() {
    local label=$1 ns body
    body=$({
        printf 'label=%s\n' "$label"
        stat -f -c 'fs_block=%S blocks=%b free=%f avail=%a' -- "$scratch_root" || printf 'stat-f-failed rc=%s\n' "$?"
        for ns in "${scratch_ns[@]}"; do
            if [[ -e $ns ]]; then du -sb -- "$ns" || printf 'du-failed rc=%s %s\n' "$?" "$ns"; else printf 'absent %s\n' "$ns"; fi
        done
    } 2>&1)
    printf '%s\n' "$body" > "$evidence/disk.$label.txt"
}
