set -Eeuo pipefail
out=$1 sha=$2 name=$3 phase=$4 command=$5 carried=$6
source "$out/prefix.sh" "$out/invalid.json" "$sha" "$out/$name-evidence"
source "$out/cfg.sh"
source "$out/phases.sh"
source "$out/sample.sh"
scratch_root=$out; scratch_ns=()
if [[ $name == fixture-escaped ]]; then
 ROOT=$out
 controlled_negative_identity=$out/staging-escaped/native/descendant.identity
fi
whole_deadline=$((SECONDS+120)); manager_deadline=$((SECONDS+40))
source "$out/observer-init.sh"
jq -n --arg phase "$phase" '{phases:{($phase):{timeout_seconds:11}}}' > "$evidence/config.json"
run_phase "$phase" 1048576 /bin/bash -c "$command"
if [[ $carried == 0 || $carried == 2 || $carried == 3 ]]; then
 [[ $(require_clean_exits "$phase") == "$carried" ]] || die 'fixture native exit mismatch'
 completed+=("$phase"); verified=1; baseline_invoked=1; baseline_exit=$carried
 stage=canary_fixture_closed
 exit "$carried"
fi
require_success "$phase"
