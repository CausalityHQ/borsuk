set -eu
trap '' TERM
printf 'pid=%s\n' "$$" > "$1"
cat "/proc/$$/cgroup" >> "$1"
cat "/proc/$$/stat" > "$1.procstat"
# Exact logger-descriptor cleanup from the accepted r7 timeout descendant.
for ((fd=3;fd<64;fd++)); do eval "exec $fd>&-"; done
exec /bin/sleep 60
