#!/usr/bin/env bash
# SOURCE ONLY / RUNTIME UNVERIFIED. Repaired per-phase PID128 1M/Q32 gate:
# One native 1M/Q32 build gate: derive -> SQ8 full-copy stage -> generation -> LocalFileSystem publish -> Q32 baseline.
# Root owns the cgroup scope, config freeze, remote canary and run; this wrapper authenticates, runs one native
# process at a time (no retry, stop at first failure, nothing deleted) and retains every original exit/log/limit.
# The baseline output is opaque: it is never decoded, thresholded or interpreted here.

# shellcheck disable=SC2329 # EXIT trap invokes finish, which invokes owned cleanup.
set -Eeuo pipefail
set -o noclobber
umask 077
export LC_ALL=C

die() { printf 'INVALID: %s\n' "$*" >&2; exit 98; }
[[ $# == 3 ]] || die 'usage: CONFIG CONFIG_SHA NEW_EVIDENCE'
config=$1 config_sha=$2 evidence=$3

# Closed first-admission (04bccf4e) seals of the regenerated preparer outputs, the root-supplied derivation config
# (ea45653c) and the fixed 1M/Q32 cohort identity. The gate config must repeat them exactly.
readonly DERIVE_CONFIG_BYTES=1145
readonly DERIVE_CONFIG_SHA=2737d3e9e8b6c741bffd322e34b4ddf5aa8e318a8cfb4fafc00e262288b96a2d
readonly RESERVED_SHA=8460a81ff2f979deff7d82bede874a1301f47dfd3e4589305c9f53e020920d5e
readonly SEALS='{"corpus.f32":{"bytes":4096000000,"sha256":"1a491c060ec8b668b4983042dc1ac3971456327f41f28fd6fd2449df24cf3e38"},
 "queries.f32":{"bytes":131072,"sha256":"664f5b269756a1de5a77c4ec359e56ccbe85c87603fa01fc5d87cc3f02e52667"},
 "corpus.ids.jsonl":{"bytes":200873446,"sha256":"008191ae3103d78db682276008190cc858a361b19e487f6780c02cea5dd70067"},
 "queries.ids.jsonl":{"bytes":6200,"sha256":"e27fa2d4d0a22a4f9f4dbb9eb2aeeeb0681f48c7e2193e3aa57a2b49cb5ddeb4"},
 "truth.u64":{"bytes":2560,"sha256":"36e83267ebfe5efb86db28c778d18897563a8c6c0784933e2b8d6d05cf31bb93"}}'
readonly DATASET=CohereLabs/wikipedia-2023-11-embed-multilingual-v3
readonly REVISION=ade45fb52bd549f5e8c065636fe4160a43c2af36
readonly STORE_PREFIX=semantic/index # same LocalFileSystem layout the qualified preflight used
readonly BASELINE_MEMORY=536870912   # check_cohere_native_baseline MEMORY_CAP, unchanged

for tool in jq sha256sum stat realpath timeout tee head cmp sync sed awk cp mkdir prlimit find sort xargs du mountpoint tr systemctl systemd-run sleep env cat; do
    command -v "$tool" >/dev/null || die "missing $tool"
done
[[ -x /usr/bin/time && -x /usr/bin/dd && $config_sha =~ ^[0-9a-f]{64}$ ]] || die 'time/dd/config SHA'

canonical() {
    [[ $1 == /* && $1 != *[$'\t\r\n\\']* && $(realpath -e -- "$1") == "$1" ]] || die "noncanonical path: $1"
}
new_path() {
    [[ $1 != */ && ${1##*/} != . && ${1##*/} != .. && ! -e $1 && ! -L $1 ]] || die "occupied/invalid namespace: $1"
    canonical "${1%/*}"
    [[ -d ${1%/*} && $1 != *[$'\t\r\n\\']* ]] || die "namespace parent: $1"
}
(( EUID == 0 )) || die 'root-owned system-manager supervision required'
new_path "$evidence"
mkdir -- "$evidence"
stage=admission
failed_line=0
verified=0
baseline_exit=
baseline_invoked=0
signal_name=
completed=()
owned_unit='' owned_id='' owned_cg='' phase_dir='' observer_cg=''
finish() {
    local rc=$? status=INVALID wf=0 original signal=$signal_name cleanup=0
    original=$rc
    trap '' HUP INT TERM
    trap - EXIT ERR
    set +e
    # Cleanup precedes closure sealing and cannot be mistaken for native success.
    if [[ -n $owned_unit ]]; then cleanup_owned || cleanup=$?; fi
    if [[ -n $observer_cg && -f $evidence/observer.initial ]]; then
        snapshot "$observer_cg" "$evidence/observer.closure" || wf=1
        check_limits "$evidence/observer.closure" 268435456 1 0 || wf=1
        check_events "$evidence/observer.initial" "$evidence/observer.closure" || wf=1
    fi
    (( cleanup == 0 )) || wf=1
    # An explicit signal keeps 129/130/143 and its name. Otherwise only a fully closed chain may carry the baseline's own
    # exit (0, 2 or 3) out as the wrapper exit; every other raw status (jq, cmp, cp, redirection, ...) becomes 98 and is
    # retained separately as original_exit.
    if [[ -n $signal ]]; then
        :
    elif (( verified == 1 && rc == 0 )) && [[ $baseline_exit == 0 ]]; then
        status=NATIVE_CHAIN_CLOSED
    elif (( verified == 1 && (rc == 2 || rc == 3) )) && [[ $rc == "$baseline_exit" ]]; then
        status=BASELINE_NONZERO_EXIT
    else
        rc=98
    fi
    printf 'stage=%s line=%s original_exit=%s exit=%s signal=%s\n' "$stage" "$failed_line" "$original" "$rc" "$signal" \
        > "$evidence/closure.txt" || { wf=1; rc=98; }
    printf '%s\n' "$cleanup" > "$evidence/cleanup.exit" || wf=1
    (( wf == 0 )) || { status=INVALID; rc=98; }
    jq -n --arg status "$status" --arg stage "$stage" --argjson intended_exit "$rc" \
        --arg config_sha256 "$config_sha" --arg baseline_exit "$baseline_exit" --arg evidence "$evidence" \
        --argjson baseline_invoked "$baseline_invoked" --argjson original_exit "$original" --arg signal "$signal" \
        --argjson failed_line "$failed_line" \
        --args '{schema:"borsuk-native-scale-build-gate-local-v2",status:$status,stage:$stage,intended_exit:$intended_exit,
          original_exit:$original_exit,signal:(if $signal == "" then null else $signal end),failed_line:$failed_line,
          config_sha256:$config_sha256,baseline_native_exit:(if $baseline_exit == "" then null else ($baseline_exit|tonumber) end),
          phases_completed:$ARGS.positional,evidence:$evidence,
          wrapper_exit_scope:"intended_exit",actual_manager_and_outer_exit_required:true,
          scope:"local exact1M/Q32 derive, stage, generation, publish and baseline run; output opaque",
          baseline_invoked:($baseline_invoked == 1),actual_query_completion_requires_external_replay:true,
          instance_termination_verified:false,performance_claim:false}' \
        -- ${completed[@]+"${completed[@]}"} > "$evidence/terminal.json" || { wf=1; rc=98; }
    # Seal terminal and phase evidence; the later wrapper.exit is bound independently.
    (cd -- "$evidence" && find . -type f ! -path ./closure.sha256 ! -path ./wrapper.exit -print0 | sort -z | xargs -0 sha256sum --) \
        > "$evidence/closure.sha256" || { wf=1; rc=98; }
    sync -f "$evidence" || { wf=1; rc=98; }
    printf '%s\n' "$rc" > "$evidence/wrapper.exit" || { wf=1; rc=98; }
    (( wf == 0 )) || status=INVALID
    sync -f "$evidence" || { wf=1; rc=98; }
    (( wf == 0 )) || printf 'INVALID: evidence publication failed (original_exit=%s signal=%s)\n' "$original" "${signal:-none}" >&2
    # Root must require normal manager termination and the original outer wait exits, including write failures.
    exit "$rc"
}
trap finish EXIT
trap 'failed_line=$LINENO' ERR
trap 'signal_name=HUP; stage=signal-HUP; exit 129' HUP
trap 'signal_name=INT; stage=signal-INT; exit 130' INT
trap 'signal_name=TERM; stage=signal-TERM; exit 143' TERM
jq -n --args '$ARGS.positional' -- "$@" > "$evidence/invocation.json"

authenticate() {
    local path=$1 bytes=$2 expected=$3 stamp digest
    canonical "$path"
    [[ -f $path && ! -L $path && $bytes =~ ^[1-9][0-9]*$ && $expected =~ ^[0-9a-f]{64}$ ]] || die "regular pinned file: $path"
    stamp=$(stat -c '%d:%i:%s:%y:%z' -- "$path")
    [[ $(stat -c %s -- "$path") == "$bytes" ]] || die "length: $path"
    digest=$(sha256sum < "$path")
    [[ ${digest%% *} == "$expected" && $(stat -c '%d:%i:%s:%y:%z' -- "$path") == "$stamp" ]] || die "SHA/metadata drift: $path"
    jq -cn --arg path "$path" --argjson bytes "$bytes" --arg sha256 "$expected" --arg stamp "$stamp" \
        --argjson device "$(stat -c %d -- "$path")" --argjson inode "$(stat -c %i -- "$path")" \
        '{path:$path,bytes:$bytes,sha256:$sha256,stamp:$stamp,device:$device,inode:$inode}'
}

