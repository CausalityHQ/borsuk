def f32dec: . as $b
  | (($b / 8388608 | floor) % 256) as $e
  | ($b % 8388608) as $m
  | (if $b >= 2147483648 then -1 else 1 end) as $s
  | if $e == 255 then error("nonfinite f32")
    elif $e == 0 then $s * $m * pow(2; -149)
    else $s * ($m + 8388608) * pow(2; $e - 150) end;
def magbits: . as $a
  | if $a == 0 then 0
    elif $a < pow(2; -126) then $a * pow(2; 149)
    else ($a | log2 | floor) as $x | ($x + 127) * 8388608 + ($a / pow(2; $x) - 1) * 8388608 end;
def f32ok: . as $b | (f32dec) as $v
  | ((($v | fabs) | magbits) == ($b % 2147483648)) and ((($b >= 2147483648) == ($v < 0)) or ($v == 0));
[[1065353216,1],[3221225472,-2],[1,1.401298464324817e-45],[2139095039,3.4028234663852886e38]] |
all(.[]; . as $pair | ($pair[0]|f32dec)==$pair[1] and ($pair[0]|f32ok))
