cfg() { jq -er "$1" "$evidence/config.json"; }
