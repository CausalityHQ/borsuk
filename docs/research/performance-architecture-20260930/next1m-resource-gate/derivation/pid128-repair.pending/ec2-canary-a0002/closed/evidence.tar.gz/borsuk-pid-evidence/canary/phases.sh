# ---- one native process at a time -------------------------------------------------------------------------------
# Source-bound reuse of accepted r7 manager/ownership/drain/observation mechanics.
manager() {
    local remaining budget call rc
    remaining=$((manager_deadline-SECONDS))
    (( remaining >= 2 )) || { printf 'manager deadline exhausted\n' >&2; return 98; }
    budget=$((remaining-1)); (( budget <= 2 )) || budget=2
    call=$evidence/manager-calls/$(< /proc/sys/kernel/random/uuid)
    mkdir -- "$call" || return 98
    printf '%q ' "$@" > "$call/argv" || return 98
    printf 'timeout_seconds=%s kill_grace_seconds=1 total_deadline=%s\n' "$budget" "$manager_deadline" > "$call/deadline" || return 98
    # Applies only to the manager client; its timeout is not evidence of payload termination.
    if prlimit --core=0:0 --fsize=1048576:1048576 -- timeout --signal=TERM --kill-after=1 "$budget" "$@" > "$call/stdout" 2> "$call/stderr"; then rc=0; else rc=$?; fi
    printf '%s\n' "$rc" > "$call/exit" || return 98
    cat "$call/stdout" || return 98
    cat "$call/stderr" >&2 || return 98
    return "$rc"
}

# All controls are restricted to the same random unit, InvocationID and ControlGroup.
owned() {
    local invocation description control_group
    [[ -n $owned_unit && -n $owned_id && -n $owned_cg ]] || return 1
    invocation=$(manager systemctl show "$owned_unit" -p InvocationID --value) || return 1
    description=$(manager systemctl show "$owned_unit" -p Description --value) || return 1
    control_group=$(manager systemctl show "$owned_unit" -p ControlGroup --value) || return 1
    [[ $invocation == "$owned_id" && $description == "$owned_unit" &&
       $control_group == "${owned_cg#/sys/fs/cgroup}" ]]
}
drained() {
    [[ ! -e $owned_cg && ! -L $owned_cg ]] && return 0
    [[ -d $owned_cg && ! -L $owned_cg && -r $owned_cg/cgroup.events ]] || return 1
    local events
    events=$(cat "$owned_cg/cgroup.events") || return 1
    [[ $events == *'populated 0'* ]]
}
capture_owned_drain() {
    local dest=$1 rc=0 invocation description reported
    [[ -n $owned_unit && $owned_id =~ ^[0-9a-f]{32}$ &&
       $owned_cg == "/sys/fs/cgroup/system.slice/$owned_unit" && ! -L $owned_cg ]] || return 1
    if [[ -e $owned_cg ]]; then
        [[ -d $owned_cg && $(realpath -e "$owned_cg") == "$owned_cg" ]] || return 1
        cat "$owned_cg/cgroup.events" > "$dest" 2> "$dest.read.stderr" || rc=$?
        printf '%s\n' "$rc" > "$dest.read.exit" || return 1
        if ((rc==0)); then
            awk '$1=="populated" {if(NF!=2 || $2!="0" || n++) bad=1} END {if(bad || n!=1) exit 1}' "$dest" || return 1
            drain_state=empty
            return 0
        fi
    fi
    # A read failure is acceptable only as authenticated original-path removal.
    [[ ! -e $owned_cg && ! -L $owned_cg ]] || return 1
    invocation=$(manager systemctl show "$owned_unit" -p InvocationID --value) || return 1
    description=$(manager systemctl show "$owned_unit" -p Description --value) || return 1
    reported=$(manager systemctl show "$owned_unit" -p ControlGroup --value) || return 1
    [[ $invocation == "$owned_id" && $description == "$owned_unit" &&
       ( $reported == '' || $reported == "${owned_cg#/sys/fs/cgroup}" ) &&
       ! -e $owned_cg && ! -L $owned_cg ]] || return 1
    drain_state=removed
}
cleanup_owned() {
    local end cleanup_rc=0
    [[ -n $owned_unit ]] || return 0
    manager_deadline=$((SECONDS+40))
    if ! owned; then
        [[ ! -e $owned_cg && ! -L $owned_cg ]] || return 1
        capture_owned_drain "$phase_dir/cleanup.drain.events" || return 1
        jq -n --arg state "$drain_state" --arg path "$owned_cg" --arg id "$owned_id" \
          '{schema:"borsuk-native-pid128-payload-drain-v1",state:$state,path:$path,invocation_id:$id}' > "$phase_dir/cleanup.drain.json" || return 1
        manager systemctl stop "$owned_unit" > "$phase_dir/cleanup.stop.log" 2>&1
        local removed_stop_rc=$?
        printf '%s\n' "$removed_stop_rc" > "$phase_dir/cleanup.stop.exit" || return 1
        ((removed_stop_rc==0)) || return 1
        owned_unit='' owned_id='' owned_cg=''
        return 0
    fi
    snapshot "$owned_cg" "$phase_dir/resources.cleanup" || cleanup_rc=1
    manager systemctl kill --kill-whom=all --signal=TERM "$owned_unit" > "$phase_dir/cleanup.term.log" 2>&1
    printf '%s\n' "$?" > "$phase_dir/cleanup.term.exit" || cleanup_rc=1
    end=$((SECONDS+10)); (( end <= manager_deadline )) || end=$manager_deadline
    while ! drained && (( SECONDS < end )); do sleep 0.05; done
    if ! drained; then
        owned || return 1
        printf '1\n' > "$owned_cg/cgroup.kill" || return 1
        printf 'cgroup.kill=1\n' > "$phase_dir/cleanup.kill.txt" || cleanup_rc=1
    fi
    end=$manager_deadline
    while ! drained && (( SECONDS < end )); do sleep 0.05; done
    drained || return 1
    capture_owned_drain "$phase_dir/cleanup.drain.events" || return 1
    cleanup_drain_state=$drain_state
    jq -n --arg state "$cleanup_drain_state" --arg path "$owned_cg" --arg id "$owned_id" \
      '{schema:"borsuk-native-pid128-payload-drain-v1",state:$state,path:$path,invocation_id:$id}' > "$phase_dir/cleanup.drain.json" || cleanup_rc=1
    manager systemctl show "$owned_unit" > "$phase_dir/manager.cleanup.txt" || cleanup_rc=1
    manager systemctl stop "$owned_unit" > "$phase_dir/cleanup.stop.log" 2>&1
    local stop_rc=$?
    printf '%s\n' "$stop_rc" > "$phase_dir/cleanup.stop.exit" || cleanup_rc=1
    (( stop_rc == 0 )) || cleanup_rc=1
    owned_unit='' owned_id='' owned_cg=''
    return "$cleanup_rc"
}

snapshot() {
    local dir=$1 output=$2 name value
    local -a args
    while :; do
        args=(--arg path "$dir")
        for name in cpu.max cpuset.cpus.effective memory.max memory.swap.max pids.max pids.current pids.peak pids.events \
            memory.current memory.peak memory.events memory.swap.current memory.swap.peak memory.swap.events cgroup.events cgroup.threads cgroup.procs; do
            value=absent
            if [[ -r $dir/$name ]]; then value=$(< "$dir/$name") || return 1;
            elif [[ $dir != /sys/fs/cgroup ]]; then printf 'missing counter: %s/%s\n' "$dir" "$name" >&2; return 1; fi
            args+=(--arg "${name//./_}" "$value")
        done
        jq -cn "${args[@]}" '$ARGS.named' || return 1
        [[ $dir != /sys/fs/cgroup ]] || break
        dir=${dir%/*}
    done > "$output"
}
check_limits() {
    jq -es --argjson memory "$2" --argjson cores "$3" --arg cpus "$4" '
      def cap($k): [.[]|.[$k]|select(.!="absent" and .!="max")|tonumber]|min;
      (cap("memory_max")==$memory and cap("memory_swap_max")==0 and cap("pids_max")==128) and
      ([.[]|.cpu_max|select(.!="absent")|split(" ")|select(.[0]!="max")|(.[0]|tonumber)/(.[1]|tonumber)]|min)==$cores and
      .[0].cpuset_cpus_effective==$cpus and (.[0].memory_peak|tonumber)<=$memory and
      (.[0].memory_swap_current|tonumber)==0 and (.[0].memory_swap_peak|tonumber)==0 and
      (.[0].pids_peak|tonumber)<=128' "$1" > "$1.validated"
}
check_events() {
    jq -nes --slurpfile b "$1" --slurpfile a "$2" '
      def events: split("\n")|map(select(length>0)|split(" ")|{key:.[0],value:(.[1]|tonumber)})|from_entries;
      def limits: {path,cpu_max,cpuset_cpus_effective,memory_max,memory_swap_max,pids_max};
      ($a|length)==($b|length) and all(range(0;$a|length); . as $i |
        ($a[$i]|limits)==($b[$i]|limits) and $a[$i].pids_events==$b[$i].pids_events and
        (if $a[$i].memory_events=="absent" then $b[$i].memory_events=="absent" else
          ($a[$i].memory_events|events|{oom,oom_kill,oom_group_kill})==($b[$i].memory_events|events|{oom,oom_kill,oom_group_kill}) end) and
        (if $a[$i].memory_swap_current=="absent" then true else ($a[$i].memory_swap_current|tonumber)==0 and
          ($a[$i].memory_swap_peak|tonumber)==0 end))' > "$2.events-valid"
}

# Reused layered time/timeout/native/log-writer collection; each layer writes its own actual exit.
IFS= read -r -d '' INNER <<'EOF' || true
set -u -o noclobber
dir=$1 errfd=$2
shift 2
bash -c 'printf "%s\n" "$$" > "$1" || exit 98; shift; exec "$@"' _ "$dir/native.pid" "$@" 2>&"$errfd"
rc=$?
printf '%s\n' "$rc" > "$dir/native.exit" || exit 98
exit "$rc"
EOF
IFS= read -r -d '' OUTER <<'EOF' || true
set -u -o noclobber
inner=$1 dir=$2 errfd=$3 secs=$4
shift 4
timeout --signal=TERM --kill-after=10 "$secs" bash -c "$inner" _ "$dir" "$errfd" "$@"
rc=$?
printf '%s\n' "$rc" > "$dir/timeout.exit" || exit 98
exit "$rc"
EOF
IFS= read -r -d '' PAYLOAD <<'EOF' || true
set -u -o pipefail -o noclobber
umask 077
dir=$1 secs=$2 inner=$3 outer=$4
shift 4
printf '%s\n' "$$" > "$dir/ready" || exit 98
until [[ -f $dir/release ]]; do (( SECONDS < 30 )) || exit 98; sleep 0.05; done
exec {ef}> >(exec prlimit --core=0:0 --fsize=1048576:1048576 -- tee "$dir/native.stderr.txt" >/dev/null)
ep=$!
exec {sf}> >(exec prlimit --core=0:0 --fsize=1048576:1048576 -- tee "$dir/supervisor.stderr.txt" >/dev/null)
sp=$!
exec {tf}> >(exec prlimit --core=0:0 --fsize=1048576:1048576 -- tee "$dir/native.time.txt" >/dev/null)
tp=$!
/usr/bin/time -v -o "/dev/fd/$tf" bash -c "$outer" _ "$inner" "$dir" "$ef" "$secs" "$@" 2>&"$sf" |
    prlimit --core=0:0 --fsize=1048576:1048576 -- tee "$dir/native.stdout" >/dev/null
ps=("${PIPESTATUS[@]}")
printf '%s\n' "${ps[0]}" > "$dir/time.exit" || exit 98
printf '%s\n' "${ps[1]}" > "$dir/tee.exit" || exit 98
exec {tf}>&- {sf}>&- {ef}>&-
wait "$tp"; printf '%s\n' "$?" > "$dir/time-log.exit" || exit 98
wait "$sp"; printf '%s\n' "$?" > "$dir/supervisor-stderr-log.exit" || exit 98
wait "$ep"; printf '%s\n' "$?" > "$dir/native-stderr-log.exit" || exit 98
rc=98
if [[ -f $dir/native.exit && $(< "$dir/native.exit") =~ ^[0-9]+$ ]]; then
    native_rc=$(< "$dir/native.exit")
    if (( native_rc <= 255 )); then
        rc=$native_rc
        for f in timeout time; do
            [[ -f $dir/$f.exit && $(< "$dir/$f.exit") == "$native_rc" ]] || rc=98
        done
        for f in tee time-log supervisor-stderr-log native-stderr-log; do
            [[ -f $dir/$f.exit && $(< "$dir/$f.exit") == 0 ]] || rc=98
        done
    fi
fi
printf '%s\n' "$rc" > "$dir/payload.exit" || exit 98
printf 'done\n' > "$dir/done" || exit 98
end=$((SECONDS+30))
until [[ -f $dir/close ]]; do (( SECONDS < end )) || exit 98; sleep 0.05; done
exit "$rc"
EOF
mono_cs() { local up rest; read -r up rest < /proc/uptime; printf '%s\n' "${up/./}"; }
observe() {
    local end=$1 fd=$2 now previous gap pid=none tasks threads current peak line written=0 samples=0 membership procstat
    local -a task_paths
    previous=$(mono_cs)
    while [[ ! -f $phase_dir/done ]]; do
        now=$(mono_cs); gap=$((now-previous)); previous=$now
        (( now < end )) || die 'observer deadline; no retry'
        [[ -d $owned_cg ]] || die 'payload cgroup vanished before final counters'
        current=$(< "$owned_cg/pids.current"); peak=$(< "$owned_cg/pids.peak"); threads=$(< "$owned_cg/cgroup.threads")
        tasks=none
        membership=absent procstat=absent
        if [[ -f $phase_dir/native.pid ]]; then
            pid=$(< "$phase_dir/native.pid")
            [[ $pid =~ ^[1-9][0-9]*$ ]] || die 'native PID'
            if [[ -d /proc/$pid/task ]]; then
                if ! membership=$(< "/proc/$pid/cgroup"); then membership=exited; fi
                if ! procstat=$(< "/proc/$pid/stat"); then procstat=exited; fi
                if [[ $membership == "0::${owned_cg#/sys/fs/cgroup}" ]]; then
                    task_paths=(/proc/"$pid"/task/[0-9]*)
                    tasks=${task_paths[*]}
                else tasks='membership-gone'; fi
            else tasks=exited; fi
        fi
        printf -v line 'mono_cs=%s gap_cs=%s pids.current=%s pids.peak=%s native_pid=%s tasks=%s threads=%s membership=%s procstat=%s\n' \
            "$now" "$gap" "$current" "$peak" "$pid" "$tasks" "${threads//$'\n'/,}" "${membership//$'\n'/,}" "$procstat"
        written=$((written+${#line})); samples=$((samples+1))
        (( written <= 16777216 && samples <= 80000 )) || die 'observer evidence cap'
        printf '%s' "$line" >&"$fd"
        sleep 0.05
    done
    printf 'samples=%s bytes=%s cadence_ms=50 timestamps=proc_uptime_centiseconds\n' "$samples" "$written" > "$phase_dir/observer.txt"
}
run_phase() {
    local name=$1 cap=$2 secs memory cores cpus token manager_rc sample_fd end cg main f load_state native_rc expected_result
    shift 2
    secs=$(cfg ".phases.$name.timeout_seconds")
    [[ $cap == 1048576 ]] || die 'phase stdout cap must remain 1MiB'
    memory=8589934592; cores=4; cpus=0-3
    if [[ $name == baseline ]]; then memory=536870912; cores=1; cpus=0; fi
    stage=$name
    phase_dir=$evidence/phases/$name
    mkdir -- "$phase_dir"
    printf '%s\n' "$secs" > "$phase_dir/timeout.seconds"
    sample_disk "phase-$name-before"
    (( SECONDS + secs + 80 < whole_deadline )) || die 'phase cannot fit whole-stage deadline'
    manager_deadline=$((SECONDS+secs+80))
    jq -n --args '$ARGS.positional' -- "$@" > "$phase_dir/argv.json"
    printf 'environment=env-i PATH=/usr/bin:/bin LC_ALL=C HOME=/root\n' > "$phase_dir/environment.txt"
    token=$(< /proc/sys/kernel/random/uuid)
    owned_unit=borsuk-pid128-$token-$name.service
    load_state=$(manager systemctl show "$owned_unit" -p LoadState --value) || die 'unit existence response failed'
    [[ $load_state == not-found ]] || die 'unit already exists'
    printf '%s\n' "$owned_unit" > "$phase_dir/unit"
    set +e
    manager systemd-run --expand-environment=no --quiet --unit="$owned_unit" --description="$owned_unit" --service-type=exec \
        -p CPUQuota="$((cores*100))%" -p AllowedCPUs="$cpus" -p MemoryMax="$memory" -p MemorySwapMax=0 -p TasksMax=128 \
        -p KillMode=control-group -p OOMPolicy=continue -p TimeoutStopSec=10 -p RuntimeMaxSec="$((secs+80))" -p RemainAfterExit=yes \
        -p "BindsTo=${observer_relative##*/}" -p "After=${observer_relative##*/}" \
        /usr/bin/env -i PATH=/usr/bin:/bin LC_ALL=C HOME=/root /bin/bash -c "$PAYLOAD" _ "$phase_dir" "$secs" "$INNER" "$OUTER" "$@" \
        > "$phase_dir/manager.start.stdout" 2> "$phase_dir/manager.start.stderr"
    manager_rc=$?
    set -e
    printf '%s\n' "$manager_rc" > "$phase_dir/manager.start.exit"
    owned_id=$(manager systemctl show "$owned_unit" -p InvocationID --value)
    cg=$(manager systemctl show "$owned_unit" -p ControlGroup --value)
    [[ $owned_id =~ ^[0-9a-f]{32}$ && $cg == /system.slice/"$owned_unit" ]] || die 'manager ownership receipt'
    owned_cg=/sys/fs/cgroup$cg
    owned || die 'unit ownership mismatch'
    [[ $manager_rc == 0 ]] || die 'manager start failed'
    canonical "$owned_cg"
    [[ $owned_cg != "$observer_cg" && $owned_cg != "$observer_cg/"* && $observer_cg != "$owned_cg/"* ]] || die 'observer overlaps payload'
    end=$((SECONDS+20))
    until [[ -f $phase_dir/ready ]]; do (( SECONDS < end )) || die 'payload not ready'; sleep 0.05; done
    main=$(manager systemctl show "$owned_unit" -p MainPID --value)
    [[ $main == "$(< "$phase_dir/ready")" && $(< "/proc/$main/cgroup") == "0::$cg" ]] || die 'ready PID membership'
    manager systemctl show "$owned_unit" > "$phase_dir/manager.initial.txt"
    snapshot "$owned_cg" "$phase_dir/resources.initial"
    check_limits "$phase_dir/resources.initial" "$memory" "$cores" "$cpus"
    [[ -w $owned_cg/cgroup.kill ]] || die 'owned cgroup.kill unavailable'
    exec {sample_fd}> "$phase_dir/samples.txt"
    mono_cs > "$phase_dir/release.uptime_cs"
    printf 'release\n' > "$phase_dir/release"
    observe "$(( $(mono_cs) + (secs+15)*100 ))" "$sample_fd"
    exec {sample_fd}>&-
    if [[ -n ${controlled_negative_identity:-} ]]; then
        [[ $controlled_negative_identity == "$ROOT"/staging-*/native/descendant.identity &&
           -f $controlled_negative_identity && ! -L $controlled_negative_identity &&
           -f $controlled_negative_identity.procstat && ! -L $controlled_negative_identity.procstat &&
           $(< "$phase_dir/timeout.exit") =~ ^(124|137)$ ]] || die 'controlled timeout identity unavailable'
        child_pid=$(sed -n 's/^pid=//p' "$controlled_negative_identity")
        [[ $child_pid =~ ^[1-9][0-9]*$ && $(sed -n 's/^0:://p' "$controlled_negative_identity") == "${owned_cg#/sys/fs/cgroup}" ]] || die 'controlled descendant identity'
        cp "$controlled_negative_identity" "$phase_dir/child.identity"
        cp "$controlled_negative_identity.procstat" "$phase_dir/child.initial.procstat"
        cat "/proc/$child_pid/stat" > "$phase_dir/child.after-timeout.procstat"
        cat "/proc/$child_pid/cgroup" > "$phase_dir/child.after-timeout.cgroup"
        [[ $(< "$phase_dir/child.after-timeout.cgroup") == "0::${owned_cg#/sys/fs/cgroup}" ]] || die 'descendant no longer in original cgroup'
        child_start=$(awk '{s=$0;sub(/^[0-9]+ \(.*\) /,"",s);split(s,a," ");print a[20]}' "$phase_dir/child.initial.procstat")
        [[ $child_start =~ ^[1-9][0-9]*$ ]] || die 'descendant start time'
        awk -v pid="$child_pid" -v start="$child_start" '{n++; if(n!=1) exit 1; s=$0;sub(/^[0-9]+ \(.*\) /,"",s);split(s,a," ");
          if($1!=pid || a[1]!~/^(R|S|D)$/ || a[3]!=pid || a[4]!=pid || a[20]!=start) exit 1} END {if(n!=1) exit 1}' "$phase_dir/child.after-timeout.procstat" || die 'descendant not alive in separate session after timeout'
        mono_cs > "$phase_dir/child.witness.uptime_cs"
        jq -n --argjson pid "$child_pid" --arg start "$child_start" --arg cg "${owned_cg#/sys/fs/cgroup}" --arg id "$owned_id" \
          '{schema:"borsuk-native-pid128-timeout-witness-v1",pid:$pid,start_time_ticks:$start,control_group:$cg,invocation_id:$id,alive_after_timeout:true,separate_process_group_and_session:true}' > "$phase_dir/child.witness.json"
    fi
    snapshot "$owned_cg" "$phase_dir/resources.final"
    # Capture every original manager status before allowing the cgroup holder to exit.
    manager systemctl show "$owned_unit" > "$phase_dir/manager.before-close.txt"
    printf 'close\n' > "$phase_dir/close"
    end=$((SECONDS+30)); (( end <= manager_deadline )) || end=$manager_deadline
    until drained; do (( SECONDS < end )) || die 'owned descendants failed to drain'; sleep 0.05; done
    capture_owned_drain "$phase_dir/drain.events" || die 'original cgroup drain not authenticated'
    mono_cs > "$phase_dir/drain.uptime_cs"
    jq -n --arg state "$drain_state" --arg path "$owned_cg" --arg id "$owned_id" \
      '{schema:"borsuk-native-pid128-payload-drain-v1",state:$state,path:$path,invocation_id:$id}' > "$phase_dir/drain.json"
    # Empty cgroup can precede the manager's final execution fields. Preserve
    # ownership and wait inside the existing phase/manager deadline before stop.
    end=$((SECONDS+5)); (( end <= manager_deadline )) || end=$manager_deadline
    local original_manager_deadline=$manager_deadline
    manager_deadline=$end
    while :; do
        manager systemctl show "$owned_unit" >| "$phase_dir/manager.final.poll"
        [[ $(sed -n 's/^InvocationID=//p' "$phase_dir/manager.final.poll") == "$owned_id" &&
           $(sed -n 's/^Description=//p' "$phase_dir/manager.final.poll") == "$owned_unit" ]] || die 'manager final ownership changed'
        final_cg=$(sed -n 's/^ControlGroup=//p' "$phase_dir/manager.final.poll")
        [[ $final_cg == "${owned_cg#/sys/fs/cgroup}" ||
           ( $final_cg == '' && ! -e $owned_cg && ! -L $owned_cg ) ]] || die 'original terminal cgroup changed'
        if [[ $(sed -n 's/^MainPID=//p' "$phase_dir/manager.final.poll") == 0 &&
              $(sed -n 's/^ExecMainCode=//p' "$phase_dir/manager.final.poll") == 1 &&
              $(sed -n 's/^ActiveState=//p' "$phase_dir/manager.final.poll") =~ ^(active|failed)$ &&
              $(sed -n 's/^SubState=//p' "$phase_dir/manager.final.poll") =~ ^(exited|failed)$ ]]; then break; fi
        (( SECONDS < end )) || die 'manager terminal-state deadline'
        sleep 0.05
    done
    cp "$phase_dir/manager.final.poll" "$phase_dir/manager.final.txt"
    manager_deadline=$original_manager_deadline
    [[ $(sed -n 's/^InvocationID=//p' "$phase_dir/manager.final.txt") == "$owned_id" ]] || die 'manager invocation changed'
    set +e
    manager systemctl stop "$owned_unit" > "$phase_dir/manager.stop.log" 2>&1
    manager_rc=$?
    set -e
    printf '%s\n' "$manager_rc" > "$phase_dir/manager.stop.exit"
    [[ $manager_rc == 0 ]] || die 'manager stop failed'
    drained || die 'manager drain failed'
    owned_unit='' owned_id='' owned_cg=''
    # Record final resource checks before classifying an intended failed payload.
    check_limits "$phase_dir/resources.final" "$memory" "$cores" "$cpus"
    check_events "$phase_dir/resources.initial" "$phase_dir/resources.final"
    [[ -f $phase_dir/native.exit && $(< "$phase_dir/native.exit") =~ ^[0-9]+$ ]] || die "$name: missing/invalid original native exit"
    native_rc=$(< "$phase_dir/native.exit")
    (( native_rc <= 255 )) || die 'native exit range'
    expected_result=exit-code; (( native_rc != 0 )) || expected_result=success
    [[ $(sed -n 's/^Result=//p' "$phase_dir/manager.final.txt") == "$expected_result" &&
       $(sed -n 's/^ExecMainCode=//p' "$phase_dir/manager.final.txt") == 1 &&
       $(sed -n 's/^ExecMainStatus=//p' "$phase_dir/manager.final.txt") == "$native_rc" ]] || die 'manager/native original exit mismatch'
    for f in timeout time payload; do
        [[ -f $phase_dir/$f.exit && $(< "$phase_dir/$f.exit") == "$native_rc" ]] || die "$name: missing/mismatched $f exit"
    done
    for f in tee time-log supervisor-stderr-log native-stderr-log; do
        [[ -f $phase_dir/$f.exit && $(< "$phase_dir/$f.exit") == 0 ]] || die "$name: missing/nonzero $f exit"
    done
    awk -F ': ' -v cap="$((memory/1024))" '/Maximum resident set size \(kbytes\)/ {n++; if ($2<=0 || $2>cap) bad=1} END {exit(n!=1 || bad)}' "$phase_dir/native.time.txt"
    sample_disk "phase-$name-after"
}

exit_of() { # phase file -> numeric exit, refusing a missing/garbled receipt
    local file=$evidence/phases/$1/$2.exit
    [[ -f $file && ! -L $file ]] || die "phase $1: missing $2 exit"
    [[ $(< "$file") =~ ^[0-9]+$ ]] || die "phase $1: malformed $2 exit"
    printf '%s\n' "$(< "$file")"
}
require_clean_exits() { # phase [allowed native exit...]: stdout/log writers must be clean; supervisors mirror native
    local name=$1 native f
    native=$(exit_of "$name" native)
    for f in tee time-log supervisor-stderr-log native-stderr-log; do
        [[ $(exit_of "$name" "$f") == 0 ]] || die "phase $name: nonzero $f exit"
    done
    [[ $(exit_of "$name" timeout) == "$native" && $(exit_of "$name" time) == "$native" ]] || die "phase $name: supervisor exit differs from native"
    local rss_cap=8388608
    [[ $name != baseline ]] || rss_cap=524288
    awk -F ': ' -v cap="$rss_cap" '/Maximum resident set size \(kbytes\)/ {n++; if ($2 <= 0 || $2 > cap) bad=1}
        END {exit (n != 1 || bad)}' "$evidence/phases/$name/native.time.txt" || die "phase $name: GNU time RSS evidence"
    printf '%s\n' "$native"
}
finish_phase() {
    local name=$1
    resources "after-$name"
    resource_closure "after-$name" "$prev_label"
    prev_label=after-$name
    sample_disk "after-$name"
    completed+=("$name")
}
require_success() {
    [[ $(require_clean_exits "$1") == 0 ]] || die "phase $1: native exit nonzero"
}

