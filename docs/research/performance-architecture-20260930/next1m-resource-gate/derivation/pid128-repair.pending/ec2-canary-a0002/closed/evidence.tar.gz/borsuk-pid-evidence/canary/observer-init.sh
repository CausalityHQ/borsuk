observer_relative=$(sed -n 's/^0:://p' /proc/self/cgroup)
[[ $observer_relative =~ ^/system.slice/borsuk-pid128-observer-[a-z0-9-]+\.service$ && ${INVOCATION_ID:-} =~ ^[0-9a-f]{32}$ ]] || die 'bounded original observer service required'
observer_cg=/sys/fs/cgroup$observer_relative
canonical "$observer_cg"
mkdir -- "$evidence/manager-calls" "$evidence/phases"
jq -n --arg id "$INVOCATION_ID" --arg cg "$observer_relative" \
    '{schema:"borsuk-native-pid128-observer-identity-v1",invocation_id:$id,control_group:$cg}' > "$evidence/observer.identity.json"
snapshot "$observer_cg" "$evidence/observer.initial"
check_limits "$evidence/observer.initial" 268435456 1 0
