#!/usr/bin/env bash
set -Eeuo pipefail
config=$1 sha=$2 evidence=$3
mkdir "$evidence"
code=$(jq -er .exit "$config"); mode=$(jq -er .mode "$config")
cg=$(sed -n 's/^0:://p' /proc/self/cgroup)
[[ $INVOCATION_ID =~ ^[0-9a-f]{32}$ && $cg == /system.slice/borsuk-pid128-observer-* ]]
jq -n --arg cg "$cg" --arg id "$INVOCATION_ID" '{synthetic_metadata:true,invocation_id:$id,control_group:$cg}' > "$evidence/observer.identity.json"
jq -n --arg path "/sys/fs/cgroup$cg" '{path:$path,synthetic_metadata:true}' > "$evidence/observer.initial"
jq -n --arg sha "$sha" --argjson code "$code" '{schema:"borsuk-native-scale-build-gate-local-v2",synthetic_metadata:true,config_sha256:$sha,stage:"native_chain_closed",original_exit:$code,intended_exit:$code,baseline_native_exit:$code,baseline_invoked:true,signal:null,phases_completed:["derive","stage","generation","publish","baseline"],status:(if $code==0 then "NATIVE_CHAIN_CLOSED" else "BASELINE_NONZERO_EXIT" end),ann_executed:false,performance_claim:false}' > "$evidence/terminal.json"
printf '0\n' > "$evidence/cleanup.exit"
printf '%s\n' "$code" > "$evidence/wrapper.exit"
printf 'synthetic fixture; no phases or native program executed\n' > "$evidence/synthetic.txt"
if [[ $mode == descendant ]]; then
 /bin/sleep 60 </dev/null >/dev/null 2>&1 &
 child=$!
 printf '%s\n' "$child" > "$evidence/descendant.pid"
 cat "/proc/$child/cgroup" > "$evidence/descendant.cgroup"
 cat "/proc/$child/stat" > "$evidence/descendant.stat"
fi
(cd "$evidence"; find . -type f ! -name closure.sha256 ! -name wrapper.exit -print0 | sort -z | xargs -0 sha256sum) > "$evidence/closure.sha256"
if [[ $mode == deadline ]]; then exec /bin/sleep 60; fi
exit "$code"
