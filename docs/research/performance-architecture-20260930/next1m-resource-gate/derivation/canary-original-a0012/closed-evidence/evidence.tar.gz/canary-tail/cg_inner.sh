cg_inner () 
{ 
    set -Eeuo pipefail;
    local rel d name value key;
    local -a args;
    rel=$(sed -n 's/^0:://p' /proc/self/cgroup);
    [[ $rel == /system.slice/borsuk-canary-cgroup.service ]];
    d=/sys/fs/cgroup$rel;
    while :; do
        args=(--arg path "$d");
        for name in cpu.max cpuset.cpus.effective memory.max memory.swap.max pids.max memory.events pids.events;
        do
            value=absent;
            if [[ -r $d/$name ]]; then
                value=$(< "$d/$name");
            fi;
            key=${name//./_};
            args+=(--arg "$key" "$value");
        done;
        jq -cn "${args[@]}" '$ARGS.named';
        [[ $d != /sys/fs/cgroup ]] || break;
        d=${d%/*};
    done;
    sleep 300 > /dev/null 2>&1 & printf '%s\n' "$!" > "$1"
}
cg_inner "$1"
