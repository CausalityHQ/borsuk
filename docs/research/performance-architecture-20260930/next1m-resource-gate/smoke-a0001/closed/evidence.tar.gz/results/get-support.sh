get_support() {
 (ulimit -f 64; timeout -k 5 30 aws s3api get-object --bucket "$bucket" --key "$prefix/inputs/$1" "$1")
 [[ $(stat -c %s "$1") -le 65536 ]]
}
