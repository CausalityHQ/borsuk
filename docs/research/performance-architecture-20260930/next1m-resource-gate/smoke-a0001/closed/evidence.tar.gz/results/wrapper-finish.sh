finish() {
    local rc=$? status=INVALID
    trap '' HUP INT TERM
    trap - EXIT ERR
    set +e
    (( rc == 0 && verified == 1 )) && status=ADMISSION_VERIFIED
    [[ $status == ADMISSION_VERIFIED || $rc != 0 ]] || rc=98
    printf 'stage=%s line=%s exit=%s\n' "$stage" "$failed_line" "$rc" > "$evidence/closure.txt" || rc=98
    # Seal pre-status evidence; wrapper.exit and terminal.json record the later intent.
    (cd -- "$evidence" && for file in *; do
        [[ $file == closure.sha256 ]] || sha256sum -- "$file" || exit 98
    done) > "$evidence/closure.sha256" || rc=98
    sync -f "$evidence" || rc=98
    printf '%s\n' "$rc" > "$evidence/wrapper.exit" || rc=98
    (( rc == 0 )) || status=INVALID
    jq -n --arg status "$status" --arg stage "$stage" --argjson intended_exit "$rc" \
        --arg config_sha256 "$config_sha" --arg elf_sha256 "$elf_sha" --arg output "$output" \
        '{schema:"borsuk-actual-cohort-admission-local-v1",status:$status,stage:$stage,intended_exit:$intended_exit,
          config_sha256:$config_sha256,elf_sha256:$elf_sha256,output:$output,
          wrapper_exit_scope:"intended_exit",actual_manager_and_outer_exit_required:true,
          scope:"local exact1M/Q32 source, fresh truth, historical prefixes and resource closure only",
          publication_verified:false,instance_termination_verified:false,ann_run:false,performance_claim:false}' \
        > "$evidence/terminal.json" || rc=98
    # Root must require normal manager termination and original outer wait exits, including write failures.
    exit "$rc"
}
