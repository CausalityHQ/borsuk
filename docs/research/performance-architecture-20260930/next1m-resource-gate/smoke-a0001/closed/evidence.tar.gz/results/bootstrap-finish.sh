finish() {
 original=$?; trap - EXIT TERM INT HUP PIPE; set +e
 status=$original
 # Seal only after every owned service is inactive; stop failure leaves no success publication.
 for unit in borsuk-cohort-transport.service borsuk-cohort-parity.service; do
  state=$(timeout -k 2 10 systemctl show "$unit" -p ActiveState --value) || { shutdown -h now; exit 96; }
  if [[ $state == active || $state == activating || $state == deactivating ]]; then
   timeout -k 2 30 systemctl stop "$unit" || { shutdown -h now; exit 96; }
  fi
  state=$(timeout -k 2 10 systemctl show "$unit" -p ActiveState --value) || { shutdown -h now; exit 96; }
  [[ $state != active && $state != activating && $state != deactivating ]] || { shutdown -h now; exit 96; }
 done
 # Owned services have closed their inherited pipe writers before logger collection.
 exec >/dev/null 2>&1
 if [[ -n ${log_pid:-} ]]; then wait "$log_pid" || status=96; fi
 systemctl show borsuk-cohort-parity.service > evidence-root/systemd-after.txt 2>&1
 # Admit every quiesced evidence body before copying it.
 log_bytes=$(stat -c %s run.log) || { shutdown -h now; exit 96; }
 existing_bytes=$(du -sb evidence-root | awk '{print $1}') || { shutdown -h now; exit 96; }
 local_bytes=0
 if [[ -d evidence-local ]]; then local_bytes=$(du -sb evidence-local | awk '{print $1}') || { shutdown -h now; exit 96; }; fi
 [[ $log_bytes =~ ^[0-9]+$ && $existing_bytes =~ ^[0-9]+$ && $local_bytes =~ ^[0-9]+$ ]] || { shutdown -h now; exit 96; }
 extra_bytes=0
 for body in prepared-parent/cohort/complete.json prepared-parent/cohort/truth.u64 finalized-config.json; do
  if [[ -e $body || -L $body ]]; then
   [[ -f $body && ! -L $body ]] || { shutdown -h now; exit 96; }
   body_bytes=$(stat -c %s "$body") || { shutdown -h now; exit 96; }
   [[ $body_bytes =~ ^[0-9]+$ ]] || { shutdown -h now; exit 96; }
   (( body_bytes <= 33554432 )) || { shutdown -h now; exit 96; }
   extra_bytes=$((extra_bytes + body_bytes))
  fi
 done
 (( log_bytes + existing_bytes + local_bytes + extra_bytes + 65536 <= 33554432 )) || { shutdown -h now; exit 96; }
 cp support.sha256 evidence-root/support.sha256 || status=96
 cp run.log evidence-root/bootstrap.log || status=96
 printf '%s\n' "$original" > evidence-root/bootstrap.exit || status=96
 if [[ -d evidence-local ]]; then cp -a evidence-local evidence-root/ || status=96; fi
 if [[ -d prepared-parent/cohort && -f prepared-parent/cohort/complete.json ]]; then
  cp prepared-parent/cohort/complete.json evidence-root/native-complete.json || status=96
  cp prepared-parent/cohort/truth.u64 evidence-root/actual-truth.u64 || status=96
 fi
 if [[ -f finalized-config.json ]]; then cp finalized-config.json evidence-root/ || status=96; fi
 (cd evidence-root && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum) > artifacts.sha256 || status=96
 (ulimit -f 65536; tar -czf evidence.tar.gz -C evidence-root .) || { shutdown -h now; exit 96; }
 bytes=$(stat -c %s evidence.tar.gz); digest=$(sha256sum evidence.tar.gz); digest=${digest%% *}
 [[ $bytes -gt 0 && $bytes -le 67108864 ]] || { shutdown -h now; exit 96; }
 timeout -k 5 120 aws s3api put-object --bucket "$bucket" --key "$prefix/evidence.tar.gz" --body evidence.tar.gz --if-none-match '*' > evidence.put.json || status=96
 timeout -k 5 30 aws s3api put-object --bucket "$bucket" --key "$prefix/artifacts.sha256" --body artifacts.sha256 --if-none-match '*' > manifest.put.json || status=96
 jq -n --arg instance "$instance" --arg phase "$phase" --argjson original "$original" --argjson exit "$status" --arg sha "$digest" --argjson bytes "$bytes" \
 '{schema:"borsuk-actual-cohort-parity-closed-v1",instance_id:$instance,phase:$phase,original_exit:$original,exit:$exit,evidence:{bytes:$bytes,sha256:$sha},acceptance:"PROVISIONAL_REQUIRES_EXTERNAL_BOOTSTRAP_EXIT",publication_verified:false,performance_claim:false,ann_run:false}' > terminal.json || status=96
 timeout -k 5 30 aws s3api put-object --bucket "$bucket" --key "$prefix/terminal.json" --body terminal.json --if-none-match '*' || status=96
 printf '%s\n' "$status" > final.exit || { shutdown -h now; exit 96; }
 sync -f final.exit || { rm -f -- final.exit; shutdown -h now; exit 96; }
 # Preserve the original absolute machine shutdown schedule; never postpone it.
 exit "$status"
}
