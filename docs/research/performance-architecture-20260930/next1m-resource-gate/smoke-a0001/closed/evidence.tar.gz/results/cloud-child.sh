#!/usr/bin/env bash
set -Eeuo pipefail
src=$1; out=$2; mode=$3
root=/mnt/borsuk-scale1m
export PATH="$out/bin:$PATH" CASE_MODE=$mode
cd "$root"
touch ready
while [[ ! -e go ]]; do sleep .05; done
(
 source "$out/wrapper-finish.sh"
 evidence=$root/evidence-local; config_sha=fixture; elf_sha=fixture; output=fixture
 stage=fixture; failed_line=0; verified=1
 true; finish
)
source "$out/bootstrap-finish.sh"
phase=complete
case $mode in normal) instance=i-00000000000000001;; lost) instance=i-00000000000000002;; term) instance=i-00000000000000003;; esac
bucket=borsuk-bench-453182569524-euc1; prefix=research/mechanical-smoke
trap finish EXIT
true
