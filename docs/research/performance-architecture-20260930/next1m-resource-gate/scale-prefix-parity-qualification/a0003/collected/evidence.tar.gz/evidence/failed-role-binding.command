cargo test --locked -p borsuk --example compare_native_replay tests::scale_parity_role_aliases_and_native_config_reuse_are_refused -- --exact --test-threads=1
